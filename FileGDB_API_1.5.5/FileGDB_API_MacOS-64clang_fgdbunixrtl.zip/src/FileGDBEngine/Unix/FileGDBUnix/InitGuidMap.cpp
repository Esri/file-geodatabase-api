/*
 * This file contains helper functions for supporting GUIDS on Unix.
 *
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#include "FileGDBUnix.h"
#include "InitGUID.H"

extern std::map<LPCWSTR, GUID, GuidMapComp> g_GuidMap;

void InitGuidMap()
{
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriGeometryType", GUIDIFY(L"1b07791d-38c5-11d0-92d2-00805f7c28b0")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriShapeType", GUIDIFY(L"8448500f-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriShapeModifiers", GUIDIFY(L"9184f0da-1c3c-4cdc-8e1a-1d2548601928")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSegmentType", GUIDIFY(L"84485012-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriGeometryDimension", GUIDIFY(L"84485016-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriShapeExportFlags", GUIDIFY(L"cac13741-aaef-41e6-882d-6c0e4843df95")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriShapeImportFlags", GUIDIFY(L"5adf494f-934b-430d-8eb5-53d307e76c64")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSRGeoCSType", GUIDIFY(L"75b51d56-c5ba-11d1-bc92-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriProjectionHint", GUIDIFY(L"69999309-0802-4945-9618-03df2108ea79")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriTransformDirection", GUIDIFY(L"8448501b-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometryFactory", GUIDIFY(L"f71f8c16-ef07-11d0-8327-0000f8775be9")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry", GUIDIFY(L"1b07790d-38c5-11d0-92d2-00805f7c28b0")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry2", GUIDIFY(L"b79b2d7e-dbc8-11d3-9f60-00c04f6bdd7f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry3", GUIDIFY(L"d034f81b-7137-40a6-90ea-d88968c33e60")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry4", GUIDIFY(L"c4c70b7a-dfba-4892-86cd-a9100357409b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry5", GUIDIFY(L"134b247e-83f6-471c-9ad1-11c35312d5ef")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IESRIShape", GUIDIFY(L"7b91ff70-53a9-11d0-a8f3-00608c85ede5")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IESRIShape2", GUIDIFY(L"c90ee28c-01af-11d4-9f6c-00c04f6bdd7f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IRelationalOperator", GUIDIFY(L"1b07790e-38c5-11d0-92d2-00805f7c28b0")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnvelope", GUIDIFY(L"1b077914-38c5-11d0-92d2-00805f7c28b0")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnvelope2", GUIDIFY(L"6b256adf-1cde-11d4-9f5c-00c04f6bdf0d")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReferenceFactory", GUIDIFY(L"6cd10b60-c4f6-11d1-bc92-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReferenceInfo", GUIDIFY(L"4da0fe00-1dd2-11b2-bf49-08002022f573")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReference", GUIDIFY(L"4434d680-f4da-11d1-bca6-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReference2", GUIDIFY(L"3267d410-f5d9-11d3-9f69-00c04f6bdd7f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReference3", GUIDIFY(L"170572bf-545c-45a8-a45d-0d33c79441c7")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReferenceTolerance", GUIDIFY(L"587dc301-2766-4597-a3e5-9fa152329eb8")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeographicCoordinateSystem", GUIDIFY(L"40870d80-1dd2-11b2-bf4c-08002022f573")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeographicCoordinateSystem2", GUIDIFY(L"f78b2a38-89c4-11d4-9f9f-00c04f6bc8e8")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem", GUIDIFY(L"f94e4c00-1dd1-11b2-bf4e-08002022f573")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem2", GUIDIFY(L"a690307d-6c11-43a1-966a-9e8db0672033")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem3", GUIDIFY(L"d9b13c10-5c5e-11d5-9fee-00c04f6bdd7f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem4", GUIDIFY(L"d765fb6b-05d3-4398-86ac-79430de530e5")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem5", GUIDIFY(L"734e8d44-09b8-4796-8fb7-1985a32be7be")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IUnknownCoordinateSystem", GUIDIFY(L"b6ea1e3b-15e5-11d2-aacd-00c04fa33c20")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ITransformation", GUIDIFY(L"6f2cf924-7e00-11d0-82f4-0000f8034032")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IControlPrecision", GUIDIFY(L"ed4e18dd-ee33-11d3-9fef-00c04f6bc724")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IControlPrecision2", GUIDIFY(L"a1b0d8b3-474c-4fab-808e-0a3c5c498b1b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IESRISpatialReference", GUIDIFY(L"e78f2cd0-c9b2-11d1-bc93-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IESRISpatialReferenceGEN", GUIDIFY(L"f90e304c-a0f7-4a7d-9f62-25fd2a5c96af")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ICompareCoordinateSystems", GUIDIFY(L"75f37757-465c-43b1-afe8-8a4fdcb02839")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IUnit", GUIDIFY(L"0ae02580-1dd2-11b2-bf4a-08002022f573")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IAngularUnit", GUIDIFY(L"74ad43f0-d31c-11d1-bc9b-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriFieldType", GUIDIFY(L"4ca2d959-5a38-11d2-aabd-00c04fa37585")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSQLSpecialCharacters", GUIDIFY(L"18e2854c-edc8-11d2-aaef-00c04fa37849")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSQLFunctionName", GUIDIFY(L"18e2854b-edc8-11d2-aaef-00c04fa37849")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSQLPredicates", GUIDIFY(L"18e2854d-edc8-11d2-aaef-00c04fa37849")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSQLClauses", GUIDIFY(L"167034f3-0ca3-11d3-80a5-00c04f686238")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSpatialRelEnum", GUIDIFY(L"6b2072e1-23f7-11d1-89d8-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSchemaLock", GUIDIFY(L"ec0dc325-20dd-11d3-80b1-00c04f686238")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriFieldValueStatus", GUIDIFY(L"9606889b-c492-11d3-9f6b-00c04f6bddd9")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriEditDataChangesType", GUIDIFY(L"f4c53970-4e19-4a50-bdee-669d4c832681")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriDatasetFileStatAccessMode", GUIDIFY(L"4f69bd2e-ca3e-47dc-9801-a1678e710c02")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriConfigurationKeywordType", GUIDIFY(L"320bcae1-a626-4f6b-82a4-6a8dae3bad45")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriXMLIndexType", GUIDIFY(L"5b0bc26d-9919-4673-977a-6284cfaa8d4f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"rstResamplingTypes", GUIDIFY(L"0e9ae900-6c90-11d3-ab56-0008c73fca1c")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriRasterCompressionType", GUIDIFY(L"d044e70b-f632-4497-ae75-48a4f74033d1")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"fdoError", GUIDIFY(L"6f098201-b2d5-11d1-9ce6-0000f8780619")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"CoordRef", GUIDIFY(L"6e583d31-157a-4095-8a36-27c93ee95b54")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IDomain", GUIDIFY(L"df18fe0a-84ba-11d2-ab61-000000000000")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometryDef", GUIDIFY(L"439a0d50-3915-11d1-9ca7-0000f8780619")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometryDefEdit", GUIDIFY(L"439a0d51-3915-11d1-9ca7-0000f8780619")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometryDefImpl", GUIDIFY(L"b7a78cd5-79e2-46bc-9513-014c1ab2745b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IRasterStorageDef", GUIDIFY(L"30b9828a-85a6-4228-a7a4-7afb8a9842cc")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IRasterDef", GUIDIFY(L"cdba994f-8f18-4abe-8a39-502bed07265e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IRasterDef2", GUIDIFY(L"16c76984-e0e8-4112-80c9-e052c9b9c9d2")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IRasterValue", GUIDIFY(L"6b2d0243-7100-4e3f-aa02-5ec12daf6980")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IRasterDatasetNameEx", GUIDIFY(L"5f9195b9-d40d-4015-b0be-153d0d8e2c75")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IField", GUIDIFY(L"fcb01cb3-9f0b-11d0-bec7-00805f7c4268")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFieldEdit", GUIDIFY(L"300aa631-b207-11d0-beca-00805f7c4268")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IField2", GUIDIFY(L"f19f696b-f4f1-4066-9a7f-273754d9dc2a")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFieldEdit2", GUIDIFY(L"8bad0db3-a817-4dbb-9752-3faf6757e22c")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFieldImpl", GUIDIFY(L"76acaea7-2b36-11d4-a10d-00c04f6bdf0e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IModelInfo", GUIDIFY(L"2d660904-1dbd-11d3-9f87-00c04f6bdd84")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFields", GUIDIFY(L"6b2072e3-23f7-11d1-89d8-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFields2", GUIDIFY(L"c3eda031-6ec1-11d3-a024-00c04f6bdf0e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFieldsEdit", GUIDIFY(L"6b2072e4-23f7-11d1-89d8-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFieldsInfo", GUIDIFY(L"360c1b71-41e4-11d1-89db-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IIndex", GUIDIFY(L"2063fd01-4ce0-11d1-89db-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IIndexEdit", GUIDIFY(L"2063fd02-4ce0-11d1-89db-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IIndexes", GUIDIFY(L"2063fd03-4ce0-11d1-89db-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IIndexesEdit", GUIDIFY(L"2063fd04-4ce0-11d1-89db-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumIndex", GUIDIFY(L"23bd2b49-bf8b-11d2-aadd-00c04fa37849")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IXMLIndex", GUIDIFY(L"5240ceaa-366d-42ed-97fe-61dfb3c20248")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IXMLIndexEdit", GUIDIFY(L"537fc360-cc9b-4671-b155-07d141fe8d99")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFIDSet", GUIDIFY(L"d79bdaf1-caa8-11d2-b2be-0000f878229e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFIDSet2", GUIDIFY(L"6ebaadc0-7541-46a4-82d7-4842ec9b1e55")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFIDSetOperator", GUIDIFY(L"ed3c0c61-0c11-49e1-9d71-f3d2caff085f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumIDs", GUIDIFY(L"7d84b001-1521-11d2-89ed-006097aff44e")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISchemaLockInfo", GUIDIFY(L"a67958d8-226e-11d3-80b2-00c04f686238")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumSchemaLockInfo", GUIDIFY(L"a67958d7-226e-11d3-80b2-00c04f686238")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumSchemaLockInfoImpl", GUIDIFY(L"5de5f824-9561-4e0a-9c2c-a8864b3e66da")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumConfigurationParameter", GUIDIFY(L"75b1cca3-ee77-4a5f-8fcd-1775d6f9497b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IConfigurationKeyword", GUIDIFY(L"2be5da4c-7a75-4cc9-aa73-c0320b89846f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IConfigurationKeyword2", GUIDIFY(L"bbe02adf-ae75-4ea4-be73-fba83cc3ee10")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IConfigurationParameter", GUIDIFY(L"32bd0a83-25e5-4f24-b81b-5ebea2dfe35a")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IConfigurationParameter2", GUIDIFY(L"4eac0cf1-ee2a-405c-a18a-c588dc53a0e7")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumConfigurationKeyword", GUIDIFY(L"b055bbd8-de08-49cd-a589-fffd22112cd5")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IQueryFilter", GUIDIFY(L"fdfebd93-ed75-11d0-9a95-080009ec734b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialFilter", GUIDIFY(L"fdfebd94-ed75-11d0-9a95-080009ec734b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IQueryFilterFIDSet", GUIDIFY(L"4430bbbe-47b7-11d4-9f52-00c04f79927c")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFilterDef", GUIDIFY(L"8b67e76a-b7f8-4cdb-aca2-b647581bd9ea")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IFilterDefs", GUIDIFY(L"0fa04c6d-25bd-4fee-b9e7-1146219b102d")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IXMLFilterDef", GUIDIFY(L"0b308561-d65c-4256-9bf9-4363f7997f3b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IQueryFilterDefinition", GUIDIFY(L"90f3c7ca-30d5-454b-ab33-fb869991edfe")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IQueryFilterDefinition2", GUIDIFY(L"45096447-06ff-4e5e-a260-9213e009af29")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IQueryDef", GUIDIFY(L"97103d51-3a9e-11d1-8816-0000f877762d")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ICursor", GUIDIFY(L"d4803ee7-79f4-11d0-97fc-0080c7f79481")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumSpatialReferenceInfo", GUIDIFY(L"5f345e5f-4251-11d4-8145-00c04f686238")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISQLSyntax", GUIDIFY(L"18e2854e-edc8-11d2-aaef-00c04fa37849")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriGeometryType", GUIDIFY(L"1b07791d-38c5-11d0-92d2-00805f7c28b0")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriShapeType", GUIDIFY(L"8448500f-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriShapeModifiers", GUIDIFY(L"9184f0da-1c3c-4cdc-8e1a-1d2548601928")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSegmentType", GUIDIFY(L"84485012-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriGeometryDimension", GUIDIFY(L"84485016-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriShapeExportFlags", GUIDIFY(L"cac13741-aaef-41e6-882d-6c0e4843df95")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriShapeImportFlags", GUIDIFY(L"5adf494f-934b-430d-8eb5-53d307e76c64")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriSRGeoCSType", GUIDIFY(L"75b51d56-c5ba-11d1-bc92-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriProjectionHint", GUIDIFY(L"69999309-0802-4945-9618-03df2108ea79")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriTransformDirection", GUIDIFY(L"8448501b-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriGeometryError", GUIDIFY(L"84485021-9284-11d1-b987-080009ee4e51")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometryFactory", GUIDIFY(L"f71f8c16-ef07-11d0-8327-0000f8775be9")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry", GUIDIFY(L"1b07790d-38c5-11d0-92d2-00805f7c28b0")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry2", GUIDIFY(L"b79b2d7e-dbc8-11d3-9f60-00c04f6bdd7f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry3", GUIDIFY(L"d034f81b-7137-40a6-90ea-d88968c33e60")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry4", GUIDIFY(L"c4c70b7a-dfba-4892-86cd-a9100357409b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeometry5", GUIDIFY(L"134b247e-83f6-471c-9ad1-11c35312d5ef")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IESRIShape", GUIDIFY(L"7b91ff70-53a9-11d0-a8f3-00608c85ede5")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IESRIShape2", GUIDIFY(L"c90ee28c-01af-11d4-9f6c-00c04f6bdd7f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IRelationalOperator", GUIDIFY(L"1b07790e-38c5-11d0-92d2-00805f7c28b0")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnvelope", GUIDIFY(L"1b077914-38c5-11d0-92d2-00805f7c28b0")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnvelope2", GUIDIFY(L"6b256adf-1cde-11d4-9f5c-00c04f6bdf0d")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReferenceFactory", GUIDIFY(L"6cd10b60-c4f6-11d1-bc92-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReferenceInfo", GUIDIFY(L"4da0fe00-1dd2-11b2-bf49-08002022f573")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReference", GUIDIFY(L"4434d680-f4da-11d1-bca6-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReference2", GUIDIFY(L"3267d410-f5d9-11d3-9f69-00c04f6bdd7f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReference3", GUIDIFY(L"170572bf-545c-45a8-a45d-0d33c79441c7")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISpatialReferenceTolerance", GUIDIFY(L"587dc301-2766-4597-a3e5-9fa152329eb8")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeographicCoordinateSystem", GUIDIFY(L"40870d80-1dd2-11b2-bf4c-08002022f573")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IGeographicCoordinateSystem2", GUIDIFY(L"f78b2a38-89c4-11d4-9f9f-00c04f6bc8e8")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem", GUIDIFY(L"f94e4c00-1dd1-11b2-bf4e-08002022f573")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem2", GUIDIFY(L"a690307d-6c11-43a1-966a-9e8db0672033")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem3", GUIDIFY(L"d9b13c10-5c5e-11d5-9fee-00c04f6bdd7f")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem4", GUIDIFY(L"d765fb6b-05d3-4398-86ac-79430de530e5")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IProjectedCoordinateSystem5", GUIDIFY(L"734e8d44-09b8-4796-8fb7-1985a32be7be")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IUnknownCoordinateSystem", GUIDIFY(L"b6ea1e3b-15e5-11d2-aacd-00c04fa33c20")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ITransformation", GUIDIFY(L"6f2cf924-7e00-11d0-82f4-0000f8034032")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IControlPrecision", GUIDIFY(L"ed4e18dd-ee33-11d3-9fef-00c04f6bc724")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IControlPrecision2", GUIDIFY(L"a1b0d8b3-474c-4fab-808e-0a3c5c498b1b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IESRISpatialReferenceGEN", GUIDIFY(L"f90e304c-a0f7-4a7d-9f62-25fd2a5c96af")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ICompareCoordinateSystems", GUIDIFY(L"75f37757-465c-43b1-afe8-8a4fdcb02839")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IUnit", GUIDIFY(L"0ae02580-1dd2-11b2-bf4a-08002022f573")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IAngularUnit", GUIDIFY(L"74ad43f0-d31c-11d1-bc9b-0000f875bcce")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriArcGISVersion", GUIDIFY(L"73abea55-3bc9-47d4-95c1-defa1924de26")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"esriLockMgrType", GUIDIFY(L"583257c3-207d-11d3-b7dc-0000f878098d")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IClassID", GUIDIFY(L"9f9650f1-5f49-4041-ba0f-d10baff1d7bc")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IClone", GUIDIFY(L"9bff8aeb-e415-11d0-943c-080009eebecb")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IMessageLogger", GUIDIFY(L"57a048c7-dfb1-4bc7-b6df-24ef539373ea")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IBlobStream", GUIDIFY(L"bc92995e-e736-11d0-9a93-080009ec734b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IMemoryBlobStream", GUIDIFY(L"bc92995f-e736-11d0-9a93-080009ec734b")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IMemoryBlobStream2", GUIDIFY(L"5ce09f2c-9c93-4a3b-83ad-e12fb6a67ad4")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumBSTR", GUIDIFY(L"18a45ba8-1266-11d1-86ad-0000f8751720")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IEnumVariantSimple", GUIDIFY(L"0f0a3d86-8690-4d41-9df7-efefe99c4ec5")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IName", GUIDIFY(L"4ba33331-d55f-11d1-8882-0000f877762d")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IUnknown", GUIDIFY(L"00000000-0000-0000-c000-000000000046")));
}

extern "C" const GUID EXPORT IID_IUnknown =
    {0x00000000,0x0000,0x0000,{0xc0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
extern "C" const GUID EXPORT IID_IClassFactory =
    {0x00000001,0x0000,0x0000,{0xc0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
extern "C" const GUID EXPORT IID_ISupportErrorInfo =
    {0xDF0B3D60,0x548F,0x101B,{0x8E,0x65,0x08,0x00,0x2B,0x2B,0xD1,0x19}};
extern "C" const GUID EXPORT IID_IErrorInfo =
    {0x1CF2B120,0x547D,0x101B,{0x8E,0x65,0x08,0x00,0x2B,0x2B,0xD1,0x19}};


// global GUID definitions
extern "C" const GUID EXPORT IID_IClassID =
    {0x9f9650f1,0x5f49,0x4041,{0xba,0x0f,0xd1,0x0b,0xaf,0xf1,0xd7,0xbc}};
extern "C" const GUID EXPORT IID_IClone =
    {0x9bff8aeb,0xe415,0x11d0,{0x94,0x3c,0x08,0x00,0x09,0xee,0xbe,0xcb}};
extern "C" const GUID EXPORT IID_IEnumBSTR =
    {0x18a45ba8,0x1266,0x11d1,{0x86,0xad,0x00,0x00,0xf8,0x75,0x17,0x20}};
extern "C" const GUID EXPORT IID_IEnumVariantSimple =
    {0x0f0a3d86,0x8690,0x4d41,{0x9d,0xf7,0xef,0xef,0xe9,0x9c,0x4e,0xc5}};
extern "C" const GUID EXPORT IID_IBlobStream =
    {0xbc92995e,0xe736,0x11d0,{0x9a,0x93,0x08,0x00,0x09,0xec,0x73,0x4b}};
extern "C" const GUID EXPORT IID_IMemoryBlobStream =
    {0xbc92995f,0xe736,0x11d0,{0x9a,0x93,0x08,0x00,0x09,0xec,0x73,0x4b}};
extern "C" const GUID EXPORT IID_IMemoryBlobStream2 =
    {0x5ce09f2c,0x9c93,0x4a3b,{0x83,0xad,0xe1,0x2f,0xb6,0xa6,0x7a,0xd4}};

////////////////////////////////////////////////////////////////////////////////

extern "C" const GUID EXPORT CLSID_ESRIExtendedErrorInfo =
    {0x912de21a,0xd259,0x406a,{0xaa,0xff,0xa6,0xea,0x73,0xe2,0xac,0x05}};
extern "C" const GUID EXPORT CLSID_MessageLogger =
    {0xa2e96efd,0xd501,0x433b,{0x94,0x1f,0x83,0x44,0x79,0x16,0xb8,0xf6}};
extern "C" const GUID EXPORT CLSID_MemoryBlobStream =
    {0xbc929960,0xe736,0x11d0,{0x9a,0x93,0x08,0x00,0x09,0xec,0x73,0x4b}};

////////////////////////////////////////////////////////////////////////////////

extern "C" const GUID EXPORT IID_IGeometryFactory =
    {0xf71f8c16,0xef07,0x11d0,{0x83,0x27,0x00,0x00,0xf8,0x77,0x5b,0xe9}};

extern "C" const GUID EXPORT IID_ISpatialReferenceFactory =
    {0x6cd10b60,0xc4f6,0x11d1,{0xbc,0x92,0x00,0x00,0xf8,0x75,0xbc,0xce}};

extern "C" const GUID EXPORT IID_ISpatialReferenceInfo =
    {0x4da0fe00,0x1dd2,0x11b2,{0xbf,0x49,0x08,0x00,0x20,0x22,0xf5,0x73}};
extern "C" const GUID EXPORT IID_ISpatialReference =
    {0x4434d680,0xf4da,0x11d1,{0xbc,0xa6,0x00,0x00,0xf8,0x75,0xbc,0xce}};
extern "C" const GUID EXPORT IID_ISpatialReference2 =
    {0x3267d410,0xf5d9,0x11d3,{0x9f,0x69,0x00,0xc0,0x4f,0x6b,0xdd,0x7f}};
extern "C" const GUID EXPORT IID_ISpatialReference3 =
    {0x170572bf,0x545c,0x45a8,{0xa4,0x5d,0x0d,0x33,0xc7,0x94,0x41,0xc7}};

extern "C" const GUID EXPORT IID_IESRIShape =
    {0x7b91ff70,0x53a9,0x11d0,{0xa8,0xf3,0x00,0x60,0x8c,0x85,0xed,0xe5}};
extern "C" const GUID EXPORT IID_IESRIShape2 =
    {0xc90ee28c,0x01af,0x11d4,{0x9f,0x6c,0x00,0xc0,0x4f,0x6b,0xdd,0x7f}};

extern "C" const GUID EXPORT IID_IGeometry =
    {0x1b07790d,0x38c5,0x11d0,{0x92,0xd2,0x00,0x80,0x5f,0x7c,0x28,0xb0}};
extern "C" const GUID EXPORT IID_IGeometry2 =
    {0xb79b2d7e,0xdbc8,0x11d3,{0x9f,0x60,0x00,0xc0,0x4f,0x6b,0xdd,0x7f}};
extern "C" const GUID EXPORT IID_IGeometry3 =
    {0xd034f81b,0x7137,0x40a6,{0x90,0xea,0xd8,0x89,0x68,0xc3,0x3e,0x60}};
extern "C" const GUID EXPORT IID_IGeometry4 =
    {0xc4c70b7a,0xdfba,0x4892,{0x86,0xcd,0xa9,0x10,0x03,0x57,0x40,0x9b}};
extern "C" const GUID EXPORT IID_IGeometry5 =
    {0x134b247e,0x83f6,0x471c,{0x9a,0xd1,0x11,0xc3,0x53,0x12,0xd5,0xef}};

extern "C" const GUID EXPORT IID_IEnvelope =
    {0x1b077914,0x38c5,0x11d0,{0x92,0xd2,0x00,0x80,0x5f,0x7c,0x28,0xb0}};
extern "C" const GUID EXPORT IID_IEnvelope2 =
    {0x6b256adf,0x1cde,0x11d4,{0x9f,0x5c,0x00,0xc0,0x4f,0x6b,0xdf,0x0d}};

extern "C" const GUID EXPORT IID_ICompareCoordinateSystems =
    {0x75f37757,0x465c,0x43b1,{0xaf,0xe8,0x8a,0x4f,0xdc,0xb0,0x28,0x39}};
extern "C" const GUID EXPORT IID_IControlPrecision =
    {0xed4e18dd,0xee33,0x11d3,{0x9f,0xef,0x00,0xc0,0x4f,0x6b,0xc7,0x24}};
extern "C" const GUID EXPORT IID_IControlPrecision2 =
    {0xa1b0d8b3,0x474c,0x4fab,{0x80,0x8e,0x0a,0x3c,0x5c,0x49,0x8b,0x1b}};
extern "C" const GUID EXPORT IID_ISpatialReferenceTolerance =
    {0x587dc301,0x2766,0x4597,{0xa3,0xe5,0x9f,0xa1,0x52,0x32,0x9e,0xb8}};
extern "C" const GUID EXPORT IID_IESRISpatialReferenceGEN =
    {0xf90e304c,0xa0f7,0x4a7d,{0x9f,0x62,0x25,0xfd,0x2a,0x5c,0x96,0xaf}};

extern "C" const GUID EXPORT IID_IGeographicCoordinateSystem =
    {0x40870d80,0x1dd2,0x11b2,{0xbf,0x4c,0x08,0x00,0x20,0x22,0xf5,0x73}};
extern "C" const GUID EXPORT IID_IGeographicCoordinateSystem2 =
    {0xf78b2a38,0x89c4,0x11d4,{0x9f,0x9f,0x00,0xc0,0x4f,0x6b,0xc8,0xe8}};

extern "C" const GUID EXPORT IID_IUnknownCoordinateSystem =
    {0xb6ea1e3b,0x15e5,0x11d2,{0xaa,0xcd,0x00,0xc0,0x4f,0xa3,0x3c,0x20}};

////////////////////////////////////////////////////////////////////////////////

extern "C" const GUID EXPORT CLSID_GeometryEnvironment =
  {0x11735dae,0x816c,0x11d0,{0x82,0xf5,0x00,0x00,0xf8,0x03,0x40,0x32}};

extern "C" const GUID EXPORT CLSID_SpatialReferenceEnvironment =
  {0x7b5b7020,0xc4f6,0x11d1,{0xbc,0x92,0x00,0x00,0xf8,0x75,0xbc,0xce}};
extern "C" const GUID EXPORT CLSID_GeographicCoordinateSystem =
    {0xa6a87a80,0x1dd1,0x11b2,{0xbf,0x51,0x08,0x00,0x20,0x22,0xf5,0x73}};
extern "C" const GUID EXPORT CLSID_ProjectedCoordinateSystem =
    {0x2a626700,0x1dd2,0x11b2,{0xbf,0x51,0x08,0x00,0x20,0x22,0xf5,0x73}};
extern "C" const GUID EXPORT CLSID_UnknownCoordinateSystem =
    {0xb286c06b,0x0879,0x11d2,{0xaa,0xca,0x00,0xc0,0x4f,0xa3,0x3c,0x20}};

extern "C" const GUID EXPORT CLSID_Point =
    {0x00a5cb41,0x52da,0x11d0,{0xa8,0xf2,0x00,0x60,0x8c,0x85,0xed,0xe5}};
extern "C" const GUID EXPORT CLSID_Multipoint =
    {0x00a5cb40,0x52da,0x11d0,{0xa8,0xf2,0x00,0x60,0x8c,0x85,0xed,0xe5}};
extern "C" const GUID EXPORT CLSID_Polyline =
    {0x30707210,0x52d5,0x11d0,{0xa8,0xf2,0x00,0x60,0x8c,0x85,0xed,0xe5}};
extern "C" const GUID EXPORT CLSID_Polygon =
    {0x00a5cb42,0x52da,0x11d0,{0xa8,0xf2,0x00,0x60,0x8c,0x85,0xed,0xe5}};
extern "C" const GUID EXPORT CLSID_MultiPatch =
    {0xf3c041c6,0xae4d,0x11d2,{0x9c,0x93,0x00,0xc0,0x4f,0xb1,0x78,0x38}};

extern "C" const GUID EXPORT CLSID_Envelope =
  {0x30707212,0x52d5,0x11d0,{0xa8,0xf2,0x00,0x60,0x8c,0x85,0xed,0xe5}};

extern "C" const GUID EXPORT IID_IConfigurationParameter =
    {0x32bd0a83,0x25e5,0x4f24,{0xb8,0x1b,0x5e,0xbe,0xa2,0xdf,0xe3,0x5a}};
extern "C" const GUID EXPORT IID_IEnumConfigurationParameter =
    {0x75b1cca3,0xee77,0x4a5f,{0x8f,0xcd,0x17,0x75,0xd6,0xf9,0x49,0x7b}};
extern "C" const GUID EXPORT IID_IConfigurationKeyword =
    {0x2be5da4c,0x7a75,0x4cc9,{0xaa,0x73,0xc0,0x32,0x0b,0x89,0x84,0x6f}};
extern "C" const GUID EXPORT IID_IEnumConfigurationKeyword =
    {0xb055bbd8,0xde08,0x49cd,{0xa5,0x89,0xff,0xfd,0x22,0x11,0x2c,0xd5}};
extern "C" const GUID EXPORT IID_IConfigurationKeyword2 =
    {0xbbe02adf,0xae75,0x4ea4,{0xbe,0x73,0xfb,0xa8,0x3c,0xc3,0xee,0x10}};
extern "C" const GUID EXPORT IID_IConfigurationParameter2 =
    {0x4eac0cf1,0xee2a,0x405c,{0xa1,0x8a,0xc5,0x88,0xdc,0x53,0xa0,0xe7}};

extern "C" const GUID EXPORT IID_IField =
    {0xfcb01cb3,0x9f0b,0x11d0,{0xbe,0xc7,0x00,0x80,0x5f,0x7c,0x42,0x68}};
extern "C" const GUID EXPORT IID_IFieldEdit =
    {0x300aa631,0xb207,0x11d0,{0xbe,0xca,0x00,0x80,0x5f,0x7c,0x42,0x68}};
extern "C" const GUID EXPORT IID_IField2 =
    {0xf19f696b,0xf4f1,0x4066,{0x9a,0x7f,0x27,0x37,0x54,0xd9,0xdc,0x2a}};
extern "C" const GUID EXPORT IID_IFieldEdit2 =
    {0x8bad0db3,0xa817,0x4dbb,{0x97,0x52,0x3f,0xaf,0x67,0x57,0xe2,0x2c}};
extern "C" const GUID EXPORT IID_IFields =
    {0x6b2072e3,0x23f7,0x11d1,{0x89,0xd8,0x00,0x60,0x97,0xaf,0xf4,0x4e}};
extern "C" const GUID EXPORT IID_IFields2 =
    {0xc3eda031,0x6ec1,0x11d3,{0xa0,0x24,0x00,0xc0,0x4f,0x6b,0xdf,0x0e}};
extern "C" const GUID EXPORT IID_IFieldsEdit =
    {0x6b2072e4,0x23f7,0x11d1,{0x89,0xd8,0x00,0x60,0x97,0xaf,0xf4,0x4e}};
extern "C" const GUID EXPORT IID_IFieldsInfo =
    {0x360c1b71,0x41e4,0x11d1,{0x89,0xdb,0x00,0x60,0x97,0xaf,0xf4,0x4e}};
extern "C" const GUID EXPORT IID_IFieldImpl =
    {0x76acaea7,0x2b36,0x11d4,{0xa1,0x0d,0x00,0xc0,0x4f,0x6b,0xdf,0x0e}};
extern "C" const GUID EXPORT IID_IModelInfo =
    {0x2d660904,0x1dbd,0x11d3,{0x9f,0x87,0x00,0xc0,0x4f,0x6b,0xdd,0x84}};
extern "C" const GUID EXPORT IID_IGeometryDef =
    {0x439a0d50,0x3915,0x11d1,{0x9c,0xa7,0x00,0x00,0xf8,0x78,0x06,0x19}};
extern "C" const GUID EXPORT IID_IGeometryDefEdit =
    {0x439a0d51,0x3915,0x11d1,{0x9c,0xa7,0x00,0x00,0xf8,0x78,0x06,0x19}};
extern "C" const GUID EXPORT IID_IGeometryDefImpl =
    {0xb7a78cd5,0x79e2,0x46bc,{0x95,0x13,0x01,0x4c,0x1a,0xb2,0x74,0x5b}};
extern "C" const GUID EXPORT IID_IIndex =
    {0x2063fd01,0x4ce0,0x11d1,{0x89,0xdb,0x00,0x60,0x97,0xaf,0xf4,0x4e}};
extern "C" const GUID EXPORT IID_IIndexEdit =
    {0x2063fd02,0x4ce0,0x11d1,{0x89,0xdb,0x00,0x60,0x97,0xaf,0xf4,0x4e}};
extern "C" const GUID EXPORT IID_IIndexesEdit =
    {0x2063fd04,0x4ce0,0x11d1,{0x89,0xdb,0x00,0x60,0x97,0xaf,0xf4,0x4e}};
extern "C" const GUID EXPORT IID_IIndexes =
    {0x2063fd03,0x4ce0,0x11d1,{0x89,0xdb,0x00,0x60,0x97,0xaf,0xf4,0x4e}};
extern "C" const GUID EXPORT IID_IEnumIndex =
    {0x23bd2b49,0xbf8b,0x11d2,{0xaa,0xdd,0x00,0xc0,0x4f,0xa3,0x78,0x49}};

extern "C" const GUID EXPORT IID_IFIDSet =
    {0xd79bdaf1,0xcaa8,0x11d2,{0xb2,0xbe,0x00,0x00,0xf8,0x78,0x22,0x9e}};
extern "C" const GUID EXPORT IID_IFIDSet2 =
    {0x6ebaadc0,0x7541,0x46a4,{0x82,0xd7,0x48,0x42,0xec,0x9b,0x1e,0x55}};
extern "C" const GUID EXPORT IID_IFIDSetOperator =
    {0xed3c0c61,0x0c11,0x49e1,{0x9d,0x71,0xf3,0xd2,0xca,0xff,0x08,0x5f}};
extern "C" const GUID EXPORT IID_IEnumIDs =
    {0x7d84b001,0x1521,0x11d2,{0x89,0xed,0x00,0x60,0x97,0xaf,0xf4,0x4e}};

extern "C" const GUID EXPORT IID_IEnumSpatialReferenceInfo =
    {0x5f345e5f,0x4251,0x11d4,{0x81,0x45,0x00,0xc0,0x4f,0x68,0x62,0x38}};

extern "C" const GUID EXPORT IID_ISchemaLock =
    {0xdca648e5,0x0fbb,0x11d3,{0x80,0xa5,0x00,0xc0,0x4f,0x68,0x62,0x38}};
extern "C" const GUID EXPORT IID_ISchemaLockInfo =
    {0xa67958d8,0x226e,0x11d3,{0x80,0xb2,0x00,0xc0,0x4f,0x68,0x62,0x38}};
extern "C" const GUID EXPORT IID_IEnumSchemaLockInfo =
    {0xa67958d7,0x226e,0x11d3,{0x80,0xb2,0x00,0xc0,0x4f,0x68,0x62,0x38}};
extern "C" const GUID EXPORT IID_IEnumSchemaLockInfoImpl =
    {0x5de5f824,0x9561,0x4e0a,{0x9c,0x2c,0xa8,0x86,0x4b,0x3e,0x66,0xda}};

extern "C" const GUID EXPORT IID_IQueryFilter =
    {0xfdfebd93,0xed75,0x11d0,{0x9a,0x95,0x08,0x00,0x09,0xec,0x73,0x4b}};
extern "C" const GUID EXPORT IID_ICursor =
    {0xd4803ee7,0x79f4,0x11d0,{0x97,0xfc,0x00,0x80,0xc7,0xf7,0x94,0x81}};
extern "C" const GUID EXPORT IID_IWorkspace =
    {0xd4803ee1,0x79f4,0x11d0,{0x97,0xfc,0x00,0x80,0xc7,0xf7,0x94,0x81}};

////////////////////////////////////////////////////////////////////////////////

extern "C" const GUID EXPORT CLSID_Field =
    {0xf94f7534,0x9fdf,0x11d0,{0xbe,0xc7,0x00,0x80,0x5f,0x7c,0x42,0x68}};
extern "C" const GUID EXPORT CLSID_Fields =
    {0xf94f7535,0x9fdf,0x11d0,{0xbe,0xc7,0x00,0x80,0x5f,0x7c,0x42,0x68}};
extern "C" const GUID EXPORT CLSID_Index =
    {0x826e2701,0x4da6,0x11d1,{0x88,0x24,0x00,0x00,0xf8,0x77,0x76,0x2d}};
extern "C" const GUID EXPORT CLSID_Indexes =
    {0x03859813,0x4da5,0x11d1,{0x88,0x24,0x00,0x00,0xf8,0x77,0x76,0x2d}};
extern "C" const GUID EXPORT CLSID_XMLIndex =
    {0x18ec559b,0x07be,0x4f98,{0x89,0x60,0x20,0x66,0x36,0xba,0x25,0x9a}};
extern "C" const GUID EXPORT CLSID_GeometryDef =
    {0x439a0d52,0x3915,0x11d1,{0x9c,0xa7,0x00,0x00,0xf8,0x78,0x06,0x19}};
extern "C" const GUID EXPORT CLSID_RasterDef =
    {0xa8386192,0x3659,0x4525,{0x98,0x4f,0x5d,0x64,0x3a,0x40,0xee,0x8c}};
extern "C" const GUID EXPORT CLSID_RasterValue =
    {0x93d0b191,0x6bf1,0x418f,{0xab,0x89,0x6f,0x29,0x02,0x78,0xc2,0x45}};
extern "C" const GUID EXPORT CLSID_FIDSet =
    {0xd79bdaf0,0xcaa8,0x11d2,{0xb2,0xbe,0x00,0x00,0xf8,0x78,0x22,0x9e}};
extern "C" const GUID EXPORT CLSID_ConfigurationKeyword =
    {0xfbf57161,0xa05d,0x11d4,{0xa6,0x4c,0x00,0x08,0xc7,0x11,0xc8,0xc1}};
extern "C" const GUID EXPORT CLSID_ConfigurationParameter =
    {0xfbf57162,0xa05d,0x11d4,{0xa6,0x4c,0x00,0x08,0xc7,0x11,0xc8,0xc1}};

// remaining smart pointer guids
extern "C" const GUID EXPORT IID_IRelationalOperator =
    {0x1b07790e,0x38c5,0x11d0,{0x92,0xd2,0x00,0x80,0x5f,0x7c,0x28,0xb0}};
extern "C" const GUID EXPORT IID_IQueryFilterDefinition2 =
    {0x45096447,0x06ff,0x4e5e,{0xa2,0x60,0x92,0x13,0xe0,0x09,0xaf,0x29}};
extern "C" const GUID EXPORT IID_IQueryFilterFIDSet =
    {0x4430bbbe,0x47b7,0x11d4,{0x9f,0x52,0x00,0xc0,0x4f,0x79,0x92,0x7c}};
extern "C" const GUID EXPORT IID_ISpatialFilter =
    {0xfdfebd94,0xed75,0x11d0,{0x9a,0x95,0x08,0x00,0x09,0xec,0x73,0x4b}};
extern "C" const GUID EXPORT IID_IRasterValue =
    {0x6b2d0243,0x7100,0x4e3f,{0xaa,0x02,0x5e,0xc1,0x2d,0xaf,0x69,0x80}};
extern "C" const GUID EXPORT IID_IRasterDatasetNameEx =
    {0x5f9195b9,0xd40d,0x4015,{0xb0,0xbe,0x15,0x3d,0x0d,0x8e,0x2c,0x75}};
extern "C" const GUID EXPORT IID_IRasterDef2 =
    {0x16c76984,0xe0e8,0x4112,{0x80,0xc9,0xe0,0x52,0xc9,0xb9,0xc9,0xd2}};
extern "C" const GUID EXPORT IID_IRasterDef =
    {0xcdba994f,0x8f18,0x4abe,{0x8a,0x39,0x50,0x2b,0xed,0x07,0x26,0x5e}};
extern "C" const GUID EXPORT IID_IXMLIndexEdit =
    {0x537fc360,0xcc9b,0x4671,{0xb1,0x55,0x07,0xd1,0x41,0xfe,0x8d,0x99}};
extern "C" const GUID EXPORT IID_IXMLIndex =
    {0x5240ceaa,0x366d,0x42ed,{0x97,0xfe,0x61,0xdf,0xb3,0xc2,0x02,0x48}};

extern "C" const GUID EXPORT IID_IUnit =
    {0x0ae02580,0x1dd2,0x11b2,{0xbf,0x4a,0x08,0x00,0x20,0x22,0xf5,0x73}};
extern "C" const GUID EXPORT IID_IAngularUnit =
    {0x74ad43f0,0xd31c,0x11d1,{0xbc,0x9b,0x00,0x00,0xf8,0x75,0xbc,0xce}};
extern "C" const GUID EXPORT CLSID_AngularUnit =
    {0x74ad43f4,0xd31c,0x11d1,{0xbc,0x9b,0x00,0x00,0xf8,0x75,0xbc,0xce}};
    
extern "C" const GUID EXPORT IID_IProjectedCoordinateSystem =
    {0xf94e4c00,0x1dd1,0x11b2,{0xbf,0x4e,0x08,0x00,0x20,0x22,0xf5,0x73}};
extern "C" const GUID EXPORT IID_IProjectedCoordinateSystem2 =
    {0xa690307d,0x6c11,0x43a1,{0x96,0x6a,0x9e,0x8d,0xb0,0x67,0x20,0x33}};
extern "C" const GUID EXPORT IID_IProjectedCoordinateSystem3 =
    {0xd9b13c10,0x5c5e,0x11d5,{0x9f,0xee,0x00,0xc0,0x4f,0x6b,0xdd,0x7f}};
extern "C" const GUID EXPORT IID_IProjectedCoordinateSystem4 =
    {0xd765fb6b,0x05d3,0x4398,{0x86,0xac,0x79,0x43,0x0d,0xe5,0x30,0xe5}};
extern "C" const GUID EXPORT IID_IProjectedCoordinateSystem5 =
    {0x734e8d44,0x09b8,0x4796,{0x8f,0xb7,0x19,0x85,0xa3,0x2b,0xe7,0xbe}};

extern "C" const GUID EXPORT GUID_NULL =
    {0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}};
extern "C" const GUID EXPORT IID_IStream =
    {0x0000000c,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
extern "C" const GUID EXPORT IID_ISequentialStream =
    {0x0C733A30,0x2A1C,0x11CE,{0xAD,0xE5,0x00,0xAA,0x00,0x44,0x77,0x3D}};
extern "C" const GUID EXPORT IID_IPersist =
    {0x0000010c,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
extern "C" const GUID EXPORT IID_IPersistStream =
    {0x00000109,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
extern "C" const GUID EXPORT IID_IErrorRecords =
    {0x0c733a67,0x2a1c,0x11ce,{0xad,0xe5,0x00,0xaa,0x00,0x44,0x77,0x3d}};

extern "C" const GUID EXPORT IID_ISpatialReferenceSingletonManager =
    {0x58ab2690,0x5981,0x11d2,{0xbc,0xda,0x00,0x00,0xf8,0x75,0xbc,0xce}};
extern "C" const GUID EXPORT IID_ILinearUnit =
    {0x74ad43f1,0xd31c,0x11d1,{0xbc,0x9b,0x00,0x00,0xf8,0x75,0xbc,0xce}};
extern "C" const GUID EXPORT IID_ISpatialReferenceResolution =
    {0x833ac5b9, 0x20e3, 0x4896, { 0x8d, 0x55, 0x77, 0x0f, 0x4e, 0x90, 0xa2, 0xe4}};
extern "C" const GUID EXPORT IID_ISpatialReferenceAuthority =
    {0xd2f20dac,0x5ca7,0x4b58,{0xbd,0xdb,0x30,0x9f,0xdd,0x0e,0x36,0x4a}};
extern "C" const GUID EXPORT CLSID_LinearUnit =
    {0xde162780,0x1dd1,0x11b2,{0xbf,0x4f,0x08,0x00,0x20,0x22,0xf5,0x73}};
extern "C" const GUID EXPORT IID_IVerticalCoordinateSystem =
    {0x3f6c2145,0x3320,0x446f,{0x82,0xbf,0xb3,0xe3,0x8f,0xad,0xc8,0x33}};
extern "C" const GUID EXPORT CLSID_VerticalCoordinateSystem =
    {0x6d7ef7c6,0x40db,0x48fb,{0xb5,0xbb,0xba,0xdf,0xdc,0xa5,0xa2,0xd8}};

