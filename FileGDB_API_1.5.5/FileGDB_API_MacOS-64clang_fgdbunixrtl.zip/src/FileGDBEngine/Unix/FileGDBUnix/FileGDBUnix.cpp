/*
 * This file contains the implementation of the parts of the Win32 API
 * that are required for the ESRI File GDB API to function on Unix.
 *
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */
 
#ifndef UNIX_FILEGDB_API
#error This file must only be compiled on Unix builds
#endif

#include "FileGDBUnix.h"

#if defined(__clang__) || (_MSC_VER > 1800) || (GCC_VERSION >= 40900)
  #include <regex>
#else
  #include <boost/regex.hpp>
#endif
#include <fstream>

// GLOBALS
std::map<LPCWSTR, GUID, GuidMapComp> g_GuidMap;

extern void InitGuidMap();

// Debug tracing.
// Output method depends on environment variable FileGDBAPI_TRACE.
// Define FileGDBAPI_TRACE = 0 (or undefined) for no output
// Define FileGDBAPI_TRACE = 1 for print messages on the console to stdout
// Define FileGDBAPI_TRACE = 2 for output to a logfile in /tmp/FileGDBAPI.log
// Define FileGDBAPI_TRACE = <file name> for output to a specific logfile
static void FileGDBAPI_TRACE(const char* message, const char* fname = NULL)
{
  char *var;
  var = getenv("FileGDBAPI_TRACE");
  if (var == NULL || strcmp(var, "0") == 0)
    return;

  if (strcmp(var, "1") == 0)
  {
    bool syncState = std::ios_base::sync_with_stdio(false);
    std::cout << "FileGDBAPI_TRACE: " << message << " ";
    fname ? std::cout << fname << std::endl : std::cout << std::endl;
    std::ios_base::sync_with_stdio(syncState);
    return;
  }

  time_t tim = time(NULL);
  struct tm* tms = localtime(&tim);
  const char* logName = (strcmp(var, "2") == 0)
                      ? "/tmp/FileGDBAPI.log"
                      : var;
  std::ofstream logFile(logName, std::ios_base::out|std::ios_base::app);
  logFile << "FileGDBAPI_TRACE: "
          << tms->tm_mon+1 << "/" << tms->tm_mday << "/" << tms->tm_year+1900
          << " " << tms->tm_hour << ":" << tms->tm_min << ":" << tms->tm_sec
          << ": " << "Process ID = " << getpid() << ": ";
  logFile << message << " ";
  fname ? logFile << fname << std::endl : logFile << std::endl;
  logFile.close();
}

/* InitSystemGuids
 * This function inserts the system Guids into the global Guid map.
 */
static void InitSystemGuids()
{ // register Guids defined in WinStructures.h
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ISequentialStream", GUIDIFY(L"0c733a30-2a1c-11ce-ade5-00aa0044773d")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IClassFactory", GUIDIFY(L"00000001-0000-0000-C000-000000000046")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IStream", GUIDIFY(L"0000000c-0000-0000-C000-000000000046")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ITypeComp", GUIDIFY(L"00020403-0000-0000-C000-000000000046")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ITypeLib", GUIDIFY(L"00020402-0000-0000-C000-000000000046")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"ITypeInfo", GUIDIFY(L"00020401-0000-0000-C000-000000000046")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IDispatch", GUIDIFY(L"00020400-0000-0000-C000-000000000046")));
  g_GuidMap.insert(std::pair<LPCWSTR, GUID>
  (L"IRecordInfo", GUIDIFY(L"0000002F-0000-0000-C000-000000000046")));
}

/* uuidof
 * This function simulates the __uuidof MS compiler intrinsic. We instead use
 * an stl map to hold all of the Guids, so this function just located the 
 * requested Guid in the map. GUID_NULL is returned if clsid not found.
 */
GUID WINAPI uuidof(LPWSTR clsid)
{
  static bool bGuidsInitialized = false;
  if (!bGuidsInitialized)
  { // populate Guid Map
    InitGuidMap(); // ArcGIS Guids and IUnknown
    InitSystemGuids(); // System Guids we define
    bGuidsInitialized = true;
  }
  std::map<LPCWSTR, GUID>::iterator it = g_GuidMap.find(clsid);
  if (it == g_GuidMap.end())
    return GUIDIFY(L"00000000-0000-0000-0000-000000000000");

  return it->second;
}

/* InitializeCriticalSection
 * This function initializes a CRITICAL_SECTION object. This is a no-op since
 * the CRITICAL_SECTION constructor handles it.
 */
void WINAPI InitializeCriticalSection(LPCRITICAL_SECTION lpCriticalSection)
{
}

/* EnterCriticalSection
 * This function locks the current CRITICAL_SECTION object.
 */
void WINAPI EnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection)
{ // lpCriticalSection cannot be NULL
  lpCriticalSection->lock();
}

/* LeaveCriticalSection
 * This function unlocks the current CRITICAL_SECTION object.
 */
void WINAPI LeaveCriticalSection(LPCRITICAL_SECTION lpCriticalSection)
{ // lpCriticalSection cannot be NULL
  lpCriticalSection->unlock();
}

/* InitializeCriticalSectionAndSpinCount
 * This function is a no-op on Unix. It just initiates a busy wait on 
 * multi-cpu.
 */
BOOL WINAPI InitializeCriticalSectionAndSpinCount(
                               LPCRITICAL_SECTION lpCriticalSection,
                               DWORD dwSpinCount)
{
  return true; // also a no-op
}

/* DeleteCriticalSection
 * This function is a no-op on Unix. The CRITICAL_SECTION destructor 
 * handles it.
 */
void WINAPI DeleteCriticalSection(LPCRITICAL_SECTION lpCriticalSection)
{
}

/* InterlockedIncrement(atomicLong*)
 * This function implements an atomic increment operation on an atomicLong
 * object. The atomicLong operation contains its own locking mechanisms.
 */
LONG WINAPI InterlockedIncrement(atomicLong* aLong)
{ // aLong can never be null
  LONG tmp;
  aLong->lock();
  ++(*aLong);
  tmp = *aLong;
  aLong->unlock();
  return tmp;
}

/* InterlockedDecrement(atomicLong*)
 * This function implements an atomic decrement operation on an atomicLong
 * object. The atomicLong operation contains its own locking mechanisms.
 */
LONG WINAPI InterlockedDecrement(atomicLong* aLong)
{ // aLong can never be null
  LONG tmp;
  aLong->lock();
  --(*aLong);
  tmp = *aLong;
  aLong->unlock();
  return tmp;
}

/* InterlockedIncrementDummy(LONG*)
 * This function implements a non-atomic increment operation on a LONG
 * object. This is not thread-safe.
 */
LONG WINAPI InterlockedIncrementDummy(LONG *val)
{
  (*val)++;
  return *val;
}

/* InterlockedDecrementDummy(LONG*)
 * This function implements a non-atomic decrement operation on a LONG
 * object. This is not thread-safe.
 */
LONG WINAPI InterlockedDecrementDummy(LONG *val)
{
  (*val)--;
  return *val;
}

/* GetComputerName
 * This function returns the host name of the computer.
 */
BOOL WINAPI GetComputerName(LPTSTR lpBuffer, LPDWORD lpnSize)
{ // Per MSDN, if buffer is too small return failure and assign
  // lpnSize to be the required size.
  char name[MAX_COMPUTERNAME_LENGTH + 1];
  int rv = gethostname(name, size_t(MAX_COMPUTERNAME_LENGTH + 1));
  
  DWORD requiredLen = (DWORD)strlen(name)+1;
  
  if (requiredLen > *lpnSize)
  { // buffer too small
    *lpnSize = requiredLen;
    return FALSE;
  }
  wcscpy(lpBuffer, StrAdapter(name));
  return rv == 0 ? TRUE : FALSE;
}

/* GetCurrentProcessId
 * This function returns the process ID.
 */
DWORD WINAPI GetCurrentProcessId(void)
{
  return (DWORD)getpid();
}

/* GetCurrentThreadId
 * This function returns the thread ID. For OS X, it returns a unique 
 * non thread-related ID.
 */
DWORD WINAPI GetCurrentThreadId(void)
{
#ifndef __APPLE__
  return (DWORD)pthread_self();
#else // pthread_t is an opaque, non-unique pointer on OS X
  static bool cached = false;
  static DWORD simulatedTid = 0;
  if (!cached)
  {
    cached = true;
    struct timeval tv;
    gettimeofday(&tv, NULL);
    srand((unsigned int)((tv.tv_sec + tv.tv_usec) % UINT_MAX));
    DWORD pid = GetCurrentProcessId();
    DWORD modValue = 1;
    while (pid < 100000000U)
    {
      pid *= 10; // add some zeros to the end so we can stick a rand on the end
      modValue *= 10;
    }
    simulatedTid = pid + ((rand() % UINT_MAX) % modValue);
  }
  return simulatedTid;
#endif
}

/* GetEnvironmentVariable
 * This function retrieves the requested environment variable.
 */
DWORD WINAPI GetEnvironmentVariable(LPCTSTR lpName, LPTSTR lpBuffer, DWORD nSize)
// From MSDN - nSize = the size of the buffer pointed to by the lpBuffer 
// parameter, including the null-terminating character, in characters.
// If lpBuffer is not large enough to hold the data, the return value is
// the buffer size, in characters, required to hold the string and its
// terminating null character and the contents of lpBuffer are undefined.
// If the function succeeds, the return value is the number of characters 
// stored in the buffer pointed to by lpBuffer, not including the terminating
// null character. If the function fails, the return value is zero.
{
  char *var;
  var = getenv(StrAdapter(lpName));
  if (!var)
    return 0; // error
  if (strlen(var)+1 > nSize)
    return (DWORD)(strlen(var)+1); // required size + null
  wcscpy(lpBuffer, StrAdapter(var));
  return wcslen(lpBuffer); // actual size, ignore null
}

/* GetProcessHeap
 * This function is a no-op on Unix. We use the standard heap.
 */
HANDLE WINAPI GetProcessHeap()
{ // This is a no-op for Unix, just use the standard heap
  return 0;
}

/* HeapAlloc
 * This function allocates memory off the runtime heap.
 */
LPVOID WINAPI HeapAlloc(HANDLE hHeap, DWORD dwFlags, SIZE_T dwBytes)
{ // HEAP_ZERO_MEMORY is important for callers expecting a zeroed out buffer
  if (dwFlags & HEAP_ZERO_MEMORY)
    return calloc(dwBytes, 1);
  return malloc(dwBytes);
}

/* HeapReAlloc
 * This function reallocates memory off the runtime heap.
 */
LPVOID WINAPI HeapReAlloc(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem, SIZE_T dwBytes)
{
  FileGDBAPI_TRACE("check HeapReAlloc implementation", __FUNCTION__);
  return realloc(lpMem, dwBytes);
}

/* HeapFree
 * This function frees memory from the runtime heap.
 */
BOOL WINAPI HeapFree(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem)
{
  free(lpMem);
  return 1;
}

/* GetModuleHandle
 * This function wraps dlopen.
 */
HMODULE WINAPI GetModuleHandle(LPCTSTR lpModuleName)
{
  return dlopen(StrAdapter(lpModuleName), RTLD_LAZY); // only resolve as needed
}

/* LoadLibraryEx
 * This function wraps dlopen.
 */
HMODULE WINAPI LoadLibraryEx(LPCTSTR lpFileName, HANDLE hFile, DWORD dwFlags)
{// ignore dwFlags on Unix, use standard dlopen search strategy
  return LoadLibrary(lpFileName);
}

#ifdef __APPLE__
/* _tcsdup == wcsdup
 * Same as strdup, but with wide strings.
 */
WCHAR WINAPI *_tcsdup(const WCHAR *wstr)
{
  if (wstr == NULL)
    return NULL;
  
  size_t len = wcslen(wstr);
  WCHAR* rv = (WCHAR*)malloc(len*sizeof(WCHAR)+sizeof(WCHAR));
  memcpy(rv, wstr, len*sizeof(WCHAR)+sizeof(WCHAR));
  return rv;
}
#endif

/* LoadLibrary
 * This function wraps dlopen.
 */
HMODULE WINAPI LoadLibrary(LPCTSTR lpFileName)
{
  return dlopen(StrAdapter(lpFileName), RTLD_NOW); // resolve now
}

/* FreeLibrary
 * This function wraps dlclose.
 */
BOOL WINAPI FreeLibrary(HMODULE hModule)
{
 return (dlclose(hModule) == 0);
}

/* GetProcAddress
 * This function gets a pointer to the requested function.
 */
void WINAPI *GetProcAddress(HMODULE hModule, LPCSTR lpProcName)
{// GetProcAddress returns a 'FARPROC' on Windows, a typedef'd function pointer
  return dlsym(hModule, StrAdapter(lpProcName));
}

/* DebugBreak
 * This function initiates an interrupt.
 * Warning - Not portable.
 */
void WINAPI DebugBreak()
{// Trigger an interrupt on a debug build only. Applies to x86 only.
#if defined (DEBUG) || defined (_DEBUG)
  asm("int $3");
#endif
}

/* FatalAppExit
 * This function calls exit to halt the process.
 */
void WINAPI FatalAppExit(UINT uAction, LPCTSTR lpMessageText)
{
  exit((INT)uAction);
}

/* Sleep
 * This function will sleep for the specified milliseconds.
 */
void WINAPI Sleep(DWORD dwMilliseconds)
{
  struct timeval t;
  t.tv_sec  = dwMilliseconds / 1000;
  t.tv_usec = (dwMilliseconds % 1000) * 1000;
  select(0, 0, 0, 0, &t);
}

/* MultiByteToWideChar
 * This function converts a multibyte sequence to a wide char.
 * char* -> wchar_t* .
 */
int WINAPI MultiByteToWideChar(UINT CodePage, // ignored, assume UTF-8
                 DWORD dwFlags,        // ignored
                 LPCSTR lpMultiByteStr,// to be converted
                 int cbMultiByte,      // size(bytes), -1 for null-term'd
                 LPWSTR lpWideCharStr, // (OPT) output wchar
                 int cchWideChar)      // 0 means ignore lpWideCharStr
{
  if (cchWideChar == 0) // will need this many wide characters
  {
    if (cbMultiByte == -1) // it's null terminated
      return str_utf8_len(lpMultiByteStr)+1;
    return str_utf8_len(lpMultiByteStr, cbMultiByte);
  }
  if (cbMultiByte == -1) // it's null terminated
    return str_utf8_to_uni(lpWideCharStr, lpMultiByteStr, cchWideChar)+1;
  return str_utf8_to_uni(lpWideCharStr, lpMultiByteStr, cchWideChar, cbMultiByte);
}

/* WideCharToMultiByte
 * This function converts a wide char sequence to a multibyte.
 * wchar_t* -> char* .
 */
int WINAPI WideCharToMultiByte(UINT CodePage, // ignored, assume UTF-8
              DWORD dwFlags,           // ignored
              LPCWSTR lpWideCharStr,   // to be converted
              int cchWideChar,         // size(chars), -1 for null-term'd
              LPSTR lpMultiByteStr,    // (OPT) output mbchar
              int cbMultiByte,         // 0 means ignore lpMultiByteStr
              LPCSTR lpDefaultChar,    // ignored
              LPBOOL lpUsedDefaultChar)// ignored
{
  if (cbMultiByte == 0) // will need this many bytes
  {
    if (cchWideChar == -1) // it's null terminated
      return str_uni_bytes(lpWideCharStr)+1;
    return str_uni_bytes(lpWideCharStr, cchWideChar);
  }
  if (cchWideChar == -1) // it's null terminated
    return str_uni_to_utf8(lpMultiByteStr, lpWideCharStr, cbMultiByte)+1;
  return str_uni_to_utf8(lpMultiByteStr, lpWideCharStr, cbMultiByte, cchWideChar);
}

/* SysAllocStringLen
 * This function allocates a BSTR.
 * We store the size of the BSTR one DWORD before the beginning of the BSTR
 * object. Note that the size stored is always the byte size.
 */
BSTR WINAPI SysAllocStringLen(const OLECHAR *pch, unsigned int cch)
{ // From MSDN: The pch string can contain embedded null characters
  // and does not need to end with a NULL
  BSTR bstr;
  bstr = (BSTR)malloc((cch*sizeof(OLECHAR))+sizeof(OLECHAR)+sizeof(DWORD));
  *bstr = (DWORD)((DWORD)cch * sizeof(WCHAR));
  (DWORD*)(bstr)++;
  
  if (pch)
    wmemcpy(bstr, pch, (size_t)cch); // copy any nulls too, don't use wcscpy
  else
    wcscpy(bstr, L"");
 
  bstr[cch] = L'\0';
  return bstr;
}

/* SysFreeString
 * This function deallocates a BSTR by rewinding the pointer and freeing it.
 */
VOID WINAPI SysFreeString(BSTR bstr)
{ // be sure to rewind the pointer to where the DWORD size is
  if (bstr)
  {
    (DWORD*)(bstr)--;
    free(bstr);
  }
}

/* SysStringLen
 * This function returns the length in characters of the BSTR, which is stored
 * one DWORD behind the BSTR.
 */
UINT WINAPI SysStringLen(BSTR bstr)
{
  if (!bstr)
    return 0;
  
  (DWORD*)(bstr)--;
  DWORD len = (DWORD)(((DWORD)*bstr) / sizeof(WCHAR));
  (DWORD*)(bstr)++;
  return (UINT)len;
}

/* SysStringByteLen
 * This function returns the length in bytes of the BSTR, which is stored
 * one DWORD behind the BSTR.
 */
UINT WINAPI SysStringByteLen(BSTR bstr)
{
  return SysStringLen(bstr)*sizeof(WCHAR);
}

/* SysAllocString
 * This function allocates a new BSTR from the passed in OLECHAR*.
 */
BSTR WINAPI SysAllocString(const OLECHAR *sz)
{ // note, input string is not a BSTR, so we can assume it cannot have
  // any valid nulls and is null terminated
  if (!sz)
    return NULL;
  if (wcslen(sz) == 0)
    return SysAllocStringLen(NULL, 0); // allocate a 0-length string, L'\0'
  
  return SysAllocStringLen(sz, wcslen(sz));
}

/* SysAllocStringByteLen
 * This function allocates a new BSTR from the passed in char*.
 */
BSTR WINAPI SysAllocStringByteLen(char *psz, unsigned int len)
{ // do not perform any Unicode conversion at all, malloc a chunk of mem 
  // and return as cast to wide char
  
  DWORD *buf = (DWORD*)malloc(len + sizeof(OLECHAR) + sizeof(DWORD));

  // Always indicate the length is 'len' even if psz is NULL
  // A caller can request an uninitialized buffer this way
 *buf = (DWORD)len;
  buf++;
  
  if (psz)
    memcpy(buf, psz, len);
  
  char *strBuf = (char*)buf;
  
  for (DWORD i = 0; i < sizeof(OLECHAR) ; i++)
    strBuf[len+i] = 0; // zero out the last OLECHAR len size for null char
  
  return (BSTR)strBuf;
}

/* OutputDebugString
 * This function prints an output string when debugging is enabled.
 */
void WINAPI OutputDebugString(LPCTSTR lpOutputString)
{ // only works with a debug build
#if defined (DEBUG) || defined (_DEBUG)
  fprintf(stderr, StrAdapter(lpOutputString));
#endif
}

/* CoTaskMemFree
 * This function frees the pointer.
 */
void WINAPI CoTaskMemFree(LPVOID pv)
{
  free(pv);
}

/* CoTaskMemAlloc
 * This function allocates memory from the standard heap.
 */
LPVOID WINAPI CoTaskMemAlloc(SIZE_T cb)
{
  return malloc(cb);
}

/* QueryDosDevice
 * This function is a dummy implementation that does nothing.
 */
DWORD WINAPI QueryDosDevice(LPCTSTR lpDeviceName, LPTSTR lpTargetPath, DWORD ucchMax)
{ // a no-op for Unix
  return 0;
}

/* PathIsDirectory
 * This function determines if the argument is a directory.
 */
BOOL WINAPI PathIsDirectory(LPCTSTR pszPath)
{
  if (!pszPath)
    return FALSE;
  
  struct stat stat_buf;
  if (stat(StrAdapter(pszPath), &stat_buf) == -1)
    return FALSE; // doesn't even exist
  if (stat_buf.st_mode == S_IFDIR)
    return TRUE;
  return FALSE; // exists, but is NOT a directory
}


/* PathIsDirectoryW
 * This function determines if the argument is a directory.
 */
BOOL WINAPI PathIsDirectoryW(const wchar_t* pszPath)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* PathIsDirectoryEmpty
 * This function determines if the argument is a directory and if is empty.
 * The only allowed entries in the directory are '.' and '..'.
 */
BOOL WINAPI PathIsDirectoryEmpty(LPCTSTR pszPath)
{
  if (!PathIsDirectory(pszPath))
    return FALSE;
  
  DIR *dir;
  struct dirent *entry;

  // no need to validate dir, we've already established it's a valid directory
  dir = opendir(StrAdapter(pszPath));
  
  while ((entry = readdir(dir)) != NULL)
  { // read all entries in the directory
    if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
      continue; // these are the only allowed entries in an empty directory
    closedir(dir);
    return FALSE;
  }
  closedir(dir);
  return TRUE;
}

/* wsprintf
 * This function wraps a call to vswprintf.
 */
int WINAPI wsprintf(LPTSTR lpOut, LPCTSTR lpFmt, ...)
{
  va_list argList;
  va_start(argList, lpFmt);
  // MSDN states wsprintf only allows 1024 max
  vswprintf(lpOut, 1024, lpFmt, argList);
  va_end(argList);
  return wcslen(lpOut);
}

/* wcscat_s
 * This function wraps a call to wcsncat.
 */
errno_t WINAPI wcscat_s(wchar_t *strDestination, size_t numberOfElements,
                                          const wchar_t *strSource)
{
  wcsncat(strDestination, strSource, numberOfElements);
  return 0; // wcsncat has no ability to track errors
}

/* wcscpy_s
 * This function wraps a call to wcsncpy.
 */
errno_t WINAPI wcscpy_s(wchar_t *strDestination, size_t numberOfElements,
                                          const wchar_t *strSource)
{
  wcsncpy(strDestination, strSource, numberOfElements);
  return 0; // wcsncpy has no ability to track errors
}

/* StringFromCLSID
 * This function allocates memory (which the caller needs to free), and 
 * converts a GUID into a string.
 */
HRESULT WINAPI StringFromCLSID(REFCLSID rclsid, LPOLESTR *lplpsz)
{ // caller is responsible to free memory allocated here
  OLECHAR *guid = (OLECHAR*)malloc(GUID_STR_LEN*sizeof(OLECHAR));
  if (!guid)
    return E_FAIL;
  if (StringFromGUID2(rclsid, guid, GUID_STR_LEN) == -1)
  {
    free(guid);
    return E_FAIL;
  }
  *lplpsz = guid;
  return S_OK;
}

/* StringFromGUID2
 * This function converts a GUID into a string without allocating memory.
 */
int WINAPI StringFromGUID2(REFGUID rguid, LPOLESTR lpsz, int cchMax)
{
  if (cchMax < GUID_STR_LEN)
    return -1;
  swprintf(lpsz, cchMax, L"{%.8X-%.4X-%.4X-%.2X%.2X-%.2X%.2X%.2X%.2X%.2X%.2X}\0",
           rguid.Data1, rguid.Data2, rguid.Data3, 
           rguid.Data4[0], rguid.Data4[1],
           rguid.Data4[2], rguid.Data4[3],
           rguid.Data4[4], rguid.Data4[5],
           rguid.Data4[6], rguid.Data4[7]);
  if (wcslen(lpsz) == 0)
    return -1;
  return (int)(wcslen(lpsz) + 1);
}

/* CoCreateGuid
 * This function creates a random, V4-compliant Guid.
 */
HRESULT WINAPI CoCreateGuid(GUID *pguid)
{ // pguid cannot be null
  static bool seeded = false;
  if (!seeded)
  {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    srand((unsigned int)((tv.tv_sec + tv.tv_usec) % UINT_MAX));
    seeded = true;
  }
#ifndef _LP64
  pguid->Data1 = rand() % ULONG_MAX;
#else
  pguid->Data1 = rand() % UINT_MAX;
#endif
  pguid->Data2 = rand() % USHRT_MAX;
  // a 4 must appear as the first entry here to be V4 Guid compliant
  pguid->Data3 = ((rand() % USHRT_MAX) % 0xFFF) + 0x4000;
  for (int i = 0; i < 8; i++)
    pguid->Data4[i] = rand() % UCHAR_MAX;

  return S_OK;
}

/* UuidCreate
 * another form of CoCreateGuid for RPC
 */
RPC_STATUS WINAPI UuidCreate(UUID *Uuid)
{
  CoCreateGuid(Uuid);
  return RPC_S_OK;
}

/* charToInt
 * Helper function to map characters.
 */
static int charToInt(char ch)
{ // Map ascii to integers with hex support: '4'=4, 'f'=15, 'B'=11
  if (ch >= 48 && ch <= 57)
    return int(ch-48); // [0-9]
  if (ch >= 65 && ch <= 70)
    return int(ch-55); // [A-F]
  
  // has to be lower-case [a-f]
  return int(ch-87);
}

/* CLSIDFromString
 * This function converts a string into a Guid.
 */
HRESULT WINAPI CLSIDFromString(LPCOLESTR lpsz, LPCLSID pclsid)
{
  if (!lpsz)
    return CO_E_CLASSSTRING;

  int PowOf16[8] = {1, 16, 256, 4096, 65536, 1048576, 16777216, 268435456};
  memset((void*)pclsid, 0, sizeof(CLSID));
  
  LPCOLESTR str = lpsz;
  //support representations starting with "{" and without
  if (str[0] == L'{')
    str++;
  
  for (int i = 7 ; i >= 0 ; i--)
  {
    pclsid->Data1 += PowOf16[i]*charToInt((char)str[0]);
    str++;
  }
  str++; // chew up a '-'
  
  for (int i = 3 ; i >= 0 ; i--)
  {
    pclsid->Data2 += PowOf16[i]*charToInt((char)str[0]);
    str++;
  }
  str++; // chew up a '-'
  
  for (int i = 3 ; i >= 0 ; i--)
  {
    pclsid->Data3 += PowOf16[i]*charToInt((char)str[0]);
    str++;
  }
  str++; // chew up a '-'
  
  for (int j = 0; j < 8; j++)
  {
    for (int i = 1; i >= 0; i--)
    {
      pclsid->Data4[j] += PowOf16[i]*charToInt((char)str[0]);
      str++;
    }
    if (j == 1)
      str++; // chew up a '-'
  }
  
  return S_OK;
}

/* GetLocaleInfo
 * This function retrieves requested locale-specific info.
 */
#define IS_LOC(a) ((a & LCType) == a)
int WINAPI GetLocaleInfo(LCID Locale, LCTYPE LCType, LPTSTR lpLCData, int cchData)
// Note, Windows uses Day 1 = Monday. Unix/Linux locale uses Day 1 = Sunday
{
  bool preflight = cchData == 0 ? true : false;
  if (!lpLCData && !preflight)
    return 0; // caller requested writing into NULL buffer

  // Load the current locale, as determined by the environment
  char *localePrev;
  localePrev = setlocale(LC_ALL, NULL);
  setlocale(LC_ALL, "");
  
  char buffer[128];
  lconv *lc = localeconv();
  if (IS_LOC(LOCALE_SABBREVMONTHNAME13) || IS_LOC(LOCALE_SMONTHNAME13))
    strcpy(&buffer[0], ""); // no such concept or query
  else if (IS_LOC(LOCALE_SYEARMONTH)) // year month format string
    strcpy(&buffer[0], "MMMM, yyyy"); // no such thing, put default Win English
  else if (IS_LOC(LOCALE_SNEGATIVESIGN)) // negative sign
    strcpy(&buffer[0], lc->negative_sign);
  else if (IS_LOC(LOCALE_SPOSITIVESIGN)) // positive sign
    strcpy(&buffer[0], lc->positive_sign);
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME12)) // abbr name for December
    strcpy(&buffer[0], nl_langinfo(ABMON_12));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME11)) // abbr name for November
    strcpy(&buffer[0], nl_langinfo(ABMON_11));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME10)) // abbr name for October
    strcpy(&buffer[0], nl_langinfo(ABMON_10));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME9)) // abbr name for September
    strcpy(&buffer[0], nl_langinfo(ABMON_9));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME8)) // abbr name for August
    strcpy(&buffer[0], nl_langinfo(ABMON_8));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME7)) // abbr name for July
    strcpy(&buffer[0], nl_langinfo(ABMON_7));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME6)) // abbr name for June
    strcpy(&buffer[0], nl_langinfo(ABMON_6));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME5)) // abbr name for May
    strcpy(&buffer[0], nl_langinfo(ABMON_5));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME4)) // abbr name for April
    strcpy(&buffer[0], nl_langinfo(ABMON_4));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME3)) // abbr name for March
    strcpy(&buffer[0], nl_langinfo(ABMON_3));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME2)) // abbr name for February
    strcpy(&buffer[0], nl_langinfo(ABMON_2));
  else if (IS_LOC(LOCALE_SABBREVMONTHNAME1)) // abbr name for January
    strcpy(&buffer[0], nl_langinfo(ABMON_1));
  else if (IS_LOC(LOCALE_SMONTHNAME12)) // long name for December
    strcpy(&buffer[0], nl_langinfo(MON_12)); 
  else if (IS_LOC(LOCALE_SMONTHNAME11)) // long name for November
    strcpy(&buffer[0], nl_langinfo(MON_11));
  else if (IS_LOC(LOCALE_SMONTHNAME10)) // long name for October
    strcpy(&buffer[0], nl_langinfo(MON_10));
  else if (IS_LOC(LOCALE_SMONTHNAME9)) // long name for September
    strcpy(&buffer[0], nl_langinfo(MON_9));
  else if (IS_LOC(LOCALE_SMONTHNAME8)) // long name for August
    strcpy(&buffer[0], nl_langinfo(MON_8));
  else if (IS_LOC(LOCALE_SMONTHNAME7)) // long name for July
    strcpy(&buffer[0], nl_langinfo(MON_7));
  else if (IS_LOC(LOCALE_SMONTHNAME6)) // long name for June
    strcpy(&buffer[0], nl_langinfo(MON_6));
  else if (IS_LOC(LOCALE_SMONTHNAME5)) // long name for May
    strcpy(&buffer[0], nl_langinfo(MON_5));
  else if (IS_LOC(LOCALE_SMONTHNAME4)) // long name for April
    strcpy(&buffer[0], nl_langinfo(MON_4));
  else if (IS_LOC(LOCALE_SMONTHNAME3)) // long name for March
    strcpy(&buffer[0], nl_langinfo(MON_3));
  else if (IS_LOC(LOCALE_SMONTHNAME2)) // long name for February
    strcpy(&buffer[0], nl_langinfo(MON_2));
  else if (IS_LOC(LOCALE_SMONTHNAME1)) // long name for January
    strcpy(&buffer[0], nl_langinfo(MON_1));
  else if (IS_LOC(LOCALE_SABBREVDAYNAME7)) // abbreviated name for Sunday
    strcpy(&buffer[0], nl_langinfo(ABDAY_1));
  else if (IS_LOC(LOCALE_SABBREVDAYNAME6)) // abbreviated name for Saturday
    strcpy(&buffer[0], nl_langinfo(ABDAY_7));
  else if (IS_LOC(LOCALE_SABBREVDAYNAME5)) // abbreviated name for Friday
    strcpy(&buffer[0], nl_langinfo(ABDAY_6));
  else if (IS_LOC(LOCALE_SABBREVDAYNAME4)) // abbreviated name for Thursday
    strcpy(&buffer[0], nl_langinfo(ABDAY_5));
  else if (IS_LOC(LOCALE_SABBREVDAYNAME3)) // abbreviated name for Wednesday
    strcpy(&buffer[0], nl_langinfo(ABDAY_4));
  else if (IS_LOC(LOCALE_SABBREVDAYNAME2)) // abbreviated name for Tuesday
    strcpy(&buffer[0], nl_langinfo(ABDAY_3));
  else if (IS_LOC(LOCALE_SABBREVDAYNAME1)) // abbreviated name for Monday
    strcpy(&buffer[0], nl_langinfo(ABDAY_2));
  else if (IS_LOC(LOCALE_SDAYNAME7)) // long name for Sunday
    strcpy(&buffer[0], nl_langinfo(DAY_1));
  else if (IS_LOC(LOCALE_SDAYNAME6)) // long name for Saturday
    strcpy(&buffer[0], nl_langinfo(DAY_7));
  else if (IS_LOC(LOCALE_SDAYNAME5)) // long name for Friday
    strcpy(&buffer[0], nl_langinfo(DAY_6));
  else if (IS_LOC(LOCALE_SDAYNAME4)) // long name for Thursday
    strcpy(&buffer[0], nl_langinfo(DAY_5));
  else if (IS_LOC(LOCALE_SDAYNAME3)) // long name for Wednesday
    strcpy(&buffer[0], nl_langinfo(DAY_4));
  else if (IS_LOC(LOCALE_SDAYNAME2)) // long name for Tuesday
    strcpy(&buffer[0], nl_langinfo(DAY_3));
  else if (IS_LOC(LOCALE_SDAYNAME1)) // long name for Monday
    strcpy(&buffer[0], nl_langinfo(DAY_2));
  else if (IS_LOC(LOCALE_S2359)) // PM designator
    strcpy(&buffer[0], nl_langinfo(PM_STR));
  else if (IS_LOC(LOCALE_S1159)) // AM designator
    strcpy(&buffer[0], nl_langinfo(AM_STR));
  else if (IS_LOC(LOCALE_IDATE))
  {// Note, we assume LOCALE_RETURN_NUMBER is set in this case
    // from http://msdn.microsoft.com/en-us/library/dd373757(VS.85).aspx ,
    // available return values are:
    // 0 Month-Day-Year
    // 1 Day-Month-Year
    // 2 Year-Month-Day
    char *token = nl_langinfo(D_FMT);
    DWORD val = 0;
    if (strcmp(&token[1], "d") == 0 || strcmp(&token[1], "D") == 0)
      val = 1;
    if (strcmp(&token[1], "y") == 0 || strcmp(&token[1], "Y") == 0)
      val = 2;
    // no preflighting allowed for this value with LOCALE_RETURN_NUMBER
    lpLCData[0] = val;
    // restore previous locale
    setlocale(LC_ALL, localePrev);
    return sizeof(DWORD);
  }
  // long date format string or short date format string
  else if (IS_LOC(LOCALE_SLONGDATE) || IS_LOC(LOCALE_SSHORTDATE))
    strcpy(&buffer[0], nl_langinfo(D_FMT));
  else if (IS_LOC(LOCALE_SDATE)) // date separator
  {
    // we need to tokenize the string to find the first separator
    char token[80];
    strcpy(token, nl_langinfo(D_FMT));
    strtok(token, "%mMdDyYeE ");
    if (strlen(token) == 0 || strchr(token,'%') == NULL || // something went wrong, default to '/'
       (strcmp(&token[0], "/") != 0 && // it's not a known, acceptable value
        strcmp(&token[0], ".") != 0 && // some locales use different values
        strcmp(&token[0], "-") != 0) ) // for separators
    {
      strcpy(&buffer[0], "/");
    }
    else
    { // grab the separator token
      char tmp[2];
      tmp[0] = token[0];
      tmp[1] = '\0';
      strcpy(&buffer[0], tmp);
    }
  }
  else if (IS_LOC(LOCALE_SMONTHOUSANDSEP)) // monetary thousand separator
    strcpy(&buffer[0], lc->mon_thousands_sep);
  else if (IS_LOC(LOCALE_SMONDECIMALSEP)) //  monetary decimal separator
  { // Allow for English override to force dot separator
    if (Locale == 1033)
      strcpy(&buffer[0], ".");
    else  
      strcpy(&buffer[0], lc->mon_decimal_point);
  }
  else if (IS_LOC(LOCALE_SCURRENCY)) // local monetary symbol
    strcpy(&buffer[0], lc->currency_symbol);
  else if (IS_LOC(LOCALE_STHOUSAND)) // thousand separator (non-monetary)
    strcpy(&buffer[0], lc->thousands_sep);
  else if (IS_LOC(LOCALE_SDECIMAL)) // decimal separator (non-monetary)
  { // Allow for English override to force dot separator
    if (Locale == 1033)
      strcpy(&buffer[0], ".");
    else  
      strcpy(&buffer[0], lc->decimal_point);
  }  
  else // unknown
    strcpy(&buffer[0], "");

  // restore previous locale
  setlocale(LC_ALL, localePrev);
  
  if (preflight)
    return strlen(&buffer[0])+1;
 
  if ((int)strlen(&buffer[0]) + 1 > cchData)
    return ERROR_INSUFFICIENT_BUFFER;
  wcscpy(lpLCData, StrAdapter(&buffer[0]));
  return wcslen(lpLCData)+1;
}

/* GetNumberFormat
 * This function converts a numeric value string into a locale-specific string
 * representation.
 */
int WINAPI GetNumberFormat(LCID Locale, DWORD dwFlags, LPCTSTR lpValue,
                    const NUMBERFMT *lpFormat, LPTSTR lpNumberStr,
                    int cchNumber)
// Note, if you pass "00000000.0000", no trimming will take place.
// For example, you'll get back "00,000,000.0000" and not "0". 
// In other words, this function is mathematically ignorant; it only 
// performs the following checks, as mentioned on MSDN.
// The only valid characters consist of:
// Characters "0" through "9".
// One decimal point (dot) if the number is a floating-point value.
// A minus sign in the first character position if the number is negative.
{
  bool preflight = cchNumber == 0 ? true : false;
  
  bool negative = false;
  if ((WCHAR)*&lpValue[0] == (WCHAR)L'-')
    negative = true;
  WCHAR decimalSep[2];
  WCHAR thousandsSep[2];
  // get the standard separators, not the monetary ones.
  GetLocaleInfo(Locale, LOCALE_SDECIMAL , &decimalSep[0]  , 2 );
  GetLocaleInfo(Locale, LOCALE_STHOUSAND, &thousandsSep[0], 2 );
  
  //validate the string
  LPCTSTR tmpVal = lpValue;
  int decFound = 0;
  for (unsigned int i = 0; i < wcslen(lpValue); i++)
  {
    if (i == 0 && negative)
    { // we've already verified the L'-' comes first in this case
      continue;
    }
    if (
      (WCHAR)L'0' != (WCHAR)*&tmpVal[i] && (WCHAR)L'1' != (WCHAR)*&tmpVal[i] &&
      (WCHAR)L'2' != (WCHAR)*&tmpVal[i] && (WCHAR)L'3' != (WCHAR)*&tmpVal[i] &&
      (WCHAR)L'4' != (WCHAR)*&tmpVal[i] && (WCHAR)L'5' != (WCHAR)*&tmpVal[i] &&
      (WCHAR)L'6' != (WCHAR)*&tmpVal[i] && (WCHAR)L'7' != (WCHAR)*&tmpVal[i] &&
      (WCHAR)L'8' != (WCHAR)*&tmpVal[i] && (WCHAR)L'9' != (WCHAR)*&tmpVal[i]
       )
    { // it's not a numeric value, check decimal
      if ((WCHAR)L'.' == (WCHAR)*&tmpVal[i])
        decFound++;
      else // unknown value
        return ERROR_INVALID_PARAMETER;
    }
  }
  
  bool hasDecimal = decFound == 1 ? true : false;
  if (decFound > 1) // more than one decimal found, it's invalid
    return ERROR_INVALID_PARAMETER;
  
  // get the number of digits before the decimal, if there is one
  int numDigits = 0;
  if (!hasDecimal)
      numDigits = wcslen(lpValue);
  else
  {
    for (unsigned int i = 0; i < wcslen(lpValue); i++)
    {
      if ((WCHAR)*&tmpVal[i] == (WCHAR)L'.' )
        break;
      numDigits++;
    }
  }

  if (negative)
    numDigits--;
  
  // it's valid and we know what we need to now
  // start writing it out
  WCHAR result[512];
  LPTSTR resultPtr = &result[0];
  
  // handle negative value, if it is one
  if (negative)
  {
    *resultPtr = (WCHAR)L'-';
    resultPtr++;
    tmpVal++;
  }
  
  // handle all pre-decimal point digits
  for (int i = numDigits ; i > 0 ; i--)
  {
    if ( (i % 3) == 0 && // write separator every 3 digits
        i != numDigits &&  // but not here ",100.00"
        i != 1)            // and not here "100,.00"
    { // write a thousands separator
      *resultPtr = thousandsSep[0];
      resultPtr++;
    }
    *resultPtr = (WCHAR)*tmpVal; // write the numeric value
    resultPtr++;
    tmpVal++;
  }
  
  // handle the decimal and remaining digits
  if (hasDecimal)
  {
    *resultPtr = decimalSep[0];
    resultPtr++;
    tmpVal++; // go past the decimal
    while ((WCHAR)*tmpVal != (WCHAR)L'\0')
    {
      *resultPtr = *tmpVal;
      resultPtr++;
      tmpVal++;
    }
  }

  *resultPtr = *tmpVal; // write the teriminator
  
  // rewind resultPtr to the beginning of the value
  resultPtr = &result[0];
  
  // report back length if preflighting, if not, ensure we have sufficient buffer space
  int wCharsNeeded = wcslen(resultPtr)+1;

  if (preflight)
    return wCharsNeeded;

  if (wCharsNeeded > cchNumber)
    return ERROR_INSUFFICIENT_BUFFER;
  
  wcscpy(lpNumberStr, resultPtr);
  
  return wCharsNeeded;
}

/* IsLeapYear
 * Helper Function to determine if the argument year is a leap year.
 */
static bool IsLeapYear(WORD year)
{
  if (year % 400 == 0)
    return true;
  else if (year % 100 == 0)
    return false;
  else if (year % 4 == 0)
    return true;
  return false;
}

/* SystemTimeToTMStruct
 * This function converts SystemTime struct to a TM Struct.
 */
static void SystemTimeToTMStruct(const SYSTEMTIME *lpTime, struct tm* tms)
{
  INT DaysInMonth[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  if (IsLeapYear(lpTime->wYear))
    DaysInMonth[1] = 29;
  
  time_t tim = time(NULL);
  tms = localtime(&tim);
  tms->tm_sec  = lpTime->wSecond;
  tms->tm_min  = lpTime->wMinute;
  tms->tm_hour = lpTime->wHour;
  tms->tm_mday = lpTime->wDay;
  tms->tm_wday = lpTime->wDayOfWeek % 7; // ensure that Win day 7 maps to 0
  tms->tm_mon  = lpTime->wMonth-1; // Unix uses months 0-11, Windows 1-12
  tms->tm_year = lpTime->wYear-1900;

   // Unix uses days 0 - 365, so day 1 (Jan 1), is actually day 0.
  tms->tm_yday = tms->tm_mday-1;
  for (int i = 0; i < tms->tm_mon ; i++) // add up all the passed months
    tms->tm_yday += DaysInMonth[i];
  // ignore __tm_gmtoff, __hopefully__ it should be ignored for calculations
}

/* GetLocalTime
 * This function gets the local time in a SYSTEMTIME struct format.
 */
void WINAPI GetLocalTime(LPSYSTEMTIME lpSystemTime)
{
  time_t tim = time(NULL);
  struct tm* tms = localtime(&tim);
  lpSystemTime->wYear         = tms->tm_year+1900;
  lpSystemTime->wMonth        = tms->tm_mon+1;
  if (tms->tm_wday == 0)
    lpSystemTime->wDayOfWeek  = 7;
  else
    lpSystemTime->wDayOfWeek  = tms->tm_wday;
  lpSystemTime->wDay          = tms->tm_mday;
  lpSystemTime->wHour         = tms->tm_hour;
  lpSystemTime->wMinute       = tms->tm_min;
  lpSystemTime->wSecond       = tms->tm_sec;
  lpSystemTime->wMilliseconds = 0; // we can't get this resolution
}

/* GetDateTimeFormat
 * Helper function for GetTimeFormat and GetDateTimeFormat.
 */
static int GetDateTimeFormat(LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpTime,
                  LPCTSTR lpFormat, LPTSTR lpTimeStr, int cchTime, bool date)
{
  // Ignore lpFormat
  bool preflight = cchTime == 0 ? true : false;
  struct tm tms;
  SystemTimeToTMStruct(lpTime, &tms);
  char TimeFormat[128];

  // see http://www.opengroup.org/onlinepubs/000095399/functions/strftime.html
  if (date) // %Ex is locale-specific date
    strftime(&TimeFormat[0], 128, "%Ex", &tms);
  else      // %EX is locale-specific time
    strftime(&TimeFormat[0], 128, "%EX", &tms);
  
  int charsNeeded = (int)strlen(&TimeFormat[0])+1;
  if (preflight)
    return charsNeeded;
  if (cchTime < charsNeeded)
    return ERROR_INSUFFICIENT_BUFFER;
  wcscpy(lpTimeStr, StrAdapter(&TimeFormat[0]));
  return charsNeeded;
}

/* GetTimeFormat
 * This function formats time as a time string for a locale specified by 
 * identifier. The function formats either a specified time or the local 
 * system time.
 */
int WINAPI GetTimeFormat(LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpTime,
                  LPCTSTR lpFormat, LPTSTR lpTimeStr, int cchTime)
{
  return GetDateTimeFormat(Locale, dwFlags, lpTime, lpFormat,
                           lpTimeStr, cchTime, true /*call date version */ );
}

/* GetDateFormat
 * This function formats a date as a date string for a locale specified by the 
 * locale identifier. The function formats either a specified date or the local
 * system date.
 */
int WINAPI GetDateFormat(LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpDate,
                  LPCTSTR lpFormat, LPTSTR lpDateStr, int cchDate)
{
  return GetDateTimeFormat(Locale, dwFlags, lpDate, lpFormat,
                           lpDateStr, cchDate, false /*call time version */ );
}

/* GetFileAttributes
 * This function gets the file attributes of the specified file.
 */
DWORD WINAPI GetFileAttributes(LPCTSTR lpFileName)
{
  struct stat stat_buf;
  StrAdapter FileNameChar(lpFileName);
  int ret = stat(LPCSTR(FileNameChar), &stat_buf);
  DWORD attr=0;
  
  //File exists
  if (ret == -1)
    return INVALID_FILE_ATTRIBUTES;
  
  //Is file a dir
  if (S_ISDIR(stat_buf.st_mode))
    attr |= FILE_ATTRIBUTE_DIRECTORY;

  //Does it have read only permissions
  if (S_ISREG(stat_buf.st_mode))
    if (!(stat_buf.st_mode & S_IWUSR) || !(stat_buf.st_mode & S_IXUSR))
      attr |= FILE_ATTRIBUTE_READONLY;

  return attr;
}

/* GetCurrentProcess
 * This function is a no-op on Unix.
 */
HANDLE WINAPI GetCurrentProcess(void)
{
  return NULL;
}

/* TIME_ClockTimeToFileTime
 * Helper function used by GetProcessTimes.
 */
static void TIME_ClockTimeToFileTime(clock_t unix_time, LPFILETIME filetime)
{
    LONG clocksPerSec = sysconf(_SC_CLK_TCK);
    ULONGLONG secs = (ULONGLONG)unix_time * 10000000 / clocksPerSec;
    filetime->dwLowDateTime  = (DWORD)secs;
    filetime->dwHighDateTime = (DWORD)(secs >> 32);
}

/* GetProcessTimes
 * This function retrieves timing information for the specified process.
 */
BOOL WINAPI GetProcessTimes( HANDLE hprocess, LPFILETIME lpCreationTime,
    LPFILETIME lpExitTime, LPFILETIME lpKernelTime, LPFILETIME lpUserTime )
{
    struct tms tmsi;

    times(&tmsi);
    TIME_ClockTimeToFileTime(tmsi.tms_utime,lpUserTime);
    TIME_ClockTimeToFileTime(tmsi.tms_stime,lpKernelTime);

    /* Todo: Gather process creation time and exit time */
    return TRUE;
}

/* _wsetlocale
 * This function sets the specified locale.
 */
wchar_t WINAPI *_wsetlocale(int category, const wchar_t *locale)
{
  StrAdapter localeChar(locale);
  char *temp = setlocale(category, LPCSTR(localeChar));

  StrAdapter retChar(temp);

  return((wchar_t *)LPCWSTR(retChar));

}

/* PathAddforwardslashW
 * This function adds a forward slash to the argument.
 */
LPWSTR WINAPI PathAddforwardslashW( LPWSTR lpszPath )
{
  size_t iLen;

  if (!lpszPath || (iLen = wcslen(lpszPath)) >= MAX_PATH)
    return NULL;

  if (iLen)
  {
    lpszPath += iLen;
    if (lpszPath[-1] != '/')
    {
      *lpszPath++ = '/';
      *lpszPath = '\0';
    }
  }
  return lpszPath;
}

/* PathCombineW
 * This function combines two paths.
 */
LPTSTR WINAPI PathCombineW(LPTSTR lpszDest, LPCTSTR lpszDir, LPCTSTR lpszFile)
{

  WCHAR szTemp[MAX_PATH];
  BOOL bUseBoth = FALSE, bStrip = FALSE;
  /* Invalid parameters */
  if (!lpszDest)
    return NULL;
  if (!lpszDir && !lpszFile)
  {
    lpszDest[0] = 0;
    return NULL;
  }

  if ((!lpszFile || !*lpszFile) && lpszDir)
  {
    /* Use dir only */
    wcsncpy(szTemp, lpszDir, MAX_PATH);
  }
  else if (!lpszDir || !*lpszDir)
  {
      /* Use file only */
      wcsncpy(szTemp, lpszFile, MAX_PATH);
  }
  else
  {
    bUseBoth = TRUE;
    if (*lpszFile == '/')
      bStrip = TRUE;
  }

  if (bUseBoth)
  {
    wcsncpy(szTemp, lpszDir, MAX_PATH);
    if (bStrip)
    {
      lpszFile++; /* Skip '/' */
    }
    if (!PathAddforwardslashW(szTemp) || wcslen(szTemp) + wcslen(lpszFile) >= MAX_PATH)
    {
      lpszDest[0] = 0;
      return NULL;
    }
    wcscat(szTemp, lpszFile);
  }
  wcsncpy(lpszDest, szTemp, MAX_PATH);
  return lpszDest;

}

/* PathFileExistsW
 * This function determines if the file exists.
 */
BOOL WINAPI PathFileExistsW(LPCTSTR pszPath)
{
  struct stat stat_buf;
  StrAdapter fileNameChar(pszPath);
  int ret = stat(LPCSTR(fileNameChar), &stat_buf);
  if (ret != -1)
    return true;
  else
    return false;
  
}

/* PathFileExistsA
 * This function determines if the file exists.
 */
BOOL WINAPI PathFileExistsA(LPCSTR lpszPath)
{
  struct stat stat_buf;
  int ret = stat(lpszPath, &stat_buf);
  if (ret != -1)
    return true;
  else
    return false;
  
}

/* GetModuleFileName
 * This function retrieves the fully-qualified path for the file that contains
 * the specified module.
 */
DWORD WINAPI GetModuleFileName(HMODULE hModule, LPTSTR lpFilename, DWORD nSize)
{
#ifndef __APPLE__
  struct link_map *lm;
  dlinfo((void *)hModule, RTLD_DI_LINKMAP, &lm);
  if (lm)
  {
    StrAdapter str1(lm->l_name);
    DWORD size = strlen(lm->l_name);
    wcsncpy(lpFilename, StrAdapter(lm->l_name), nSize);
    return size;
  }
  hModule = NULL;
#else
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  lpFilename = NULL;
#endif
  return 0;
}

/* IsCharAlphaNumeric
 * This function determines if the TCHAR is alpha-numeric.
 */
BOOL WINAPI IsCharAlphaNumeric(TCHAR ch)
{

  if (isalnum(ch))
    return true;
  else
    return false;

}

/* PathFindExtensionW
 * This function searches the path for an extension. It returns a pointer to the
 * '.' if found or a pointer to the NULL terminator if not found.
 */
LPWSTR WINAPI PathFindExtensionW( LPCWSTR lpszPath )
{
  LPCWSTR end = NULL;

  if (lpszPath)
  {
    while (*lpszPath)
    {
      if (*lpszPath == '\\' || *lpszPath==' ')
        end = NULL;
      else if (*lpszPath == '.')
        end = lpszPath;
      lpszPath++;
    }
  }
  return (LPWSTR)(end ? end : lpszPath);
}

/* PathFindFileNameW
 * This function searches the path for a file name. It returns a pointer to the
 * string if found or a pointer to the start of lpszPath if not found.
 */
LPWSTR WINAPI PathFindFileNameW(LPCWSTR lpszPath)
{
  LPCWSTR Slash = lpszPath;

  while (lpszPath && *lpszPath)
  {
    if ((*lpszPath == '\\' || *lpszPath == '/' || *lpszPath == ':') &&
        lpszPath[1] && lpszPath[1] != '\\' && lpszPath[1] != '/')
      Slash = lpszPath + 1;
    lpszPath++;
  }
  return (LPWSTR)Slash;
}

/* PathRemoveExtensionW
 * This function removes the extension from the argument passed in.
 */
void WINAPI PathRemoveExtensionW(LPTSTR pszPath)
{

  LPWSTR lastpoint = NULL;
  if (pszPath)
  {
    while (*pszPath)
    {
      if (*pszPath == '\\' || *pszPath=='/')
        lastpoint = NULL;
      else if (*pszPath == '.')
        lastpoint = pszPath;
      pszPath++;
    }
  }
  
  //*pszPath = '\0';
  *lastpoint = '\0';
  return;
}

/* PathRemoveFileSpecW
 * This function removes the trailing file name and backslash from a path,
 * if they are present.
 */
BOOL WINAPI PathRemoveFileSpecW(LPWSTR pszPath)
{
  LPWSTR pszFileSpec = pszPath;
  BOOL bModified = FALSE;

  if(pszPath)
  {
    /* Skip directory or UNC path */
    if (*pszPath == '\\')
      pszFileSpec = ++pszPath;
    if (*pszPath == '\\')
      pszFileSpec = ++pszPath;
    if (*pszPath == '/')
      pszFileSpec = ++pszPath;

    while (*pszPath)
    {
      if(*pszPath == '\\')
        pszFileSpec = pszPath; /* Skip dir */
      if(*pszPath == '/')
        pszFileSpec = pszPath; /* Skip dir */
      else if(*pszPath == ':')
      {
        pszFileSpec = ++pszPath; /* Skip drive */
        if (*pszPath == '\\')
          pszFileSpec++;
      }
      pszPath++;
    }

    if (*pszFileSpec)
    {
      *pszFileSpec = '\0';
      bModified = TRUE;
    }
  }
  return bModified;
}

/* IsDigit(char)
 * This function determines if the argument is a digit or not.
 */
bool WINAPI IsDigit(const char *a) 
{ 
  return (*a > 47 && *a < 58) ? true : false; 
}

/* isdigitW(WCHAR)
 * This function determines if the argument is a digit or not.
 */
bool WINAPI isdigitW(const WCHAR chr)
{
  WCHAR tmp[2];
  tmp[0] = chr;
  tmp[1] = 0;
  StrAdapter wide(&tmp[0]);
  const char *ansi = wide;
  return IsDigit(ansi);
}

/* strtoulW
 * This function convert strings to an unsigned long-integer value.
 */
ULONG WINAPI strtoulW(WCHAR *a, WCHAR **b, int base)
{
  return wcstoul(a, b, base);
}

/* isspaceW
 * This function determines if the argument is a space.
 */
bool WINAPI isspaceW(const WCHAR chr)
{
  WCHAR tmp[2];
  tmp[0] = chr;
  tmp[1] = 0;
  return wcscmp(&tmp[0], L" ") == 0 ? true : false; 
}

/* SetErrorInfo
 * This function is a no-op.
 */
HRESULT WINAPI SetErrorInfo(DWORD  dwReserved, IErrorInfo  *perrinfo)
{// No stored COM error state support
  return S_OK;
}

/* GetErrorInfo
 * This function is a no-op.
 */
HRESULT WINAPI GetErrorInfo(DWORD  dwReserved, IErrorInfo  **pperrinfo)
{ // No stored COM error state support
  *pperrinfo = NULL;
  return S_FALSE;
}

/* _tcstok
 * This function tokenizes a WCHAR* string.
 */
WCHAR WINAPI *_tcstok(WCHAR* wcs, const WCHAR* del)
{ // if first arg is valid, start scanning. Otherwise, continue scanning.
  // TODO - This is not thread safe.
  static WCHAR* internalPtr;
  if (wcs)
    internalPtr = 0;
 
  return wcs ? wcstok(wcs, del, &internalPtr) : wcstok(NULL, del, &internalPtr);
}

/* _wtoi64
 * This function converts a string to a 64-bit integer.
 */
__int64 WINAPI _wtoi64(const wchar_t *_Str)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* _wcsncoll
 * This function compares strings using locale-specific information.
 */
int WINAPI _wcsncoll(const wchar_t *str1, const wchar_t *str2, size_t count)
{
  FileGDBAPI_TRACE("Partially implemented function called:", __FUNCTION__);
  return wcsncmp(str1, str2, count);  // todo: implement locale-sensitive compare
}

/* _wcsnicoll
 * This function compares strings using locale-specific information.
 */
int WINAPI _wcsnicoll(const wchar_t *str1, const wchar_t *str2, size_t count)
{
  FileGDBAPI_TRACE("Partially implemented function called:", __FUNCTION__);
  return wcsncasecmp(str1, str2, count);  // todo: implement locale-sensitive compare
}

/* _wcsicoll
 * This function compares strings using locale-specific information.
 */
int WINAPI _wcsicoll(const wchar_t *str1, const wchar_t *str2)
{
  FileGDBAPI_TRACE("Partially implemented function called:", __FUNCTION__);
  return wcscasecmp(str1, str2);  // todo: implement locale-sensitive compare
}

/* _fpreset
 * This function is a no-op on Unix.
 */
void WINAPI _fpreset()
{
  // This function resets the floating point math package on windows but nothing to do on unix
}

/* _wmakepath
 * This function creates a path name from the components.
 */
void WINAPI _wmakepath(wchar_t *path, const wchar_t *drive, const wchar_t *dir, const wchar_t *fname, const wchar_t *ext)
{
  wcscpy(path, L"");
  // add dir to path
  if(dir)
  {
    wcscat(path, dir);

    // if path does not end in '/', add it
    size_t len = wcslen(dir);
    if(len > 0 && dir[len - 1] != L'/')
      wcscat(path, L"/");
  }

  // add fname to path
  if(fname)
    wcscat(path, fname);

  // add ext to path
  if(ext)
  {
    // if ext does not begin with '.', add it
    if(ext[0] != L'.')
      wcscat(path, L".");
    wcscat(path, ext);
  }
}

/* _wsplitpath
 * This function breaks a path name into its components. We support folders
 * with dots in them.
 */
void WINAPI _wsplitpath(const wchar_t *path, wchar_t *drive, wchar_t *dir, wchar_t *fname, wchar_t *ext)
//see http://msdn.microsoft.com/en-us/library/e737s6tf(v=VS.90).aspx
{
  // From MSDN, dots in path are not allowed. However on Unix 
  // paths are common using "/../" and so must be supported.

  if (drive)
    wcscpy(drive, L""); // not supported on Unix
  if (dir)
    wcscpy(dir, L"");
  if (fname)
    wcscpy(fname, L"");
  if (ext)
    wcscpy(ext, L"");

  if (!path)
    return;

  bool containsSlashes = false;
  // hasExtension only applies to a proper extension, which must be
  // distinguished from a folder with dots.
  bool hasExtension    = false;
  
  const wchar_t *dot = L".";
  const wchar_t *slash = L"/";

  if (wcspbrk(path, slash) != NULL)
    containsSlashes = true;

  if (dir)
  {
    if (containsSlashes)
    {// directory must contain slashes
      const wchar_t *pathEnd = wcsrchr(path, slash[0]);
      size_t len = pathEnd-path; // this will be in wchar_t's
      wmemcpy(dir, path, len+1);
      dir[len+1] = L'\0';
    }
  } // dir
  
  if (fname || ext) // we need to find if fname has a dot/ext
  {
    const wchar_t *fNameTmp = path;
    if (containsSlashes) // skip all slashes
    {
      fNameTmp = wcsrchr(path, slash[0]);
      fNameTmp++; // move past the last slash
    }
    
    if (wcsrchr(fNameTmp, dot[0]) != NULL)
      hasExtension = true;
    
    if (fname)
    {
      if (hasExtension)
      {
        const wchar_t *lastDot = wcsrchr(path, dot[0]);
        size_t len = lastDot-fNameTmp;
        wmemcpy(fname, fNameTmp, len);
        fname[len] = L'\0';
      }
      else
        wcscpy(fname,fNameTmp);
    }
  } // fname || ext

  if (ext)
  {
    if (hasExtension)
    { // we distinguish in fname between dots in paths and a valid ext
      const wchar_t *extTmp = wcsrchr(path, dot[0]); // skip to last dot
      wcscat(ext, extTmp);
    }
  } // ext
}

/* _wfullpath
 * This function creates an absolute or full path name for the specified 
 * relative path name.
 */
wchar_t WINAPI *_wfullpath(wchar_t *absPath, const wchar_t *relPath, size_t maxLength)
{
  if (relPath[0] != L'/')
  {
    char tmpBuf[2048];
    getcwd(tmpBuf, 2048);
    wcscpy(absPath, StrAdapter(tmpBuf));
    wcscat(absPath, L"/");
    wcscat(absPath, relPath);
  } 
  else
  {
    wcscpy(absPath, relPath);
  }
  return absPath;
}

/* wcsftime
 * This function is unimplemented.
 */
#ifdef LINUX_CLANG
size_t WINAPI wcsftime(wchar_t *strDest, size_t maxsize, const wchar_t *format, const struct tm *timeptr) throw()
#else
size_t WINAPI wcsftime(wchar_t *strDest, size_t maxsize, const wchar_t *format, const struct tm *timeptr)
#endif
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* CloseHandle
 * This function is unimplemented.
 */
BOOL WINAPI CloseHandle(HANDLE hObject)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* OpenProcess
 * This function is unimplemented.
 */
HANDLE WINAPI OpenProcess(DWORD dwDesiredAccess, BOOL bInheritHandle, DWORD dwProcessId)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* GetModuleFileNameExA
 * This function is unimplemented.
 */
DWORD WINAPI GetModuleFileNameExA(HANDLE hProcess, HMODULE hModule, LPSTR lpFilename, DWORD nSize)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* GetModuleFileNameExW
 * This function is unimplemented.
 */
DWORD WINAPI GetModuleFileNameExW(HANDLE hProcess, HMODULE hModule, LPWSTR lpFilename, DWORD nSize)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* _filelengthi64
 * Gets the length of a file. Requires that large file support be compiled in so that off_t is
 * 64-bits wide even on 32-bit Linux.
 */
__int64 WINAPI _filelengthi64(int fd)
{
  struct stat buf;
  if (fstat(fd, &buf) == 0)
    return (__int64)buf.st_size;

  return (__int64)-1;
}

/* _filelength
 * Gets the length of a file.
 */
int WINAPI _filelength(int fd)
{
  struct stat buf;
  if (fstat(fd, &buf) == 0)
    return (int)buf.st_size;

  return -1;
}

/* LoadStringW
 * This function is unimplemented.
 */
int WINAPI LoadStringW(HINSTANCE hInstance, UINT uID, LPWSTR lpBuffer, int cchBufferMax)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* LocalFree
 * This function is unimplemented.
 */
HANDLE WINAPI LocalFree(HANDLE hMem)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* _wcsinc
 * This function advances a string pointer by one character.
 */
const wchar_t WINAPI *_wcsinc(const wchar_t *current)
{
  current++;
  return current;
}

/* _vstprintf
 * This function writes formatted output using a pointer to a list of 
 * arguments.
 */
int WINAPI _vstprintf(wchar_t *buffer, size_t maxLen, const wchar_t *lpszFormat, va_list argptr)
{
#if defined UNICODE || defined _UNICODE
  int numStrs = 0;
  for (size_t i = 0; i < wcslen(lpszFormat); i++)
  { // count the number of strings so we don't have to 
    // malloc tons of spacing for not knowing
    if (lpszFormat[i] == L'%')
    {
      if (lpszFormat[i+1] == L's')
        numStrs++; // found a "%s", count it
    }
  }
  
  LPWSTR lpszFormatUnix = 0;
  if (numStrs != 0)
  {
    lpszFormatUnix = (LPWSTR)malloc((wcslen(lpszFormat)*sizeof(WCHAR)) 
                 + sizeof(WCHAR) + (numStrs*sizeof(WCHAR)));
  
    const WCHAR *longStr = L"l";
    LPWSTR lpszFormatUnixTmp = lpszFormatUnix;
    LPCWSTR lpszFormatTmp = lpszFormat;
    // find and replace every "%s" with "%ls"
    for (size_t i = 0; i <= wcslen(lpszFormat); i++) // even copy the null
    {
      if (lpszFormatTmp[0] == L'%')
      {
        wmemcpy(lpszFormatUnixTmp, lpszFormatTmp, 1);
        lpszFormatUnixTmp++;
        lpszFormatTmp++;
        if (lpszFormatTmp[0] == L's')
        {
          wmemcpy(lpszFormatUnixTmp, longStr, 1);
          lpszFormatUnixTmp++;
          wmemcpy(lpszFormatUnixTmp, lpszFormatTmp, 1);
          lpszFormatUnixTmp++;
          lpszFormatTmp++;
          i++; // we copied two this time
          continue;
        }
        continue;
      }
      wmemcpy(lpszFormatUnixTmp, lpszFormatTmp, 1);
      lpszFormatUnixTmp++;
      lpszFormatTmp++;
    }
#ifdef __APPLE__ // OS X vswprintf will fail with UNICODE without the locale set
    char *localePrev;
    localePrev = setlocale(LC_ALL, NULL);
    setlocale(LC_ALL, "");
#endif
    vswprintf(buffer, maxLen, lpszFormatUnix, argptr);
#ifdef __APPLE__
    setlocale(LC_ALL, localePrev);
#endif
    if (lpszFormatUnix)
      free(lpszFormatUnix);
  }
  else // no strings to convert
#endif // if it's not UNICODE or has no strings, then convert nothing
    vswprintf(buffer, maxLen, lpszFormat, argptr);

  return 0;
}

/* swscanf_s
 * This function is not implemented.
 */
int WINAPI swscanf_s(const wchar_t *buffer, const wchar_t *format, ...)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* GetCommandLineW
 * This function is not implemented.
 */
LPWSTR WINAPI GetCommandLineW(void)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* CommandLineToArgvW
 * This function is not implemented.
 */
LPWSTR WINAPI *CommandLineToArgvW(LPCWSTR lpCmdLine, int *pNumArgs)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* _wcsupr
 * This function is not implemented.
 */
wchar_t WINAPI *_wcsupr( wchar_t *string )
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* FormatMessage
 * This function is not implemented.
 */
DWORD WINAPI FormatMessage(
        DWORD dwFlags,
        LPCVOID lpSource,
        DWORD dwMessageId,
        DWORD dwLanguageId,
        LPTSTR lpBuffer,
        DWORD nSize,
        va_list *Arguments
)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* ProgIDFromCLSID
 * This function is not implemented.
 */
HRESULT WINAPI ProgIDFromCLSID(REFCLSID clsid, LPOLESTR *lplpszProgID)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* CreateErrorInfo
 * This function is not implemented.
 */
HRESULT WINAPI CreateErrorInfo(ICreateErrorInfo** pperrinfo)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* GetUserDefaultUILanguage
 * This function is not implemented.
 */
LANGID WINAPI GetUserDefaultUILanguage(void)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* SetThreadUILanguage
 * This function is not implemented.
 */
LANGID WINAPI SetThreadUILanguage(LANGID LangId)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* GetUserDefaultLangID
 * This function is not implemented.
 */
LANGID WINAPI GetUserDefaultLangID(void)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* SetThreadLocale
 * This function is not implemented.
 */
BOOL WINAPI SetThreadLocale(LCID Locale)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* GetLongPathName
 * This function is not implemented.
 */
DWORD WINAPI GetLongPathName(LPCTSTR lpszShortPath, LPTSTR lpszLongPath, DWORD cchBuffer)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* wcsnicmp
 * This function is not implemented.
 */
int WINAPI wcsnicmp(const wchar_t *string1, const wchar_t *string2, size_t count)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* PathRenameExtension
 * This function is not implemented.
 */
BOOL WINAPI PathRenameExtension(LPTSTR pszPath, LPCTSTR pszExt)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* WinHelpW
 * This function is not implemented.
 */
BOOL WINAPI WinHelpW(HWND hWndMain, LPCTSTR lpszHelp, UINT uCommand, ULONG_PTR dwData)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* HtmlHelpW
 * This function is not implemented.
 */
HWND WINAPI HtmlHelpW(HWND hwndCaller, LPCWSTR pszFile, UINT uCommand, DWORD_PTR dwData)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* EnumSystemLocales
 * This function is not implemented.
 */
BOOL WINAPI EnumSystemLocales(LOCALE_ENUMPROC lpLocaleEnumProc, DWORD dwFlags)
{
  FileGDBAPI_TRACE("Unimplemented function called:", __FUNCTION__);
  return 0;
}

/* CoGetClassObject
 * This function should never be called.
 */
HRESULT WINAPI CoGetClassObject(REFCLSID rclsid, DWORD dwClsContext, COSERVERINFO *pServerInfo, REFIID riid, LPVOID *ppv)
{
  FileGDBAPI_TRACE("ERROR: This function should never be called:", __FUNCTION__);
  return E_FAIL;
}

/* CoCreateInstance
 * This function should never be called.
 */
HRESULT WINAPI CoCreateInstance(REFCLSID rclsid, LPUNKNOWN pUnkOuter, DWORD dwClsContext, REFIID riid, LPVOID *ppv)
{
  FileGDBAPI_TRACE("ERROR: This function should never be called:", __FUNCTION__);
  return E_FAIL;
}

/* replace_all
 * This function is a helper function for internal regex support.
 */
static void replace_all(std::string & str, const std::string & from, const std::string & to)
{
  std::string::size_type pos = 0;
  while((pos = str.find(from, pos)) != std::string::npos)
  {
    str.replace(pos, from.size(), to);
    pos += to.size();
  }
}

/* EscapeRegex
 * This function is a helper function for internal regex support.
 */
static void EscapeRegex(std::string &regex) {
  replace_all(regex, std::string("\\"), std::string("\\\\"));
  replace_all(regex, std::string("^"), std::string("\\^"));
  replace_all(regex, std::string("."), std::string("\\."));
  replace_all(regex, std::string("$"), std::string("\\$"));
  replace_all(regex, std::string("("), std::string("\\("));
  replace_all(regex, std::string(")"), std::string("\\)"));
  replace_all(regex, std::string("["), std::string("\\["));
  replace_all(regex, std::string("]"), std::string("\\]"));
  replace_all(regex, std::string("*"), std::string("\\*"));
  replace_all(regex, std::string("+"), std::string("\\+"));
  replace_all(regex, std::string("?"), std::string("\\?"));
}

struct WINAPI FindFile
{
  DIR *dir;
#if defined(__clang__) || (_MSC_VER > 1800) || (GCC_VERSION >= 40900)
  std::regex mask;
#else
  boost::regex mask;
#endif
  FindFile():dir(0){}
  ~FindFile(){if (dir) closedir(dir);}
};

/* FindFirstFile
 * This function searches a directory for a file or subdirectory with a name 
 * that matches a specific name (or partial name if wildcards are used).
 */
HANDLE WINAPI FindFirstFile(LPCTSTR lpFileName, LPWIN32_FIND_DATA lpFindFileData)
// WARNING - This function is only implemented to the extent that we need
// it to work for the FileGDB API. The only fields that it look for are:
// 1: FileName and 2: Attributes. The only attributes it cares about are
// is it a directory, and everything else is considered 'not a directory'.
// All other fields in the WIN32_FIND_DATA structure are completely ignored.
{
  FindFile* ff = new FindFile;
  wchar_t fullpath[256];
  wchar_t extension[256];
  wchar_t searchTerm[256];
  _wsplitpath(lpFileName, NULL, fullpath, searchTerm, extension);
  wcscat(searchTerm, extension);

  ff->dir = opendir(StrAdapter(fullpath));
  if (ff->dir == NULL)
  {
    delete ff;
    return INVALID_HANDLE_VALUE;
  }
  
  // get the first entry.
  struct dirent *entry; 
  entry = readdir(ff->dir);

  std::string StdSearch((LPCSTR)StrAdapter(searchTerm));
  EscapeRegex(StdSearch);
  replace_all(StdSearch, "\\*", ".*");
  replace_all(StdSearch, "\\?", ".");

#if defined(__clang__) || (_MSC_VER > 1800) || (GCC_VERSION >= 40900)
  std::regex e(StdSearch, std::regex_constants::icase);
#else
  boost::regex e(StdSearch, boost::regex_constants::icase);
#endif

  bool foundMatch = false;
  // Logic to find first match. Should also handle dots correctly
  while (!foundMatch && entry)
  {
    foundMatch = regex_match( std::string(entry->d_name), e );
    if (!foundMatch)
      entry = readdir(ff->dir);
  }
  
  // check to see if there were no matches
  if (!foundMatch)
  {
    delete ff;
    return INVALID_HANDLE_VALUE;
  }

  // Store the mask
  ff->mask = e;
  
  // found a match
  wcscpy(lpFindFileData->cFileName, StrAdapter(entry->d_name));
  if (entry->d_type == DT_DIR)
    lpFindFileData->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
  else // directories and !directories are the only distinction we need
    lpFindFileData->dwFileAttributes = FILE_ATTRIBUTE_NORMAL;
  return (HANDLE)ff;
}

/* FindNextFile
 * This function continues a file search from a previous call to the 
 * FindFirstFile function.
 */
BOOL WINAPI FindNextFile(HANDLE hFindFile, LPWIN32_FIND_DATA lpFindFileData)
{
  FindFile *ff = (FindFile*)hFindFile;
  struct dirent *entry; 
  entry = readdir(ff->dir);
  
  bool foundMatch = false;
  while (!foundMatch && entry)
  {
    foundMatch = regex_match( std::string(entry->d_name), ff->mask );
    if (!foundMatch)
      entry = readdir(ff->dir);
  }
  
  // found a match
  if (foundMatch)
  {
    wcscpy(lpFindFileData->cFileName, StrAdapter(entry->d_name));
    if (entry->d_type == DT_DIR)
      lpFindFileData->dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
    else // directories and !directories are the only distinction we need
      lpFindFileData->dwFileAttributes = FILE_ATTRIBUTE_NORMAL;
    return TRUE;
  }

  return FALSE;
}

/* FindClose
 * This function closes a file search handle opened by the FindFirstFile.
 */
BOOL WINAPI FindClose(HANDLE hFindFile)
{
  FindFile *ff = (FindFile*)hFindFile;
  delete ff; // destructor calls closedir
  return TRUE;
}

/* _waccess
 * This function determines the specified access for a specified file or 
 * directory. Return 0 on success or -1 on failure.
 */
int WINAPI _waccess(const wchar_t *path, int mode)
{
  // Windows flags from MSDN:
  // 00 - Existence only
  // 02 - Write-only
  // 04 - Read only
  // 06 - Read and Write
  if (!path)
    return -1;

  if (wcslen(path) == 0)
    return -1;

  switch (mode)
  {
    case 0: // exists
    {
      return access(StrAdapter(path), F_OK);
    }
    case 2: // write only
    {
      if (access(StrAdapter(path), W_OK) == 0 &&
          access(StrAdapter(path), R_OK) == -1)
        return 0;
    
      return -1;
    }
    case 4: // read only
    {
      if (access(StrAdapter(path), R_OK) == 0 &&
          access(StrAdapter(path), W_OK) == -1)
        return 0;
    
      return -1;
    }
    case 6: // read and write
    {
      return (StrAdapter(path), R_OK|W_OK);
    }
    default:
    {
      return -1;
    }
  }
}

/* _getcwd
 * returns the current working directory, or null on error.
 */
char WINAPI *_getcwd(char *buffer, int maxlen)
{
  return getcwd(buffer, (size_t)maxlen);
}

/* _wgetcwd
 * returns the current working directory, or null on error.
 */
wchar_t WINAPI *_wgetcwd(wchar_t *buffer, int maxlen)
{
  char cwd[MAX_PATH] = {0};
  if (getcwd(cwd, (size_t)maxlen) == NULL)
    return NULL;

  wcscpy(buffer, StrAdapter(cwd));
  return buffer;
}

#define FACILITY_WIN32                   7
HRESULT WINAPI HRESULT_FROM_WIN32(ULONG x) { return (HRESULT)(x) <= 0 ? (HRESULT)(x) : (HRESULT) (((x) & 0x0000FFFF) | (FACILITY_WIN32 << 16) | 0x80000000);}

/*
 * Unicode UTF-8 helper conversion routines
 */

/* str_utf8_to_uni
 * This function converts unicode char* to wchar_t*.
 */
int EXPORT str_utf8_to_uni (wchar_t *target, const char *source, int n)
{
   register wchar_t *    t = target;
   register const char * s = source;

   if (target == NULL)
      return (0);

   if (source == NULL)
   {
      *target = 0;
      return (0);
   }

   {
      typedef enum chartype
         { REG, OPEN1, OPEN2, OPEN3, CONT, INVALID } CHARTYPE;
      typedef enum state
         { NORMAL, INSEQ } STATE;

      wchar_t  bad_char  = '?';
      STATE    state     = NORMAL;
      int      current   = 0;
      int      need      = 0;

#     define RESET()  state = NORMAL; current = 0; need = 0

      for (; n && *s; s++)
      {
         int        c = *((const unsigned char *)s);
         CHARTYPE   char_type;

         if      ((c & 0x80) == 0x00) char_type = REG;
         else if ((c & 0xe0) == 0xc0) char_type = OPEN1;
         else if ((c & 0xf0) == 0xe0) char_type = OPEN2;
         else if ((c & 0xf8) == 0xf0) char_type = OPEN3;
         else if ((c & 0xc0) == 0x80) char_type = CONT;
         else                         char_type = INVALID;

         switch (char_type)
         {
         case REG:
            if (state == NORMAL)
            {
               *t++ = (wchar_t)c;
            }
            else
            {
               *t++ = bad_char;
               RESET();
            }
            break;

         case OPEN1:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x1f;
               need    = 1;
            }
            else
            {
               *t++ = bad_char;
               RESET();
            }
            break;

         case OPEN2:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x0f;
               need    = 2;
            }
            else
            {
               *t++ = bad_char;
               RESET();
            }
            break;

         case OPEN3:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x07;
               need    = 3;
            }
            else
            {
               *t++ = bad_char;
               RESET();
            }
            break;

         case CONT:
            if (state == INSEQ)
            {
               c &= 0x3f;
               current = (current << 6) | c;
               if (--need == 0)
               {
                  *t++ = (wchar_t)current;
                  RESET();
               }
            }
            break;

         case INVALID:
            *t++ = bad_char;
            RESET();
            break;
         }
      }

#     undef RESET

      *t = 0;
   }

   return (int)(t - target);
}

/* str_utf8_to_uni
 * This function converts unicode char* to wchar_t* while allowing a partial
 * extraction.
 */
int EXPORT str_utf8_to_uni (wchar_t *target, const char *source, int n, int scan)
{ // only converts the amount of characters requested and does not add null
   register wchar_t *    t = target;
   register const char * s = source;

   if (target == NULL)
      return (0);

   if (source == NULL || scan <= 0)
   {
      *target = 0;
      return (0);
   }

   {
      typedef enum chartype
         { REG, OPEN1, OPEN2, OPEN3, CONT, INVALID } CHARTYPE;
      typedef enum state
         { NORMAL, INSEQ } STATE;

      wchar_t  bad_char  = '?';
      STATE    state     = NORMAL;
      int      current   = 0;
      int      need      = 0;

#     define RESET()  state = NORMAL; current = 0; need = 0

      for (int i = 0; n && (i < scan); i++, s++)
      {
         int        c = *((const unsigned char *)s);
         CHARTYPE   char_type;

         if      ((c & 0x80) == 0x00) char_type = REG;
         else if ((c & 0xe0) == 0xc0) char_type = OPEN1;
         else if ((c & 0xf0) == 0xe0) char_type = OPEN2;
         else if ((c & 0xf8) == 0xf0) char_type = OPEN3;
         else if ((c & 0xc0) == 0x80) char_type = CONT;
         else                         char_type = INVALID;

         switch (char_type)
         {
         case REG:
            if (state == NORMAL)
            {
               *t++ = (wchar_t)c;
            }
            else
            {
               *t++ = bad_char;
               RESET();
            }
            break;

         case OPEN1:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x1f;
               need    = 1;
            }
            else
            {
               *t++ = bad_char;
               RESET();
            }
            break;

         case OPEN2:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x0f;
               need    = 2;
            }
            else
            {
               *t++ = bad_char;
               RESET();
            }
            break;

         case OPEN3:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x07;
               need    = 3;
            }
            else
            {
               *t++ = bad_char;
               RESET();
            }
            break;

         case CONT:
            if (state == INSEQ)
            {
               c &= 0x3f;
               current = (current << 6) | c;
               if (--need == 0)
               {
                  *t++ = (wchar_t)current;
                  RESET();
               }
            }
            break;

         case INVALID:
            *t++ = bad_char;
            RESET();
            break;
         }
      }
#     undef RESET
   }
   return (int)(t - target);
}

/* str_uni_to_utf8
 * This function converts unicode wchar_t* to char*.
 */
int EXPORT str_uni_to_utf8 (char *target, const wchar_t *source, int n)
{
   register char *           t = target;
   register const wchar_t *  s = source;

   if (target == NULL)
      return (0);

   if (source == NULL)
   {
      *target = 0;
      return (0);
   }

   {
      for (; n && *s; s++)
      {
         register wchar_t u = *s;

         if (u < 0x0080)
         {
            /*------------------------------------------------------------
             * 00000000 0xxxxxxx   ->   0xxxxxxx
             */
            if (--n != 0)
               *t++ = (char) (u);
         }

         else
         if (u < 0x0800)
         {
            /*------------------------------------------------------------
             * 00000yyy yxxxxxxx   ->   110yyyyx
             *                          10xxxxxx
             */
            if (--n != 0)
               *t++ = (char) (((u         ) >>  6) | 0xc0);
            if (n != 0 && --n != 0)
               *t++ = (char) (((u & 0x003f)      ) | 0x80);
         }

         else
         {
            /*------------------------------------------------------------
             * zzzzzyyy yxxxxxxx   ->   1110zzzz
             *                          10zyyyyx
             *                          10xxxxxx
             */
            if (--n != 0)
               *t++ = (char) (((u         ) >> 12) | 0xe0);
            if (n != 0 && --n != 0)
               *t++ = (char) (((u & 0x0fc0) >>  6) | 0x80);
            if (n != 0 && --n != 0)
               *t++ = (char) (((u & 0x003f)      ) | 0x80);
         }
      }
      *t = 0;
   }
   return (int)(t - target);
}

/* str_uni_to_utf8
 * This function converts unicode wchar_t* to char* while allowing a partial
 * extraction.
 */
int EXPORT str_uni_to_utf8 (char *target, const wchar_t *source, int n, int scan)
{ // only converts the amount of characters requested and does not add null
   register char *           t = target;
   register const wchar_t *  s = source;

   if (target == NULL)
      return (0);

   if (source == NULL || scan <= 0)
   {
      *target = 0;
      return (0);
   }

   {
      for (int i = 0; n && (i < scan) ; i++, s++)
      {
         register wchar_t u = *s;
         // don't stop scanning to save room for NULL - write everything.
         if (u < 0x0080)
         {
            /*------------------------------------------------------------
             * 00000000 0xxxxxxx   ->   0xxxxxxx
             */
             *t++ = (char) (u);
             n -= 1;
         }

         else
         if (u < 0x0800)
         {
            /*------------------------------------------------------------
             * 00000yyy yxxxxxxx   ->   110yyyyx
             *                          10xxxxxx
             */
             *t++ = (char) (((u         ) >>  6) | 0xc0);
             *t++ = (char) (((u & 0x003f)      ) | 0x80);
             n -= 2;
         }

         else
         {
            /*------------------------------------------------------------
             * zzzzzyyy yxxxxxxx   ->   1110zzzz
             *                          10zyyyyx
             *                          10xxxxxx
             */
            *t++ = (char) (((u         ) >> 12) | 0xe0);
            *t++ = (char) (((u & 0x0fc0) >>  6) | 0x80);
            *t++ = (char) (((u & 0x003f)      ) | 0x80);
            n -= 3;
         }
      }
   }
   return (int)(t - target);
}

/* str_utf8_len
 * This function returns the length (character) of a unicode string.
 */
int EXPORT str_utf8_len(const char *str)
{
   register const char * s = str;
   int len = 0;

   if (str == NULL || *str == 0)
      return 0;

   {
      typedef enum chartype
         { REG, OPEN1, OPEN2, OPEN3, CONT, INVALID } CHARTYPE;
      typedef enum state
         { NORMAL, INSEQ } STATE;

      STATE    state     = NORMAL;
      int      current   = 0;
      int      need      = 0;

#     define RESET()  state = NORMAL; current = 0; need = 0

      for (; *s; s++)
      {
         int        c = *((const unsigned char *)s);
         CHARTYPE   char_type;

         if      ((c & 0x80) == 0x00) char_type = REG;
         else if ((c & 0xe0) == 0xc0) char_type = OPEN1;
         else if ((c & 0xf0) == 0xe0) char_type = OPEN2;
         else if ((c & 0xf8) == 0xf0) char_type = OPEN3;
         else if ((c & 0xc0) == 0x80) char_type = CONT;
         else                         char_type = INVALID;

         switch (char_type)
         {
         case REG:
            if (state == NORMAL)
               len++;
            else
            {
               len++;
               RESET();
            }
            break;

         case OPEN1:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x1f;
               need    = 1;
            }
            else
            {
               len++;
               RESET();
            }
            break;

         case OPEN2:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x0f;
               need    = 2;
            }
            else
            {
               len++;
               RESET();
            }
            break;

         case OPEN3:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x07;
               need    = 3;
            }
            else
            {
               len++;
               RESET();
            }
            break;

         case CONT:
            if (state == INSEQ)
            {
               c &= 0x3f;
               current = (current << 6) | c;
               if (--need == 0)
               {
                  len++;
                  RESET();
               }
            }
            break;

         case INVALID:
            len++;
            RESET();
            break;
         }
      }
#     undef RESET
   }
   return len;
}

/* str_utf8_len
 * This function returns the length (character) of a unicode string up to 
 * 'scan' characters.
 */
int EXPORT str_utf8_len(const char *str, int scan)
{ // process only the amount of characters requested
   register const char * s = str;
   int len = 0;

   if (str == NULL || *str == 0 || scan <= 0)
      return 0;

   {
      typedef enum chartype
         { REG, OPEN1, OPEN2, OPEN3, CONT, INVALID } CHARTYPE;
      typedef enum state
         { NORMAL, INSEQ } STATE;

      STATE    state     = NORMAL;
      int      current   = 0;
      int      need      = 0;

#     define RESET()  state = NORMAL; current = 0; need = 0

      for (int i = 0; i < scan; i++, s++)
      {
         int        c = *((const unsigned char *)s);
         CHARTYPE   char_type;

         if      ((c & 0x80) == 0x00) char_type = REG;
         else if ((c & 0xe0) == 0xc0) char_type = OPEN1;
         else if ((c & 0xf0) == 0xe0) char_type = OPEN2;
         else if ((c & 0xf8) == 0xf0) char_type = OPEN3;
         else if ((c & 0xc0) == 0x80) char_type = CONT;
         else                         char_type = INVALID;

         switch (char_type)
         {
         case REG:
            if (state == NORMAL)
               len++;
            else
            {
               len++;
               RESET();
            }
            break;

         case OPEN1:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x1f;
               need    = 1;
            }
            else
            {
               len++;
               RESET();
            }
            break;

         case OPEN2:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x0f;
               need    = 2;
            }
            else
            {
               len++;
               RESET();
            }
            break;

         case OPEN3:
            if (state == NORMAL)
            {
               state   = INSEQ;
               current = c & 0x07;
               need    = 3;
            }
            else
            {
               len++;
               RESET();
            }
            break;

         case CONT:
            if (state == INSEQ)
            {
               c &= 0x3f;
               current = (current << 6) | c;
               if (--need == 0)
               {
                  len++;
                  RESET();
               }
            }
            break;

         case INVALID:
            len++;
            RESET();
            break;
         }
      }
#     undef RESET
   }
   return len;
}

/* str_uni_bytes
 * This function returns the length (bytes) of a unicode string.
 */
int EXPORT str_uni_bytes(const wchar_t *str)
{ // returns number of bytes required for conversion, NOT including null
   if (str == NULL)
      return (0);

   register const wchar_t *  s = str;

   int count = 0;
   for (; *s; s++)
   {
      register wchar_t u = *s;
      if      (u < 0x0080)   count += 1;
      else if (u < 0x0800)   count += 2;
      else                   count += 3;
   }
   return count;
}

/* str_uni_bytes
 * This function returns the length (bytes) of a unicode string up to 
 * 'scan' characters.
 */
int EXPORT str_uni_bytes(const wchar_t *str, int scan)
{ // returns number of bytes required for conversion for the number of 
  // chars requested.
   if (str == NULL || scan <= 0)
      return (0);

   register const wchar_t *  s = str;

   int count = 0;
   for (int i = 0 ;i < scan ; i++, s++)
   {
      register wchar_t u = *s;
      if      (u < 0x0080)   count += 1;
      else if (u < 0x0800)   count += 2;
      else                   count += 3;
   }
   return count;
}
