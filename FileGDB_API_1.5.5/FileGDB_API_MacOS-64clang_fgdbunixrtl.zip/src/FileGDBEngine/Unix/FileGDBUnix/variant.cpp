/*
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * This file adapted for the ESRI FGDB Unix RTL from Wine sources. Modified on
 * 02/07/2011.
 */

#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#include "WineInternal.h"
#include "InitGUID.H"

#define CY_MULTIPLIER   10000             /* 4 dp of precision */
#define CY_MULTIPLIER_F 10000.0
#define CY_HALF         (CY_MULTIPLIER/2) /* 0.5 */
#define CY_HALF_F       (CY_MULTIPLIER_F/2.0)

static const WCHAR szFloatFormatW[] = { '%','.','7','G','\0' };
static const WCHAR szDoubleFormatW[] = { '%','.','1','5','G','\0' };

/* Copy data from one variant to another. */
static inline void VARIANT_CopyData(const VARIANT *srcVar, VARTYPE vt, void *pOut)
{
  switch (vt)
  {
  case VT_I1:
  case VT_UI1: memcpy(pOut, &V_UI1(srcVar), sizeof(BYTE)); break;
  case VT_BOOL:
  case VT_I2:
  case VT_UI2: memcpy(pOut, &V_UI2(srcVar), sizeof(SHORT)); break;
  case VT_R4:
  case VT_INT:
  case VT_I4:
  case VT_UINT:
  case VT_UI4: memcpy(pOut, &V_UI4(srcVar), sizeof (LONG)); break;
  case VT_R8:
  case VT_DATE:
  case VT_CY:
  case VT_I8:
  case VT_UI8: memcpy(pOut, &V_UI8(srcVar), sizeof (LONG64)); break;
  case VT_INT_PTR: memcpy(pOut, &V_INT_PTR(srcVar), sizeof (INT_PTR)); break;
  case VT_DECIMAL: memcpy(pOut, &V_DECIMAL(srcVar), sizeof (DECIMAL)); break;
  case VT_BSTR: memcpy(pOut, &V_BSTR(srcVar), sizeof(BSTR)); break;
  default:
    break;////FixMe("VT_ type %d unhandled, please report!\n", vt);
  }
}

/* Macro to inline conversion from a float or double to any integer type,
 * rounding according to the 'dutch' convention.
 */
#define VARIANT_DutchRound(typ, value, res) do { \
  double whole = value < 0 ? ceil(value) : floor(value); \
  double fract = value - whole; \
  if (fract > 0.5) res = (typ)whole + (typ)1; \
  else if (fract == 0.5) { typ is_odd = (typ)whole & 1; res = (typ)whole + is_odd; } \
  else if (fract >= 0.0) res = (typ)whole; \
  else if (fract == -0.5) { typ is_odd = (typ)whole & 1; res = (typ)whole - is_odd; } \
  else if (fract > -0.5) res = (typ)whole; \
  else res = (typ)whole - (typ)1; \
} while(0)


/* Coerce VT_BSTR to a numeric type */
static HRESULT VARIANT_NumberFromBstr(OLECHAR* pStrIn, LCID lcid, ULONG ulFlags,
                                      void* pOut, VARTYPE vt)
{
  VARIANTARG dstVar;
  HRESULT hRet;
  NUMPARSE np;
  BYTE rgb[1024];

  /* Use VarParseNumFromStr/VarNumFromParseNum as MSDN indicates */
  np.cDig = sizeof(rgb) / sizeof(BYTE);
  np.dwInFlags = NUMPRS_STD;

  hRet = VarParseNumFromStr(pStrIn, lcid, ulFlags, &np, rgb);

  if (SUCCEEDED(hRet))
  {
    /* 1 << vt gives us the VTBIT constant for the destination number type */
    hRet = VarNumFromParseNum(&np, rgb, 1 << vt, &dstVar);
    if (SUCCEEDED(hRet))
      VARIANT_CopyData(&dstVar, vt, pOut);
  }
  return hRet;
}

/* Inline return type */
#define RETTYP static inline HRESULT


/* Simple compiler cast from one type to another */
#define SIMPLE(dest, src, func) RETTYP _##func(src in, dest* out) { \
  *out = in; return S_OK; }

/* Compiler cast where input cannot be negative */
#define NEGTST(dest, src, func) RETTYP _##func(src in, dest* out) { \
  if (in < 0) return DISP_E_OVERFLOW; *out = in; return S_OK; }

/* Compiler cast where input cannot be > some number */
#define POSTST(dest, src, func, tst) RETTYP _##func(src in, dest* out) { \
  if (in > (dest)tst) return DISP_E_OVERFLOW; *out = in; return S_OK; }

/* Compiler cast where input cannot be < some number or >= some other number */
#define BOTHTST(dest, src, func, lo, hi) RETTYP _##func(src in, dest* out) { \
  if (in < (dest)lo || in > hi) return DISP_E_OVERFLOW; *out = in; return S_OK; }

/* I1 */
POSTST(signed char, BYTE, VarI1FromUI1, I1_MAX)
BOTHTST(signed char, SHORT, VarI1FromI2, I1_MIN, I1_MAX)
BOTHTST(signed char, LONG, VarI1FromI4, I1_MIN, I1_MAX)
SIMPLE(signed char, VARIANT_BOOL, VarI1FromBool)
POSTST(signed char, USHORT, VarI1FromUI2, I1_MAX)
POSTST(signed char, ULONG, VarI1FromUI4, I1_MAX)
BOTHTST(signed char, LONG64, VarI1FromI8, I1_MIN, I1_MAX)
POSTST(signed char, ULONG64, VarI1FromUI8, I1_MAX)

/* UI1 */
BOTHTST(BYTE, SHORT, VarUI1FromI2, UI1_MIN, UI1_MAX)
SIMPLE(BYTE, VARIANT_BOOL, VarUI1FromBool)
NEGTST(BYTE, signed char, VarUI1FromI1)
POSTST(BYTE, USHORT, VarUI1FromUI2, UI1_MAX)
BOTHTST(BYTE, LONG, VarUI1FromI4, UI1_MIN, UI1_MAX)
POSTST(BYTE, ULONG, VarUI1FromUI4, UI1_MAX)
BOTHTST(BYTE, LONG64, VarUI1FromI8, UI1_MIN, UI1_MAX)
POSTST(BYTE, ULONG64, VarUI1FromUI8, UI1_MAX)

/* I2 */
SIMPLE(SHORT, BYTE, VarI2FromUI1)
BOTHTST(SHORT, LONG, VarI2FromI4, I2_MIN, I2_MAX)
SIMPLE(SHORT, VARIANT_BOOL, VarI2FromBool)
SIMPLE(SHORT, signed char, VarI2FromI1)
POSTST(SHORT, USHORT, VarI2FromUI2, I2_MAX)
POSTST(SHORT, ULONG, VarI2FromUI4, I2_MAX)
BOTHTST(SHORT, LONG64, VarI2FromI8, I2_MIN, I2_MAX)
POSTST(SHORT, ULONG64, VarI2FromUI8, I2_MAX)

/* UI2 */
SIMPLE(USHORT, BYTE, VarUI2FromUI1)
NEGTST(USHORT, SHORT, VarUI2FromI2)
BOTHTST(USHORT, LONG, VarUI2FromI4, UI2_MIN, UI2_MAX)
SIMPLE(USHORT, VARIANT_BOOL, VarUI2FromBool)
NEGTST(USHORT, signed char, VarUI2FromI1)
POSTST(USHORT, ULONG, VarUI2FromUI4, UI2_MAX)
BOTHTST(USHORT, LONG64, VarUI2FromI8, UI2_MIN, UI2_MAX)
POSTST(USHORT, ULONG64, VarUI2FromUI8, UI2_MAX)

/* I4 */
SIMPLE(LONG, BYTE, VarI4FromUI1)
SIMPLE(LONG, SHORT, VarI4FromI2)
SIMPLE(LONG, VARIANT_BOOL, VarI4FromBool)
SIMPLE(LONG, signed char, VarI4FromI1)
SIMPLE(LONG, USHORT, VarI4FromUI2)
POSTST(LONG, ULONG, VarI4FromUI4, I4_MAX)
BOTHTST(LONG, LONG64, VarI4FromI8, I4_MIN, I4_MAX)
POSTST(LONG, ULONG64, VarI4FromUI8, I4_MAX)

/* UI4 */
SIMPLE(ULONG, BYTE, VarUI4FromUI1)
NEGTST(ULONG, SHORT, VarUI4FromI2)
NEGTST(ULONG, LONG, VarUI4FromI4)
SIMPLE(ULONG, VARIANT_BOOL, VarUI4FromBool)
NEGTST(ULONG, signed char, VarUI4FromI1)
SIMPLE(ULONG, USHORT, VarUI4FromUI2)
BOTHTST(ULONG, LONG64, VarUI4FromI8, UI4_MIN, UI4_MAX)
POSTST(ULONG, ULONG64, VarUI4FromUI8, UI4_MAX)

/* I8 */
SIMPLE(LONG64, BYTE, VarI8FromUI1)
SIMPLE(LONG64, SHORT, VarI8FromI2)
SIMPLE(LONG64, signed char, VarI8FromI1)
SIMPLE(LONG64, USHORT, VarI8FromUI2)
SIMPLE(LONG64, ULONG, VarI8FromUI4)
POSTST(LONG64, ULONG64, VarI8FromUI8, I8_MAX)

/* UI8 */
SIMPLE(ULONG64, BYTE, VarUI8FromUI1)
NEGTST(ULONG64, SHORT, VarUI8FromI2)
NEGTST(ULONG64, signed char, VarUI8FromI1)
SIMPLE(ULONG64, USHORT, VarUI8FromUI2)
SIMPLE(ULONG64, ULONG, VarUI8FromUI4)
NEGTST(ULONG64, LONG64, VarUI8FromI8)

/* R4 (float) */
SIMPLE(float, BYTE, VarR4FromUI1)
SIMPLE(float, SHORT, VarR4FromI2)
SIMPLE(float, signed char, VarR4FromI1)
SIMPLE(float, USHORT, VarR4FromUI2)
SIMPLE(float, LONG, VarR4FromI4)
SIMPLE(float, ULONG, VarR4FromUI4)
SIMPLE(float, LONG64, VarR4FromI8)
SIMPLE(float, ULONG64, VarR4FromUI8)

/* R8 (double) */
SIMPLE(double, BYTE, VarR8FromUI1)
SIMPLE(double, SHORT, VarR8FromI2)
SIMPLE(double, float, VarR8FromR4)
RETTYP _VarR8FromCy(CY i, double* o) { *o = (double)i.int64 / CY_MULTIPLIER_F; return S_OK; }
SIMPLE(double, DATE, VarR8FromDate)
SIMPLE(double, signed char, VarR8FromI1)
SIMPLE(double, USHORT, VarR8FromUI2)
SIMPLE(double, LONG, VarR8FromI4)
SIMPLE(double, ULONG, VarR8FromUI4)
SIMPLE(double, LONG64, VarR8FromI8)
SIMPLE(double, ULONG64, VarR8FromUI8)


/* I1
 */

/************************************************************************
 * VarI1FromUI1 (OLEAUT32.244)
 *
 * Convert a VT_UI1 to a VT_I1.
 *
 * PARAMS
 *  bIn     [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromUI1(BYTE bIn, signed char* pcOut)
{
  return _VarI1FromUI1(bIn, pcOut);
}

/************************************************************************
 * VarI1FromI2 (OLEAUT32.245)
 *
 * Convert a VT_I2 to a VT_I1.
 *
 * PARAMS
 *  sIn     [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromI2(SHORT sIn, signed char* pcOut)
{
  return _VarI1FromI2(sIn, pcOut);
}

/************************************************************************
 * VarI1FromI4 (OLEAUT32.246)
 *
 * Convert a VT_I4 to a VT_I1.
 *
 * PARAMS
 *  iIn     [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromI4(LONG iIn, signed char* pcOut)
{
  return _VarI1FromI4(iIn, pcOut);
}

/************************************************************************
 * VarI1FromR4 (OLEAUT32.247)
 *
 * Convert a VT_R4 to a VT_I1.
 *
 * PARAMS
 *  fltIn   [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromR4(FLOAT fltIn, signed char* pcOut)
{
  return VarI1FromR8(fltIn, pcOut);
}

/************************************************************************
 * VarI1FromR8 (OLEAUT32.248)
 *
 * Convert a VT_R8 to a VT_I1.
 *
 * PARAMS
 *  dblIn   [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  See VarI8FromR8() for details concerning rounding.
 */
HRESULT WINAPI VarI1FromR8(double dblIn, signed char* pcOut)
{
  if (dblIn < (double)I1_MIN || dblIn > (double)I1_MAX)
    return DISP_E_OVERFLOW;
  VARIANT_DutchRound(CHAR, dblIn, *pcOut);
  return S_OK;
}

/************************************************************************
 * VarI1FromDate (OLEAUT32.249)
 *
 * Convert a VT_DATE to a VT_I1.
 *
 * PARAMS
 *  dateIn  [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromDate(DATE dateIn, signed char* pcOut)
{
  return VarI1FromR8(dateIn, pcOut);
}

/************************************************************************
 * VarI1FromCy (OLEAUT32.250)
 *
 * Convert a VT_CY to a VT_I1.
 *
 * PARAMS
 *  cyIn    [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromCy(CY cyIn, signed char* pcOut)
{
  LONG i = I1_MAX + 1;

  VarI4FromCy(cyIn, &i);
  return _VarI1FromI4(i, pcOut);
}

/************************************************************************
 * VarI1FromStr (OLEAUT32.251)
 *
 * Convert a VT_BSTR to a VT_I1.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarI1FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, signed char* pcOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pcOut, VT_I1);
}


/************************************************************************
 * VarI1FromBool (OLEAUT32.253)
 *
 * Convert a VT_BOOL to a VT_I1.
 *
 * PARAMS
 *  boolIn  [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI1FromBool(VARIANT_BOOL boolIn, signed char* pcOut)
{
  return _VarI1FromBool(boolIn, pcOut);
}

/************************************************************************
 * VarI1FromUI2 (OLEAUT32.254)
 *
 * Convert a VT_UI2 to a VT_I1.
 *
 * PARAMS
 *  usIn    [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromUI2(USHORT usIn, signed char* pcOut)
{
  return _VarI1FromUI2(usIn, pcOut);
}

/************************************************************************
 * VarI1FromUI4 (OLEAUT32.255)
 *
 * Convert a VT_UI4 to a VT_I1.
 *
 * PARAMS
 *  ulIn    [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarI1FromUI4(ULONG ulIn, signed char* pcOut)
{
  return _VarI1FromUI4(ulIn, pcOut);
}

/************************************************************************
 * VarI1FromDec (OLEAUT32.256)
 *
 * Convert a VT_DECIMAL to a VT_I1.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromDec(DECIMAL *pdecIn, signed char* pcOut)
{
  LONG64 i64;
  HRESULT hRet;

  hRet = VarI8FromDec(pdecIn, &i64);

  if (SUCCEEDED(hRet))
    hRet = _VarI1FromI8(i64, pcOut);
  return hRet;
}

/************************************************************************
 * VarI1FromI8 (OLEAUT32.376)
 *
 * Convert a VT_I8 to a VT_I1.
 *
 * PARAMS
 *  llIn  [I] Source
 *  pcOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromI8(LONG64 llIn, signed char* pcOut)
{
  return _VarI1FromI8(llIn, pcOut);
}

/************************************************************************
 * VarI1FromUI8 (OLEAUT32.377)
 *
 * Convert a VT_UI8 to a VT_I1.
 *
 * PARAMS
 *  ullIn   [I] Source
 *  pcOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI1FromUI8(ULONG64 ullIn, signed char* pcOut)
{
  return _VarI1FromUI8(ullIn, pcOut);
}

/* UI1
 */

/************************************************************************
 * VarUI1FromI2 (OLEAUT32.130)
 *
 * Convert a VT_I2 to a VT_UI1.
 *
 * PARAMS
 *  sIn   [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromI2(SHORT sIn, BYTE* pbOut)
{
  return _VarUI1FromI2(sIn, pbOut);
}

/************************************************************************
 * VarUI1FromI4 (OLEAUT32.131)
 *
 * Convert a VT_I4 to a VT_UI1.
 *
 * PARAMS
 *  iIn   [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromI4(LONG iIn, BYTE* pbOut)
{
  return _VarUI1FromI4(iIn, pbOut);
}

/************************************************************************
 * VarUI1FromR4 (OLEAUT32.132)
 *
 * Convert a VT_R4 to a VT_UI1.
 *
 * PARAMS
 *  fltIn [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarUI1FromR4(FLOAT fltIn, BYTE* pbOut)
{
  return VarUI1FromR8(fltIn, pbOut);
}

/************************************************************************
 * VarUI1FromR8 (OLEAUT32.133)
 *
 * Convert a VT_R8 to a VT_UI1.
 *
 * PARAMS
 *  dblIn [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  See VarI8FromR8() for details concerning rounding.
 */
HRESULT WINAPI VarUI1FromR8(double dblIn, BYTE* pbOut)
{
  if (dblIn < -0.5 || dblIn > (double)UI1_MAX)
    return DISP_E_OVERFLOW;
  VARIANT_DutchRound(BYTE, dblIn, *pbOut);
  return S_OK;
}

/************************************************************************
 * VarUI1FromCy (OLEAUT32.134)
 *
 * Convert a VT_CY to a VT_UI1.
 *
 * PARAMS
 *  cyIn     [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  Negative values >= -5000 will be converted to 0.
 */
HRESULT WINAPI VarUI1FromCy(CY cyIn, BYTE* pbOut)
{
  ULONG i = UI1_MAX + 1;

  VarUI4FromCy(cyIn, &i);
  return _VarUI1FromUI4(i, pbOut);
}

/************************************************************************
 * VarUI1FromDate (OLEAUT32.135)
 *
 * Convert a VT_DATE to a VT_UI1.
 *
 * PARAMS
 *  dateIn [I] Source
 *  pbOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromDate(DATE dateIn, BYTE* pbOut)
{
  return VarUI1FromR8(dateIn, pbOut);
}

/************************************************************************
 * VarUI1FromStr (OLEAUT32.136)
 *
 * Convert a VT_BSTR to a VT_UI1.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarUI1FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, BYTE* pbOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pbOut, VT_UI1);
}


/************************************************************************
 * VarUI1FromBool (OLEAUT32.138)
 *
 * Convert a VT_BOOL to a VT_UI1.
 *
 * PARAMS
 *  boolIn [I] Source
 *  pbOut  [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI1FromBool(VARIANT_BOOL boolIn, BYTE* pbOut)
{
  return _VarUI1FromBool(boolIn, pbOut);
}

/************************************************************************
 * VarUI1FromI1 (OLEAUT32.237)
 *
 * Convert a VT_I1 to a VT_UI1.
 *
 * PARAMS
 *  cIn   [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromI1(signed char cIn, BYTE* pbOut)
{
  return _VarUI1FromI1(cIn, pbOut);
}

/************************************************************************
 * VarUI1FromUI2 (OLEAUT32.238)
 *
 * Convert a VT_UI2 to a VT_UI1.
 *
 * PARAMS
 *  usIn  [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromUI2(USHORT usIn, BYTE* pbOut)
{
  return _VarUI1FromUI2(usIn, pbOut);
}

/************************************************************************
 * VarUI1FromUI4 (OLEAUT32.239)
 *
 * Convert a VT_UI4 to a VT_UI1.
 *
 * PARAMS
 *  ulIn  [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromUI4(ULONG ulIn, BYTE* pbOut)
{
  return _VarUI1FromUI4(ulIn, pbOut);
}

/************************************************************************
 * VarUI1FromDec (OLEAUT32.240)
 *
 * Convert a VT_DECIMAL to a VT_UI1.
 *
 * PARAMS
 *  pDecIn [I] Source
 *  pbOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromDec(DECIMAL *pdecIn, BYTE* pbOut)
{
  LONG64 i64;
  HRESULT hRet;

  hRet = VarI8FromDec(pdecIn, &i64);

  if (SUCCEEDED(hRet))
    hRet = _VarUI1FromI8(i64, pbOut);
  return hRet;
}

/************************************************************************
 * VarUI1FromI8 (OLEAUT32.372)
 *
 * Convert a VT_I8 to a VT_UI1.
 *
 * PARAMS
 *  llIn  [I] Source
 *  pbOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromI8(LONG64 llIn, BYTE* pbOut)
{
  return _VarUI1FromI8(llIn, pbOut);
}

/************************************************************************
 * VarUI1FromUI8 (OLEAUT32.373)
 *
 * Convert a VT_UI8 to a VT_UI1.
 *
 * PARAMS
 *  ullIn   [I] Source
 *  pbOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI1FromUI8(ULONG64 ullIn, BYTE* pbOut)
{
  return _VarUI1FromUI8(ullIn, pbOut);
}


/* I2
 */

/************************************************************************
 * VarI2FromUI1 (OLEAUT32.48)
 *
 * Convert a VT_UI2 to a VT_I2.
 *
 * PARAMS
 *  bIn     [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI2FromUI1(BYTE bIn, SHORT* psOut)
{
  return _VarI2FromUI1(bIn, psOut);
}

/************************************************************************
 * VarI2FromI4 (OLEAUT32.49)
 *
 * Convert a VT_I4 to a VT_I2.
 *
 * PARAMS
 *  iIn     [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromI4(LONG iIn, SHORT* psOut)
{
  return _VarI2FromI4(iIn, psOut);
}

/************************************************************************
 * VarI2FromR4 (OLEAUT32.50)
 *
 * Convert a VT_R4 to a VT_I2.
 *
 * PARAMS
 *  fltIn   [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromR4(FLOAT fltIn, SHORT* psOut)
{
  return VarI2FromR8(fltIn, psOut);
}

/************************************************************************
 * VarI2FromR8 (OLEAUT32.51)
 *
 * Convert a VT_R8 to a VT_I2.
 *
 * PARAMS
 *  dblIn   [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  See VarI8FromR8() for details concerning rounding.
 */
HRESULT WINAPI VarI2FromR8(double dblIn, SHORT* psOut)
{
  if (dblIn < (double)I2_MIN || dblIn > (double)I2_MAX)
    return DISP_E_OVERFLOW;
  VARIANT_DutchRound(SHORT, dblIn, *psOut);
  return S_OK;
}

/************************************************************************
 * VarI2FromCy (OLEAUT32.52)
 *
 * Convert a VT_CY to a VT_I2.
 *
 * PARAMS
 *  cyIn    [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromCy(CY cyIn, SHORT* psOut)
{
  LONG i = I2_MAX + 1;

  VarI4FromCy(cyIn, &i);
  return _VarI2FromI4(i, psOut);
}

/************************************************************************
 * VarI2FromDate (OLEAUT32.53)
 *
 * Convert a VT_DATE to a VT_I2.
 *
 * PARAMS
 *  dateIn  [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromDate(DATE dateIn, SHORT* psOut)
{
  return VarI2FromR8(dateIn, psOut);
}

/************************************************************************
 * VarI2FromStr (OLEAUT32.54)
 *
 * Convert a VT_BSTR to a VT_I2.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if any parameter is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarI2FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, SHORT* psOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, psOut, VT_I2);
}


/************************************************************************
 * VarI2FromBool (OLEAUT32.56)
 *
 * Convert a VT_BOOL to a VT_I2.
 *
 * PARAMS
 *  boolIn  [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI2FromBool(VARIANT_BOOL boolIn, SHORT* psOut)
{
  return _VarI2FromBool(boolIn, psOut);
}

/************************************************************************
 * VarI2FromI1 (OLEAUT32.205)
 *
 * Convert a VT_I1 to a VT_I2.
 *
 * PARAMS
 *  cIn     [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI2FromI1(signed char cIn, SHORT* psOut)
{
  return _VarI2FromI1(cIn, psOut);
}

/************************************************************************
 * VarI2FromUI2 (OLEAUT32.206)
 *
 * Convert a VT_UI2 to a VT_I2.
 *
 * PARAMS
 *  usIn    [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromUI2(USHORT usIn, SHORT* psOut)
{
  return _VarI2FromUI2(usIn, psOut);
}

/************************************************************************
 * VarI2FromUI4 (OLEAUT32.207)
 *
 * Convert a VT_UI4 to a VT_I2.
 *
 * PARAMS
 *  ulIn    [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromUI4(ULONG ulIn, SHORT* psOut)
{
  return _VarI2FromUI4(ulIn, psOut);
}

/************************************************************************
 * VarI2FromDec (OLEAUT32.208)
 *
 * Convert a VT_DECIMAL to a VT_I2.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  psOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromDec(DECIMAL *pdecIn, SHORT* psOut)
{
  LONG64 i64;
  HRESULT hRet;

  hRet = VarI8FromDec(pdecIn, &i64);

  if (SUCCEEDED(hRet))
    hRet = _VarI2FromI8(i64, psOut);
  return hRet;
}

/************************************************************************
 * VarI2FromI8 (OLEAUT32.346)
 *
 * Convert a VT_I8 to a VT_I2.
 *
 * PARAMS
 *  llIn  [I] Source
 *  psOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromI8(LONG64 llIn, SHORT* psOut)
{
  return _VarI2FromI8(llIn, psOut);
}

/************************************************************************
 * VarI2FromUI8 (OLEAUT32.347)
 *
 * Convert a VT_UI8 to a VT_I2.
 *
 * PARAMS
 *  ullIn [I] Source
 *  psOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI2FromUI8(ULONG64 ullIn, SHORT* psOut)
{
  return _VarI2FromUI8(ullIn, psOut);
}

/* UI2
 */

/************************************************************************
 * VarUI2FromUI1 (OLEAUT32.257)
 *
 * Convert a VT_UI1 to a VT_UI2.
 *
 * PARAMS
 *  bIn    [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI2FromUI1(BYTE bIn, USHORT* pusOut)
{
  return _VarUI2FromUI1(bIn, pusOut);
}

/************************************************************************
 * VarUI2FromI2 (OLEAUT32.258)
 *
 * Convert a VT_I2 to a VT_UI2.
 *
 * PARAMS
 *  sIn    [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromI2(SHORT sIn, USHORT* pusOut)
{
  return _VarUI2FromI2(sIn, pusOut);
}

/************************************************************************
 * VarUI2FromI4 (OLEAUT32.259)
 *
 * Convert a VT_I4 to a VT_UI2.
 *
 * PARAMS
 *  iIn    [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromI4(LONG iIn, USHORT* pusOut)
{
  return _VarUI2FromI4(iIn, pusOut);
}

/************************************************************************
 * VarUI2FromR4 (OLEAUT32.260)
 *
 * Convert a VT_R4 to a VT_UI2.
 *
 * PARAMS
 *  fltIn  [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromR4(FLOAT fltIn, USHORT* pusOut)
{
  return VarUI2FromR8(fltIn, pusOut);
}

/************************************************************************
 * VarUI2FromR8 (OLEAUT32.261)
 *
 * Convert a VT_R8 to a VT_UI2.
 *
 * PARAMS
 *  dblIn  [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  See VarI8FromR8() for details concerning rounding.
 */
HRESULT WINAPI VarUI2FromR8(double dblIn, USHORT* pusOut)
{
  if (dblIn < -0.5 || dblIn > (double)UI2_MAX)
    return DISP_E_OVERFLOW;
  VARIANT_DutchRound(USHORT, dblIn, *pusOut);
  return S_OK;
}

/************************************************************************
 * VarUI2FromDate (OLEAUT32.262)
 *
 * Convert a VT_DATE to a VT_UI2.
 *
 * PARAMS
 *  dateIn [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromDate(DATE dateIn, USHORT* pusOut)
{
  return VarUI2FromR8(dateIn, pusOut);
}

/************************************************************************
 * VarUI2FromCy (OLEAUT32.263)
 *
 * Convert a VT_CY to a VT_UI2.
 *
 * PARAMS
 *  cyIn   [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  Negative values >= -5000 will be converted to 0.
 */
HRESULT WINAPI VarUI2FromCy(CY cyIn, USHORT* pusOut)
{
  ULONG i = UI2_MAX + 1;

  VarUI4FromCy(cyIn, &i);
  return _VarUI2FromUI4(i, pusOut);
}

/************************************************************************
 * VarUI2FromStr (OLEAUT32.264)
 *
 * Convert a VT_BSTR to a VT_UI2.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pusOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarUI2FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, USHORT* pusOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pusOut, VT_UI2);
}


/************************************************************************
 * VarUI2FromBool (OLEAUT32.266)
 *
 * Convert a VT_BOOL to a VT_UI2.
 *
 * PARAMS
 *  boolIn  [I] Source
 *  pusOut  [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI2FromBool(VARIANT_BOOL boolIn, USHORT* pusOut)
{
  return _VarUI2FromBool(boolIn, pusOut);
}

/************************************************************************
 * VarUI2FromI1 (OLEAUT32.267)
 *
 * Convert a VT_I1 to a VT_UI2.
 *
 * PARAMS
 *  cIn    [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromI1(signed char cIn, USHORT* pusOut)
{
  return _VarUI2FromI1(cIn, pusOut);
}

/************************************************************************
 * VarUI2FromUI4 (OLEAUT32.268)
 *
 * Convert a VT_UI4 to a VT_UI2.
 *
 * PARAMS
 *  ulIn   [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromUI4(ULONG ulIn, USHORT* pusOut)
{
  return _VarUI2FromUI4(ulIn, pusOut);
}

/************************************************************************
 * VarUI2FromDec (OLEAUT32.269)
 *
 * Convert a VT_DECIMAL to a VT_UI2.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pusOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromDec(DECIMAL *pdecIn, USHORT* pusOut)
{
  LONG64 i64;
  HRESULT hRet;

  hRet = VarI8FromDec(pdecIn, &i64);

  if (SUCCEEDED(hRet))
    hRet = _VarUI2FromI8(i64, pusOut);
  return hRet;
}

/************************************************************************
 * VarUI2FromI8 (OLEAUT32.378)
 *
 * Convert a VT_I8 to a VT_UI2.
 *
 * PARAMS
 *  llIn   [I] Source
 *  pusOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromI8(LONG64 llIn, USHORT* pusOut)
{
  return _VarUI2FromI8(llIn, pusOut);
}

/************************************************************************
 * VarUI2FromUI8 (OLEAUT32.379)
 *
 * Convert a VT_UI8 to a VT_UI2.
 *
 * PARAMS
 *  ullIn    [I] Source
 *  pusOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI2FromUI8(ULONG64 ullIn, USHORT* pusOut)
{
  return _VarUI2FromUI8(ullIn, pusOut);
}

/* I4
 */

/************************************************************************
 * VarI4FromUI1 (OLEAUT32.58)
 *
 * Convert a VT_UI1 to a VT_I4.
 *
 * PARAMS
 *  bIn     [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI4FromUI1(BYTE bIn, LONG *piOut)
{
  return _VarI4FromUI1(bIn, piOut);
}

/************************************************************************
 * VarI4FromI2 (OLEAUT32.59)
 *
 * Convert a VT_I2 to a VT_I4.
 *
 * PARAMS
 *  sIn     [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI4FromI2(SHORT sIn, LONG *piOut)
{
  return _VarI4FromI2(sIn, piOut);
}

/************************************************************************
 * VarI4FromR4 (OLEAUT32.60)
 *
 * Convert a VT_R4 to a VT_I4.
 *
 * PARAMS
 *  fltIn   [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI4FromR4(FLOAT fltIn, LONG *piOut)
{
  return VarI4FromR8(fltIn, piOut);
}

/************************************************************************
 * VarI4FromR8 (OLEAUT32.61)
 *
 * Convert a VT_R8 to a VT_I4.
 *
 * PARAMS
 *  dblIn   [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  See VarI8FromR8() for details concerning rounding.
 */
HRESULT WINAPI VarI4FromR8(double dblIn, LONG *piOut)
{
  if (dblIn < (double)I4_MIN || dblIn > (double)I4_MAX)
    return DISP_E_OVERFLOW;
  VARIANT_DutchRound(LONG, dblIn, *piOut);
  return S_OK;
}

/************************************************************************
 * VarI4FromCy (OLEAUT32.62)
 *
 * Convert a VT_CY to a VT_I4.
 *
 * PARAMS
 *  cyIn    [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI4FromCy(CY cyIn, LONG *piOut)
{
  double d = cyIn.int64 / CY_MULTIPLIER_F;
  return VarI4FromR8(d, piOut);
}

/************************************************************************
 * VarI4FromDate (OLEAUT32.63)
 *
 * Convert a VT_DATE to a VT_I4.
 *
 * PARAMS
 *  dateIn  [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI4FromDate(DATE dateIn, LONG *piOut)
{
  return VarI4FromR8(dateIn, piOut);
}

/************************************************************************
 * VarI4FromStr (OLEAUT32.64)
 *
 * Convert a VT_BSTR to a VT_I4.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  piOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if any parameter is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if strIn cannot be converted
 */
HRESULT WINAPI VarI4FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, LONG *piOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, piOut, VT_I4);
}


/************************************************************************
 * VarI4FromBool (OLEAUT32.66)
 *
 * Convert a VT_BOOL to a VT_I4.
 *
 * PARAMS
 *  boolIn  [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI4FromBool(VARIANT_BOOL boolIn, LONG *piOut)
{
  return _VarI4FromBool(boolIn, piOut);
}

/************************************************************************
 * VarI4FromI1 (OLEAUT32.209)
 *
 * Convert a VT_I4 to a VT_I4.
 *
 * PARAMS
 *  cIn     [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI4FromI1(signed char cIn, LONG *piOut)
{
  return _VarI4FromI1(cIn, piOut);
}

/************************************************************************
 * VarI4FromUI2 (OLEAUT32.210)
 *
 * Convert a VT_UI2 to a VT_I4.
 *
 * PARAMS
 *  usIn    [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI4FromUI2(USHORT usIn, LONG *piOut)
{
  return _VarI4FromUI2(usIn, piOut);
}

/************************************************************************
 * VarI4FromUI4 (OLEAUT32.211)
 *
 * Convert a VT_UI4 to a VT_I4.
 *
 * PARAMS
 *  ulIn    [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI4FromUI4(ULONG ulIn, LONG *piOut)
{
  return _VarI4FromUI4(ulIn, piOut);
}

/************************************************************************
 * VarI4FromDec (OLEAUT32.212)
 *
 * Convert a VT_DECIMAL to a VT_I4.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  piOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pdecIn is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI4FromDec(DECIMAL *pdecIn, LONG *piOut)
{
  LONG64 i64;
  HRESULT hRet;

  hRet = VarI8FromDec(pdecIn, &i64);

  if (SUCCEEDED(hRet))
    hRet = _VarI4FromI8(i64, piOut);
  return hRet;
}

/************************************************************************
 * VarI4FromI8 (OLEAUT32.348)
 *
 * Convert a VT_I8 to a VT_I4.
 *
 * PARAMS
 *  llIn  [I] Source
 *  piOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI4FromI8(LONG64 llIn, LONG *piOut)
{
  return _VarI4FromI8(llIn, piOut);
}

/************************************************************************
 * VarI4FromUI8 (OLEAUT32.349)
 *
 * Convert a VT_UI8 to a VT_I4.
 *
 * PARAMS
 *  ullIn [I] Source
 *  piOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI4FromUI8(ULONG64 ullIn, LONG *piOut)
{
  return _VarI4FromUI8(ullIn, piOut);
}

/* UI4
 */

/************************************************************************
 * VarUI4FromUI1 (OLEAUT32.270)
 *
 * Convert a VT_UI1 to a VT_UI4.
 *
 * PARAMS
 *  bIn    [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI4FromUI1(BYTE bIn, ULONG *pulOut)
{
  return _VarUI4FromUI1(bIn, pulOut);
}

/************************************************************************
 * VarUI4FromI2 (OLEAUT32.271)
 *
 * Convert a VT_I2 to a VT_UI4.
 *
 * PARAMS
 *  sIn    [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromI2(SHORT sIn, ULONG *pulOut)
{
  return _VarUI4FromI2(sIn, pulOut);
}

/************************************************************************
 * VarUI4FromI4 (OLEAUT32.272)
 *
 * Convert a VT_I4 to a VT_UI4.
 *
 * PARAMS
 *  iIn    [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromI4(LONG iIn, ULONG *pulOut)
{
  return _VarUI4FromI4(iIn, pulOut);
}

/************************************************************************
 * VarUI4FromR4 (OLEAUT32.273)
 *
 * Convert a VT_R4 to a VT_UI4.
 *
 * PARAMS
 *  fltIn  [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromR4(FLOAT fltIn, ULONG *pulOut)
{
  return VarUI4FromR8(fltIn, pulOut);
}

/************************************************************************
 * VarUI4FromR8 (OLEAUT32.274)
 *
 * Convert a VT_R8 to a VT_UI4.
 *
 * PARAMS
 *  dblIn  [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  See VarI8FromR8() for details concerning rounding.
 */
HRESULT WINAPI VarUI4FromR8(double dblIn, ULONG *pulOut)
{
  if (dblIn < -0.5 || dblIn > (double)UI4_MAX)
    return DISP_E_OVERFLOW;
  VARIANT_DutchRound(ULONG, dblIn, *pulOut);
  return S_OK;
}

/************************************************************************
 * VarUI4FromDate (OLEAUT32.275)
 *
 * Convert a VT_DATE to a VT_UI4.
 *
 * PARAMS
 *  dateIn [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromDate(DATE dateIn, ULONG *pulOut)
{
  return VarUI4FromR8(dateIn, pulOut);
}

/************************************************************************
 * VarUI4FromCy (OLEAUT32.276)
 *
 * Convert a VT_CY to a VT_UI4.
 *
 * PARAMS
 *  cyIn   [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromCy(CY cyIn, ULONG *pulOut)
{
  double d = cyIn.int64 / CY_MULTIPLIER_F;
  return VarUI4FromR8(d, pulOut);
}

/************************************************************************
 * VarUI4FromStr (OLEAUT32.277)
 *
 * Convert a VT_BSTR to a VT_UI4.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pulOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if any parameter is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if strIn cannot be converted
 */
HRESULT WINAPI VarUI4FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, ULONG *pulOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pulOut, VT_UI4);
}


/************************************************************************
 * VarUI4FromBool (OLEAUT32.279)
 *
 * Convert a VT_BOOL to a VT_UI4.
 *
 * PARAMS
 *  boolIn  [I] Source
 *  pulOut  [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI4FromBool(VARIANT_BOOL boolIn, ULONG *pulOut)
{
  return _VarUI4FromBool(boolIn, pulOut);
}

/************************************************************************
 * VarUI4FromI1 (OLEAUT32.280)
 *
 * Convert a VT_I1 to a VT_UI4.
 *
 * PARAMS
 *  cIn    [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromI1(signed char cIn, ULONG *pulOut)
{
  return _VarUI4FromI1(cIn, pulOut);
}

/************************************************************************
 * VarUI4FromUI2 (OLEAUT32.281)
 *
 * Convert a VT_UI2 to a VT_UI4.
 *
 * PARAMS
 *  usIn   [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI4FromUI2(USHORT usIn, ULONG *pulOut)
{
  return _VarUI4FromUI2(usIn, pulOut);
}

/************************************************************************
 * VarUI4FromDec (OLEAUT32.282)
 *
 * Convert a VT_DECIMAL to a VT_UI4.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pulOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pdecIn is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromDec(DECIMAL *pdecIn, ULONG *pulOut)
{
  LONG64 i64;
  HRESULT hRet;

  hRet = VarI8FromDec(pdecIn, &i64);

  if (SUCCEEDED(hRet))
    hRet = _VarUI4FromI8(i64, pulOut);
  return hRet;
}

/************************************************************************
 * VarUI4FromI8 (OLEAUT32.425)
 *
 * Convert a VT_I8 to a VT_UI4.
 *
 * PARAMS
 *  llIn   [I] Source
 *  pulOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromI8(LONG64 llIn, ULONG *pulOut)
{
  return _VarUI4FromI8(llIn, pulOut);
}

/************************************************************************
 * VarUI4FromUI8 (OLEAUT32.426)
 *
 * Convert a VT_UI8 to a VT_UI4.
 *
 * PARAMS
 *  ullIn    [I] Source
 *  pulOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI4FromUI8(ULONG64 ullIn, ULONG *pulOut)
{
  return _VarUI4FromUI8(ullIn, pulOut);
}

/* I8
 */

/************************************************************************
 * VarI8FromUI1 (OLEAUT32.333)
 *
 * Convert a VT_UI1 to a VT_I8.
 *
 * PARAMS
 *  bIn     [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI8FromUI1(BYTE bIn, LONG64* pi64Out)
{
  return _VarI8FromUI1(bIn, pi64Out);
}


/************************************************************************
 * VarI8FromI2 (OLEAUT32.334)
 *
 * Convert a VT_I2 to a VT_I8.
 *
 * PARAMS
 *  sIn     [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI8FromI2(SHORT sIn, LONG64* pi64Out)
{
  return _VarI8FromI2(sIn, pi64Out);
}

/************************************************************************
 * VarI8FromR4 (OLEAUT32.335)
 *
 * Convert a VT_R4 to a VT_I8.
 *
 * PARAMS
 *  fltIn   [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI8FromR4(FLOAT fltIn, LONG64* pi64Out)
{
  return VarI8FromR8(fltIn, pi64Out);
}

/************************************************************************
 * VarI8FromR8 (OLEAUT32.336)
 *
 * Convert a VT_R8 to a VT_I8.
 *
 * PARAMS
 *  dblIn   [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  Only values that fit into 63 bits are accepted. Due to rounding issues,
 *  very high or low values will not be accurately converted.
 *
 *  Numbers are rounded using Dutch rounding, as follows:
 *
 *|  Fractional Part   Sign  Direction  Example
 *|  ---------------   ----  ---------  -------
 *|  < 0.5              +    Down        0.4 ->  0.0
 *|  < 0.5              -    Up         -0.4 ->  0.0
 *|  > 0.5              +    Up          0.6 ->  1.0
 *|  < 0.5              -    Up         -0.6 -> -1.0
 *|  = 0.5              +    Up/Down    Down if even, Up if odd
 *|  = 0.5              -    Up/Down    Up if even, Down if odd
 *
 *  This system is often used in supermarkets.
 */
HRESULT WINAPI VarI8FromR8(double dblIn, LONG64* pi64Out)
{
  if ( dblIn < -4611686018427387904.0 || dblIn >= 4611686018427387904.0)
    return DISP_E_OVERFLOW;
  VARIANT_DutchRound(LONG64, dblIn, *pi64Out);
  return S_OK;
}

/************************************************************************
 * VarI8FromCy (OLEAUT32.337)
 *
 * Convert a VT_CY to a VT_I8.
 *
 * PARAMS
 *  cyIn    [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 *
 * NOTES
 *  All negative numbers are rounded down by 1, including those that are
 *  evenly divisible by 10000 (this is a Win32 bug that Wine mimics).
 *  Positive numbers are rounded using Dutch rounding: See VarI8FromR8()
 *  for details.
 */
HRESULT WINAPI VarI8FromCy(CY cyIn, LONG64* pi64Out)
{
  *pi64Out = cyIn.int64 / CY_MULTIPLIER;

  if (cyIn.int64 < 0)
    (*pi64Out)--; /* Mimic Win32 bug */
  else
  {
    cyIn.int64 -= *pi64Out * CY_MULTIPLIER; /* cyIn.s.Lo now holds fractional remainder */

    if (cyIn.Lo > CY_HALF || (cyIn.Lo == CY_HALF && (*pi64Out & 0x1)))
      (*pi64Out)++;
  }
  return S_OK;
}

/************************************************************************
 * VarI8FromDate (OLEAUT32.338)
 *
 * Convert a VT_DATE to a VT_I8.
 *
 * PARAMS
 *  dateIn  [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarI8FromDate(DATE dateIn, LONG64* pi64Out)
{
  return VarI8FromR8(dateIn, pi64Out);
}

/************************************************************************
 * VarI8FromStr (OLEAUT32.339)
 *
 * Convert a VT_BSTR to a VT_I8.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarI8FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, LONG64* pi64Out)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pi64Out, VT_I8);
}


/************************************************************************
 * VarI8FromBool (OLEAUT32.341)
 *
 * Convert a VT_BOOL to a VT_I8.
 *
 * PARAMS
 *  boolIn  [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI8FromBool(VARIANT_BOOL boolIn, LONG64* pi64Out)
{
  return VarI8FromI2(boolIn, pi64Out);
}

/************************************************************************
 * VarI8FromI1 (OLEAUT32.342)
 *
 * Convert a VT_I1 to a VT_I8.
 *
 * PARAMS
 *  cIn     [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI8FromI1(signed char cIn, LONG64* pi64Out)
{
  return _VarI8FromI1(cIn, pi64Out);
}

/************************************************************************
 * VarI8FromUI2 (OLEAUT32.343)
 *
 * Convert a VT_UI2 to a VT_I8.
 *
 * PARAMS
 *  usIn    [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI8FromUI2(USHORT usIn, LONG64* pi64Out)
{
  return _VarI8FromUI2(usIn, pi64Out);
}

/************************************************************************
 * VarI8FromUI4 (OLEAUT32.344)
 *
 * Convert a VT_UI4 to a VT_I8.
 *
 * PARAMS
 *  ulIn    [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarI8FromUI4(ULONG ulIn, LONG64* pi64Out)
{
  return _VarI8FromUI4(ulIn, pi64Out);
}

/************************************************************************
 * VarI8FromDec (OLEAUT32.345)
 *
 * Convert a VT_DECIMAL to a VT_I8.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI8FromDec(DECIMAL *pdecIn, LONG64* pi64Out)
{
  if (!DEC_SCALE(pdecIn))
  {
    /* This decimal is just a 96 bit integer */
    if (DEC_SIGN(pdecIn) & ~DECIMAL_NEG)
      return E_INVALIDARG;

    if (DEC_HI32(pdecIn) || DEC_MID32(pdecIn) & 0x80000000)
      return DISP_E_OVERFLOW;

    if (DEC_SIGN(pdecIn))
      *pi64Out = -DEC_LO64(pdecIn);
    else
      *pi64Out = DEC_LO64(pdecIn);
    return S_OK;
  }
  else
  {
    /* Decimal contains a floating point number */
    HRESULT hRet;
    double dbl;

    hRet = VarR8FromDec(pdecIn, &dbl);
    if (SUCCEEDED(hRet))
      hRet = VarI8FromR8(dbl, pi64Out);
    return hRet;
  }
}

/************************************************************************
 * VarI8FromUI8 (OLEAUT32.427)
 *
 * Convert a VT_UI8 to a VT_I8.
 *
 * PARAMS
 *  ullIn   [I] Source
 *  pi64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarI8FromUI8(ULONG64 ullIn, LONG64* pi64Out)
{
  return _VarI8FromUI8(ullIn, pi64Out);
}

/* UI8
 */

/************************************************************************
 * VarUI8FromI8 (OLEAUT32.428)
 *
 * Convert a VT_I8 to a VT_UI8.
 *
 * PARAMS
 *  ulIn     [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI8FromI8(LONG64 llIn, ULONG64* pui64Out)
{
  return _VarUI8FromI8(llIn, pui64Out);
}

/************************************************************************
 * VarUI8FromUI1 (OLEAUT32.429)
 *
 * Convert a VT_UI1 to a VT_UI8.
 *
 * PARAMS
 *  bIn      [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI8FromUI1(BYTE bIn, ULONG64* pui64Out)
{
  return _VarUI8FromUI1(bIn, pui64Out);
}

/************************************************************************
 * VarUI8FromI2 (OLEAUT32.430)
 *
 * Convert a VT_I2 to a VT_UI8.
 *
 * PARAMS
 *  sIn      [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI8FromI2(SHORT sIn, ULONG64* pui64Out)
{
  return _VarUI8FromI2(sIn, pui64Out);
}

/************************************************************************
 * VarUI8FromR4 (OLEAUT32.431)
 *
 * Convert a VT_R4 to a VT_UI8.
 *
 * PARAMS
 *  fltIn    [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI8FromR4(FLOAT fltIn, ULONG64* pui64Out)
{
  return VarUI8FromR8(fltIn, pui64Out);
}

/************************************************************************
 * VarUI8FromR8 (OLEAUT32.432)
 *
 * Convert a VT_R8 to a VT_UI8.
 *
 * PARAMS
 *  dblIn    [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  See VarI8FromR8() for details concerning rounding.
 */
HRESULT WINAPI VarUI8FromR8(double dblIn, ULONG64* pui64Out)
{
  if (dblIn < -0.5 || dblIn > 1.844674407370955e19)
    return DISP_E_OVERFLOW;
  VARIANT_DutchRound(ULONG64, dblIn, *pui64Out);
  return S_OK;
}

/************************************************************************
 * VarUI8FromCy (OLEAUT32.433)
 *
 * Convert a VT_CY to a VT_UI8.
 *
 * PARAMS
 *  cyIn     [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  Negative values >= -5000 will be converted to 0.
 */
HRESULT WINAPI VarUI8FromCy(CY cyIn, ULONG64* pui64Out)
{
  if (cyIn.int64 < 0)
  {
    if (cyIn.int64 < -CY_HALF)
      return DISP_E_OVERFLOW;
    *pui64Out = 0;
  }
  else
  {
    *pui64Out = cyIn.int64 / CY_MULTIPLIER;

    cyIn.int64 -= *pui64Out * CY_MULTIPLIER; /* cyIn.s.Lo now holds fractional remainder */

    if (cyIn.Lo > CY_HALF || (cyIn.Lo == CY_HALF && (*pui64Out & 0x1)))
      (*pui64Out)++;
  }
  return S_OK;
}

/************************************************************************
 * VarUI8FromDate (OLEAUT32.434)
 *
 * Convert a VT_DATE to a VT_UI8.
 *
 * PARAMS
 *  dateIn   [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarUI8FromDate(DATE dateIn, ULONG64* pui64Out)
{
  return VarUI8FromR8(dateIn, pui64Out);
}

/************************************************************************
 * VarUI8FromStr (OLEAUT32.435)
 *
 * Convert a VT_BSTR to a VT_UI8.
 *
 * PARAMS
 *  strIn    [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarUI8FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, ULONG64* pui64Out)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pui64Out, VT_UI8);
}


/************************************************************************
 * VarUI8FromBool (OLEAUT32.437)
 *
 * Convert a VT_BOOL to a VT_UI8.
 *
 * PARAMS
 *  boolIn   [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI8FromBool(VARIANT_BOOL boolIn, ULONG64* pui64Out)
{
  return VarI8FromI2(boolIn, (LONG64 *)pui64Out);
}
/************************************************************************
 * VarUI8FromI1 (OLEAUT32.438)
 *
 * Convert a VT_I1 to a VT_UI8.
 *
 * PARAMS
 *  cIn      [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarUI8FromI1(signed char cIn, ULONG64* pui64Out)
{
  return _VarUI8FromI1(cIn, pui64Out);
}

/************************************************************************
 * VarUI8FromUI2 (OLEAUT32.439)
 *
 * Convert a VT_UI2 to a VT_UI8.
 *
 * PARAMS
 *  usIn     [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI8FromUI2(USHORT usIn, ULONG64* pui64Out)
{
  return _VarUI8FromUI2(usIn, pui64Out);
}

/************************************************************************
 * VarUI8FromUI4 (OLEAUT32.440)
 *
 * Convert a VT_UI4 to a VT_UI8.
 *
 * PARAMS
 *  ulIn     [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarUI8FromUI4(ULONG ulIn, ULONG64* pui64Out)
{
  return _VarUI8FromUI4(ulIn, pui64Out);
}

/************************************************************************
 * VarUI8FromDec (OLEAUT32.441)
 *
 * Convert a VT_DECIMAL to a VT_UI8.
 *
 * PARAMS
 *  pDecIn   [I] Source
 *  pui64Out [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  Under native Win32, if the source value has a scale of 0, its sign is
 *  ignored, i.e. this function takes the absolute value rather than fail
 *  with DISP_E_OVERFLOW. This bug has been fixed in Wine's implementation
 *  (use VarAbs() on pDecIn first if you really want this behaviour).
 */
HRESULT WINAPI VarUI8FromDec(DECIMAL *pdecIn, ULONG64* pui64Out)
{
  if (!DEC_SCALE(pdecIn))
  {
    /* This decimal is just a 96 bit integer */
    if (DEC_SIGN(pdecIn) & ~DECIMAL_NEG)
      return E_INVALIDARG;

    if (DEC_HI32(pdecIn))
      return DISP_E_OVERFLOW;

    if (DEC_SIGN(pdecIn))
    {
      WARN("Sign would be ignored under Win32!\n");
      return DISP_E_OVERFLOW;
    }

    *pui64Out = DEC_LO64(pdecIn);
    return S_OK;
  }
  else
  {
    /* Decimal contains a floating point number */
    HRESULT hRet;
    double dbl;

    hRet = VarR8FromDec(pdecIn, &dbl);
    if (SUCCEEDED(hRet))
      hRet = VarUI8FromR8(dbl, pui64Out);
    return hRet;
  }
}

/* R4
 */

/************************************************************************
 * VarR4FromUI1 (OLEAUT32.68)
 *
 * Convert a VT_UI1 to a VT_R4.
 *
 * PARAMS
 *  bIn     [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR4FromUI1(BYTE bIn, float *pFltOut)
{
  return _VarR4FromUI1(bIn, pFltOut);
}

/************************************************************************
 * VarR4FromI2 (OLEAUT32.69)
 *
 * Convert a VT_I2 to a VT_R4.
 *
 * PARAMS
 *  sIn     [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR4FromI2(SHORT sIn, float *pFltOut)
{
  return _VarR4FromI2(sIn, pFltOut);
}

/************************************************************************
 * VarR4FromI4 (OLEAUT32.70)
 *
 * Convert a VT_I4 to a VT_R4.
 *
 * PARAMS
 *  sIn     [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR4FromI4(LONG lIn, float *pFltOut)
{
  return _VarR4FromI4(lIn, pFltOut);
}

/************************************************************************
 * VarR4FromR8 (OLEAUT32.71)
 *
 * Convert a VT_R8 to a VT_R4.
 *
 * PARAMS
 *  dblIn   [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination.
 */
HRESULT WINAPI VarR4FromR8(double dblIn, float *pFltOut)
{
  double d = dblIn < 0.0 ? -dblIn : dblIn;
  if (d > R4_MAX) return DISP_E_OVERFLOW;
  *pFltOut = dblIn;
  return S_OK;
}

/************************************************************************
 * VarR4FromCy (OLEAUT32.72)
 *
 * Convert a VT_CY to a VT_R4.
 *
 * PARAMS
 *  cyIn    [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR4FromCy(CY cyIn, float *pFltOut)
{
  *pFltOut = (double)cyIn.int64 / CY_MULTIPLIER_F;
  return S_OK;
}

/************************************************************************
 * VarR4FromDate (OLEAUT32.73)
 *
 * Convert a VT_DATE to a VT_R4.
 *
 * PARAMS
 *  dateIn  [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination.
 */
HRESULT WINAPI VarR4FromDate(DATE dateIn, float *pFltOut)
{
  return VarR4FromR8(dateIn, pFltOut);
}

/************************************************************************
 * VarR4FromStr (OLEAUT32.74)
 *
 * Convert a VT_BSTR to a VT_R4.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if strIn or pFltOut is invalid.
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarR4FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, float *pFltOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pFltOut, VT_R4);
}


/************************************************************************
 * VarR4FromBool (OLEAUT32.76)
 *
 * Convert a VT_BOOL to a VT_R4.
 *
 * PARAMS
 *  boolIn  [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR4FromBool(VARIANT_BOOL boolIn, float *pFltOut)
{
  return VarR4FromI2(boolIn, pFltOut);
}

/************************************************************************
 * VarR4FromI1 (OLEAUT32.213)
 *
 * Convert a VT_I1 to a VT_R4.
 *
 * PARAMS
 *  cIn     [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarR4FromI1(signed char cIn, float *pFltOut)
{
  return _VarR4FromI1(cIn, pFltOut);
}

/************************************************************************
 * VarR4FromUI2 (OLEAUT32.214)
 *
 * Convert a VT_UI2 to a VT_R4.
 *
 * PARAMS
 *  usIn    [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarR4FromUI2(USHORT usIn, float *pFltOut)
{
  return _VarR4FromUI2(usIn, pFltOut);
}

/************************************************************************
 * VarR4FromUI4 (OLEAUT32.215)
 *
 * Convert a VT_UI4 to a VT_R4.
 *
 * PARAMS
 *  ulIn    [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarR4FromUI4(ULONG ulIn, float *pFltOut)
{
  return _VarR4FromUI4(ulIn, pFltOut);
}

/************************************************************************
 * VarR4FromDec (OLEAUT32.216)
 *
 * Convert a VT_DECIMAL to a VT_R4.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid.
 */
HRESULT WINAPI VarR4FromDec(DECIMAL* pDecIn, float *pFltOut)
{
  BYTE scale = DEC_SCALE(pDecIn);
  int divisor = 1;
  double highPart;

  if (scale > DEC_MAX_SCALE || DEC_SIGN(pDecIn) & ~DECIMAL_NEG)
    return E_INVALIDARG;

  while (scale--)
    divisor *= 10;

  if (DEC_SIGN(pDecIn))
    divisor = -divisor;

  if (DEC_HI32(pDecIn))
  {
    highPart = (double)DEC_HI32(pDecIn) / (double)divisor;
    highPart *= 4294967296.0F;
    highPart *= 4294967296.0F;
  }
  else
    highPart = 0.0;

  *pFltOut = (double)DEC_LO64(pDecIn) / (double)divisor + highPart;
  return S_OK;
}

/************************************************************************
 * VarR4FromI8 (OLEAUT32.360)
 *
 * Convert a VT_I8 to a VT_R4.
 *
 * PARAMS
 *  ullIn   [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR4FromI8(LONG64 llIn, float *pFltOut)
{
  return _VarR4FromI8(llIn, pFltOut);
}

/************************************************************************
 * VarR4FromUI8 (OLEAUT32.361)
 *
 * Convert a VT_UI8 to a VT_R4.
 *
 * PARAMS
 *  ullIn   [I] Source
 *  pFltOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR4FromUI8(ULONG64 ullIn, float *pFltOut)
{
  return _VarR4FromUI8(ullIn, pFltOut);
}

/************************************************************************
 * VarR4CmpR8 (OLEAUT32.316)
 *
 * Compare a VT_R4 to a VT_R8.
 *
 * PARAMS
 *  fltLeft  [I] Source
 *  dblRight [I] Value to compare
 *
 * RETURNS
 *  VARCMP_LT, VARCMP_EQ or VARCMP_GT indicating that fltLeft is less than,
 *  equal to or greater than dblRight respectively.
 */
HRESULT WINAPI VarR4CmpR8(float fltLeft, double dblRight)
{
  if (fltLeft < dblRight)
    return VARCMP_LT;
  else if (fltLeft > dblRight)
    return VARCMP_GT;
  return VARCMP_EQ;
}

/* R8
 */

/************************************************************************
 * VarR8FromUI1 (OLEAUT32.78)
 *
 * Convert a VT_UI1 to a VT_R8.
 *
 * PARAMS
 *  bIn     [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromUI1(BYTE bIn, double *pDblOut)
{
  return _VarR8FromUI1(bIn, pDblOut);
}

/************************************************************************
 * VarR8FromI2 (OLEAUT32.79)
 *
 * Convert a VT_I2 to a VT_R8.
 *
 * PARAMS
 *  sIn     [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromI2(SHORT sIn, double *pDblOut)
{
  return _VarR8FromI2(sIn, pDblOut);
}

/************************************************************************
 * VarR8FromI4 (OLEAUT32.80)
 *
 * Convert a VT_I4 to a VT_R8.
 *
 * PARAMS
 *  sIn     [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromI4(LONG lIn, double *pDblOut)
{
  return _VarR8FromI4(lIn, pDblOut);
}

/************************************************************************
 * VarR8FromR4 (OLEAUT32.81)
 *
 * Convert a VT_R4 to a VT_R8.
 *
 * PARAMS
 *  fltIn   [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromR4(FLOAT fltIn, double *pDblOut)
{
  return _VarR8FromR4(fltIn, pDblOut);
}

/************************************************************************
 * VarR8FromCy (OLEAUT32.82)
 *
 * Convert a VT_CY to a VT_R8.
 *
 * PARAMS
 *  cyIn    [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromCy(CY cyIn, double *pDblOut)
{
  return _VarR8FromCy(cyIn, pDblOut);
}

/************************************************************************
 * VarR8FromDate (OLEAUT32.83)
 *
 * Convert a VT_DATE to a VT_R8.
 *
 * PARAMS
 *  dateIn  [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromDate(DATE dateIn, double *pDblOut)
{
  return _VarR8FromDate(dateIn, pDblOut);
}

/************************************************************************
 * VarR8FromStr (OLEAUT32.84)
 *
 * Convert a VT_BSTR to a VT_R8.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if strIn or pDblOut is invalid.
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarR8FromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, double *pDblOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pDblOut, VT_R8);
}


/************************************************************************
 * VarR8FromBool (OLEAUT32.86)
 *
 * Convert a VT_BOOL to a VT_R8.
 *
 * PARAMS
 *  boolIn  [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromBool(VARIANT_BOOL boolIn, double *pDblOut)
{
  return VarR8FromI2(boolIn, pDblOut);
}

/************************************************************************
 * VarR8FromI1 (OLEAUT32.217)
 *
 * Convert a VT_I1 to a VT_R8.
 *
 * PARAMS
 *  cIn     [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarR8FromI1(signed char cIn, double *pDblOut)
{
  return _VarR8FromI1(cIn, pDblOut);
}

/************************************************************************
 * VarR8FromUI2 (OLEAUT32.218)
 *
 * Convert a VT_UI2 to a VT_R8.
 *
 * PARAMS
 *  usIn    [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarR8FromUI2(USHORT usIn, double *pDblOut)
{
  return _VarR8FromUI2(usIn, pDblOut);
}

/************************************************************************
 * VarR8FromUI4 (OLEAUT32.219)
 *
 * Convert a VT_UI4 to a VT_R8.
 *
 * PARAMS
 *  ulIn    [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarR8FromUI4(ULONG ulIn, double *pDblOut)
{
  return _VarR8FromUI4(ulIn, pDblOut);
}

/************************************************************************
 * VarR8FromDec (OLEAUT32.220)
 *
 * Convert a VT_DECIMAL to a VT_R8.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid.
 */
HRESULT WINAPI VarR8FromDec(const DECIMAL* pDecIn, double *pDblOut)
{
  BYTE scale = DEC_SCALE(pDecIn);
  double divisor = 1.0, highPart;

  if (scale > DEC_MAX_SCALE || DEC_SIGN(pDecIn) & ~DECIMAL_NEG)
    return E_INVALIDARG;

  while (scale--)
    divisor *= 10;

  if (DEC_SIGN(pDecIn))
    divisor = -divisor;

  if (DEC_HI32(pDecIn))
  {
    highPart = (double)DEC_HI32(pDecIn) / divisor;
    highPart *= 4294967296.0F;
    highPart *= 4294967296.0F;
  }
  else
    highPart = 0.0;

  *pDblOut = (double)DEC_LO64(pDecIn) / divisor + highPart;
  return S_OK;
}

/************************************************************************
 * VarR8FromI8 (OLEAUT32.362)
 *
 * Convert a VT_I8 to a VT_R8.
 *
 * PARAMS
 *  ullIn   [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromI8(LONG64 llIn, double *pDblOut)
{
  return _VarR8FromI8(llIn, pDblOut);
}

/************************************************************************
 * VarR8FromUI8 (OLEAUT32.363)
 *
 * Convert a VT_UI8 to a VT_R8.
 *
 * PARAMS
 *  ullIn   [I] Source
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarR8FromUI8(ULONG64 ullIn, double *pDblOut)
{
  return _VarR8FromUI8(ullIn, pDblOut);
}

/************************************************************************
 * VarR8Pow (OLEAUT32.315)
 *
 * Raise a VT_R8 to a power.
 *
 * PARAMS
 *  dblLeft [I] Source
 *  dblPow  [I] Power to raise dblLeft by
 *  pDblOut [O] Destination
 *
 * RETURNS
 *  S_OK. pDblOut contains dblLeft to the power of dblRight.
 */
HRESULT WINAPI VarR8Pow(double dblLeft, double dblPow, double *pDblOut)
{
  *pDblOut = pow(dblLeft, dblPow);
  return S_OK;
}

/************************************************************************
 * VarR8Round (OLEAUT32.317)
 *
 * Round a VT_R8 to a given number of decimal points.
 *
 * PARAMS
 *  dblIn   [I] Source
 *  nDig    [I] Number of decimal points to round to
 *  pDblOut [O] Destination for rounded number
 *
 * RETURNS
 *  Success: S_OK. pDblOut is rounded to nDig digits.
 *  Failure: E_INVALIDARG, if cDecimals is less than 0.
 *
 * NOTES
 *  The native version of this function rounds using the internal
 *  binary representation of the number. Wine uses the dutch rounding
 *  convention, so therefore small differences can occur in the value returned.
 *  MSDN says that you should use your own rounding function if you want
 *  rounding to be predictable in your application.
 */
HRESULT WINAPI VarR8Round(double dblIn, int nDig, double *pDblOut)
{
  double scale, whole, fract;

  if (nDig < 0)
    return E_INVALIDARG;

  scale = pow(10.0, nDig);

  dblIn *= scale;
  whole = dblIn < 0 ? ceil(dblIn) : floor(dblIn);
  fract = dblIn - whole;

  if (fract > 0.5)
    dblIn = whole + 1.0;
  else if (fract == 0.5)
    dblIn = whole + fmod(whole, 2.0);
  else if (fract >= 0.0)
    dblIn = whole;
  else if (fract == -0.5)
    dblIn = whole - fmod(whole, 2.0);
  else if (fract > -0.5)
    dblIn = whole;
  else
    dblIn = whole - 1.0;

  *pDblOut = dblIn / scale;
  return S_OK;
}

/* CY
 */

/* Powers of 10 from 0..4 D.P. */
static const int CY_Divisors[5] = { CY_MULTIPLIER/10000, CY_MULTIPLIER/1000,
  CY_MULTIPLIER/100, CY_MULTIPLIER/10, CY_MULTIPLIER };

/************************************************************************
 * VarCyFromUI1 (OLEAUT32.98)
 *
 * Convert a VT_UI1 to a VT_CY.
 *
 * PARAMS
 *  bIn    [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromUI1(BYTE bIn, CY* pCyOut)
{
    pCyOut->int64 = (ULONG64)bIn * CY_MULTIPLIER;
    return S_OK;
}

/************************************************************************
 * VarCyFromI2 (OLEAUT32.99)
 *
 * Convert a VT_I2 to a VT_CY.
 *
 * PARAMS
 *  sIn    [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromI2(SHORT sIn, CY* pCyOut)
{
    pCyOut->int64 = (LONG64)sIn * CY_MULTIPLIER;
    return S_OK;
}

/************************************************************************
 * VarCyFromI4 (OLEAUT32.100)
 *
 * Convert a VT_I4 to a VT_CY.
 *
 * PARAMS
 *  sIn    [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromI4(LONG lIn, CY* pCyOut)
{
    pCyOut->int64 = (LONG64)lIn * CY_MULTIPLIER;
    return S_OK;
}

/************************************************************************
 * VarCyFromR4 (OLEAUT32.101)
 *
 * Convert a VT_R4 to a VT_CY.
 *
 * PARAMS
 *  fltIn  [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromR4(FLOAT fltIn, CY* pCyOut)
{
  return VarCyFromR8(fltIn, pCyOut);
}

/************************************************************************
 * VarCyFromR8 (OLEAUT32.102)
 *
 * Convert a VT_R8 to a VT_CY.
 *
 * PARAMS
 *  dblIn  [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromR8(double dblIn, CY* pCyOut)
{
#if 0 /* don't use assembler */ // defined (__GNUC__) && (defined(__i386__) || defined(__x86_64__))
  /* This code gives identical results to Win32 on Intel.
   * Here we use fp exceptions to catch overflows when storing the value.
   */
  static const unsigned short r8_fpcontrol = 0x137f;
  static const double r8_multiplier = CY_MULTIPLIER_F;
  unsigned short old_fpcontrol, result_fpstatus;

  /* Clear exceptions, save the old fp state and load the new state */
  __asm__ __volatile__( "fnclex" );
  __asm__ __volatile__( "fstcw %0"   :   "=m" (old_fpcontrol) : );
  __asm__ __volatile__( "fldcw %0"   : : "m"  (r8_fpcontrol) );
  /* Perform the conversion. */
  __asm__ __volatile__( "fldl  %0"   : : "m"  (dblIn) );
  __asm__ __volatile__( "fmull %0"   : : "m"  (r8_multiplier) );
  __asm__ __volatile__( "fistpll %0" : : "m"  (*pCyOut) );
  /* Save the resulting fp state, load the old state and clear exceptions */
  __asm__ __volatile__( "fstsw %0"   :   "=m" (result_fpstatus) : );
  __asm__ __volatile__( "fnclex" );
  __asm__ __volatile__( "fldcw %0"   : : "m"  (old_fpcontrol) );

  if (result_fpstatus & 0x9) /* Overflow | Invalid */
    return DISP_E_OVERFLOW;
#else
  /* This version produces slightly different results for boundary cases */
  if (dblIn < -922337203685477.5807 || dblIn >= 922337203685477.5807)
    return DISP_E_OVERFLOW;
  dblIn *= CY_MULTIPLIER_F;
  VARIANT_DutchRound(LONG64, dblIn, pCyOut->int64);
#endif
  return S_OK;
}

/************************************************************************
 * VarCyFromDate (OLEAUT32.103)
 *
 * Convert a VT_DATE to a VT_CY.
 *
 * PARAMS
 *  dateIn [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromDate(DATE dateIn, CY* pCyOut)
{
  return VarCyFromR8(dateIn, pCyOut);
}

/************************************************************************
 * VarCyFromStr (OLEAUT32.104)
 *
 * Convert a VT_BSTR to a VT_CY.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pCyOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, CY* pCyOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pCyOut, VT_CY);
}


/************************************************************************
 * VarCyFromBool (OLEAUT32.106)
 *
 * Convert a VT_BOOL to a VT_CY.
 *
 * PARAMS
 *  boolIn [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 *
 * NOTES
 *  While the sign of the boolean is stored in the currency, the value is
 *  converted to either 0 or 1.
 */
HRESULT WINAPI VarCyFromBool(VARIANT_BOOL boolIn, CY* pCyOut)
{
    pCyOut->int64 = (LONG64)boolIn * CY_MULTIPLIER;
    return S_OK;
}

/************************************************************************
 * VarCyFromI1 (OLEAUT32.225)
 *
 * Convert a VT_I1 to a VT_CY.
 *
 * PARAMS
 *  cIn    [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromI1(signed char cIn, CY* pCyOut)
{
    pCyOut->int64 = (LONG64)cIn * CY_MULTIPLIER;
    return S_OK;
}

/************************************************************************
 * VarCyFromUI2 (OLEAUT32.226)
 *
 * Convert a VT_UI2 to a VT_CY.
 *
 * PARAMS
 *  usIn   [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromUI2(USHORT usIn, CY* pCyOut)
{
    pCyOut->int64 = (ULONG64)usIn * CY_MULTIPLIER;
    return S_OK;
}

/************************************************************************
 * VarCyFromUI4 (OLEAUT32.227)
 *
 * Convert a VT_UI4 to a VT_CY.
 *
 * PARAMS
 *  ulIn   [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromUI4(ULONG ulIn, CY* pCyOut)
{
    pCyOut->int64 = (ULONG64)ulIn * CY_MULTIPLIER;
    return S_OK;
}

/************************************************************************
 * VarCyFromDec (OLEAUT32.228)
 *
 * Convert a VT_DECIMAL to a VT_CY.
 *
 * PARAMS
 *  pdecIn  [I] Source
 *  pCyOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromDec(DECIMAL* pdecIn, CY* pCyOut)
{
  DECIMAL rounded;
  HRESULT hRet;

  hRet = VarDecRound(pdecIn, 4, &rounded);

  if (SUCCEEDED(hRet))
  {
    double d;

    if (DEC_HI32(&rounded))
      return DISP_E_OVERFLOW;

    /* Note: Without the casts this promotes to int64 which loses precision */
    d = (double)DEC_LO64(&rounded) / (double)CY_Divisors[DEC_SCALE(&rounded)];
    if (DEC_SIGN(&rounded))
      d = -d;
    return VarCyFromR8(d, pCyOut);
  }
  return hRet;
}

/************************************************************************
 * VarCyFromI8 (OLEAUT32.366)
 *
 * Convert a VT_I8 to a VT_CY.
 *
 * PARAMS
 *  ullIn  [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromI8(LONG64 llIn, CY* pCyOut)
{
  if (llIn <= (I8_MIN/CY_MULTIPLIER) || llIn >= (I8_MAX/CY_MULTIPLIER)) return DISP_E_OVERFLOW;
  pCyOut->int64 = llIn * CY_MULTIPLIER;
  return S_OK;
}

/************************************************************************
 * VarCyFromUI8 (OLEAUT32.375)
 *
 * Convert a VT_UI8 to a VT_CY.
 *
 * PARAMS
 *  ullIn  [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if the source value is invalid
 *           DISP_E_OVERFLOW, if the value will not fit in the destination
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 */
HRESULT WINAPI VarCyFromUI8(ULONG64 ullIn, CY* pCyOut)
{
    if (ullIn >= (I8_MAX/CY_MULTIPLIER)) return DISP_E_OVERFLOW;
    pCyOut->int64 = ullIn * CY_MULTIPLIER;
    return S_OK;
}

/************************************************************************
 * VarCyAdd (OLEAUT32.299)
 *
 * Add one CY to another.
 *
 * PARAMS
 *  cyLeft  [I] Source
 *  cyRight [I] Value to add
 *  pCyOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarCyAdd(const CY cyLeft, const CY cyRight, CY* pCyOut)
{
  double l,r;
  _VarR8FromCy(cyLeft, &l);
  _VarR8FromCy(cyRight, &r);
  l = l + r;
  return VarCyFromR8(l, pCyOut);
}

/************************************************************************
 * VarCyMul (OLEAUT32.303)
 *
 * Multiply one CY by another.
 *
 * PARAMS
 *  cyLeft  [I] Source
 *  cyRight [I] Value to multiply by
 *  pCyOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarCyMul(const CY cyLeft, const CY cyRight, CY* pCyOut)
{
  double l,r;
  _VarR8FromCy(cyLeft, &l);
  _VarR8FromCy(cyRight, &r);
  l = l * r;
  return VarCyFromR8(l, pCyOut);
}

/************************************************************************
 * VarCyMulI4 (OLEAUT32.304)
 *
 * Multiply one CY by a VT_I4.
 *
 * PARAMS
 *  cyLeft  [I] Source
 *  lRight  [I] Value to multiply by
 *  pCyOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarCyMulI4(const CY cyLeft, LONG lRight, CY* pCyOut)
{
  double d;

  _VarR8FromCy(cyLeft, &d);
  d = d * lRight;
  return VarCyFromR8(d, pCyOut);
}

/************************************************************************
 * VarCySub (OLEAUT32.305)
 *
 * Subtract one CY from another.
 *
 * PARAMS
 *  cyLeft  [I] Source
 *  cyRight [I] Value to subtract
 *  pCyOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarCySub(const CY cyLeft, const CY cyRight, CY* pCyOut)
{
  double l,r;
  _VarR8FromCy(cyLeft, &l);
  _VarR8FromCy(cyRight, &r);
  l = l - r;
  return VarCyFromR8(l, pCyOut);
}

/************************************************************************
 * VarCyAbs (OLEAUT32.306)
 *
 * Convert a VT_CY into its absolute value.
 *
 * PARAMS
 *  cyIn   [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK. pCyOut contains the absolute value.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarCyAbs(const CY cyIn, CY* pCyOut)
{
  if (cyIn.Hi == (int)0x80000000 && !cyIn.Lo)
    return DISP_E_OVERFLOW;

  pCyOut->int64 = cyIn.int64 < 0 ? -cyIn.int64 : cyIn.int64;
  return S_OK;
}

/************************************************************************
 * VarCyFix (OLEAUT32.307)
 *
 * Return the integer part of a VT_CY.
 *
 * PARAMS
 *  cyIn   [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  - The difference between this function and VarCyInt() is that VarCyInt() rounds
 *    negative numbers away from 0, while this function rounds them towards zero.
 */
HRESULT WINAPI VarCyFix(const CY cyIn, CY* pCyOut)
{
  pCyOut->int64 = cyIn.int64 / CY_MULTIPLIER;
  pCyOut->int64 *= CY_MULTIPLIER;
  return S_OK;
}

/************************************************************************
 * VarCyInt (OLEAUT32.308)
 *
 * Return the integer part of a VT_CY.
 *
 * PARAMS
 *  cyIn   [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  - The difference between this function and VarCyFix() is that VarCyFix() rounds
 *    negative numbers towards 0, while this function rounds them away from zero.
 */
HRESULT WINAPI VarCyInt(const CY cyIn, CY* pCyOut)
{
  pCyOut->int64 = cyIn.int64 / CY_MULTIPLIER;
  pCyOut->int64 *= CY_MULTIPLIER;

  if (cyIn.int64 < 0 && cyIn.int64 % CY_MULTIPLIER != 0)
  {
    pCyOut->int64 -= CY_MULTIPLIER;
  }
  return S_OK;
}

/************************************************************************
 * VarCyNeg (OLEAUT32.309)
 *
 * Change the sign of a VT_CY.
 *
 * PARAMS
 *  cyIn   [I] Source
 *  pCyOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarCyNeg(const CY cyIn, CY* pCyOut)
{
  if (cyIn.Hi == (int)0x80000000 && !cyIn.Lo)
    return DISP_E_OVERFLOW;

  pCyOut->int64 = -cyIn.int64;
  return S_OK;
}

/************************************************************************
 * VarCyRound (OLEAUT32.310)
 *
 * Change the precision of a VT_CY.
 *
 * PARAMS
 *  cyIn      [I] Source
 *  cDecimals [I] New number of decimals to keep
 *  pCyOut    [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if cDecimals is less than 0.
 */
HRESULT WINAPI VarCyRound(const CY cyIn, int cDecimals, CY* pCyOut)
{
  if (cDecimals < 0)
    return E_INVALIDARG;

  if (cDecimals > 3)
  {
    /* Rounding to more precision than we have */
    *pCyOut = cyIn;
    return S_OK;
  }
  else
  {
    double d, div = CY_Divisors[cDecimals];

    _VarR8FromCy(cyIn, &d);
    d = d * div;
    VARIANT_DutchRound(LONGLONG, d, pCyOut->int64);
    d = (double)pCyOut->int64 / div * CY_MULTIPLIER_F;
    VARIANT_DutchRound(LONGLONG, d, pCyOut->int64);
    return S_OK;
  }
}

/************************************************************************
 * VarCyCmp (OLEAUT32.311)
 *
 * Compare two VT_CY values.
 *
 * PARAMS
 *  cyLeft  [I] Source
 *  cyRight [I] Value to compare
 *
 * RETURNS
 *  Success: VARCMP_LT, VARCMP_EQ or VARCMP_GT indicating that the value to
 *           compare is less, equal or greater than source respectively.
 *  Failure: DISP_E_OVERFLOW, if overflow occurs during the comparison
 */
HRESULT WINAPI VarCyCmp(const CY cyLeft, const CY cyRight)
{
  HRESULT hRet;
  CY result;

  /* Subtract right from left, and compare the result to 0 */
  hRet = VarCySub(cyLeft, cyRight, &result);

  if (SUCCEEDED(hRet))
  {
    if (result.int64 < 0)
      hRet = (HRESULT)VARCMP_LT;
    else if (result.int64 > 0)
      hRet = (HRESULT)VARCMP_GT;
    else
      hRet = (HRESULT)VARCMP_EQ;
  }
  return hRet;
}

/************************************************************************
 * VarCyCmpR8 (OLEAUT32.312)
 *
 * Compare a VT_CY to a double
 *
 * PARAMS
 *  cyLeft   [I] Currency Source
 *  dblRight [I] double to compare to cyLeft
 *
 * RETURNS
 *  Success: VARCMP_LT, VARCMP_EQ or VARCMP_GT indicating that dblRight is
 *           less than, equal to or greater than cyLeft respectively.
 *  Failure: DISP_E_OVERFLOW, if overflow occurs during the comparison
 */
HRESULT WINAPI VarCyCmpR8(const CY cyLeft, double dblRight)
{
  HRESULT hRet;
  CY cyRight;

  hRet = VarCyFromR8(dblRight, &cyRight);

  if (SUCCEEDED(hRet))
    hRet = VarCyCmp(cyLeft, cyRight);

  return hRet;
}

/************************************************************************
 * VarCyMulI8 (OLEAUT32.329)
 *
 * Multiply a VT_CY by a VT_I8.
 *
 * PARAMS
 *  cyLeft  [I] Source
 *  llRight [I] Value to multiply by
 *  pCyOut  [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarCyMulI8(const CY cyLeft, LONG64 llRight, CY* pCyOut)
{
  double d;

  _VarR8FromCy(cyLeft, &d);
  d = d  * (double)llRight;
  return VarCyFromR8(d, pCyOut);
}

/* DECIMAL
 */

/************************************************************************
 * VarDecFromUI1 (OLEAUT32.190)
 *
 * Convert a VT_UI1 to a DECIMAL.
 *
 * PARAMS
 *  bIn     [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromUI1(BYTE bIn, DECIMAL* pDecOut)
{
  return VarDecFromUI4(bIn, pDecOut);
}

/************************************************************************
 * VarDecFromI2 (OLEAUT32.191)
 *
 * Convert a VT_I2 to a DECIMAL.
 *
 * PARAMS
 *  sIn     [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromI2(SHORT sIn, DECIMAL* pDecOut)
{
  return VarDecFromI4(sIn, pDecOut);
}

/************************************************************************
 * VarDecFromI4 (OLEAUT32.192)
 *
 * Convert a VT_I4 to a DECIMAL.
 *
 * PARAMS
 *  sIn     [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromI4(LONG lIn, DECIMAL* pDecOut)
{
  DEC_HI32(pDecOut) = 0;
  DEC_MID32(pDecOut) = 0;

  if (lIn < 0)
  {
    DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_NEG,0);
    DEC_LO32(pDecOut) = -lIn;
  }
  else
  {
    DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_POS,0);
    DEC_LO32(pDecOut) = lIn;
  }
  return S_OK;
}

#define LOCALE_EN_US		(MAKELCID(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_US),SORT_DEFAULT))

/* internal representation of the value stored in a DECIMAL. The bytes are
   stored from LSB at index 0 to MSB at index 11
 */
typedef struct DECIMAL_internal
{
    DWORD bitsnum[3];  /* 96 significant bits, unsigned */
    unsigned char scale;      /* number scaled * 10 ^ -(scale) */
    unsigned int  sign : 1;   /* 0 - positive, 1 - negative */
} VARIANT_DI;

static HRESULT VARIANT_DI_FromR4(float source, VARIANT_DI * dest);
static HRESULT VARIANT_DI_FromR8(double source, VARIANT_DI * dest);
static void VARIANT_DIFromDec(const DECIMAL * from, VARIANT_DI * to);
static void VARIANT_DecFromDI(const VARIANT_DI * from, DECIMAL * to);

/************************************************************************
 * VarDecFromR4 (OLEAUT32.193)
 *
 * Convert a VT_R4 to a DECIMAL.
 *
 * PARAMS
 *  fltIn   [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromR4(FLOAT fltIn, DECIMAL* pDecOut)
{
  VARIANT_DI di;
  HRESULT hres;

  hres = VARIANT_DI_FromR4(fltIn, &di);
  if (hres == S_OK) VARIANT_DecFromDI(&di, pDecOut);
  return hres;
}

/************************************************************************
 * VarDecFromR8 (OLEAUT32.194)
 *
 * Convert a VT_R8 to a DECIMAL.
 *
 * PARAMS
 *  dblIn   [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromR8(double dblIn, DECIMAL* pDecOut)
{
  VARIANT_DI di;
  HRESULT hres;

  hres = VARIANT_DI_FromR8(dblIn, &di);
  if (hres == S_OK) VARIANT_DecFromDI(&di, pDecOut);
  return hres;
}

/************************************************************************
 * VarDecFromDate (OLEAUT32.195)
 *
 * Convert a VT_DATE to a DECIMAL.
 *
 * PARAMS
 *  dateIn  [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromDate(DATE dateIn, DECIMAL* pDecOut)
{
  return VarDecFromR8(dateIn, pDecOut);
}

/************************************************************************
 * VarDecFromCy (OLEAUT32.196)
 *
 * Convert a VT_CY to a DECIMAL.
 *
 * PARAMS
 *  cyIn    [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromCy(CY cyIn, DECIMAL* pDecOut)
{
  DEC_HI32(pDecOut) = 0;

  /* Note: This assumes 2s complement integer representation */
  if (cyIn.Hi & 0x80000000)
  {
    DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_NEG,4);
    DEC_LO64(pDecOut) = -cyIn.int64;
  }
  else
  {
    DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_POS,4);
    DEC_MID32(pDecOut) = cyIn.Hi;
    DEC_LO32(pDecOut) = cyIn.Lo;
  }
  return S_OK;
}

/************************************************************************
 * VarDecFromStr (OLEAUT32.197)
 *
 * Convert a VT_BSTR to a DECIMAL.
 *
 * PARAMS
 *  strIn   [I] Source
 *  lcid    [I] LCID for the conversion
 *  dwFlags [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarDecFromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, DECIMAL* pDecOut)
{
  return VARIANT_NumberFromBstr(strIn, lcid, dwFlags, pDecOut, VT_DECIMAL);
}


/************************************************************************
 * VarDecFromBool (OLEAUT32.199)
 *
 * Convert a VT_BOOL to a DECIMAL.
 *
 * PARAMS
 *  bIn     [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 *
 * NOTES
 *  The value is converted to either 0 (if bIn is FALSE) or -1 (TRUE).
 */
HRESULT WINAPI VarDecFromBool(VARIANT_BOOL bIn, DECIMAL* pDecOut)
{
  DEC_HI32(pDecOut) = 0;
  DEC_MID32(pDecOut) = 0;
  if (bIn)
  {
    DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_NEG,0);
    DEC_LO32(pDecOut) = 1;
  }
  else
  {
    DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_POS,0);
    DEC_LO32(pDecOut) = 0;
  }
  return S_OK;
}

/************************************************************************
 * VarDecFromI1 (OLEAUT32.241)
 *
 * Convert a VT_I1 to a DECIMAL.
 *
 * PARAMS
 *  cIn     [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromI1(signed char cIn, DECIMAL* pDecOut)
{
  return VarDecFromI4(cIn, pDecOut);
}

/************************************************************************
 * VarDecFromUI2 (OLEAUT32.242)
 *
 * Convert a VT_UI2 to a DECIMAL.
 *
 * PARAMS
 *  usIn    [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromUI2(USHORT usIn, DECIMAL* pDecOut)
{
  return VarDecFromUI4(usIn, pDecOut);
}

/************************************************************************
 * VarDecFromUI4 (OLEAUT32.243)
 *
 * Convert a VT_UI4 to a DECIMAL.
 *
 * PARAMS
 *  ulIn    [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromUI4(ULONG ulIn, DECIMAL* pDecOut)
{
  DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_POS,0);
  DEC_HI32(pDecOut) = 0;
  DEC_MID32(pDecOut) = 0;
  DEC_LO32(pDecOut) = ulIn;
  return S_OK;
}

/************************************************************************
 * VarDecFromI8 (OLEAUT32.374)
 *
 * Convert a VT_I8 to a DECIMAL.
 *
 * PARAMS
 *  llIn    [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromI8(LONG64 llIn, DECIMAL* pDecOut)
{
  PULARGE_INTEGER pLi = (PULARGE_INTEGER)&llIn;

  DEC_HI32(pDecOut) = 0;

  /* Note: This assumes 2s complement integer representation */
  if (pLi->u.HighPart & 0x80000000)
  {
    DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_NEG,0);
    DEC_LO64(pDecOut) = -pLi->QuadPart;
  }
  else
  {
    DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_POS,0);
    DEC_MID32(pDecOut) = pLi->u.HighPart;
    DEC_LO32(pDecOut) = pLi->u.LowPart;
  }
  return S_OK;
}

/************************************************************************
 * VarDecFromUI8 (OLEAUT32.375)
 *
 * Convert a VT_UI8 to a DECIMAL.
 *
 * PARAMS
 *  ullIn   [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDecFromUI8(ULONG64 ullIn, DECIMAL* pDecOut)
{
  DEC_SIGNSCALE(pDecOut) = SIGNSCALE(DECIMAL_POS,0);
  DEC_HI32(pDecOut) = 0;
  DEC_LO64(pDecOut) = ullIn;
  return S_OK;
}

/* Make two DECIMALS the same scale; used by math functions below */
static HRESULT VARIANT_DecScale(const DECIMAL** ppDecLeft,
                                const DECIMAL** ppDecRight,
                                DECIMAL* pDecOut)
{
  static DECIMAL scaleFactor;
  DECIMAL decTemp;
  int scaleAmount, i;
  HRESULT hRet = S_OK;

  if (DEC_SIGN(*ppDecLeft) & ~DECIMAL_NEG || DEC_SIGN(*ppDecRight) & ~DECIMAL_NEG)
    return E_INVALIDARG;

  DEC_LO32(&scaleFactor) = 10;

  i = scaleAmount = DEC_SCALE(*ppDecLeft) - DEC_SCALE(*ppDecRight);

  if (!scaleAmount)
    return S_OK; /* Same scale */

  if (scaleAmount > 0)
  {
    decTemp = *(*ppDecRight); /* Left is bigger - scale the right hand side */
    *ppDecRight = pDecOut;
  }
  else
  {
    decTemp = *(*ppDecLeft); /* Right is bigger - scale the left hand side */
    *ppDecLeft = pDecOut;
    i = scaleAmount = -scaleAmount;
  }

  if (DEC_SCALE(&decTemp) + scaleAmount > DEC_MAX_SCALE)
    return DISP_E_OVERFLOW; /* Can't scale up */

  /* Multiply up the value to be scaled by the correct amount */
  while (SUCCEEDED(hRet) && i--)
  {
    /* Note we are multiplying by a value with a scale of 0, so we don't recurse */
    hRet = VarDecMul(&decTemp, &scaleFactor, pDecOut);
    decTemp = *pDecOut;
  }
  DEC_SCALE(pDecOut) += scaleAmount; /* Set the new scale */
  return hRet;
}

/* Add two unsigned 32 bit values with overflow */
static ULONG VARIANT_Add(ULONG ulLeft, ULONG ulRight, ULONG* pulHigh)
{
  ULARGE_INTEGER ul64;

  ul64.QuadPart = (ULONG64)ulLeft + (ULONG64)ulRight + (ULONG64)*pulHigh;
  *pulHigh = ul64.u.HighPart;
  return ul64.u.LowPart;
}

/* Subtract two unsigned 32 bit values with underflow */
static ULONG VARIANT_Sub(ULONG ulLeft, ULONG ulRight, ULONG* pulHigh)
{
  int invert = 0;
  ULARGE_INTEGER ul64;

  ul64.QuadPart = (LONG64)ulLeft - (ULONG64)ulRight;
  if (ulLeft < ulRight)
    invert = 1;

  if (ul64.QuadPart > (ULONG64)*pulHigh)
    ul64.QuadPart -= (ULONG64)*pulHigh;
  else
  {
    ul64.QuadPart -= (ULONG64)*pulHigh;
    invert = 1;
  }
  if (invert)
    ul64.u.HighPart = -ul64.u.HighPart ;

  *pulHigh = ul64.u.HighPart;
  return ul64.u.LowPart;
}

/* Multiply two unsigned 32 bit values with overflow */
static ULONG VARIANT_Mul(ULONG ulLeft, ULONG ulRight, ULONG* pulHigh)
{
  ULARGE_INTEGER ul64;

  ul64.QuadPart = (ULONG64)ulLeft * (ULONG64)ulRight + (ULONG64)*pulHigh;
  *pulHigh = ul64.u.HighPart;
  return ul64.u.LowPart;
}

/* Compare two decimals that have the same scale */
static inline int VARIANT_DecCmp(const DECIMAL *pDecLeft, const DECIMAL *pDecRight)
{
  if ( DEC_HI32(pDecLeft) < DEC_HI32(pDecRight) ||
      (DEC_HI32(pDecLeft) <= DEC_HI32(pDecRight) && DEC_LO64(pDecLeft) < DEC_LO64(pDecRight)))
    return -1;
  else if (DEC_HI32(pDecLeft) == DEC_HI32(pDecRight) && DEC_LO64(pDecLeft) == DEC_LO64(pDecRight))
    return 0;
  return 1;
}

/************************************************************************
 * VarDecAdd (OLEAUT32.177)
 *
 * Add one DECIMAL to another.
 *
 * PARAMS
 *  pDecLeft  [I] Source
 *  pDecRight [I] Value to add
 *  pDecOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarDecAdd(const DECIMAL* pDecLeft, const DECIMAL* pDecRight, DECIMAL* pDecOut)
{
  HRESULT hRet;
  DECIMAL scaled;
  int cmp;
  hRet = VARIANT_DecScale(&pDecLeft, &pDecRight, &scaled);

  if (SUCCEEDED(hRet))
  {
    /* Our decimals now have the same scale, we can add them as 96 bit integers */
    ULONG overflow = 0;
    BYTE sign = DECIMAL_POS;

    /* Correct for the sign of the result */
    if (DEC_SIGN(pDecLeft) && DEC_SIGN(pDecRight))
    {
      /* -x + -y : Negative */
      sign = DECIMAL_NEG;
      goto VarDecAdd_AsPositive;
    }
    else if (DEC_SIGN(pDecLeft) && !DEC_SIGN(pDecRight))
    {
      cmp = VARIANT_DecCmp(pDecLeft, pDecRight);

      /* -x + y : Negative if x > y */
      if (cmp > 0)
      {
        sign = DECIMAL_NEG;
VarDecAdd_AsNegative:
        DEC_LO32(pDecOut)  = VARIANT_Sub(DEC_LO32(pDecLeft),  DEC_LO32(pDecRight),  &overflow);
        DEC_MID32(pDecOut) = VARIANT_Sub(DEC_MID32(pDecLeft), DEC_MID32(pDecRight), &overflow);
        DEC_HI32(pDecOut)  = VARIANT_Sub(DEC_HI32(pDecLeft),  DEC_HI32(pDecRight),  &overflow);
      }
      else
      {
VarDecAdd_AsInvertedNegative:
        DEC_LO32(pDecOut)  = VARIANT_Sub(DEC_LO32(pDecRight),  DEC_LO32(pDecLeft),  &overflow);
        DEC_MID32(pDecOut) = VARIANT_Sub(DEC_MID32(pDecRight), DEC_MID32(pDecLeft), &overflow);
        DEC_HI32(pDecOut)  = VARIANT_Sub(DEC_HI32(pDecRight),  DEC_HI32(pDecLeft),  &overflow);
      }
    }
    else if (!DEC_SIGN(pDecLeft) && DEC_SIGN(pDecRight))
    {
      cmp = VARIANT_DecCmp(pDecLeft, pDecRight);

      /* x + -y : Negative if x <= y */
      if (cmp <= 0)
      {
        sign = DECIMAL_NEG;
        goto VarDecAdd_AsInvertedNegative;
      }
      goto VarDecAdd_AsNegative;
    }
    else
    {
      /* x + y : Positive */
VarDecAdd_AsPositive:
      DEC_LO32(pDecOut)  = VARIANT_Add(DEC_LO32(pDecLeft),  DEC_LO32(pDecRight),  &overflow);
      DEC_MID32(pDecOut) = VARIANT_Add(DEC_MID32(pDecLeft), DEC_MID32(pDecRight), &overflow);
      DEC_HI32(pDecOut)  = VARIANT_Add(DEC_HI32(pDecLeft),  DEC_HI32(pDecRight),  &overflow);
    }

    if (overflow)
      return DISP_E_OVERFLOW; /* overflowed */

    DEC_SCALE(pDecOut) = DEC_SCALE(pDecLeft);
    DEC_SIGN(pDecOut) = sign;
  }
  return hRet;
}

/* translate from external DECIMAL format into an internal representation */
static void VARIANT_DIFromDec(const DECIMAL * from, VARIANT_DI * to)
{
    to->scale = DEC_SCALE(from);
    to->sign = DEC_SIGN(from) ? 1 : 0;

    to->bitsnum[0] = DEC_LO32(from);
    to->bitsnum[1] = DEC_MID32(from);
    to->bitsnum[2] = DEC_HI32(from);
}

static void VARIANT_DecFromDI(const VARIANT_DI * from, DECIMAL * to)
{
    if (from->sign) {
        DEC_SIGNSCALE(to) = SIGNSCALE(DECIMAL_NEG, from->scale);
    } else {
        DEC_SIGNSCALE(to) = SIGNSCALE(DECIMAL_POS, from->scale);
    }

    DEC_LO32(to) = from->bitsnum[0];
    DEC_MID32(to) = from->bitsnum[1];
    DEC_HI32(to) = from->bitsnum[2];
}

/* clear an internal representation of a DECIMAL */
static void VARIANT_DI_clear(VARIANT_DI * i)
{
    memset(i, 0, sizeof(VARIANT_DI));
}

/* divide the (unsigned) number stored in p (LSB) by a byte value (<= 0xff). Any nonzero
   size is supported. The value in p is replaced by the quotient of the division, and
   the remainder is returned as a result. This routine is most often used with a divisor
   of 10 in order to scale up numbers, and in the DECIMAL->string conversion.
 */
static unsigned char VARIANT_int_divbychar(DWORD * p, unsigned int n, unsigned char divisor)
{
    if (divisor == 0) {
        /* division by 0 */
        return 0xFF;
    } else if (divisor == 1) {
        /* dividend remains unchanged */
        return 0;
    } else {
        unsigned char remainder = 0;
        ULONGLONG iTempDividend;
        signed int i;
        
        for (i = n - 1; i >= 0 && !p[i]; i--);  /* skip leading zeros */
        for (; i >= 0; i--) {
            iTempDividend = ((ULONGLONG)remainder << 32) + p[i];
            remainder = iTempDividend % divisor;
            p[i] = iTempDividend / divisor;
        }
        
        return remainder;
    }
}

/* check to test if encoded number is a zero. Returns 1 if zero, 0 for nonzero */
static int VARIANT_int_iszero(const DWORD * p, unsigned int n)
{
    for (; n > 0; n--) if (*p++ != 0) return 0;
    return 1;
}

/* multiply two DECIMALS, without changing either one, and place result in third
   parameter. Result is normalized when scale is > 0. Attempts to remove significant
   digits when scale > 0 in order to fit an overflowing result. Final overflow
   flag is returned.
 */
static int VARIANT_DI_mul(const VARIANT_DI * a, const VARIANT_DI * b, VARIANT_DI * result)
{
    int r_overflow = 0;
    DWORD running[6];
    signed int mulstart;

    VARIANT_DI_clear(result);
    result->sign = (a->sign ^ b->sign) ? 1 : 0;

    /* Multiply 128-bit operands into a (max) 256-bit result. The scale
       of the result is formed by adding the scales of the operands.
     */
    result->scale = a->scale + b->scale;
    memset(running, 0, sizeof(running));

    /* count number of leading zero-bytes in operand A */
    for (mulstart = sizeof(a->bitsnum)/sizeof(DWORD) - 1; mulstart >= 0 && !a->bitsnum[mulstart]; mulstart--);
    if (mulstart < 0) {
        /* result is 0, because operand A is 0 */
        result->scale = 0;
        result->sign = 0;
    } else {
        unsigned char remainder = 0;
        int iA;        

        /* perform actual multiplication */
        for (iA = 0; iA <= mulstart; iA++) {
            ULONG iOverflowMul;
            int iB;
            
            for (iOverflowMul = 0, iB = 0; iB < sizeof(b->bitsnum)/sizeof(DWORD); iB++) {
                ULONG iRV;
                int iR;
                
                iRV = VARIANT_Mul(b->bitsnum[iB], a->bitsnum[iA], &iOverflowMul);
                iR = iA + iB;
                do {
                    running[iR] = VARIANT_Add(running[iR], 0, &iRV);
                    iR++;
                } while (iRV);
            }
        }

/* Too bad - native oleaut does not do this, so we should not either */
#if 0
        /* While the result is divisible by 10, and the scale > 0, divide by 10.
           This operation should not lose significant digits, and gives an
           opportunity to reduce the possibility of overflows in future
           operations issued by the application.
         */
        while (result->scale > 0) {
            memcpy(quotient, running, sizeof(quotient));
            remainder = VARIANT_int_divbychar(quotient, sizeof(quotient) / sizeof(DWORD), 10);
            if (remainder > 0) break;
            memcpy(running, quotient, sizeof(quotient));
            result->scale--;
        }
#endif
        /* While the 256-bit result overflows, and the scale > 0, divide by 10.
           This operation *will* lose significant digits of the result because
           all the factors of 10 were consumed by the previous operation.
        */
        while (result->scale > 0 && !VARIANT_int_iszero(
            running + sizeof(result->bitsnum) / sizeof(DWORD),
            (sizeof(running) - sizeof(result->bitsnum)) / sizeof(DWORD))) {
            
            remainder = VARIANT_int_divbychar(running, sizeof(running) / sizeof(DWORD), 10);
            if (remainder > 0) WARN("losing significant digits (remainder %u)...\n", remainder);
            result->scale--;
        }
        
        /* round up the result - native oleaut32 does this */
        if (remainder >= 5) {
            unsigned int i;
            for (remainder = 1, i = 0; i < sizeof(running)/sizeof(DWORD) && remainder; i++) {
                ULONGLONG digit = running[i] + 1;
                remainder = (digit > 0xFFFFFFFF) ? 1 : 0;
                running[i] = digit & 0xFFFFFFFF;
            }
        }

        /* Signal overflow if scale == 0 and 256-bit result still overflows,
           and copy result bits into result structure
        */
        r_overflow = !VARIANT_int_iszero(
            running + sizeof(result->bitsnum)/sizeof(DWORD), 
            (sizeof(running) - sizeof(result->bitsnum))/sizeof(DWORD));
        memcpy(result->bitsnum, running, sizeof(result->bitsnum));
    }
    return r_overflow;
}

/* cast DECIMAL into string. Any scale should be handled properly. en_US locale is
   hardcoded (period for decimal separator, dash as negative sign). Returns 0 for
   success, nonzero if insufficient space in output buffer.
 */
static int VARIANT_DI_tostringW(const VARIANT_DI * a, WCHAR * s, unsigned int n)
{
    int overflow = 0;
    DWORD quotient[3];
    unsigned char remainder;
    unsigned int i;

    /* place negative sign */
    if (!VARIANT_int_iszero(a->bitsnum, sizeof(a->bitsnum) / sizeof(DWORD)) && a->sign) {
        if (n > 0) {
            *s++ = '-';
            n--;
        }
        else overflow = 1;
    }

    /* prepare initial 0 */
    if (!overflow) {
        if (n >= 2) {
            s[0] = '0';
            s[1] = '\0';
        } else overflow = 1;
    }

    i = 0;
    memcpy(quotient, a->bitsnum, sizeof(a->bitsnum));
    while (!overflow && !VARIANT_int_iszero(quotient, sizeof(quotient) / sizeof(DWORD))) {
        remainder = VARIANT_int_divbychar(quotient, sizeof(quotient) / sizeof(DWORD), 10);
        if (i + 2 > n) {
            overflow = 1;
        } else {
            s[i++] = '0' + remainder;
            s[i] = '\0';
        }
    }

    if (!overflow && !VARIANT_int_iszero(a->bitsnum, sizeof(a->bitsnum) / sizeof(DWORD))) {

        /* reverse order of digits */
        WCHAR * x = s; WCHAR * y = s + i - 1;
        while (x < y) {
            *x ^= *y;
            *y ^= *x;
            *x++ ^= *y--;
        }

        /* check for decimal point. "i" now has string length */
        if (i <= a->scale) {
            unsigned int numzeroes = a->scale + 1 - i;
            if (i + 1 + numzeroes >= n) {
                overflow = 1;
            } else {
                memmove(s + numzeroes, s, (i + 1) * sizeof(WCHAR));
                i += numzeroes;
                while (numzeroes > 0) {
                    s[--numzeroes] = '0';
                }
            }
        }

        /* place decimal point */
        if (a->scale > 0) {
            unsigned int periodpos = i - a->scale;
            if (i + 2 >= n) {
                overflow = 1;
            } else {
                memmove(s + periodpos + 1, s + periodpos, (i + 1 - periodpos) * sizeof(WCHAR));
                s[periodpos] = '.'; i++;
                
                /* remove extra zeros at the end, if any */
                while (s[i - 1] == '0') s[--i] = '\0';
                if (s[i - 1] == '.') s[--i] = '\0';
            }
        }
    }

    return overflow;
}

/* shift the bits of a DWORD array to the left. p[0] is assumed LSB */
static void VARIANT_int_shiftleft(DWORD * p, unsigned int n, unsigned int shift)
{
    DWORD shifted;
    unsigned int i;
    
    /* shift whole DWORDs to the left */
    while (shift >= 32)
    {
        memmove(p + 1, p, (n - 1) * sizeof(DWORD));
        *p = 0; shift -= 32;
    }
    
    /* shift remainder (1..31 bits) */
    shifted = 0;
    if (shift > 0) for (i = 0; i < n; i++)
    {
        DWORD b;
        b = p[i] >> (32 - shift);
        p[i] = (p[i] << shift) | shifted;
        shifted = b;
    }
}

/* add the (unsigned) numbers stored in two DWORD arrays with LSB at index 0.
   Value at v is incremented by the value at p. Any size is supported, provided
   that v is not shorter than p. Any unapplied carry is returned as a result.
 */
static unsigned char VARIANT_int_add(DWORD * v, unsigned int nv, const DWORD * p,
    unsigned int np)
{
    unsigned char carry = 0;

    if (nv >= np) {
        ULONGLONG sum;
        unsigned int i;

        for (i = 0; i < np; i++) {
            sum = (ULONGLONG)v[i]
                + (ULONGLONG)p[i]
                + (ULONGLONG)carry;
            v[i] = sum & 0xffffffff;
            carry = sum >> 32;
        }
        for (; i < nv && carry; i++) {
            sum = (ULONGLONG)v[i]
                + (ULONGLONG)carry;
            v[i] = sum & 0xffffffff;
            carry = sum >> 32;
        }
    }
    return carry;
}

/* perform integral division with operand p as dividend. Parameter n indicates 
   number of available DWORDs in divisor p, but available space in p must be 
   actually at least 2 * n DWORDs, because the remainder of the integral 
   division is built in the next n DWORDs past the start of the quotient. This 
   routine replaces the dividend in p with the quotient, and appends n 
   additional DWORDs for the remainder.

   Thanks to Lee & Mark Atkinson for their book _Using_C_ (my very first book on
   C/C++ :-) where the "longhand binary division" algorithm was exposed for the
   source code to the VLI (Very Large Integer) division operator. This algorithm
   was then heavily modified by me (Alex Villacis Lasso) in order to handle
   variably-scaled integers such as the MS DECIMAL representation.
 */
static void VARIANT_int_div(DWORD * p, unsigned int n, const DWORD * divisor,
    unsigned int dn)
{
    unsigned int i;
    DWORD tempsub[8];
    DWORD * negdivisor = tempsub + n;

    /* build 2s-complement of divisor */
    for (i = 0; i < n; i++) negdivisor[i] = (i < dn) ? ~divisor[i] : 0xFFFFFFFF;
    p[n] = 1;
    VARIANT_int_add(negdivisor, n, p + n, 1);
    memset(p + n, 0, n * sizeof(DWORD));

    /* skip all leading zero DWORDs in quotient */
    for (i = 0; i < n && !p[n - 1]; i++) VARIANT_int_shiftleft(p, n, 32);
    /* i is now number of DWORDs left to process */
    for (i <<= 5; i < (n << 5); i++) {
        VARIANT_int_shiftleft(p, n << 1, 1);    /* shl quotient+remainder */

        /* trial subtraction */
        memcpy(tempsub, p + n, n * sizeof(DWORD));
        VARIANT_int_add(tempsub, n, negdivisor, n);

        /* check whether result of subtraction was negative */
        if ((tempsub[n - 1] & 0x80000000) == 0) {
            memcpy(p + n, tempsub, n * sizeof(DWORD));
            p[0] |= 1;
        }
    }
}

/* perform integral multiplication by a byte operand. Used for scaling by 10 */
static unsigned char VARIANT_int_mulbychar(DWORD * p, unsigned int n, unsigned char m)
{
    unsigned int i;
    ULONG iOverflowMul;
    
    for (iOverflowMul = 0, i = 0; i < n; i++)
        p[i] = VARIANT_Mul(p[i], m, &iOverflowMul);
    return (unsigned char)iOverflowMul;
}

/* increment value in A by the value indicated in B, with scale adjusting. 
   Modifies parameters by adjusting scales. Returns 0 if addition was 
   successful, nonzero if a parameter underflowed before it could be 
   successfully used in the addition.
 */
static int VARIANT_int_addlossy(
    DWORD * a, int * ascale, unsigned int an,
    DWORD * b, int * bscale, unsigned int bn)
{
    int underflow = 0;

    if (VARIANT_int_iszero(a, an)) {
        /* if A is zero, copy B into A, after removing digits */
        while (bn > an && !VARIANT_int_iszero(b + an, bn - an)) {
            VARIANT_int_divbychar(b, bn, 10);
            (*bscale)--;
        }
        memcpy(a, b, an * sizeof(DWORD));
        *ascale = *bscale;
    } else if (!VARIANT_int_iszero(b, bn)) {
        unsigned int tn = an + 1;
        DWORD t[5];

        if (bn + 1 > tn) tn = bn + 1;
        if (*ascale != *bscale) {
            /* first (optimistic) try - try to scale down the one with the bigger
               scale, while this number is divisible by 10 */
            DWORD * digitchosen;
            unsigned int nchosen;
            int * scalechosen;
            int targetscale;

            if (*ascale < *bscale) {
                targetscale = *ascale;
                scalechosen = bscale;
                digitchosen = b;
                nchosen = bn;
            } else {
                targetscale = *bscale;
                scalechosen = ascale;
                digitchosen = a;
                nchosen = an;
            }
            memset(t, 0, tn * sizeof(DWORD));
            memcpy(t, digitchosen, nchosen * sizeof(DWORD));

            /* divide by 10 until target scale is reached */
            while (*scalechosen > targetscale) {
                unsigned char remainder = VARIANT_int_divbychar(t, tn, 10);
                if (!remainder) {
                    (*scalechosen)--;
                    memcpy(digitchosen, t, nchosen * sizeof(DWORD));
                } else break;
            }
        }

        if (*ascale != *bscale) {
            DWORD * digitchosen;
            unsigned int nchosen;
            int * scalechosen;
            int targetscale;

            /* try to scale up the one with the smaller scale */
            if (*ascale > *bscale) {
                targetscale = *ascale;
                scalechosen = bscale;
                digitchosen = b;
                nchosen = bn;
            } else {
                targetscale = *bscale;
                scalechosen = ascale;
                digitchosen = a;
                nchosen = an;
            }
            memset(t, 0, tn * sizeof(DWORD));
            memcpy(t, digitchosen, nchosen * sizeof(DWORD));

            /* multiply by 10 until target scale is reached, or
               significant bytes overflow the number
             */
            while (*scalechosen < targetscale && t[nchosen] == 0) {
                VARIANT_int_mulbychar(t, tn, 10);
                if (t[nchosen] == 0) {
                    /* still does not overflow */
                    (*scalechosen)++;
                    memcpy(digitchosen, t, nchosen * sizeof(DWORD));
                }
            }
        }

        if (*ascale != *bscale) {
            /* still different? try to scale down the one with the bigger scale
               (this *will* lose significant digits) */
            DWORD * digitchosen;
            unsigned int nchosen;
            int * scalechosen;
            int targetscale;

            if (*ascale < *bscale) {
                targetscale = *ascale;
                scalechosen = bscale;
                digitchosen = b;
                nchosen = bn;
            } else {
                targetscale = *bscale;
                scalechosen = ascale;
                digitchosen = a;
                nchosen = an;
            }
            memset(t, 0, tn * sizeof(DWORD));
            memcpy(t, digitchosen, nchosen * sizeof(DWORD));

            /* divide by 10 until target scale is reached */
            while (*scalechosen > targetscale) {
                VARIANT_int_divbychar(t, tn, 10);
                (*scalechosen)--;
                memcpy(digitchosen, t, nchosen * sizeof(DWORD));
            }
        }

        /* check whether any of the operands still has significant digits
           (underflow case 1)
         */
        if (VARIANT_int_iszero(a, an) || VARIANT_int_iszero(b, bn)) {
            underflow = 1;
        } else {
            /* at this step, both numbers have the same scale and can be added
               as integers. However, the result might not fit in A, so further
               scaling down might be necessary.
             */
            while (!underflow) {
                memset(t, 0, tn * sizeof(DWORD));
                memcpy(t, a, an * sizeof(DWORD));

                VARIANT_int_add(t, tn, b, bn);
                if (VARIANT_int_iszero(t + an, tn - an)) {
                    /* addition was successful */
                    memcpy(a, t, an * sizeof(DWORD));
                    break;
                } else {
                    /* addition overflowed - remove significant digits
                       from both operands and try again */
                    VARIANT_int_divbychar(a, an, 10); (*ascale)--;
                    VARIANT_int_divbychar(b, bn, 10); (*bscale)--;
                    /* check whether any operand keeps significant digits after
                       scaledown (underflow case 2)
                     */
                    underflow = (VARIANT_int_iszero(a, an) || VARIANT_int_iszero(b, bn));
                }
            }
        }
    }
    return underflow;
}

/* perform complete DECIMAL division in the internal representation. Returns
   0 if the division was completed (even if quotient is set to 0), or nonzero
   in case of quotient overflow.
 */
static HRESULT VARIANT_DI_div(const VARIANT_DI * dividend, const VARIANT_DI * divisor,
                              VARIANT_DI * quotient)
{
    HRESULT r_overflow = S_OK;

    if (VARIANT_int_iszero(divisor->bitsnum, sizeof(divisor->bitsnum)/sizeof(DWORD))) {
        /* division by 0 */
        r_overflow = DISP_E_DIVBYZERO;
    } else if (VARIANT_int_iszero(dividend->bitsnum, sizeof(dividend->bitsnum)/sizeof(DWORD))) {
        VARIANT_DI_clear(quotient);
    } else {
        int quotientscale, remainderscale, tempquotientscale;
        DWORD remainderplusquotient[8];
        int underflow;

        quotientscale = remainderscale = (int)dividend->scale - (int)divisor->scale;
        tempquotientscale = quotientscale;
        VARIANT_DI_clear(quotient);
        quotient->sign = (dividend->sign ^ divisor->sign) ? 1 : 0;

        /*  The following strategy is used for division
            1) if there was a nonzero remainder from previous iteration, use it as
               dividend for this iteration, else (for first iteration) use intended
               dividend
            2) perform integer division in temporary buffer, develop quotient in
               low-order part, remainder in high-order part
            3) add quotient from step 2 to final result, with possible loss of
               significant digits
            4) multiply integer part of remainder by 10, while incrementing the
               scale of the remainder. This operation preserves the intended value
               of the remainder.
            5) loop to step 1 until one of the following is true:
                a) remainder is zero (exact division achieved)
                b) addition in step 3 fails to modify bits in quotient (remainder underflow)
         */
        memset(remainderplusquotient, 0, sizeof(remainderplusquotient));
        memcpy(remainderplusquotient, dividend->bitsnum, sizeof(dividend->bitsnum));
        do {
            VARIANT_int_div(
                remainderplusquotient, 4,
                divisor->bitsnum, sizeof(divisor->bitsnum)/sizeof(DWORD));
            underflow = VARIANT_int_addlossy(
                quotient->bitsnum, &quotientscale, sizeof(quotient->bitsnum) / sizeof(DWORD),
                remainderplusquotient, &tempquotientscale, 4);
            VARIANT_int_mulbychar(remainderplusquotient + 4, 4, 10);
            memcpy(remainderplusquotient, remainderplusquotient + 4, 4 * sizeof(DWORD));
            tempquotientscale = ++remainderscale;
        } while (!underflow && !VARIANT_int_iszero(remainderplusquotient + 4, 4));

        /* quotient scale might now be negative (extremely big number). If, so, try
           to multiply quotient by 10 (without overflowing), while adjusting the scale,
           until scale is 0. If this cannot be done, it is a real overflow.
         */
        while (r_overflow == S_OK && quotientscale < 0) {
            memset(remainderplusquotient, 0, sizeof(remainderplusquotient));
            memcpy(remainderplusquotient, quotient->bitsnum, sizeof(quotient->bitsnum));
            VARIANT_int_mulbychar(remainderplusquotient, sizeof(remainderplusquotient)/sizeof(DWORD), 10);
            if (VARIANT_int_iszero(remainderplusquotient + sizeof(quotient->bitsnum)/sizeof(DWORD),
                (sizeof(remainderplusquotient) - sizeof(quotient->bitsnum))/sizeof(DWORD))) {
                quotientscale++;
                memcpy(quotient->bitsnum, remainderplusquotient, sizeof(quotient->bitsnum));
            } else r_overflow = DISP_E_OVERFLOW;
        }
        if (r_overflow == S_OK) {
            if (quotientscale <= 255) quotient->scale = quotientscale;
            else VARIANT_DI_clear(quotient);
        }
    }
    return r_overflow;
}

/* This procedure receives a VARIANT_DI with a defined mantissa and sign, but
   with an undefined scale, which will be assigned to (if possible). It also
   receives an exponent of 2. This procedure will then manipulate the mantissa
   and calculate a corresponding scale, so that the exponent2 value is assimilated
   into the VARIANT_DI and is therefore no longer necessary. Returns S_OK if
   successful, or DISP_E_OVERFLOW if the represented value is too big to fit into
   a DECIMAL. */
static HRESULT VARIANT_DI_normalize(VARIANT_DI * val, int exponent2, int isDouble)
{
    HRESULT hres = S_OK;
    int exponent5, exponent10;

    /* A factor of 2^exponent2 is equivalent to (10^exponent2)/(5^exponent2), and
       thus equal to (5^-exponent2)*(10^exponent2). After all manipulations,
       exponent10 might be used to set the VARIANT_DI scale directly. However,
       the value of 5^-exponent5 must be assimilated into the VARIANT_DI. */
    exponent5 = -exponent2;
    exponent10 = exponent2;

    /* Handle exponent5 > 0 */
    while (exponent5 > 0) {
        char bPrevCarryBit;
        char bCurrCarryBit;

        /* In order to multiply the value represented by the VARIANT_DI by 5, it
           is best to multiply by 10/2. Therefore, exponent10 is incremented, and
           somehow the mantissa should be divided by 2.  */
        if ((val->bitsnum[0] & 1) == 0) {
            /* The mantissa is divisible by 2. Therefore the division can be done
               without losing significant digits. */
            exponent10++; exponent5--;

            /* Shift right */
            bPrevCarryBit = val->bitsnum[2] & 1;
            val->bitsnum[2] >>= 1;
            bCurrCarryBit = val->bitsnum[1] & 1;
            val->bitsnum[1] = (val->bitsnum[1] >> 1) | (bPrevCarryBit ? 0x80000000 : 0);
            val->bitsnum[0] = (val->bitsnum[0] >> 1) | (bCurrCarryBit ? 0x80000000 : 0);
        } else {
            /* The mantissa is NOT divisible by 2. Therefore the mantissa should
               be multiplied by 5, unless the multiplication overflows. */
            DWORD temp_bitsnum[3];

            exponent5--;

            memcpy(temp_bitsnum, val->bitsnum, 3 * sizeof(DWORD));
            if (0 == VARIANT_int_mulbychar(temp_bitsnum, 3, 5)) {
                /* Multiplication succeeded without overflow, so copy result back
                   into VARIANT_DI */
                memcpy(val->bitsnum, temp_bitsnum, 3 * sizeof(DWORD));

                /* Mask out 3 extraneous bits introduced by the multiply */
            } else {
                /* Multiplication by 5 overflows. The mantissa should be divided
                   by 2, and therefore will lose significant digits. */
                exponent10++;

                /* Shift right */
                bPrevCarryBit = val->bitsnum[2] & 1;
                val->bitsnum[2] >>= 1;
                bCurrCarryBit = val->bitsnum[1] & 1;
                val->bitsnum[1] = (val->bitsnum[1] >> 1) | (bPrevCarryBit ? 0x80000000 : 0);
                val->bitsnum[0] = (val->bitsnum[0] >> 1) | (bCurrCarryBit ? 0x80000000 : 0);
            }
        }
    }

    /* Handle exponent5 < 0 */
    while (exponent5 < 0) {
        /* In order to divide the value represented by the VARIANT_DI by 5, it
           is best to multiply by 2/10. Therefore, exponent10 is decremented,
           and the mantissa should be multiplied by 2 */
        if ((val->bitsnum[2] & 0x80000000) == 0) {
            /* The mantissa can withstand a shift-left without overflowing */
            exponent10--; exponent5++;
            VARIANT_int_shiftleft(val->bitsnum, 3, 1);
        } else {
            /* The mantissa would overflow if shifted. Therefore it should be
               directly divided by 5. This will lose significant digits, unless
               by chance the mantissa happens to be divisible by 5 */
            exponent5++;
            VARIANT_int_divbychar(val->bitsnum, 3, 5);
        }
    }

    /* At this point, the mantissa has assimilated the exponent5, but the
       exponent10 might not be suitable for assignment. The exponent10 must be
       in the range [-DEC_MAX_SCALE..0], so the mantissa must be scaled up or
       down appropriately. */
    while (hres == S_OK && exponent10 > 0) {
        /* In order to bring exponent10 down to 0, the mantissa should be
           multiplied by 10 to compensate. If the exponent10 is too big, this
           will cause the mantissa to overflow. */
        if (0 == VARIANT_int_mulbychar(val->bitsnum, 3, 10)) {
            exponent10--;
        } else {
            hres = DISP_E_OVERFLOW;
        }
    }
    while (exponent10 < -DEC_MAX_SCALE) {
        int rem10;
        /* In order to bring exponent up to -DEC_MAX_SCALE, the mantissa should
           be divided by 10 to compensate. If the exponent10 is too small, this
           will cause the mantissa to underflow and become 0 */
        rem10 = VARIANT_int_divbychar(val->bitsnum, 3, 10);
        exponent10++;
        if (VARIANT_int_iszero(val->bitsnum, 3)) {
            /* Underflow, unable to keep dividing */
            exponent10 = 0;
        } else if (rem10 >= 5) {
            DWORD x = 1;
            VARIANT_int_add(val->bitsnum, 3, &x, 1);
        }
    }
    /* This step is required in order to remove excess bits of precision from the
       end of the bit representation, down to the precision guaranteed by the
       floating point number. */
    if (isDouble) {
        while (exponent10 < 0 && (val->bitsnum[2] != 0 || (val->bitsnum[2] == 0 && (val->bitsnum[1] & 0xFFE00000) != 0))) {
            int rem10;

            rem10 = VARIANT_int_divbychar(val->bitsnum, 3, 10);
            exponent10++;
            if (rem10 >= 5) {
                DWORD x = 1;
                VARIANT_int_add(val->bitsnum, 3, &x, 1);
            }
        }
    } else {
        while (exponent10 < 0 && (val->bitsnum[2] != 0 || val->bitsnum[1] != 0 ||
            (val->bitsnum[2] == 0 && val->bitsnum[1] == 0 && (val->bitsnum[0] & 0xFF000000) != 0))) {
            int rem10;

            rem10 = VARIANT_int_divbychar(val->bitsnum, 3, 10);
            exponent10++;
            if (rem10 >= 5) {
                DWORD x = 1;
                VARIANT_int_add(val->bitsnum, 3, &x, 1);
            }
        }
    }
    /* Remove multiples of 10 from the representation */
    while (exponent10 < 0) {
        DWORD temp_bitsnum[3];

        memcpy(temp_bitsnum, val->bitsnum, 3 * sizeof(DWORD));
        if (0 == VARIANT_int_divbychar(temp_bitsnum, 3, 10)) {
            exponent10++;
            memcpy(val->bitsnum, temp_bitsnum, 3 * sizeof(DWORD));
        } else break;
    }

    /* Scale assignment */
    if (hres == S_OK) val->scale = -exponent10;

    return hres;
}

typedef union
{
    struct
    {
        unsigned int m : 23;
        unsigned int exp_bias : 8;
        unsigned int sign : 1;
    } i;
    float f;
} R4_FIELDS;

/* Convert a 32-bit floating point number into a DECIMAL, without using an
   intermediate string step. */
static HRESULT VARIANT_DI_FromR4(float source, VARIANT_DI * dest)
{
    HRESULT hres = S_OK;
    R4_FIELDS fx;

    fx.f = source;

    /* Detect special cases */
    if (fx.i.m == 0 && fx.i.exp_bias == 0) {
        /* Floating-point zero */
        VARIANT_DI_clear(dest);
    } else if (fx.i.m == 0  && fx.i.exp_bias == 0xFF) {
        /* Floating-point infinity */
        hres = DISP_E_OVERFLOW;
    } else if (fx.i.exp_bias == 0xFF) {
        /* Floating-point NaN */
        hres = DISP_E_BADVARTYPE;
    } else {
        int exponent2;
        VARIANT_DI_clear(dest);

        exponent2 = fx.i.exp_bias - 127;   /* Get unbiased exponent */
        dest->sign = fx.i.sign;             /* Sign is simply copied */

        /* Copy significant bits to VARIANT_DI mantissa */
        dest->bitsnum[0] = fx.i.m;
        dest->bitsnum[0] &= 0x007FFFFF;
        if (fx.i.exp_bias == 0) {
            /* Denormalized number - correct exponent */
            exponent2++;
        } else {
            /* Add hidden bit to mantissa */
            dest->bitsnum[0] |= 0x00800000;
        }

        /* The act of copying a FP mantissa as integer bits is equivalent to
           shifting left the mantissa 23 bits. The exponent2 is reduced to
           compensate. */
        exponent2 -= 23;

        hres = VARIANT_DI_normalize(dest, exponent2, 0);
    }

    return hres;
}

typedef union
{
    struct
    {
        unsigned int m_lo : 32;     /* 52 bits of precision */
        unsigned int m_hi : 20;
        unsigned int exp_bias : 11; /* bias == 1023 */
        unsigned int sign : 1;
    } i;
    double d;
} R8_FIELDS;

/* Convert a 64-bit floating point number into a DECIMAL, without using an
   intermediate string step. */
static HRESULT VARIANT_DI_FromR8(double source, VARIANT_DI * dest)
{
    HRESULT hres = S_OK;
    R8_FIELDS fx;

    fx.d = source;

    /* Detect special cases */
    if (fx.i.m_lo == 0 && fx.i.m_hi == 0 && fx.i.exp_bias == 0) {
        /* Floating-point zero */
        VARIANT_DI_clear(dest);
    } else if (fx.i.m_lo == 0 && fx.i.m_hi == 0 && fx.i.exp_bias == 0x7FF) {
        /* Floating-point infinity */
        hres = DISP_E_OVERFLOW;
    } else if (fx.i.exp_bias == 0x7FF) {
        /* Floating-point NaN */
        hres = DISP_E_BADVARTYPE;
    } else {
        int exponent2;
        VARIANT_DI_clear(dest);

        exponent2 = fx.i.exp_bias - 1023;   /* Get unbiased exponent */
        dest->sign = fx.i.sign;             /* Sign is simply copied */

        /* Copy significant bits to VARIANT_DI mantissa */
        dest->bitsnum[0] = fx.i.m_lo;
        dest->bitsnum[1] = fx.i.m_hi;
        dest->bitsnum[1] &= 0x000FFFFF;
        if (fx.i.exp_bias == 0) {
            /* Denormalized number - correct exponent */
            exponent2++;
        } else {
            /* Add hidden bit to mantissa */
            dest->bitsnum[1] |= 0x00100000;
        }

        /* The act of copying a FP mantissa as integer bits is equivalent to
           shifting left the mantissa 52 bits. The exponent2 is reduced to
           compensate. */
        exponent2 -= 52;

        hres = VARIANT_DI_normalize(dest, exponent2, 1);
    }

    return hres;
}

/************************************************************************
 * VarDecDiv (OLEAUT32.178)
 *
 * Divide one DECIMAL by another.
 *
 * PARAMS
 *  pDecLeft  [I] Source
 *  pDecRight [I] Value to divide by
 *  pDecOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarDecDiv(const DECIMAL* pDecLeft, const DECIMAL* pDecRight, DECIMAL* pDecOut)
{
  HRESULT hRet = S_OK;
  VARIANT_DI di_left, di_right, di_result;
  HRESULT divresult;

  if (!pDecLeft || !pDecRight || !pDecOut) return E_INVALIDARG;

  VARIANT_DIFromDec(pDecLeft, &di_left);
  VARIANT_DIFromDec(pDecRight, &di_right);
  divresult = VARIANT_DI_div(&di_left, &di_right, &di_result);
  if (divresult != S_OK)
  {
      /* division actually overflowed */
      hRet = divresult;
  }
  else
  {
      hRet = S_OK;

      if (di_result.scale > DEC_MAX_SCALE)
      {
        unsigned char remainder = 0;
      
        /* division underflowed. In order to comply with the MSDN
           specifications for DECIMAL ranges, some significant digits
           must be removed
         */
        WARN("result scale is %u, scaling (with loss of significant digits)...\n",
            di_result.scale);
        while (di_result.scale > DEC_MAX_SCALE && 
               !VARIANT_int_iszero(di_result.bitsnum, sizeof(di_result.bitsnum) / sizeof(DWORD)))
        {
            remainder = VARIANT_int_divbychar(di_result.bitsnum, sizeof(di_result.bitsnum) / sizeof(DWORD), 10);
            di_result.scale--;
        }
        if (di_result.scale > DEC_MAX_SCALE)
        {
            WARN("result underflowed, setting to 0\n");
            di_result.scale = 0;
            di_result.sign = 0;
        }
        else if (remainder >= 5)    /* round up result - native oleaut32 does this */
        {
            unsigned int i;
            for (remainder = 1, i = 0; i < sizeof(di_result.bitsnum) / sizeof(DWORD) && remainder; i++) {
                ULONGLONG digit = di_result.bitsnum[i] + 1;
                remainder = (digit > 0xFFFFFFFF) ? 1 : 0;
                di_result.bitsnum[i] = digit & 0xFFFFFFFF;
            }
        }
      }
      VARIANT_DecFromDI(&di_result, pDecOut);
  }
  return hRet;
}

/************************************************************************
 * VarDecMul (OLEAUT32.179)
 *
 * Multiply one DECIMAL by another.
 *
 * PARAMS
 *  pDecLeft  [I] Source
 *  pDecRight [I] Value to multiply by
 *  pDecOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarDecMul(const DECIMAL* pDecLeft, const DECIMAL* pDecRight, DECIMAL* pDecOut)
{
  HRESULT hRet = S_OK;
  VARIANT_DI di_left, di_right, di_result;
  int mulresult;

  VARIANT_DIFromDec(pDecLeft, &di_left);
  VARIANT_DIFromDec(pDecRight, &di_right);
  mulresult = VARIANT_DI_mul(&di_left, &di_right, &di_result);
  if (mulresult)
  {
    /* multiplication actually overflowed */
    hRet = DISP_E_OVERFLOW;
  }
  else
  {
    if (di_result.scale > DEC_MAX_SCALE)
    {
      /* multiplication underflowed. In order to comply with the MSDN
         specifications for DECIMAL ranges, some significant digits
         must be removed
       */
      WARN("result scale is %u, scaling (with loss of significant digits)...\n",
          di_result.scale);
      while (di_result.scale > DEC_MAX_SCALE && 
            !VARIANT_int_iszero(di_result.bitsnum, sizeof(di_result.bitsnum)/sizeof(DWORD)))
      {
        VARIANT_int_divbychar(di_result.bitsnum, sizeof(di_result.bitsnum)/sizeof(DWORD), 10);
        di_result.scale--;
      }
      if (di_result.scale > DEC_MAX_SCALE)
      {
        WARN("result underflowed, setting to 0\n");
        di_result.scale = 0;
        di_result.sign = 0;
      }
    }
    VARIANT_DecFromDI(&di_result, pDecOut);
  }
  return hRet;
}

/************************************************************************
 * VarDecSub (OLEAUT32.181)
 *
 * Subtract one DECIMAL from another.
 *
 * PARAMS
 *  pDecLeft  [I] Source
 *  pDecRight [I] DECIMAL to subtract from pDecLeft
 *  pDecOut   [O] Destination
 *
 * RETURNS
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarDecSub(const DECIMAL* pDecLeft, const DECIMAL* pDecRight, DECIMAL* pDecOut)
{
  DECIMAL decRight;

  /* Implement as addition of the negative */
  VarDecNeg(pDecRight, &decRight);
  return VarDecAdd(pDecLeft, &decRight, pDecOut);
}

/************************************************************************
 * VarDecAbs (OLEAUT32.182)
 *
 * Convert a DECIMAL into its absolute value.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK. This function does not fail.
 */
HRESULT WINAPI VarDecAbs(const DECIMAL* pDecIn, DECIMAL* pDecOut)
{
  *pDecOut = *pDecIn;
  DEC_SIGN(pDecOut) &= ~DECIMAL_NEG;
  return S_OK;
}

/************************************************************************
 * VarDecFix (OLEAUT32.187)
 *
 * Return the integer portion of a DECIMAL.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  - The difference between this function and VarDecInt() is that VarDecInt() rounds
 *    negative numbers away from 0, while this function rounds them towards zero.
 */
HRESULT WINAPI VarDecFix(const DECIMAL* pDecIn, DECIMAL* pDecOut)
{
  double dbl;
  HRESULT hr;

  if (DEC_SIGN(pDecIn) & ~DECIMAL_NEG)
    return E_INVALIDARG;

  if (!DEC_SCALE(pDecIn))
  {
    *pDecOut = *pDecIn; /* Already an integer */
    return S_OK;
  }

  hr = VarR8FromDec(pDecIn, &dbl);
  if (SUCCEEDED(hr)) {
    LONGLONG rounded = (LONGLONG)dbl;

    hr = VarDecFromI8(rounded, pDecOut);
  }
  return hr;
}

/************************************************************************
 * VarDecInt (OLEAUT32.188)
 *
 * Return the integer portion of a DECIMAL.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 *
 * NOTES
 *  - The difference between this function and VarDecFix() is that VarDecFix() rounds
 *    negative numbers towards 0, while this function rounds them away from zero.
 */
HRESULT WINAPI VarDecInt(const DECIMAL* pDecIn, DECIMAL* pDecOut)
{
  double dbl;
  HRESULT hr;

  if (DEC_SIGN(pDecIn) & ~DECIMAL_NEG)
    return E_INVALIDARG;

  if (!(DEC_SIGN(pDecIn) & DECIMAL_NEG) || !DEC_SCALE(pDecIn))
    return VarDecFix(pDecIn, pDecOut); /* The same, if +ve or no fractionals */

  hr = VarR8FromDec(pDecIn, &dbl);
  if (SUCCEEDED(hr)) {
    LONGLONG rounded = (LONGLONG)(dbl >= 0.0 ? dbl + 0.5 : dbl - 0.5);

    hr = VarDecFromI8(rounded, pDecOut);
  }
  return hr;
}

/************************************************************************
 * VarDecNeg (OLEAUT32.189)
 *
 * Change the sign of a DECIMAL.
 *
 * PARAMS
 *  pDecIn  [I] Source
 *  pDecOut [O] Destination
 *
 * RETURNS
 *  S_OK. This function does not fail.
 */
HRESULT WINAPI VarDecNeg(const DECIMAL* pDecIn, DECIMAL* pDecOut)
{
  *pDecOut = *pDecIn;
  DEC_SIGN(pDecOut) ^= DECIMAL_NEG;
  return S_OK;
}

/************************************************************************
 * VarDecRound (OLEAUT32.203)
 *
 * Change the precision of a DECIMAL.
 *
 * PARAMS
 *  pDecIn    [I] Source
 *  cDecimals [I] New number of decimals to keep
 *  pDecOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK. pDecOut contains the rounded value.
 *  Failure: E_INVALIDARG if any argument is invalid.
 */
HRESULT WINAPI VarDecRound(const DECIMAL* pDecIn, int cDecimals, DECIMAL* pDecOut)
{
  if (cDecimals < 0 || (DEC_SIGN(pDecIn) & ~DECIMAL_NEG) || DEC_SCALE(pDecIn) > DEC_MAX_SCALE)
    return E_INVALIDARG;

  if (cDecimals >= DEC_SCALE(pDecIn))
  {
    *pDecOut = *pDecIn; /* More precision than we have */
    return S_OK;
  }

  ////FixMe("semi-stub!\n");

  return DISP_E_OVERFLOW;
}

/************************************************************************
 * VarDecCmp (OLEAUT32.204)
 *
 * Compare two DECIMAL values.
 *
 * PARAMS
 *  pDecLeft  [I] Source
 *  pDecRight [I] Value to compare
 *
 * RETURNS
 *  Success: VARCMP_LT, VARCMP_EQ or VARCMP_GT indicating that pDecLeft
 *           is less than, equal to or greater than pDecRight respectively.
 *  Failure: DISP_E_OVERFLOW, if overflow occurs during the comparison
 */
HRESULT WINAPI VarDecCmp(const DECIMAL* pDecLeft, const DECIMAL* pDecRight)
{
  HRESULT hRet;
  DECIMAL result;

  if (!pDecLeft || !pDecRight)
    return VARCMP_NULL;

  if ((!(DEC_SIGN(pDecLeft) & DECIMAL_NEG)) && (DEC_SIGN(pDecRight) & DECIMAL_NEG) &&
      (DEC_HI32(pDecLeft) | DEC_MID32(pDecLeft) | DEC_LO32(pDecLeft)))
    return VARCMP_GT;
  else if ((DEC_SIGN(pDecLeft) & DECIMAL_NEG) && (!(DEC_SIGN(pDecRight) & DECIMAL_NEG)) &&
      (DEC_HI32(pDecLeft) | DEC_MID32(pDecLeft) | DEC_LO32(pDecLeft)))
    return VARCMP_LT;

  /* Subtract right from left, and compare the result to 0 */
  hRet = VarDecSub(pDecLeft, pDecRight, &result);

  if (SUCCEEDED(hRet))
  {
    int non_zero = DEC_HI32(&result) | DEC_MID32(&result) | DEC_LO32(&result);

    if ((DEC_SIGN(&result) & DECIMAL_NEG) && non_zero)
      hRet = (HRESULT)VARCMP_LT;
    else if (non_zero)
      hRet = (HRESULT)VARCMP_GT;
    else
      hRet = (HRESULT)VARCMP_EQ;
  }
  return hRet;
}

/************************************************************************
 * VarDecCmpR8 (OLEAUT32.298)
 *
 * Compare a DECIMAL to a double
 *
 * PARAMS
 *  pDecLeft [I] DECIMAL Source
 *  dblRight [I] double to compare to pDecLeft
 *
 * RETURNS
 *  Success: VARCMP_LT, VARCMP_EQ or VARCMP_GT indicating that dblRight
 *           is less than, equal to or greater than pDecLeft respectively.
 *  Failure: DISP_E_OVERFLOW, if overflow occurs during the comparison
 */
HRESULT WINAPI VarDecCmpR8(const DECIMAL* pDecLeft, double dblRight)
{
  HRESULT hRet;
  DECIMAL decRight;

  hRet = VarDecFromR8(dblRight, &decRight);

  if (SUCCEEDED(hRet))
    hRet = VarDecCmp(pDecLeft, &decRight);

  return hRet;
}

/* BOOL
 */

/************************************************************************
 * VarBoolFromUI1 (OLEAUT32.118)
 *
 * Convert a VT_UI1 to a VT_BOOL.
 *
 * PARAMS
 *  bIn      [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromUI1(BYTE bIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = bIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromI2 (OLEAUT32.119)
 *
 * Convert a VT_I2 to a VT_BOOL.
 *
 * PARAMS
 *  sIn      [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromI2(SHORT sIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = sIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromI4 (OLEAUT32.120)
 *
 * Convert a VT_I4 to a VT_BOOL.
 *
 * PARAMS
 *  sIn      [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromI4(LONG lIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = lIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromR4 (OLEAUT32.121)
 *
 * Convert a VT_R4 to a VT_BOOL.
 *
 * PARAMS
 *  fltIn    [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromR4(FLOAT fltIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = fltIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromR8 (OLEAUT32.122)
 *
 * Convert a VT_R8 to a VT_BOOL.
 *
 * PARAMS
 *  dblIn    [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromR8(double dblIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = dblIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromDate (OLEAUT32.123)
 *
 * Convert a VT_DATE to a VT_BOOL.
 *
 * PARAMS
 *  dateIn   [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromDate(DATE dateIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = dateIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromCy (OLEAUT32.124)
 *
 * Convert a VT_CY to a VT_BOOL.
 *
 * PARAMS
 *  cyIn     [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromCy(CY cyIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = cyIn.int64 ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VARIANT_GetLocalisedText [internal]
 *
 * Get a localized string from the resources
 *
 */
BOOL VARIANT_GetLocalisedText(LANGID langId, DWORD dwId, WCHAR *lpszDest)
{
/*
  HRSRC hrsrc;

  hrsrc = FindResourceExW( hProxyDll, (LPWSTR)RT_STRING,
                           MAKEINTRESOURCEW((dwId >> 4) + 1), langId );
  if (hrsrc)
  {
    HGLOBAL hmem = LoadResource( hProxyDll, hrsrc );

    if (hmem)
    {
      const WCHAR *p;
      unsigned int i;

      p = LockResource( hmem );
      for (i = 0; i < (dwId & 0x0f); i++) p += *p + 1;

      memcpy( lpszDest, p + 1, *p * sizeof(WCHAR) );
      lpszDest[*p] = '\0';
      TRACE("got %s for LANGID %08x\n", debugstr_w(lpszDest), langId);
      return TRUE;
    }
  }
  */
  
  return FALSE;
}

/************************************************************************
 * VarBoolFromStr (OLEAUT32.125)
 *
 * Convert a VT_BSTR to a VT_BOOL.
 *
 * PARAMS
 *  strIn    [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pBoolOut is invalid.
 *           DISP_E_TYPEMISMATCH, if the type cannot be converted
 *
 * NOTES
 *  - strIn will be recognised if it contains "#TRUE#" or "#FALSE#". Additionally,
 *  it may contain (in any case mapping) the text "true" or "false".
 *  - If dwFlags includes VAR_LOCALBOOL, then the text may also match the
 *  localised text of "True" or "False" in the language specified by lcid.
 *  - If none of these matches occur, the string is treated as a numeric string
 *  and the boolean pBoolOut will be set according to whether the number is zero
 *  or not. The dwFlags parameter is passed to VarR8FromStr() for this conversion.
 *  - If the text is not numeric and does not match any of the above, then
 *  DISP_E_TYPEMISMATCH is returned.
 */
HRESULT WINAPI VarBoolFromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, VARIANT_BOOL *pBoolOut)
{
  /* Any VB/VBA programmers out there should recognise these strings... */
  static const WCHAR szFalse[] = { '#','F','A','L','S','E','#','\0' };
  static const WCHAR szTrue[] = { '#','T','R','U','E','#','\0' };
  WCHAR szBuff[64];
  LANGID langId = MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT);
  HRESULT hRes = S_OK;

  if (!strIn || !pBoolOut)
    return DISP_E_TYPEMISMATCH;

  /* Check if we should be comparing against localised text */
  if (dwFlags & VAR_LOCALBOOL)
  {
    /* Convert our LCID into a usable value */
    lcid = ConvertDefaultLocale(lcid);

    langId = LANGIDFROMLCID(lcid);

    if (PRIMARYLANGID(langId) == LANG_NEUTRAL)
      langId = MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT);

    /* Note: Native oleaut32 always copies strIn and maps halfwidth characters.
     * I don't think this is needed unless any of the localised text strings
     * contain characters that can be so mapped. In the event that this is
     * true for a given language (possibly some Asian languages), then strIn
     * should be mapped here _only_ if langId is an Id for which this can occur.
     */
  }

  /* Note that if we are not comparing against localised strings, langId
   * will have its default value of LANG_ENGLISH. This allows us to mimic
   * the native behaviour of always checking against English strings even
   * after we've checked for localised ones.
   */
VarBoolFromStr_CheckLocalised:
  if (VARIANT_GetLocalisedText(langId, IDS_TRUE, szBuff))
  { // always returns false now
  /*
    // Compare against localised strings, ignoring case
    if (!strcmpiW(strIn, szBuff))
    {
      *pBoolOut = VARIANT_TRUE; // Matched localised 'true' tex
      return hRes;
    }
    VARIANT_GetLocalisedText(langId, IDS_FALSE, szBuff);
    if (!strcmpiW(strIn, szBuff))
    {
      *pBoolOut = VARIANT_FALSE; // Matched localised 'false' text 
      return hRes;
    }
   */
  }

  if (langId != MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT))
  {
    /* We have checked the localised text, now check English */
    langId = MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT);
    goto VarBoolFromStr_CheckLocalised;
  }

  /* All checks against localised text have failed, try #TRUE#/#FALSE# */
  if (!strcmpW(strIn, szFalse))
    *pBoolOut = VARIANT_FALSE;
  else if (!strcmpW(strIn, szTrue))
    *pBoolOut = VARIANT_TRUE;
  else
  {
    double d;

    /* If this string is a number, convert it as one */
    hRes = VarR8FromStr(strIn, lcid, dwFlags, &d);
    if (SUCCEEDED(hRes)) *pBoolOut = d ? VARIANT_TRUE : VARIANT_FALSE;
  }
  return hRes;
}


/************************************************************************
 * VarBoolFromI1 (OLEAUT32.233)
 *
 * Convert a VT_I1 to a VT_BOOL.
 *
 * PARAMS
 *  cIn      [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromI1(signed char cIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = cIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromUI2 (OLEAUT32.234)
 *
 * Convert a VT_UI2 to a VT_BOOL.
 *
 * PARAMS
 *  usIn     [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromUI2(USHORT usIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = usIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromUI4 (OLEAUT32.235)
 *
 * Convert a VT_UI4 to a VT_BOOL.
 *
 * PARAMS
 *  ulIn     [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromUI4(ULONG ulIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = ulIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromDec (OLEAUT32.236)
 *
 * Convert a VT_DECIMAL to a VT_BOOL.
 *
 * PARAMS
 *  pDecIn   [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pDecIn is invalid.
 */
HRESULT WINAPI VarBoolFromDec(DECIMAL* pDecIn, VARIANT_BOOL *pBoolOut)
{
  if (DEC_SCALE(pDecIn) > DEC_MAX_SCALE || (DEC_SIGN(pDecIn) & ~DECIMAL_NEG))
    return E_INVALIDARG;

  if (DEC_HI32(pDecIn) || DEC_MID32(pDecIn) || DEC_LO32(pDecIn))
    *pBoolOut = VARIANT_TRUE;
  else
    *pBoolOut = VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromI8 (OLEAUT32.370)
 *
 * Convert a VT_I8 to a VT_BOOL.
 *
 * PARAMS
 *  ullIn    [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromI8(LONG64 llIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = llIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/************************************************************************
 * VarBoolFromUI8 (OLEAUT32.371)
 *
 * Convert a VT_UI8 to a VT_BOOL.
 *
 * PARAMS
 *  ullIn    [I] Source
 *  pBoolOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarBoolFromUI8(ULONG64 ullIn, VARIANT_BOOL *pBoolOut)
{
  *pBoolOut = ullIn ? VARIANT_TRUE : VARIANT_FALSE;
  return S_OK;
}

/* BSTR
 */

/* Write a number from a UI8 and sign */
static WCHAR *VARIANT_WriteNumber(ULONG64 ulVal, WCHAR* szOut)
{
  do
  {
    WCHAR ulNextDigit = ulVal % 10;

    *szOut-- = '0' + ulNextDigit;
    ulVal = (ulVal - ulNextDigit) / 10;
  } while (ulVal);

  szOut++;
  return szOut;
}

/* Create a (possibly localised) BSTR from a UI8 and sign */
static BSTR VARIANT_MakeBstr(LCID lcid, DWORD dwFlags, WCHAR *szOut)
{
  WCHAR szConverted[256];

  if (dwFlags & VAR_NEGATIVE)
    *--szOut = '-';

  if (dwFlags & LOCALE_USE_NLS)
  {
    // Format the number for the locale
    szConverted[0] = '\0';
    GetNumberFormatW(lcid,
                     dwFlags & LOCALE_NOUSEROVERRIDE,
                     szOut, NULL, szConverted, sizeof(szConverted)/sizeof(WCHAR));
    szOut = szConverted;
  }
 
  return SysAllocStringByteLen((LPSTR)szOut, strlenW(szOut) * sizeof(WCHAR));
}

/* Create a (possibly localised) BSTR from a UI8 and sign */
static HRESULT VARIANT_BstrFromUInt(ULONG64 ulVal, LCID lcid, DWORD dwFlags, BSTR *pbstrOut)
{
  WCHAR szBuff[64], *szOut = szBuff + sizeof(szBuff)/sizeof(WCHAR) - 1;

  if (!pbstrOut)
    return E_INVALIDARG;

  /* Create the basic number string */
  *szOut-- = '\0';
  szOut = VARIANT_WriteNumber(ulVal, szOut);

  *pbstrOut = VARIANT_MakeBstr(lcid, dwFlags, szOut);
  TRACE("returning %s\n", debugstr_w(*pbstrOut));
  return *pbstrOut ? S_OK : E_OUTOFMEMORY;
}

/******************************************************************************
 * VarBstrFromUI1 (OLEAUT32.108)
 *
 * Convert a VT_UI1 to a VT_BSTR.
 *
 * PARAMS
 *  bIn      [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromUI1(BYTE bIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  return VARIANT_BstrFromUInt(bIn, lcid, dwFlags, pbstrOut);
}

/******************************************************************************
 * VarBstrFromI2 (OLEAUT32.109)
 *
 * Convert a VT_I2 to a VT_BSTR.
 *
 * PARAMS
 *  sIn      [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromI2(short sIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  ULONG64 ul64 = sIn;

  if (sIn < 0)
  {
    ul64 = -sIn;
    dwFlags |= VAR_NEGATIVE;
  }
  return VARIANT_BstrFromUInt(ul64, lcid, dwFlags, pbstrOut);
}

/******************************************************************************
 * VarBstrFromI4 (OLEAUT32.110)
 *
 * Convert a VT_I4 to a VT_BSTR.
 *
 * PARAMS
 *  lIn      [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromI4(LONG lIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  ULONG64 ul64 = lIn;

  if (lIn < 0)
  {
    ul64 = (ULONG)-lIn;
    dwFlags |= VAR_NEGATIVE;
  }
  return VARIANT_BstrFromUInt(ul64, lcid, dwFlags, pbstrOut);
}

static BSTR VARIANT_BstrReplaceDecimal(const WCHAR * buff, LCID lcid, ULONG dwFlags)
{
  BSTR bstrOut;
  WCHAR lpDecimalSep[16];

  // Native oleaut32 uses the locale-specific decimal separator even in the
  // absence of the LOCALE_USE_NLS flag. For example, the Spanish/Latin 
  // American locales will see "one thousand and one tenth" as "1000,1" 
  // instead of "1000.1" (notice the comma). The following code checks for
  // the need to replace the decimal separator, and if so, will prepare an
  // appropriate NUMBERFMTW structure to do the job via GetNumberFormatW().
  
  GetLocaleInfoW(lcid, LOCALE_SDECIMAL | (dwFlags & LOCALE_NOUSEROVERRIDE),
                 lpDecimalSep, sizeof(lpDecimalSep) / sizeof(WCHAR));
  if (lpDecimalSep[0] == '.' && lpDecimalSep[1] == '\0')
  {
    // locale is compatible with English - return original string
    bstrOut = SysAllocString(buff);
  }
  else
  {
    WCHAR numbuff[256];
    WCHAR empty[1] = {'\0'};
    NUMBERFMTW minFormat;

    minFormat.NumDigits = 0;
    minFormat.LeadingZero = 0;
    minFormat.Grouping = 0;
    minFormat.lpDecimalSep = lpDecimalSep;
    minFormat.lpThousandSep = empty;
    minFormat.NegativeOrder = 1; // NLS_NEG_LEFT

    // count number of decimal digits in string
	StrAdapter tmp(strchr( StrAdapter(buff), '.' ));
    const WCHAR *p = tmp;
    if (p) minFormat.NumDigits = strlenW(p + 1);

    numbuff[0] = '\0';
    if (!GetNumberFormatW(lcid, 0, buff, &minFormat, numbuff, sizeof(numbuff) / sizeof(WCHAR)))
    {
      WARN("GetNumberFormatW() failed, returning raw number string instead\n");
      bstrOut = SysAllocString(buff);
    }
    else
    {
      TRACE("created minimal NLS string %s\n", debugstr_w(numbuff));
      bstrOut = SysAllocString(numbuff);
    }
  }
  return bstrOut;
}

static HRESULT VARIANT_BstrFromReal(DOUBLE dblIn, LCID lcid, ULONG dwFlags,
                                    BSTR* pbstrOut, LPCWSTR lpszFormat)
{
  WCHAR buff[256];
  char *localePrev;

  if (!pbstrOut)
    return E_INVALIDARG;

  if (lcid == (LCID)1033)
  { /* English requested; make sure we get a dot when calling sprintfW */
    localePrev = setlocale(LC_NUMERIC, NULL);
    setlocale(LC_NUMERIC, "C");
  }

  sprintfW( buff, lpszFormat, dblIn );

  /* Now restore the previous locale */
  if (lcid == (LCID)1033)
    setlocale(LC_NUMERIC, localePrev);

  /* Negative zeroes are disallowed (some applications depend on this).
     If buff starts with a minus, and then nothing follows but zeroes
     and/or a period, it is a negative zero and is replaced with a
     canonical zero. This duplicates native oleaut32 behavior.
   */
  if (buff[0] == '-')
  {
    const WCHAR szAccept[] = {'0', '.', '\0'};
    if (strlenW(buff + 1) == strspnW(buff + 1, szAccept))
    { buff[0] = '0'; buff[1] = '\0'; }
  }

  TRACE("created string %s\n", debugstr_w(buff));
  
  if (dwFlags & LOCALE_USE_NLS)
  {
    WCHAR numbuff[256];

    // Format the number for the locale
    numbuff[0] = '\0';
    GetNumberFormatW(lcid, dwFlags & LOCALE_NOUSEROVERRIDE,
                     buff, NULL, numbuff, sizeof(numbuff) / sizeof(WCHAR));
    TRACE("created NLS string %s\n", debugstr_w(numbuff));
    *pbstrOut = SysAllocString(numbuff);
  }
  else
  { 
    *pbstrOut = VARIANT_BstrReplaceDecimal(buff, lcid, dwFlags);
  }
  return *pbstrOut ? S_OK : E_OUTOFMEMORY;
}

/******************************************************************************
 * VarBstrFromR4 (OLEAUT32.111)
 *
 * Convert a VT_R4 to a VT_BSTR.
 *
 * PARAMS
 *  fltIn    [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromR4(FLOAT fltIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  return VARIANT_BstrFromReal(fltIn, lcid, dwFlags, pbstrOut, szFloatFormatW);
}

/******************************************************************************
 * VarBstrFromR8 (OLEAUT32.112)
 *
 * Convert a VT_R8 to a VT_BSTR.
 *
 * PARAMS
 *  dblIn    [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromR8(double dblIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  return VARIANT_BstrFromReal(dblIn, lcid, dwFlags, pbstrOut, szDoubleFormatW);
}

/******************************************************************************
 *    VarBstrFromCy   [OLEAUT32.113]
 *
 * Convert a VT_CY to a VT_BSTR.
 *
 * PARAMS
 *  cyIn     [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromCy(CY cyIn, LCID lcid, ULONG dwFlags, BSTR *pbstrOut)
{
  WCHAR buff[256];
  VARIANT_DI decVal;

  if (!pbstrOut)
    return E_INVALIDARG;

  decVal.scale = 4;
  decVal.sign = 0;
  decVal.bitsnum[0] = cyIn.Lo;
  decVal.bitsnum[1] = cyIn.Hi;
  if (cyIn.Hi & 0x80000000UL) {
    DWORD one = 1;

    /* Negative number! */
    decVal.sign = 1;
    decVal.bitsnum[0] = ~decVal.bitsnum[0];
    decVal.bitsnum[1] = ~decVal.bitsnum[1];
    VARIANT_int_add(decVal.bitsnum, 3, &one, 1);
  }
  decVal.bitsnum[2] = 0;
  VARIANT_DI_tostringW(&decVal, buff, sizeof(buff)/sizeof(buff[0]));

  /*
  if (dwFlags & LOCALE_USE_NLS)
  {
    WCHAR cybuff[256];
    // Format the currency for the locale
    cybuff[0] = '\0';
    GetCurrencyFormatW(lcid, dwFlags & LOCALE_NOUSEROVERRIDE,
                       buff, NULL, cybuff, sizeof(cybuff) / sizeof(WCHAR));
    *pbstrOut = SysAllocString(cybuff);
  }
  else
  */
  *pbstrOut = VARIANT_BstrReplaceDecimal(buff,lcid,dwFlags);

  return *pbstrOut ? S_OK : E_OUTOFMEMORY;
}

/******************************************************************************
 *    VarBstrFromDate    [OLEAUT32.114]
 *
 * Convert a VT_DATE to a VT_BSTR.
 *
 * PARAMS
 *  dateIn   [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut or dateIn is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromDate(DATE dateIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  SYSTEMTIME st;
  DWORD dwFormatFlags = dwFlags & LOCALE_NOUSEROVERRIDE;
  WCHAR date[128], *time;

  TRACE("(%g,0x%08x,0x%08x,%p)\n", dateIn, lcid, dwFlags, pbstrOut);

  if (!pbstrOut || !VariantTimeToSystemTime(dateIn, &st))
    return E_INVALIDARG;

  *pbstrOut = NULL;

  if (dwFlags & VAR_CALENDAR_THAI)
      st.wYear += 553; /* Use the Thai buddhist calendar year */
  else if (dwFlags & (VAR_CALENDAR_HIJRI|VAR_CALENDAR_GREGORIAN))
      //FixMe("VAR_CALENDAR_HIJRI/VAR_CALENDAR_GREGORIAN not handled\n");

  if (dwFlags & LOCALE_USE_NLS)
    dwFlags &= ~(VAR_TIMEVALUEONLY|VAR_DATEVALUEONLY);
  else
  {
    double whole = dateIn < 0 ? ceil(dateIn) : floor(dateIn);
    double partial = dateIn - whole;

    if (whole == 0.0)
      dwFlags |= VAR_TIMEVALUEONLY;
    else if (partial < 1e-12)
      dwFlags |= VAR_DATEVALUEONLY;
  }

  if (dwFlags & VAR_TIMEVALUEONLY)
    date[0] = '\0';
  else
    if (!GetDateFormatW(lcid, dwFormatFlags|DATE_SHORTDATE, &st, NULL, date,
                        sizeof(date)/sizeof(WCHAR)))
      return E_INVALIDARG;

  if (!(dwFlags & VAR_DATEVALUEONLY))
  {
    time = date + strlenW(date);
    if (time != date)
      *time++ = ' ';
    if (!GetTimeFormatW(lcid, dwFormatFlags, &st, NULL, time,
                        sizeof(date)/sizeof(WCHAR)-(time-date)))
      return E_INVALIDARG;
  }

  *pbstrOut = SysAllocString(date);
  if (*pbstrOut)
    TRACE("returning %s\n", debugstr_w(*pbstrOut));
  return *pbstrOut ? S_OK : E_OUTOFMEMORY;
}

/******************************************************************************
 * VarBstrFromBool (OLEAUT32.116)
 *
 * Convert a VT_BOOL to a VT_BSTR.
 *
 * PARAMS
 *  boolIn   [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 *
 * NOTES
 *  If dwFlags includes VARIANT_LOCALBOOL, this function converts to the
 *  localised text of "True" or "False". To convert a bool into a
 *  numeric string of "0" or "-1", use VariantChangeTypeTypeEx().
 */
HRESULT WINAPI VarBstrFromBool(VARIANT_BOOL boolIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  WCHAR szBuff[64];
  DWORD dwResId = IDS_TRUE;
  LANGID langId;

  TRACE("%d,0x%08x,0x%08x,%p\n", boolIn, lcid, dwFlags, pbstrOut);

  if (!pbstrOut)
    return E_INVALIDARG;

  /* VAR_BOOLONOFF and VAR_BOOLYESNO are internal flags used
   * for variant formatting */
  switch (dwFlags & (VAR_LOCALBOOL|VAR_BOOLONOFF|VAR_BOOLYESNO))
  {
  case VAR_BOOLONOFF:
      dwResId = IDS_ON;
      break;
  case VAR_BOOLYESNO:
      dwResId = IDS_YES;
      break;
  case VAR_LOCALBOOL:
      break;
  default:
    lcid = MAKELCID(MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT),SORT_DEFAULT);
  }

  lcid = ConvertDefaultLocale(lcid);
  langId = LANGIDFROMLCID(lcid);
  if (PRIMARYLANGID(langId) == LANG_NEUTRAL)
    langId = MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT);

  if (boolIn == VARIANT_FALSE)
    dwResId++; /* Use negative form */

VarBstrFromBool_GetLocalised:
  if (VARIANT_GetLocalisedText(langId, dwResId, szBuff))
  {
    *pbstrOut = SysAllocString(szBuff);
    return *pbstrOut ? S_OK : E_OUTOFMEMORY;
  }

  if (langId != MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT))
  {
    langId = MAKELANGID(LANG_ENGLISH, SUBLANG_DEFAULT);
    goto VarBstrFromBool_GetLocalised;
  }

  /* Should never get here */
  WARN("Failed to load bool text!\n");
  return E_OUTOFMEMORY;
}

/******************************************************************************
 * VarBstrFromI1 (OLEAUT32.229)
 *
 * Convert a VT_I1 to a VT_BSTR.
 *
 * PARAMS
 *  cIn      [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromI1(signed char cIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  ULONG64 ul64 = cIn;

  if (cIn < 0)
  {
    ul64 = -cIn;
    dwFlags |= VAR_NEGATIVE;
  }
  return VARIANT_BstrFromUInt(ul64, lcid, dwFlags, pbstrOut);
}

/******************************************************************************
 * VarBstrFromUI2 (OLEAUT32.230)
 *
 * Convert a VT_UI2 to a VT_BSTR.
 *
 * PARAMS
 *  usIn     [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromUI2(USHORT usIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  return VARIANT_BstrFromUInt(usIn, lcid, dwFlags, pbstrOut);
}

/******************************************************************************
 * VarBstrFromUI4 (OLEAUT32.231)
 *
 * Convert a VT_UI4 to a VT_BSTR.
 *
 * PARAMS
 *  ulIn     [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromUI4(ULONG ulIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  return VARIANT_BstrFromUInt(ulIn, lcid, dwFlags, pbstrOut);
}

/******************************************************************************
 * VarBstrFromDec (OLEAUT32.232)
 *
 * Convert a VT_DECIMAL to a VT_BSTR.
 *
 * PARAMS
 *  pDecIn   [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromDec(DECIMAL* pDecIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  WCHAR buff[256];
  VARIANT_DI temp;

  if (!pbstrOut)
    return E_INVALIDARG;

  VARIANT_DIFromDec(pDecIn, &temp);
  VARIANT_DI_tostringW(&temp, buff, 256);
  
  if (dwFlags & LOCALE_USE_NLS)
  {
    WCHAR numbuff[256];

    // Format the number for the locale
    numbuff[0] = '\0';
    GetNumberFormatW(lcid, dwFlags & LOCALE_NOUSEROVERRIDE,
                     buff, NULL, numbuff, sizeof(numbuff) / sizeof(WCHAR));
    TRACE("created NLS string %s\n", debugstr_w(numbuff));
    *pbstrOut = SysAllocString(numbuff);
  }
  else
  {
    *pbstrOut = VARIANT_BstrReplaceDecimal(buff, lcid, dwFlags);
  }
  
  TRACE("returning %s\n", debugstr_w(*pbstrOut));
  return *pbstrOut ? S_OK : E_OUTOFMEMORY;
}

/************************************************************************
 * VarBstrFromI8 (OLEAUT32.370)
 *
 * Convert a VT_I8 to a VT_BSTR.
 *
 * PARAMS
 *  llIn     [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromI8(LONG64 llIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  ULONG64 ul64 = llIn;

  if (llIn < 0)
  {
    ul64 = -llIn;
    dwFlags |= VAR_NEGATIVE;
  }
  return VARIANT_BstrFromUInt(ul64, lcid, dwFlags, pbstrOut);
}

/************************************************************************
 * VarBstrFromUI8 (OLEAUT32.371)
 *
 * Convert a VT_UI8 to a VT_BSTR.
 *
 * PARAMS
 *  ullIn    [I] Source
 *  lcid     [I] LCID for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pbstrOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrFromUI8(ULONG64 ullIn, LCID lcid, ULONG dwFlags, BSTR* pbstrOut)
{
  return VARIANT_BstrFromUInt(ullIn, lcid, dwFlags, pbstrOut);
}


/**********************************************************************
 * VarBstrCat (OLEAUT32.313)
 *
 * Concatenate two BSTR values.
 *
 * PARAMS
 *  pbstrLeft  [I] Source
 *  pbstrRight [I] Value to concatenate
 *  pbstrOut   [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: E_INVALIDARG, if pbstrOut is invalid.
 *           E_OUTOFMEMORY, if memory allocation fails.
 */
HRESULT WINAPI VarBstrCat(BSTR pbstrLeft, BSTR pbstrRight, BSTR *pbstrOut)
{
  unsigned int lenLeft, lenRight;

  if (!pbstrOut)
    return E_INVALIDARG;

  lenLeft = pbstrLeft ? SysStringLen(pbstrLeft) : 0;
  lenRight = pbstrRight ? SysStringLen(pbstrRight) : 0;

  *pbstrOut = SysAllocStringLen(NULL, lenLeft + lenRight);
  if (!*pbstrOut)
    return E_OUTOFMEMORY;

  (*pbstrOut)[0] = '\0';

  if (pbstrLeft)
    memcpy(*pbstrOut, pbstrLeft, lenLeft * sizeof(WCHAR));

  if (pbstrRight)
    memcpy(*pbstrOut + lenLeft, pbstrRight, lenRight * sizeof(WCHAR));

  return S_OK;
}

/**********************************************************************
 * VarBstrCmp (OLEAUT32.314)
 *
 * Compare two BSTR values.
 *
 * PARAMS
 *  pbstrLeft  [I] Source
 *  pbstrRight [I] Value to compare
 *  lcid       [I] LCID for the comparison
 *  dwFlags    [I] Flags to pass directly to CompareStringW().
 *
 * RETURNS
 *  VARCMP_LT, VARCMP_EQ or VARCMP_GT indicating that pbstrLeft is less
 *  than, equal to or greater than pbstrRight respectively.
 *
 * NOTES
 *  VARCMP_NULL is NOT returned if either string is NULL unlike MSDN
 *  states. A NULL BSTR pointer is equivalent to an empty string.
 *  If LCID is equal to 0, a byte by byte comparison is performed.
 */
HRESULT WINAPI VarBstrCmp(BSTR pbstrLeft, BSTR pbstrRight, LCID lcid, DWORD dwFlags)
{
    HRESULT hres;
    int ret;

    if (!pbstrLeft || !*pbstrLeft)
    {
      if (pbstrRight && *pbstrRight)
        return VARCMP_LT;
    }
    else if (!pbstrRight || !*pbstrRight)
        return VARCMP_GT;

    if (lcid == 0)
    {
      unsigned int lenLeft = SysStringByteLen(pbstrLeft);
      unsigned int lenRight = SysStringByteLen(pbstrRight);
      ret = memcmp(pbstrLeft, pbstrRight, lenLeft < lenRight ? lenLeft : lenRight);
      if (ret < 0)
        return VARCMP_LT;
      if (ret > 0)
        return VARCMP_GT;
      if (lenLeft < lenRight)
        return VARCMP_LT;
      if (lenLeft > lenRight)
        return VARCMP_GT;
      return VARCMP_EQ;
    }
    else
    {
      unsigned int lenLeft = SysStringLen(pbstrLeft);
      unsigned int lenRight = SysStringLen(pbstrRight);

      if (lenLeft == 0 || lenRight == 0)
      {
          if (lenLeft == 0 && lenRight == 0) return VARCMP_EQ;
          return lenLeft < lenRight ? VARCMP_LT : VARCMP_GT;
      }

      hres = CompareStringW(lcid, dwFlags, pbstrLeft, lenLeft,
              pbstrRight, lenRight) - 1;
      TRACE("%d\n", hres);
      return hres;
    }
}

/*
 * DATE
 */

/******************************************************************************
 * VarDateFromUI1 (OLEAUT32.88)
 *
 * Convert a VT_UI1 to a VT_DATE.
 *
 * PARAMS
 *  bIn      [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromUI1(BYTE bIn, DATE* pdateOut)
{
  return VarR8FromUI1(bIn, pdateOut);
}

/******************************************************************************
 * VarDateFromI2 (OLEAUT32.89)
 *
 * Convert a VT_I2 to a VT_DATE.
 *
 * PARAMS
 *  sIn      [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromI2(short sIn, DATE* pdateOut)
{
  return VarR8FromI2(sIn, pdateOut);
}

/******************************************************************************
 * VarDateFromI4 (OLEAUT32.90)
 *
 * Convert a VT_I4 to a VT_DATE.
 *
 * PARAMS
 *  lIn      [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromI4(LONG lIn, DATE* pdateOut)
{
  return VarDateFromR8(lIn, pdateOut);
}

/******************************************************************************
 * VarDateFromR4 (OLEAUT32.91)
 *
 * Convert a VT_R4 to a VT_DATE.
 *
 * PARAMS
 *  fltIn    [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromR4(FLOAT fltIn, DATE* pdateOut)
{
  return VarR8FromR4(fltIn, pdateOut);
}

/******************************************************************************
 * VarDateFromR8 (OLEAUT32.92)
 *
 * Convert a VT_R8 to a VT_DATE.
 *
 * PARAMS
 *  dblIn    [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromR8(double dblIn, DATE* pdateOut)
{
  if (dblIn <= (DATE_MIN - 1.0) || dblIn >= (DATE_MAX + 1.0)) return DISP_E_OVERFLOW;
  *pdateOut = (DATE)dblIn;
  return S_OK;
}


/******************************************************************************
 * VarDateFromBool (OLEAUT32.96)
 *
 * Convert a VT_BOOL to a VT_DATE.
 *
 * PARAMS
 *  boolIn   [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromBool(VARIANT_BOOL boolIn, DATE* pdateOut)
{
  return VarR8FromBool(boolIn, pdateOut);
}

/**********************************************************************
 * VarDateFromCy (OLEAUT32.93)
 *
 * Convert a VT_CY to a VT_DATE.
 *
 * PARAMS
 *  lIn      [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromCy(CY cyIn, DATE* pdateOut)
{
  return VarR8FromCy(cyIn, pdateOut);
}

/* Date string parsing */
#define DP_TIMESEP 0x01 /* Time separator ( _must_ remain 0x1, used as a bitmask) */
#define DP_DATESEP 0x02 /* Date separator */
#define DP_MONTH   0x04 /* Month name */
#define DP_AM      0x08 /* AM */
#define DP_PM      0x10 /* PM */

typedef struct tagDATEPARSE
{
    DWORD dwCount;      /* Number of fields found so far (maximum 6) */
    DWORD dwParseFlags; /* Global parse flags (DP_ Flags above) */
    DWORD dwFlags[6];   /* Flags for each field */
    DWORD dwValues[6];  /* Value of each field */
} DATEPARSE;

#define TIMEFLAG(i) ((dp.dwFlags[i] & DP_TIMESEP) << i)

#define IsLeapYear(y) (((y % 4) == 0) && (((y % 100) != 0) || ((y % 400) == 0)))

/* Determine if a day is valid in a given month of a given year */
static BOOL VARIANT_IsValidMonthDay(DWORD day, DWORD month, DWORD year)
{
  static const BYTE days[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

  if (day && month && month < 13)
  {
    if (day <= days[month] || (month == 2 && day == 29 && IsLeapYear(year)))
      return TRUE;
  }
  return FALSE;
}

/* Possible orders for 3 numbers making up a date */
#define ORDER_MDY 0x01
#define ORDER_YMD 0x02
#define ORDER_YDM 0x04
#define ORDER_DMY 0x08
#define ORDER_MYD 0x10 /* Synthetic order, used only for funky 2 digit dates */

/* Determine a date for a particular locale, from 3 numbers */
static inline HRESULT VARIANT_MakeDate(DATEPARSE *dp, DWORD iDate,
                                       DWORD offset, SYSTEMTIME *st)
{
  DWORD dwAllOrders, dwTry, dwCount = 0, v1, v2, v3;

  if (!dp->dwCount)
  {
    v1 = 30; /* Default to (Variant) 0 date part */
    v2 = 12;
    v3 = 1899;
    goto VARIANT_MakeDate_OK;
  }

  v1 = dp->dwValues[offset + 0];
  v2 = dp->dwValues[offset + 1];
  if (dp->dwCount == 2)
  {
    SYSTEMTIME current;
    GetSystemTime(&current);
    v3 = current.wYear;
  }
  else
    v3 = dp->dwValues[offset + 2];

  TRACE("(%d,%d,%d,%d,%d)\n", v1, v2, v3, iDate, offset);

  /* If one number must be a month (Because a month name was given), then only
   * consider orders with the month in that position.
   * If we took the current year as 'v3', then only allow a year in that position.
   */
  if (dp->dwFlags[offset + 0] & DP_MONTH)
  {
    dwAllOrders = ORDER_MDY;
  }
  else if (dp->dwFlags[offset + 1] & DP_MONTH)
  {
    dwAllOrders = ORDER_DMY;
    if (dp->dwCount > 2)
      dwAllOrders |= ORDER_YMD;
  }
  else if (dp->dwCount > 2 && dp->dwFlags[offset + 2] & DP_MONTH)
  {
    dwAllOrders = ORDER_YDM;
  }
  else
  {
    dwAllOrders = ORDER_MDY|ORDER_DMY;
    if (dp->dwCount > 2)
      dwAllOrders |= (ORDER_YMD|ORDER_YDM);
  }

VARIANT_MakeDate_Start:
  TRACE("dwAllOrders is 0x%08x\n", dwAllOrders);

  while (dwAllOrders)
  {
    DWORD dwTemp;

    if (dwCount == 0)
    {
      /* First: Try the order given by iDate */
      switch (iDate)
      {
      case 0:  dwTry = dwAllOrders & ORDER_MDY; break;
      case 1:  dwTry = dwAllOrders & ORDER_DMY; break;
      default: dwTry = dwAllOrders & ORDER_YMD; break;
      }
    }
    else if (dwCount == 1)
    {
      /* Second: Try all the orders compatible with iDate */
      switch (iDate)
      {
      case 0:  dwTry = dwAllOrders & ~(ORDER_DMY|ORDER_YDM); break;
      case 1:  dwTry = dwAllOrders & ~(ORDER_MDY|ORDER_YMD|ORDER_MYD); break;
      default: dwTry = dwAllOrders & ~(ORDER_DMY|ORDER_YDM); break;
      }
    }
    else
    {
      /* Finally: Try any remaining orders */
      dwTry = dwAllOrders;
    }

    TRACE("Attempt %d, dwTry is 0x%08x\n", dwCount, dwTry);

    dwCount++;
    if (!dwTry)
      continue;

#define DATE_SWAP(x,y) do { dwTemp = x; x = y; y = dwTemp; } while (0)

    if (dwTry & ORDER_MDY)
    {
      if (VARIANT_IsValidMonthDay(v2,v1,v3))
      {
        DATE_SWAP(v1,v2);
        goto VARIANT_MakeDate_OK;
      }
      dwAllOrders &= ~ORDER_MDY;
    }
    if (dwTry & ORDER_YMD)
    {
      if (VARIANT_IsValidMonthDay(v3,v2,v1))
      {
        DATE_SWAP(v1,v3);
        goto VARIANT_MakeDate_OK;
      }
      dwAllOrders &= ~ORDER_YMD;
    }
    if (dwTry & ORDER_YDM)
    {
      if (VARIANT_IsValidMonthDay(v2,v3,v1))
      {
        DATE_SWAP(v1,v2);
        DATE_SWAP(v2,v3);
        goto VARIANT_MakeDate_OK;
      }
      dwAllOrders &= ~ORDER_YDM;
    }
    if (dwTry & ORDER_DMY)
    {
      if (VARIANT_IsValidMonthDay(v1,v2,v3))
        goto VARIANT_MakeDate_OK;
      dwAllOrders &= ~ORDER_DMY;
    }
    if (dwTry & ORDER_MYD)
    {
      /* Only occurs if we are trying a 2 year date as M/Y not D/M */
      if (VARIANT_IsValidMonthDay(v3,v1,v2))
      {
        DATE_SWAP(v1,v3);
        DATE_SWAP(v2,v3);
        goto VARIANT_MakeDate_OK;
      }
      dwAllOrders &= ~ORDER_MYD;
    }
  }

  if (dp->dwCount == 2)
  {
    /* We couldn't make a date as D/M or M/D, so try M/Y or Y/M */
    v3 = 1; /* 1st of the month */
    dwAllOrders = ORDER_YMD|ORDER_MYD;
    dp->dwCount = 0; /* Don't return to this code path again */
    dwCount = 0;
    goto VARIANT_MakeDate_Start;
  }

  /* No valid dates were able to be constructed */
  return DISP_E_TYPEMISMATCH;

VARIANT_MakeDate_OK:

  /* Check that the time part is ok */
  if (st->wHour > 23 || st->wMinute > 59 || st->wSecond > 59)
    return DISP_E_TYPEMISMATCH;

  TRACE("Time %d %d %d\n", st->wHour, st->wMinute, st->wSecond);
  if (st->wHour < 12 && (dp->dwParseFlags & DP_PM))
    st->wHour += 12;
  else if (st->wHour == 12 && (dp->dwParseFlags & DP_AM))
    st->wHour = 0;
  TRACE("Time %d %d %d\n", st->wHour, st->wMinute, st->wSecond);

  st->wDay = v1;
  st->wMonth = v2;
  /* //FixMe: For 2 digit dates, I'm not sure if 30 is hard coded or not. It may
   * be retrieved from:
   * HKCU\Control Panel\International\Calendars\TwoDigitYearMax
   * But Wine doesn't have/use that key as at the time of writing.
   */
  st->wYear = v3 < 30 ? 2000 + v3 : v3 < 100 ? 1900 + v3 : v3;
  TRACE("Returning date %d/%d/%d\n", v1, v2, st->wYear);
  return S_OK;
}

/******************************************************************************
 * VarDateFromStr [OLEAUT32.94]
 *
 * Convert a VT_BSTR to at VT_DATE.
 *
 * PARAMS
 *  strIn    [I] String to convert
 *  lcid     [I] Locale identifier for the conversion
 *  dwFlags  [I] Flags affecting the conversion (VAR_ flags from "oleauto.h")
 *  pdateOut [O] Destination for the converted value
 *
 * RETURNS
 *  Success: S_OK. pdateOut contains the converted value.
 *  FAILURE: An HRESULT error code indicating the problem.
 *
 * NOTES
 *  Any date format that can be created using the date formats from lcid
 *  (Either from kernel Nls functions, variant conversion or formatting) is a
 *  valid input to this function. In addition, a few more esoteric formats are
 *  also supported for compatibility with the native version. The date is
 *  interpreted according to the date settings in the control panel, unless
 *  the date is invalid in that format, in which the most compatible format
 *  that produces a valid date will be used.
 */
HRESULT WINAPI VarDateFromStr(OLECHAR* strIn, LCID lcid, ULONG dwFlags, DATE* pdateOut)
{
  static const USHORT ParseDateTokens[] =
  {
    LOCALE_SMONTHNAME1, LOCALE_SMONTHNAME2, LOCALE_SMONTHNAME3, LOCALE_SMONTHNAME4,
    LOCALE_SMONTHNAME5, LOCALE_SMONTHNAME6, LOCALE_SMONTHNAME7, LOCALE_SMONTHNAME8,
    LOCALE_SMONTHNAME9, LOCALE_SMONTHNAME10, LOCALE_SMONTHNAME11, LOCALE_SMONTHNAME12,
    LOCALE_SMONTHNAME13,
    LOCALE_SABBREVMONTHNAME1, LOCALE_SABBREVMONTHNAME2, LOCALE_SABBREVMONTHNAME3,
    LOCALE_SABBREVMONTHNAME4, LOCALE_SABBREVMONTHNAME5, LOCALE_SABBREVMONTHNAME6,
    LOCALE_SABBREVMONTHNAME7, LOCALE_SABBREVMONTHNAME8, LOCALE_SABBREVMONTHNAME9,
    LOCALE_SABBREVMONTHNAME10, LOCALE_SABBREVMONTHNAME11, LOCALE_SABBREVMONTHNAME12,
    LOCALE_SABBREVMONTHNAME13,
    LOCALE_SDAYNAME1, LOCALE_SDAYNAME2, LOCALE_SDAYNAME3, LOCALE_SDAYNAME4,
    LOCALE_SDAYNAME5, LOCALE_SDAYNAME6, LOCALE_SDAYNAME7,
    LOCALE_SABBREVDAYNAME1, LOCALE_SABBREVDAYNAME2, LOCALE_SABBREVDAYNAME3,
    LOCALE_SABBREVDAYNAME4, LOCALE_SABBREVDAYNAME5, LOCALE_SABBREVDAYNAME6,
    LOCALE_SABBREVDAYNAME7,
    LOCALE_S1159, LOCALE_S2359,
    LOCALE_SDATE
  };
  static const BYTE ParseDateMonths[] =
  {
    1,2,3,4,5,6,7,8,9,10,11,12,13,
    1,2,3,4,5,6,7,8,9,10,11,12,13
  };
  unsigned int i;
  BSTR tokens[sizeof(ParseDateTokens)/sizeof(ParseDateTokens[0])];
  DATEPARSE dp;
  DWORD dwDateSeps = 0, iDate = 0;
  HRESULT hRet = S_OK;

  if ((dwFlags & (VAR_TIMEVALUEONLY|VAR_DATEVALUEONLY)) ==
      (VAR_TIMEVALUEONLY|VAR_DATEVALUEONLY))
    return E_INVALIDARG;

  if (!strIn)
    return DISP_E_TYPEMISMATCH;

  *pdateOut = 0.0;

  TRACE("(%s,0x%08x,0x%08x,%p)\n", debugstr_w(strIn), lcid, dwFlags, pdateOut);

  memset(&dp, 0, sizeof(dp));

  GetLocaleInfoW(lcid, LOCALE_IDATE|LOCALE_RETURN_NUMBER|(dwFlags & LOCALE_NOUSEROVERRIDE),
                 (LPWSTR)&iDate, sizeof(iDate)/sizeof(WCHAR));
  TRACE("iDate is %d\n", iDate);

  /* Get the month/day/am/pm tokens for this locale */
  for (i = 0; i < sizeof(tokens)/sizeof(tokens[0]); i++)
  {
    WCHAR buff[128];
    LCTYPE lctype =  ParseDateTokens[i] | (dwFlags & LOCALE_NOUSEROVERRIDE);

    /* //FixMe: Alternate calendars - should use GetCalendarInfo() and/or
     *        GetAltMonthNames(). We should really cache these strings too.
     */
    buff[0] = '\0';
    GetLocaleInfoW(lcid, lctype, buff, sizeof(buff)/sizeof(WCHAR));
    tokens[i] = SysAllocString(buff);
    TRACE("token %d is %s\n", i, debugstr_w(tokens[i]));
  }

  /* Parse the string into our structure */
  while (*strIn)
  {
    if (dp.dwCount >= 6)
      break;

    if (isdigitW(*strIn))
    {
      dp.dwValues[dp.dwCount] = strtoulW(strIn, &strIn, 10);
      dp.dwCount++;
      strIn--;
    }
    else if (isalpha(*strIn))
    {
      BOOL bFound = FALSE;

      for (i = 0; i < sizeof(tokens)/sizeof(tokens[0]); i++)
      {
        DWORD dwLen = strlenW(tokens[i]);
        if (dwLen && !strncmpiW(strIn, tokens[i], dwLen))
        {
          if (i <= 25)
          {
            dp.dwValues[dp.dwCount] = ParseDateMonths[i];
            dp.dwFlags[dp.dwCount] |= (DP_MONTH|DP_DATESEP);
            dp.dwCount++;
          }
          else if (i > 39 && i < 42)
          {
            if (!dp.dwCount || dp.dwParseFlags & (DP_AM|DP_PM))
              hRet = DISP_E_TYPEMISMATCH;
            else
            {
              dp.dwFlags[dp.dwCount - 1] |= (i == 40 ? DP_AM : DP_PM);
              dp.dwParseFlags |= (i == 40 ? DP_AM : DP_PM);
            }
          }
          strIn += (dwLen - 1);
          bFound = TRUE;
          break;
        }
      }

      if (!bFound)
      {
        if ((*strIn == 'a' || *strIn == 'A' || *strIn == 'p' || *strIn == 'P') &&
            (dp.dwCount && !(dp.dwParseFlags & (DP_AM|DP_PM))))
        {
          /* Special case - 'a' and 'p' are recognised as short for am/pm */
          if (*strIn == 'a' || *strIn == 'A')
          {
            dp.dwFlags[dp.dwCount - 1] |= DP_AM;
            dp.dwParseFlags |=  DP_AM;
          }
          else
          {
            dp.dwFlags[dp.dwCount - 1] |= DP_PM;
            dp.dwParseFlags |=  DP_PM;
          }
          strIn++;
        }
        else
        {
          TRACE("No matching token for %s\n", debugstr_w(strIn));
          hRet = DISP_E_TYPEMISMATCH;
          break;
        }
      }
    }
    else if (*strIn == ':' ||  *strIn == '.')
    {
      if (!dp.dwCount || !strIn[1])
        hRet = DISP_E_TYPEMISMATCH;
      else
        if (tokens[42][0] == *strIn)
        {
          dwDateSeps++;
          if (dwDateSeps > 2)
            hRet = DISP_E_TYPEMISMATCH;
          else
            dp.dwFlags[dp.dwCount - 1] |= DP_DATESEP;
        }
        else
          dp.dwFlags[dp.dwCount - 1] |= DP_TIMESEP;
    }
    else if (*strIn == '-' || *strIn == '/')
    {
      dwDateSeps++;
      if (dwDateSeps > 2 || !dp.dwCount || !strIn[1])
        hRet = DISP_E_TYPEMISMATCH;
      else
        dp.dwFlags[dp.dwCount - 1] |= DP_DATESEP;
    }
    else if (*strIn == ',' || isspaceW(*strIn))
    {
      if (*strIn == ',' && !strIn[1])
        hRet = DISP_E_TYPEMISMATCH;
    }
    else
    {
      hRet = DISP_E_TYPEMISMATCH;
    }
    strIn++;
  }

  if (!dp.dwCount || dp.dwCount > 6 ||
      (dp.dwCount == 1 && !(dp.dwParseFlags & (DP_AM|DP_PM))))
    hRet = DISP_E_TYPEMISMATCH;

  if (SUCCEEDED(hRet))
  {
    SYSTEMTIME st;
    DWORD dwOffset = 0; /* Start of date fields in dp.dwValues */

    st.wDayOfWeek = st.wHour = st.wMinute = st.wSecond = st.wMilliseconds = 0;

    /* Figure out which numbers correspond to which fields.
     *
     * This switch statement works based on the fact that native interprets any
     * fields that are not joined with a time separator ('.' or ':') as date
     * fields. Thus we construct a value from 0-32 where each set bit indicates
     * a time field. This encapsulates the hundreds of permutations of 2-6 fields.
     * For valid permutations, we set dwOffset to point to the first date field
     * and shorten dp.dwCount by the number of time fields found. The real
     * magic here occurs in VARIANT_MakeDate() above, where we determine what
     * each date number must represent in the context of iDate.
     */
    TRACE("0x%08x\n", TIMEFLAG(0)|TIMEFLAG(1)|TIMEFLAG(2)|TIMEFLAG(3)|TIMEFLAG(4));

    switch (TIMEFLAG(0)|TIMEFLAG(1)|TIMEFLAG(2)|TIMEFLAG(3)|TIMEFLAG(4))
    {
    case 0x1: /* TT TTDD TTDDD */
      if (dp.dwCount > 3 &&
          ((dp.dwFlags[2] & (DP_AM|DP_PM)) || (dp.dwFlags[3] & (DP_AM|DP_PM)) ||
          (dp.dwFlags[4] & (DP_AM|DP_PM))))
        hRet = DISP_E_TYPEMISMATCH;
      else if (dp.dwCount != 2 && dp.dwCount != 4 && dp.dwCount != 5)
        hRet = DISP_E_TYPEMISMATCH;
      st.wHour = dp.dwValues[0];
      st.wMinute  = dp.dwValues[1];
      dp.dwCount -= 2;
      dwOffset = 2;
      break;

    case 0x3: /* TTT TTTDD TTTDDD */
      if (dp.dwCount > 4 &&
          ((dp.dwFlags[3] & (DP_AM|DP_PM)) || (dp.dwFlags[4] & (DP_AM|DP_PM)) ||
          (dp.dwFlags[5] & (DP_AM|DP_PM))))
        hRet = DISP_E_TYPEMISMATCH;
      else if (dp.dwCount != 3 && dp.dwCount != 5 && dp.dwCount != 6)
        hRet = DISP_E_TYPEMISMATCH;
      st.wHour   = dp.dwValues[0];
      st.wMinute = dp.dwValues[1];
      st.wSecond = dp.dwValues[2];
      dwOffset = 3;
      dp.dwCount -= 3;
      break;

    case 0x4: /* DDTT */
      if (dp.dwCount != 4 ||
          (dp.dwFlags[0] & (DP_AM|DP_PM)) || (dp.dwFlags[1] & (DP_AM|DP_PM)))
        hRet = DISP_E_TYPEMISMATCH;

      st.wHour = dp.dwValues[2];
      st.wMinute  = dp.dwValues[3];
      dp.dwCount -= 2;
      break;

   case 0x0: /* T DD DDD TDDD TDDD */
      if (dp.dwCount == 1 && (dp.dwParseFlags & (DP_AM|DP_PM)))
      {
        st.wHour = dp.dwValues[0]; /* T */
        dp.dwCount = 0;
        break;
      }
      else if (dp.dwCount > 4 || (dp.dwCount < 3 && dp.dwParseFlags & (DP_AM|DP_PM)))
      {
        hRet = DISP_E_TYPEMISMATCH;
      }
      else if (dp.dwCount == 3)
      {
        if (dp.dwFlags[0] & (DP_AM|DP_PM)) /* TDD */
        {
          dp.dwCount = 2;
          st.wHour = dp.dwValues[0];
          dwOffset = 1;
          break;
        }
        if (dp.dwFlags[2] & (DP_AM|DP_PM)) /* DDT */
        {
          dp.dwCount = 2;
          st.wHour = dp.dwValues[2];
          break;
        }
        else if (dp.dwParseFlags & (DP_AM|DP_PM))
          hRet = DISP_E_TYPEMISMATCH;
      }
      else if (dp.dwCount == 4)
      {
        dp.dwCount = 3;
        if (dp.dwFlags[0] & (DP_AM|DP_PM)) /* TDDD */
        {
          st.wHour = dp.dwValues[0];
          dwOffset = 1;
        }
        else if (dp.dwFlags[3] & (DP_AM|DP_PM)) /* DDDT */
        {
          st.wHour = dp.dwValues[3];
        }
        else
          hRet = DISP_E_TYPEMISMATCH;
        break;
      }
      /* .. fall through .. */

    case 0x8: /* DDDTT */
      if ((dp.dwCount == 2 && (dp.dwParseFlags & (DP_AM|DP_PM))) ||
          (dp.dwCount == 5 && ((dp.dwFlags[0] & (DP_AM|DP_PM)) ||
           (dp.dwFlags[1] & (DP_AM|DP_PM)) || (dp.dwFlags[2] & (DP_AM|DP_PM)))) ||
           dp.dwCount == 4 || dp.dwCount == 6)
        hRet = DISP_E_TYPEMISMATCH;
      st.wHour   = dp.dwValues[3];
      st.wMinute = dp.dwValues[4];
      if (dp.dwCount == 5)
        dp.dwCount -= 2;
      break;

    case 0xC: /* DDTTT */
      if (dp.dwCount != 5 ||
          (dp.dwFlags[0] & (DP_AM|DP_PM)) || (dp.dwFlags[1] & (DP_AM|DP_PM)))
        hRet = DISP_E_TYPEMISMATCH;
      st.wHour   = dp.dwValues[2];
      st.wMinute = dp.dwValues[3];
      st.wSecond = dp.dwValues[4];
      dp.dwCount -= 3;
      break;

    case 0x18: /* DDDTTT */
      if ((dp.dwFlags[0] & (DP_AM|DP_PM)) || (dp.dwFlags[1] & (DP_AM|DP_PM)) ||
          (dp.dwFlags[2] & (DP_AM|DP_PM)))
        hRet = DISP_E_TYPEMISMATCH;
      st.wHour   = dp.dwValues[3];
      st.wMinute = dp.dwValues[4];
      st.wSecond = dp.dwValues[5];
      dp.dwCount -= 3;
      break;

    default:
      hRet = DISP_E_TYPEMISMATCH;
      break;
    }

    if (SUCCEEDED(hRet))
    {
      hRet = VARIANT_MakeDate(&dp, iDate, dwOffset, &st);

      if (dwFlags & VAR_TIMEVALUEONLY)
      {
        st.wYear = 1899;
        st.wMonth = 12;
        st.wDay = 30;
      }
      else if (dwFlags & VAR_DATEVALUEONLY)
       st.wHour = st.wMinute = st.wSecond = 0;

      /* Finally, convert the value to a VT_DATE */
      if (SUCCEEDED(hRet))
        hRet = SystemTimeToVariantTime(&st, pdateOut) ? S_OK : DISP_E_TYPEMISMATCH;
    }
  }

  for (i = 0; i < sizeof(tokens)/sizeof(tokens[0]); i++)
    SysFreeString(tokens[i]);
  return hRet;
}

/******************************************************************************
 * VarDateFromI1 (OLEAUT32.221)
 *
 * Convert a VT_I1 to a VT_DATE.
 *
 * PARAMS
 *  cIn      [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromI1(signed char cIn, DATE* pdateOut)
{
  return VarR8FromI1(cIn, pdateOut);
}

/******************************************************************************
 * VarDateFromUI2 (OLEAUT32.222)
 *
 * Convert a VT_UI2 to a VT_DATE.
 *
 * PARAMS
 *  uiIn     [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromUI2(USHORT uiIn, DATE* pdateOut)
{
  return VarR8FromUI2(uiIn, pdateOut);
}

/******************************************************************************
 * VarDateFromUI4 (OLEAUT32.223)
 *
 * Convert a VT_UI4 to a VT_DATE.
 *
 * PARAMS
 *  ulIn     [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromUI4(ULONG ulIn, DATE* pdateOut)
{
  return VarDateFromR8(ulIn, pdateOut);
}

/**********************************************************************
 * VarDateFromDec (OLEAUT32.224)
 *
 * Convert a VT_DECIMAL to a VT_DATE.
 *
 * PARAMS
 *  pdecIn   [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  S_OK.
 */
HRESULT WINAPI VarDateFromDec(DECIMAL *pdecIn, DATE* pdateOut)
{
  return VarR8FromDec(pdecIn, pdateOut);
}

/******************************************************************************
 * VarDateFromI8 (OLEAUT32.364)
 *
 * Convert a VT_I8 to a VT_DATE.
 *
 * PARAMS
 *  llIn     [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarDateFromI8(LONG64 llIn, DATE* pdateOut)
{
  if (llIn < DATE_MIN || llIn > DATE_MAX) return DISP_E_OVERFLOW;
  *pdateOut = (DATE)llIn;
  return S_OK;
}

/******************************************************************************
 * VarDateFromUI8 (OLEAUT32.365)
 *
 * Convert a VT_UI8 to a VT_DATE.
 *
 * PARAMS
 *  ullIn    [I] Source
 *  pdateOut [O] Destination
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: DISP_E_OVERFLOW, if the value will not fit in the destination
 */
HRESULT WINAPI VarDateFromUI8(ULONG64 ullIn, DATE* pdateOut)
{
  if (ullIn > DATE_MAX) return DISP_E_OVERFLOW;
  *pdateOut = (DATE)ullIn;
  return S_OK;
}


const char * const wine_vtypes[VT_CLSID+1] =
{
  "VT_EMPTY","VT_NULL","VT_I2","VT_I4","VT_R4","VT_R8","VT_CY","VT_DATE",
  "VT_BSTR","VT_DISPATCH","VT_ERROR","VT_BOOL","VT_VARIANT","VT_UNKNOWN",
  "VT_DECIMAL","15","VT_I1","VT_UI1","VT_UI2","VT_UI4","VT_I8","VT_UI8",
  "VT_INT","VT_UINT","VT_VOID","VT_HRESULT","VT_PTR","VT_SAFEARRAY",
  "VT_CARRAY","VT_USERDEFINED","VT_LPSTR","VT_LPWSTR","32","33","34","35",
  "VT_RECORD","VT_INT_PTR","VT_UINT_PTR","39","40","41","42","43","44","45",
  "46","47","48","49","50","51","52","53","54","55","56","57","58","59","60",
  "61","62","63","VT_FILETIME","VT_BLOB","VT_STREAM","VT_STORAGE",
  "VT_STREAMED_OBJECT","VT_STORED_OBJECT","VT_BLOB_OBJECT","VT_CF","VT_CLSID"
};

const char * const wine_vflags[16] =
{
 "",
 "|VT_VECTOR",
 "|VT_ARRAY",
 "|VT_VECTOR|VT_ARRAY",
 "|VT_BYREF",
 "|VT_VECTOR|VT_ARRAY",
 "|VT_ARRAY|VT_BYREF",
 "|VT_VECTOR|VT_ARRAY|VT_BYREF",
 "|VT_HARDTYPE",
 "|VT_VECTOR|VT_HARDTYPE",
 "|VT_ARRAY|VT_HARDTYPE",
 "|VT_VECTOR|VT_ARRAY|VT_HARDTYPE",
 "|VT_BYREF|VT_HARDTYPE",
 "|VT_VECTOR|VT_ARRAY|VT_HARDTYPE",
 "|VT_ARRAY|VT_BYREF|VT_HARDTYPE",
 "|VT_VECTOR|VT_ARRAY|VT_BYREF|VT_HARDTYPE",
};

/* Convert a variant from one type to another */
static inline HRESULT VARIANT_Coerce(VARIANTARG* pd, LCID lcid, USHORT wFlags,
                                     VARIANTARG* ps, VARTYPE vt)
{
  HRESULT res = DISP_E_TYPEMISMATCH;
  VARTYPE vtFrom =  V_TYPE(ps);
  DWORD dwFlags = 0;

  TRACE("(%p->(%s%s),0x%08x,0x%04x,%p->(%s%s),%s%s)\n", pd, debugstr_VT(pd),
        debugstr_VF(pd), lcid, wFlags, ps, debugstr_VT(ps), debugstr_VF(ps),
        debugstr_vt(vt), debugstr_vf(vt));

  if (vt == VT_BSTR || vtFrom == VT_BSTR)
  {
    /* All flags passed to low level function are only used for
     * changing to or from strings. Map these here.
     */
    if (wFlags & VARIANT_LOCALBOOL)
      dwFlags |= VAR_LOCALBOOL;
    if (wFlags & VARIANT_CALENDAR_HIJRI)
      dwFlags |= VAR_CALENDAR_HIJRI;
    if (wFlags & VARIANT_CALENDAR_THAI)
      dwFlags |= VAR_CALENDAR_THAI;
    if (wFlags & VARIANT_CALENDAR_GREGORIAN)
      dwFlags |= VAR_CALENDAR_GREGORIAN;
    if (wFlags & VARIANT_NOUSEROVERRIDE)
      dwFlags |= LOCALE_NOUSEROVERRIDE;
    if (wFlags & VARIANT_USE_NLS)
      dwFlags |= LOCALE_USE_NLS;
  }

  /* Map int/uint to i4/ui4 */
  if (vt == VT_INT)
    vt = VT_I4;
  else if (vt == VT_UINT)
    vt = VT_UI4;

  if (vtFrom == VT_INT)
    vtFrom = VT_I4;
  else if (vtFrom == VT_UINT)
    vtFrom = VT_UI4;

  if (vt == vtFrom)
     return VariantCopy(pd, ps);

  if (wFlags & VARIANT_NOVALUEPROP && vtFrom == VT_DISPATCH && vt != VT_UNKNOWN)
  {
    /* VARIANT_NOVALUEPROP prevents IDispatch objects from being coerced by
     * accessing the default object property.
     */
    return DISP_E_TYPEMISMATCH;
  }

  switch (vt)
  {
  case VT_EMPTY:
    if (vtFrom == VT_NULL)
      return DISP_E_TYPEMISMATCH;
    /* ... Fall through */
  case VT_NULL:
    if (vtFrom <= VT_UINT && vtFrom != (VARTYPE)15 && vtFrom != VT_ERROR)
    {
      res = VariantClear( pd );
      if (vt == VT_NULL && SUCCEEDED(res))
        V_VT(pd) = VT_NULL;
    }
    return res;

  case VT_I1:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_I1(pd) = 0; return S_OK;
    case VT_I2:       return VarI1FromI2(V_I2(ps), (signed char*)&V_I1(pd));
    case VT_I4:       return VarI1FromI4(V_I4(ps), (signed char*)&V_I1(pd));
    case VT_UI1:      V_I1(pd) = V_UI1(ps); return S_OK;
    case VT_UI2:      return VarI1FromUI2(V_UI2(ps), (signed char*)&V_I1(pd));
    case VT_UI4:      return VarI1FromUI4(V_UI4(ps), (signed char*)&V_I1(pd));
    case VT_I8:       return VarI1FromI8(V_I8(ps), (signed char*)&V_I1(pd));
    case VT_UI8:      return VarI1FromUI8(V_UI8(ps), (signed char*)&V_I1(pd));
    case VT_R4:       return VarI1FromR4(V_R4(ps), (signed char*)&V_I1(pd));
    case VT_R8:       return VarI1FromR8(V_R8(ps), (signed char*)&V_I1(pd));
    case VT_DATE:     return VarI1FromDate(V_DATE(ps), (signed char*)&V_I1(pd));
    case VT_BOOL:     return VarI1FromBool(V_BOOL(ps), (signed char*)&V_I1(pd));
    case VT_CY:       return VarI1FromCy(V_CY(ps), (signed char*)&V_I1(pd));
    case VT_DECIMAL:  return VarI1FromDec(&V_DECIMAL(ps), (signed char*)&V_I1(pd) );
    //case VT_DISPATCH: return VarI1FromDisp(V_DISPATCH(ps), lcid, &V_I1(pd) );
    case VT_BSTR:     return VarI1FromStr(V_BSTR(ps), lcid, dwFlags, (signed char*)&V_I1(pd) );
    }
    break;

  case VT_I2:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_I2(pd) = 0; return S_OK;
    case VT_I1:       return VarI2FromI1(V_I1(ps), &V_I2(pd));
    case VT_I4:       return VarI2FromI4(V_I4(ps), &V_I2(pd));
    case VT_UI1:      return VarI2FromUI1(V_UI1(ps), &V_I2(pd));
    case VT_UI2:      V_I2(pd) = V_UI2(ps); return S_OK;
    case VT_UI4:      return VarI2FromUI4(V_UI4(ps), &V_I2(pd));
    case VT_I8:       return VarI2FromI8(V_I8(ps), &V_I2(pd));
    case VT_UI8:      return VarI2FromUI8(V_UI8(ps), &V_I2(pd));
    case VT_R4:       return VarI2FromR4(V_R4(ps), &V_I2(pd));
    case VT_R8:       return VarI2FromR8(V_R8(ps), &V_I2(pd));
    case VT_DATE:     return VarI2FromDate(V_DATE(ps), &V_I2(pd));
    case VT_BOOL:     return VarI2FromBool(V_BOOL(ps), &V_I2(pd));
    case VT_CY:       return VarI2FromCy(V_CY(ps), &V_I2(pd));
    case VT_DECIMAL:  return VarI2FromDec(&V_DECIMAL(ps), &V_I2(pd));
    //case VT_DISPATCH: return VarI2FromDisp(V_DISPATCH(ps), lcid, &V_I2(pd));
    case VT_BSTR:     return VarI2FromStr(V_BSTR(ps), lcid, dwFlags, &V_I2(pd));
    }
    break;

  case VT_I4:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_I4(pd) = 0; return S_OK;
    case VT_I1:       return VarI4FromI1(V_I1(ps), &V_I4(pd));
    case VT_I2:       return VarI4FromI2(V_I2(ps), &V_I4(pd));
    case VT_UI1:      return VarI4FromUI1(V_UI1(ps), &V_I4(pd));
    case VT_UI2:      return VarI4FromUI2(V_UI2(ps), &V_I4(pd));
    case VT_UI4:      V_I4(pd) = V_UI4(ps); return S_OK;
    case VT_I8:       return VarI4FromI8(V_I8(ps), &V_I4(pd));
    case VT_UI8:      return VarI4FromUI8(V_UI8(ps), &V_I4(pd));
    case VT_R4:       return VarI4FromR4(V_R4(ps), &V_I4(pd));
    case VT_R8:       return VarI4FromR8(V_R8(ps), &V_I4(pd));
    case VT_DATE:     return VarI4FromDate(V_DATE(ps), &V_I4(pd));
    case VT_BOOL:     return VarI4FromBool(V_BOOL(ps), &V_I4(pd));
    case VT_CY:       return VarI4FromCy(V_CY(ps), &V_I4(pd));
    case VT_DECIMAL:  return VarI4FromDec(&V_DECIMAL(ps), &V_I4(pd));
    //case VT_DISPATCH: return VarI4FromDisp(V_DISPATCH(ps), lcid, &V_I4(pd));
    case VT_BSTR:     return VarI4FromStr(V_BSTR(ps), lcid, dwFlags, &V_I4(pd));
    }
    break;

  case VT_UI1:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_UI1(pd) = 0; return S_OK;
    case VT_I1:       V_UI1(pd) = V_I1(ps); return S_OK;
    case VT_I2:       return VarUI1FromI2(V_I2(ps), &V_UI1(pd));
    case VT_I4:       return VarUI1FromI4(V_I4(ps), &V_UI1(pd));
    case VT_UI2:      return VarUI1FromUI2(V_UI2(ps), &V_UI1(pd));
    case VT_UI4:      return VarUI1FromUI4(V_UI4(ps), &V_UI1(pd));
    case VT_I8:       return VarUI1FromI8(V_I8(ps), &V_UI1(pd));
    case VT_UI8:      return VarUI1FromUI8(V_UI8(ps), &V_UI1(pd));
    case VT_R4:       return VarUI1FromR4(V_R4(ps), &V_UI1(pd));
    case VT_R8:       return VarUI1FromR8(V_R8(ps), &V_UI1(pd));
    case VT_DATE:     return VarUI1FromDate(V_DATE(ps), &V_UI1(pd));
    case VT_BOOL:     return VarUI1FromBool(V_BOOL(ps), &V_UI1(pd));
    case VT_CY:       return VarUI1FromCy(V_CY(ps), &V_UI1(pd));
    case VT_DECIMAL:  return VarUI1FromDec(&V_DECIMAL(ps), &V_UI1(pd));
    //case VT_DISPATCH: return VarUI1FromDisp(V_DISPATCH(ps), lcid, &V_UI1(pd));
    case VT_BSTR:     return VarUI1FromStr(V_BSTR(ps), lcid, dwFlags, &V_UI1(pd));
    }
    break;

  case VT_UI2:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_UI2(pd) = 0; return S_OK;
    case VT_I1:       return VarUI2FromI1(V_I1(ps), &V_UI2(pd));
    case VT_I2:       V_UI2(pd) = V_I2(ps); return S_OK;
    case VT_I4:       return VarUI2FromI4(V_I4(ps), &V_UI2(pd));
    case VT_UI1:      return VarUI2FromUI1(V_UI1(ps), &V_UI2(pd));
    case VT_UI4:      return VarUI2FromUI4(V_UI4(ps), &V_UI2(pd));
    case VT_I8:       return VarUI4FromI8(V_I8(ps), &V_UI4(pd));
    case VT_UI8:      return VarUI4FromUI8(V_UI8(ps), &V_UI4(pd));
    case VT_R4:       return VarUI2FromR4(V_R4(ps), &V_UI2(pd));
    case VT_R8:       return VarUI2FromR8(V_R8(ps), &V_UI2(pd));
    case VT_DATE:     return VarUI2FromDate(V_DATE(ps), &V_UI2(pd));
    case VT_BOOL:     return VarUI2FromBool(V_BOOL(ps), &V_UI2(pd));
    case VT_CY:       return VarUI2FromCy(V_CY(ps), &V_UI2(pd));
    case VT_DECIMAL:  return VarUI2FromDec(&V_DECIMAL(ps), &V_UI2(pd));
    //case VT_DISPATCH: return VarUI2FromDisp(V_DISPATCH(ps), lcid, &V_UI2(pd));
    case VT_BSTR:     return VarUI2FromStr(V_BSTR(ps), lcid, dwFlags, &V_UI2(pd));
    }
    break;

  case VT_UI4:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_UI4(pd) = 0; return S_OK;
    case VT_I1:       return VarUI4FromI1(V_I1(ps), &V_UI4(pd));
    case VT_I2:       return VarUI4FromI2(V_I2(ps), &V_UI4(pd));
    case VT_I4:       V_UI4(pd) = V_I4(ps); return S_OK;
    case VT_UI1:      return VarUI4FromUI1(V_UI1(ps), &V_UI4(pd));
    case VT_UI2:      return VarUI4FromUI2(V_UI2(ps), &V_UI4(pd));
    case VT_I8:       return VarUI4FromI8(V_I8(ps), &V_UI4(pd));
    case VT_UI8:      return VarUI4FromUI8(V_UI8(ps), &V_UI4(pd));
    case VT_R4:       return VarUI4FromR4(V_R4(ps), &V_UI4(pd));
    case VT_R8:       return VarUI4FromR8(V_R8(ps), &V_UI4(pd));
    case VT_DATE:     return VarUI4FromDate(V_DATE(ps), &V_UI4(pd));
    case VT_BOOL:     return VarUI4FromBool(V_BOOL(ps), &V_UI4(pd));
    case VT_CY:       return VarUI4FromCy(V_CY(ps), &V_UI4(pd));
    case VT_DECIMAL:  return VarUI4FromDec(&V_DECIMAL(ps), &V_UI4(pd));
    //case VT_DISPATCH: return VarUI4FromDisp(V_DISPATCH(ps), lcid, &V_UI4(pd));
    case VT_BSTR:     return VarUI4FromStr(V_BSTR(ps), lcid, dwFlags, &V_UI4(pd));
    }
    break;

  case VT_UI8:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_UI8(pd) = 0; return S_OK;
    case VT_I4:       if (V_I4(ps) < 0) return DISP_E_OVERFLOW; V_UI8(pd) = V_I4(ps); return S_OK;
    case VT_I1:       return VarUI8FromI1(V_I1(ps), &V_UI8(pd));
    case VT_I2:       return VarUI8FromI2(V_I2(ps), &V_UI8(pd));
    case VT_UI1:      return VarUI8FromUI1(V_UI1(ps), &V_UI8(pd));
    case VT_UI2:      return VarUI8FromUI2(V_UI2(ps), &V_UI8(pd));
    case VT_UI4:      return VarUI8FromUI4(V_UI4(ps), &V_UI8(pd));
    case VT_I8:       V_UI8(pd) = V_I8(ps); return S_OK;
    case VT_R4:       return VarUI8FromR4(V_R4(ps), &V_UI8(pd));
    case VT_R8:       return VarUI8FromR8(V_R8(ps), &V_UI8(pd));
    case VT_DATE:     return VarUI8FromDate(V_DATE(ps), &V_UI8(pd));
    case VT_BOOL:     return VarUI8FromBool(V_BOOL(ps), &V_UI8(pd));
    case VT_CY:       return VarUI8FromCy(V_CY(ps), &V_UI8(pd));
    case VT_DECIMAL:  return VarUI8FromDec(&V_DECIMAL(ps), &V_UI8(pd));
    //case VT_DISPATCH: return VarUI8FromDisp(V_DISPATCH(ps), lcid, &V_UI8(pd));
    case VT_BSTR:     return VarUI8FromStr(V_BSTR(ps), lcid, dwFlags, &V_UI8(pd));
    }
    break;

  case VT_I8:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_I8(pd) = 0; return S_OK;
    case VT_I4:       V_I8(pd) = V_I4(ps); return S_OK;
    case VT_I1:       return VarI8FromI1(V_I1(ps), &V_I8(pd));
    case VT_I2:       return VarI8FromI2(V_I2(ps), &V_I8(pd));
    case VT_UI1:      return VarI8FromUI1(V_UI1(ps), &V_I8(pd));
    case VT_UI2:      return VarI8FromUI2(V_UI2(ps), &V_I8(pd));
    case VT_UI4:      return VarI8FromUI4(V_UI4(ps), &V_I8(pd));
    case VT_UI8:      V_I8(pd) = V_UI8(ps); return S_OK;
    case VT_R4:       return VarI8FromR4(V_R4(ps), &V_I8(pd));
    case VT_R8:       return VarI8FromR8(V_R8(ps), &V_I8(pd));
    case VT_DATE:     return VarI8FromDate(V_DATE(ps), &V_I8(pd));
    case VT_BOOL:     return VarI8FromBool(V_BOOL(ps), &V_I8(pd));
    case VT_CY:       return VarI8FromCy(V_CY(ps), &V_I8(pd));
    case VT_DECIMAL:  return VarI8FromDec(&V_DECIMAL(ps), &V_I8(pd));
    //case VT_DISPATCH: return VarI8FromDisp(V_DISPATCH(ps), lcid, &V_I8(pd));
    case VT_BSTR:     return VarI8FromStr(V_BSTR(ps), lcid, dwFlags, &V_I8(pd));
    }
    break;

  case VT_R4:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_R4(pd) = 0.0f; return S_OK;
    case VT_I1:       return VarR4FromI1(V_I1(ps), &V_R4(pd));
    case VT_I2:       return VarR4FromI2(V_I2(ps), &V_R4(pd));
    case VT_I4:       return VarR4FromI4(V_I4(ps), &V_R4(pd));
    case VT_UI1:      return VarR4FromUI1(V_UI1(ps), &V_R4(pd));
    case VT_UI2:      return VarR4FromUI2(V_UI2(ps), &V_R4(pd));
    case VT_UI4:      return VarR4FromUI4(V_UI4(ps), &V_R4(pd));
    case VT_I8:       return VarR4FromI8(V_I8(ps), &V_R4(pd));
    case VT_UI8:      return VarR4FromUI8(V_UI8(ps), &V_R4(pd));
    case VT_R8:       return VarR4FromR8(V_R8(ps), &V_R4(pd));
    case VT_DATE:     return VarR4FromDate(V_DATE(ps), &V_R4(pd));
    case VT_BOOL:     return VarR4FromBool(V_BOOL(ps), &V_R4(pd));
    case VT_CY:       return VarR4FromCy(V_CY(ps), &V_R4(pd));
    case VT_DECIMAL:  return VarR4FromDec(&V_DECIMAL(ps), &V_R4(pd));
    //case VT_DISPATCH: return VarR4FromDisp(V_DISPATCH(ps), lcid, &V_R4(pd));
    case VT_BSTR:     return VarR4FromStr(V_BSTR(ps), lcid, dwFlags, &V_R4(pd));
    }
    break;

  case VT_R8:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_R8(pd) = 0.0; return S_OK;
    case VT_I1:       return VarR8FromI1(V_I1(ps), &V_R8(pd));
    case VT_I2:       return VarR8FromI2(V_I2(ps), &V_R8(pd));
    case VT_I4:       return VarR8FromI4(V_I4(ps), &V_R8(pd));
    case VT_UI1:      return VarR8FromUI1(V_UI1(ps), &V_R8(pd));
    case VT_UI2:      return VarR8FromUI2(V_UI2(ps), &V_R8(pd));
    case VT_UI4:      return VarR8FromUI4(V_UI4(ps), &V_R8(pd));
    case VT_I8:       return VarR8FromI8(V_I8(ps), &V_R8(pd));
    case VT_UI8:      return VarR8FromUI8(V_UI8(ps), &V_R8(pd));
    case VT_R4:       return VarR8FromR4(V_R4(ps), &V_R8(pd));
    case VT_DATE:     return VarR8FromDate(V_DATE(ps), &V_R8(pd));
    case VT_BOOL:     return VarR8FromBool(V_BOOL(ps), &V_R8(pd));
    case VT_CY:       return VarR8FromCy(V_CY(ps), &V_R8(pd));
    case VT_DECIMAL:  return VarR8FromDec(&V_DECIMAL(ps), &V_R8(pd));
    //case VT_DISPATCH: return VarR8FromDisp(V_DISPATCH(ps), lcid, &V_R8(pd));
    case VT_BSTR:     return VarR8FromStr(V_BSTR(ps), lcid, dwFlags, &V_R8(pd));
    }
    break;

  case VT_DATE:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_DATE(pd) = 0.0; return S_OK;
    case VT_I1:       return VarDateFromI1(V_I1(ps), &V_DATE(pd));
    case VT_I2:       return VarDateFromI2(V_I2(ps), &V_DATE(pd));
    case VT_I4:       return VarDateFromI4(V_I4(ps), &V_DATE(pd));
    case VT_UI1:      return VarDateFromUI1(V_UI1(ps), &V_DATE(pd));
    case VT_UI2:      return VarDateFromUI2(V_UI2(ps), &V_DATE(pd));
    case VT_UI4:      return VarDateFromUI4(V_UI4(ps), &V_DATE(pd));
    case VT_I8:       return VarDateFromI8(V_I8(ps), &V_DATE(pd));
    case VT_UI8:      return VarDateFromUI8(V_UI8(ps), &V_DATE(pd));
    case VT_R4:       return VarDateFromR4(V_R4(ps), &V_DATE(pd));
    case VT_R8:       return VarDateFromR8(V_R8(ps), &V_DATE(pd));
    case VT_BOOL:     return VarDateFromBool(V_BOOL(ps), &V_DATE(pd));
    case VT_CY:       return VarDateFromCy(V_CY(ps), &V_DATE(pd));
    case VT_DECIMAL:  return VarDateFromDec(&V_DECIMAL(ps), &V_DATE(pd));
    //case VT_DISPATCH: return VarDateFromDisp(V_DISPATCH(ps), lcid, &V_DATE(pd));
    case VT_BSTR:     return VarDateFromStr(V_BSTR(ps), lcid, dwFlags, &V_DATE(pd));
    }
    break;

  case VT_BOOL:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_BOOL(pd) = 0; return S_OK;
    case VT_I1:       return VarBoolFromI1(V_I1(ps), &V_BOOL(pd));
    case VT_I2:       return VarBoolFromI2(V_I2(ps), &V_BOOL(pd));
    case VT_I4:       return VarBoolFromI4(V_I4(ps), &V_BOOL(pd));
    case VT_UI1:      return VarBoolFromUI1(V_UI1(ps), &V_BOOL(pd));
    case VT_UI2:      return VarBoolFromUI2(V_UI2(ps), &V_BOOL(pd));
    case VT_UI4:      return VarBoolFromUI4(V_UI4(ps), &V_BOOL(pd));
    case VT_I8:       return VarBoolFromI8(V_I8(ps), &V_BOOL(pd));
    case VT_UI8:      return VarBoolFromUI8(V_UI8(ps), &V_BOOL(pd));
    case VT_R4:       return VarBoolFromR4(V_R4(ps), &V_BOOL(pd));
    case VT_R8:       return VarBoolFromR8(V_R8(ps), &V_BOOL(pd));
    case VT_DATE:     return VarBoolFromDate(V_DATE(ps), &V_BOOL(pd));
    case VT_CY:       return VarBoolFromCy(V_CY(ps), &V_BOOL(pd));
    case VT_DECIMAL:  return VarBoolFromDec(&V_DECIMAL(ps), &V_BOOL(pd));
    //case VT_DISPATCH: return VarBoolFromDisp(V_DISPATCH(ps), lcid, &V_BOOL(pd));
    case VT_BSTR:     return VarBoolFromStr(V_BSTR(ps), lcid, dwFlags, &V_BOOL(pd));
    }
    break;

  case VT_BSTR:
    switch (vtFrom)
    {
    case VT_EMPTY:
      V_BSTR(pd) = SysAllocStringLen(NULL, 0);
      return V_BSTR(pd) ? S_OK : E_OUTOFMEMORY;
    case VT_BOOL:
      if (wFlags & (VARIANT_ALPHABOOL|VARIANT_LOCALBOOL))
         return VarBstrFromBool(V_BOOL(ps), lcid, dwFlags, &V_BSTR(pd));
      return VarBstrFromI2(V_BOOL(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_I1:       return VarBstrFromI1(V_I1(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_I2:       return VarBstrFromI2(V_I2(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_I4:       return VarBstrFromI4(V_I4(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_UI1:      return VarBstrFromUI1(V_UI1(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_UI2:      return VarBstrFromUI2(V_UI2(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_UI4:      return VarBstrFromUI4(V_UI4(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_I8:       return VarBstrFromI8(V_I8(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_UI8:      return VarBstrFromUI8(V_UI8(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_R4:       return VarBstrFromR4(V_R4(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_R8:       return VarBstrFromR8(V_R8(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_DATE:     return VarBstrFromDate(V_DATE(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_CY:       return VarBstrFromCy(V_CY(ps), lcid, dwFlags, &V_BSTR(pd));
    case VT_DECIMAL:  return VarBstrFromDec(&V_DECIMAL(ps), lcid, dwFlags, &V_BSTR(pd));
    //case VT_DISPATCH: return VarBstrFromDisp(V_DISPATCH(ps), lcid, dwFlags, &V_BSTR(pd));
    }
    break;

  case VT_CY:
    switch (vtFrom)
    {
    case VT_EMPTY:    V_CY(pd).int64 = 0; return S_OK;
    case VT_I1:       return VarCyFromI1(V_I1(ps), &V_CY(pd));
    case VT_I2:       return VarCyFromI2(V_I2(ps), &V_CY(pd));
    case VT_I4:       return VarCyFromI4(V_I4(ps), &V_CY(pd));
    case VT_UI1:      return VarCyFromUI1(V_UI1(ps), &V_CY(pd));
    case VT_UI2:      return VarCyFromUI2(V_UI2(ps), &V_CY(pd));
    case VT_UI4:      return VarCyFromUI4(V_UI4(ps), &V_CY(pd));
    case VT_I8:       return VarCyFromI8(V_I8(ps), &V_CY(pd));
    case VT_UI8:      return VarCyFromUI8(V_UI8(ps), &V_CY(pd));
    case VT_R4:       return VarCyFromR4(V_R4(ps), &V_CY(pd));
    case VT_R8:       return VarCyFromR8(V_R8(ps), &V_CY(pd));
    case VT_DATE:     return VarCyFromDate(V_DATE(ps), &V_CY(pd));
    case VT_BOOL:     return VarCyFromBool(V_BOOL(ps), &V_CY(pd));
    case VT_DECIMAL:  return VarCyFromDec(&V_DECIMAL(ps), &V_CY(pd));
    //case VT_DISPATCH: return VarCyFromDisp(V_DISPATCH(ps), lcid, &V_CY(pd));
    case VT_BSTR:     return VarCyFromStr(V_BSTR(ps), lcid, dwFlags, &V_CY(pd));
    }
    break;

  case VT_DECIMAL:
    switch (vtFrom)
    {
    case VT_EMPTY:
    case VT_BOOL:
       DEC_SIGNSCALE(&V_DECIMAL(pd)) = SIGNSCALE(DECIMAL_POS,0);
       DEC_HI32(&V_DECIMAL(pd)) = 0;
       DEC_MID32(&V_DECIMAL(pd)) = 0;
        /* VarDecFromBool() coerces to -1/0, ChangeTypeEx() coerces to 1/0.
         * VT_NULL and VT_EMPTY always give a 0 value.
         */
       DEC_LO32(&V_DECIMAL(pd)) = vtFrom == VT_BOOL && V_BOOL(ps) ? 1 : 0;
       return S_OK;
    case VT_I1:       return VarDecFromI1(V_I1(ps), &V_DECIMAL(pd));
    case VT_I2:       return VarDecFromI2(V_I2(ps), &V_DECIMAL(pd));
    case VT_I4:       return VarDecFromI4(V_I4(ps), &V_DECIMAL(pd));
    case VT_UI1:      return VarDecFromUI1(V_UI1(ps), &V_DECIMAL(pd));
    case VT_UI2:      return VarDecFromUI2(V_UI2(ps), &V_DECIMAL(pd));
    case VT_UI4:      return VarDecFromUI4(V_UI4(ps), &V_DECIMAL(pd));
    case VT_I8:       return VarDecFromI8(V_I8(ps), &V_DECIMAL(pd));
    case VT_UI8:      return VarDecFromUI8(V_UI8(ps), &V_DECIMAL(pd));
    case VT_R4:       return VarDecFromR4(V_R4(ps), &V_DECIMAL(pd));
    case VT_R8:       return VarDecFromR8(V_R8(ps), &V_DECIMAL(pd));
    case VT_DATE:     return VarDecFromDate(V_DATE(ps), &V_DECIMAL(pd));
    case VT_CY:       return VarDecFromCy(V_CY(ps), &V_DECIMAL(pd));
    //case VT_DISPATCH: return VarDecFromDisp(V_DISPATCH(ps), lcid, &V_DECIMAL(pd));
    case VT_BSTR:     return VarDecFromStr(V_BSTR(ps), lcid, dwFlags, &V_DECIMAL(pd));
    }
    break;

  case VT_UNKNOWN:
    switch (vtFrom)
    {
	/*
    case VT_DISPATCH:
      if (V_DISPATCH(ps) == NULL)
        V_UNKNOWN(pd) = NULL;
      else
        res = IDispatch_QueryInterface(V_DISPATCH(ps), &IID_IUnknown, (LPVOID*)&V_UNKNOWN(pd));
      break;
	*/
    }
	
    break;

  case VT_DISPATCH:
    switch (vtFrom)
    {
	/*
    case VT_UNKNOWN:
      if (V_UNKNOWN(ps) == NULL)
        V_DISPATCH(pd) = NULL;
      else
        res = IUnknown_QueryInterface(V_UNKNOWN(ps), &IID_IDispatch, (LPVOID*)&V_DISPATCH(pd));
      break;
	*/
    }
	
    break;

  case VT_RECORD:
    break;
  }
  return res;
}

/* Coerce to/from an array */
static inline HRESULT VARIANT_CoerceArray(VARIANTARG* pd, VARIANTARG* ps, VARTYPE vt)
{
  if (vt == VT_BSTR && V_VT(ps) == (VT_ARRAY|VT_UI1))
    return BstrFromVector(V_ARRAY(ps), &V_BSTR(pd));

  if (V_VT(ps) == VT_BSTR && vt == (VT_ARRAY|VT_UI1))
    return VectorFromBstr(V_BSTR(ps), &V_ARRAY(ps));

  if (V_VT(ps) == vt)
    return SafeArrayCopy(V_ARRAY(ps), &V_ARRAY(pd));

  return DISP_E_TYPEMISMATCH;
}

/******************************************************************************
 * Check if a variants type is valid.
 */
static inline HRESULT VARIANT_ValidateType(VARTYPE vt)
{
  VARTYPE vtExtra = vt & VT_EXTRA_TYPE;

  vt &= VT_TYPEMASK;

  if (!(vtExtra & (VT_VECTOR|VT_RESERVED)))
  {
    if (vt < VT_VOID || vt == VT_RECORD || vt == VT_CLSID)
    {
      if ((vtExtra & (VT_BYREF|VT_ARRAY)) && vt <= VT_NULL)
        return DISP_E_BADVARTYPE;
      if (vt != (VARTYPE)15)
        return S_OK;
    }
  }
  return DISP_E_BADVARTYPE;
}

/******************************************************************************
 *		VariantInit	[OLEAUT32.8]
 *
 * Initialise a variant.
 *
 * PARAMS
 *  pVarg [O] Variant to initialise
 *
 * RETURNS
 *  Nothing.
 *
 * NOTES
 *  This function simply sets the type of the variant to VT_EMPTY. It does not
 *  free any existing value, use VariantClear() for that.
 */
void WINAPI VariantInit(VARIANTARG* pVarg)
{
  TRACE("(%p)\n", pVarg);

  V_VT(pVarg) = VT_EMPTY; /* Native doesn't set any other fields */
}

HRESULT VARIANT_ClearInd(VARIANTARG *pVarg)
{
    HRESULT hres;

    TRACE("(%p->(%s%s))\n", pVarg, debugstr_VT(pVarg), debugstr_VF(pVarg));

    hres = VARIANT_ValidateType(V_VT(pVarg));
    if (FAILED(hres))
        return hres;

    switch (V_VT(pVarg))
    {
    case VT_DISPATCH:
    case VT_UNKNOWN:
        if (V_UNKNOWN(pVarg))
            IUnknown_Release(V_UNKNOWN(pVarg));
        break;
    case VT_UNKNOWN | VT_BYREF:
    case VT_DISPATCH | VT_BYREF:
        if(*V_UNKNOWNREF(pVarg))
            IUnknown_Release(*V_UNKNOWNREF(pVarg));
        break;
    case VT_BSTR:
        SysFreeString(V_BSTR(pVarg));
        break;
    case VT_BSTR | VT_BYREF:
        SysFreeString(*V_BSTRREF(pVarg));
        break;
    case VT_VARIANT | VT_BYREF:
        VariantClear(V_VARIANTREF(pVarg));
        break;
    case VT_RECORD:
    case VT_RECORD | VT_BYREF:
    {
	    // This is not needed with a nameless union
        //struct __tagBRECORD* pBr = &V_UNION(pVarg,brecVal);
        if (pVarg->pRecInfo)
        {
            IRecordInfo_RecordClear(pVarg->pRecInfo, pVarg->pvRecord);
            IRecordInfo_Release(pVarg->pRecInfo);
        }
        break;
    }
    default:
        if (V_ISARRAY(pVarg) || (V_VT(pVarg) & ~VT_BYREF) == VT_SAFEARRAY)
        {
            if (V_ISBYREF(pVarg))
            {
                if (*V_ARRAYREF(pVarg))
                    hres = SafeArrayDestroy(*V_ARRAYREF(pVarg));
            }
            else if (V_ARRAY(pVarg))
                hres = SafeArrayDestroy(V_ARRAY(pVarg));
        }
        break;
    }

    V_VT(pVarg) = VT_EMPTY;
    return hres;
}

/******************************************************************************
 *		VariantClear	[OLEAUT32.9]
 *
 * Clear a variant.
 *
 * PARAMS
 *  pVarg [I/O] Variant to clear
 *
 * RETURNS
 *  Success: S_OK. Any previous value in pVarg is freed and its type is set to VT_EMPTY.
 *  Failure: DISP_E_BADVARTYPE, if the variant is not a valid variant type.
 */
HRESULT WINAPI VariantClear(VARIANTARG* pVarg)
{
  HRESULT hres = S_OK;

  TRACE("(%p->(%s%s))\n", pVarg, debugstr_VT(pVarg), debugstr_VF(pVarg));

  hres = VARIANT_ValidateType(V_VT(pVarg));

  if (SUCCEEDED(hres))
  {
    if (!V_ISBYREF(pVarg))
    {
      if (V_ISARRAY(pVarg) || V_VT(pVarg) == VT_SAFEARRAY)
      {
        if (V_ARRAY(pVarg))
          hres = SafeArrayDestroy(V_ARRAY(pVarg));
      }
      else if (V_VT(pVarg) == VT_BSTR)
      {
        SysFreeString(V_BSTR(pVarg));
      }
      else if (V_VT(pVarg) == VT_RECORD)
      {
	    // not needed with a nameless union
        //struct __tagBRECORD* pBr = &V_UNION(pVarg,brecVal);
        if (pVarg->pRecInfo)
        {
          IRecordInfo_RecordClear(pVarg->pRecInfo, pVarg->pvRecord);
          IRecordInfo_Release(pVarg->pRecInfo);
        }
      }
      else if (V_VT(pVarg) == VT_DISPATCH ||
               V_VT(pVarg) == VT_UNKNOWN)
      {
        if (V_UNKNOWN(pVarg))
          IUnknown_Release(V_UNKNOWN(pVarg));
      }
    }
    V_VT(pVarg) = VT_EMPTY;
  }
  return hres;
}

/******************************************************************************
 * Copy an IRecordInfo object contained in a variant.
 */
//static HRESULT VARIANT_CopyIRecordInfo(struct __tagBRECORD* pBr)
static HRESULT VARIANT_CopyIRecordInfo(VARIANTARG* pBr)
{
  HRESULT hres = S_OK;

  if (pBr->pRecInfo)
  {
    ULONG ulSize;

    hres = IRecordInfo_GetSize(pBr->pRecInfo, &ulSize);
    if (SUCCEEDED(hres))
    {
      PVOID pvRecord = HeapAlloc(GetProcessHeap(), 0, ulSize);
      if (!pvRecord)
        hres = E_OUTOFMEMORY;
      else
      {
        memcpy(pvRecord, pBr->pvRecord, ulSize);
        pBr->pvRecord = pvRecord;

        hres = IRecordInfo_RecordCopy(pBr->pRecInfo, pvRecord, pvRecord);
        if (SUCCEEDED(hres))
          IRecordInfo_AddRef(pBr->pRecInfo);
      }
    }
  }
  else if (pBr->pvRecord)
    hres = E_INVALIDARG;
  return hres;
}

/******************************************************************************
 *    VariantCopy  [OLEAUT32.10]
 *
 * Copy a variant.
 *
 * PARAMS
 *  pvargDest [O] Destination for copy
 *  pvargSrc  [I] Source variant to copy
 *
 * RETURNS
 *  Success: S_OK. pvargDest contains a copy of pvargSrc.
 *  Failure: DISP_E_BADVARTYPE, if either variant has an invalid type.
 *           E_OUTOFMEMORY, if memory cannot be allocated. Otherwise an
 *           HRESULT error code from SafeArrayCopy(), IRecordInfo_GetSize(),
 *           or IRecordInfo_RecordCopy(), depending on the type of pvargSrc.
 *
 * NOTES
 *  - If pvargSrc == pvargDest, this function does nothing, and succeeds if
 *    pvargSrc is valid. Otherwise, pvargDest is always cleared using
 *    VariantClear() before pvargSrc is copied to it. If clearing pvargDest
 *    fails, so does this function.
 *  - VT_CLSID is a valid type type for pvargSrc, but not for pvargDest.
 *  - For by-value non-intrinsic types, a deep copy is made, i.e. The whole value
 *    is copied rather than just any pointers to it.
 *  - For by-value object types the object pointer is copied and the objects
 *    reference count increased using IUnknown_AddRef().
 *  - For all by-reference types, only the referencing pointer is copied.
 */
HRESULT WINAPI VariantCopy(VARIANTARG* pvargDest, VARIANTARG* pvargSrc)
{
  HRESULT hres = S_OK;

  TRACE("(%p->(%s%s),%p->(%s%s))\n", pvargDest, debugstr_VT(pvargDest),
        debugstr_VF(pvargDest), pvargSrc, debugstr_VT(pvargSrc),
        debugstr_VF(pvargSrc));

  if (V_TYPE(pvargSrc) == VT_CLSID || /* VT_CLSID is a special case */
      FAILED(VARIANT_ValidateType(V_VT(pvargSrc))))
    return DISP_E_BADVARTYPE;

  if (pvargSrc != pvargDest &&
      SUCCEEDED(hres = VariantClear(pvargDest)))
  {
    *pvargDest = *pvargSrc; /* Shallow copy the value */

    if (!V_ISBYREF(pvargSrc))
    {
      if (V_ISARRAY(pvargSrc))
      {
        if (V_ARRAY(pvargSrc))
          hres = SafeArrayCopy(V_ARRAY(pvargSrc), &V_ARRAY(pvargDest));
      }
      else if (V_VT(pvargSrc) == VT_BSTR)
      {
        V_BSTR(pvargDest) = SysAllocStringByteLen((char*)V_BSTR(pvargSrc), SysStringByteLen(V_BSTR(pvargSrc)));
        if (!V_BSTR(pvargDest))
	{
	  TRACE("!V_BSTR(pvargDest), SysAllocStringByteLen() failed to allocate %d bytes\n", SysStringByteLen(V_BSTR(pvargSrc)));
          hres = E_OUTOFMEMORY;
	}
      }
      else if (V_VT(pvargSrc) == VT_RECORD)
      {
        //hres = VARIANT_CopyIRecordInfo(&V_UNION(pvargDest,brecVal));
		hres = VARIANT_CopyIRecordInfo(pvargDest);
      }
      else if (V_VT(pvargSrc) == VT_DISPATCH ||
               V_VT(pvargSrc) == VT_UNKNOWN)
      {
        if (V_UNKNOWN(pvargSrc))
          IUnknown_AddRef(V_UNKNOWN(pvargSrc));
      }
    }
  }
  return hres;
}

/* Return the byte size of a variants data */
static inline size_t VARIANT_DataSize(const VARIANT* pv)
{
  switch (V_TYPE(pv))
  {
  case VT_I1:
  case VT_UI1:   return sizeof(BYTE);
  case VT_I2:
  case VT_UI2:   return sizeof(SHORT);
  case VT_INT:
  case VT_UINT:
  case VT_I4:
  case VT_UI4:   return sizeof(LONG);
  case VT_I8:
  case VT_UI8:   return sizeof(LONGLONG);
  case VT_R4:    return sizeof(float);
  case VT_R8:    return sizeof(double);
  case VT_DATE:  return sizeof(DATE);
  case VT_BOOL:  return sizeof(VARIANT_BOOL);
  case VT_DISPATCH:
  case VT_UNKNOWN:
  case VT_BSTR:  return sizeof(void*);
  case VT_CY:    return sizeof(CY);
  case VT_ERROR: return sizeof(SCODE);
  }
  TRACE("Shouldn't be called for vt %s%s!\n", debugstr_VT(pv), debugstr_VF(pv));
  return 0;
}

/******************************************************************************
 *    VariantCopyInd  [OLEAUT32.11]
 *
 * Copy a variant, dereferencing it if it is by-reference.
 *
 * PARAMS
 *  pvargDest [O] Destination for copy
 *  pvargSrc  [I] Source variant to copy
 *
 * RETURNS
 *  Success: S_OK. pvargDest contains a copy of pvargSrc.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  Failure: DISP_E_BADVARTYPE, if either variant has an invalid by-value type.
 *           E_INVALIDARG, if pvargSrc  is an invalid by-reference type.
 *           E_OUTOFMEMORY, if memory cannot be allocated. Otherwise an
 *           HRESULT error code from SafeArrayCopy(), IRecordInfo_GetSize(),
 *           or IRecordInfo_RecordCopy(), depending on the type of pvargSrc.
 *
 * NOTES
 *  - If pvargSrc is by-value, this function behaves exactly as VariantCopy().
 *  - If pvargSrc is by-reference, the value copied to pvargDest is the pointed-to
 *    value.
 *  - if pvargSrc == pvargDest, this function dereferences in place. Otherwise,
 *    pvargDest is always cleared using VariantClear() before pvargSrc is copied
 *    to it. If clearing pvargDest fails, so does this function.
 */
HRESULT WINAPI VariantCopyInd(VARIANT* pvargDest, VARIANTARG* pvargSrc)
{
  VARIANTARG vTmp, *pSrc = pvargSrc;
  VARTYPE vt;
  HRESULT hres = S_OK;

  TRACE("(%p->(%s%s),%p->(%s%s))\n", pvargDest, debugstr_VT(pvargDest),
        debugstr_VF(pvargDest), pvargSrc, debugstr_VT(pvargSrc),
        debugstr_VF(pvargSrc));

  if (!V_ISBYREF(pvargSrc))
    return VariantCopy(pvargDest, pvargSrc);

  /* Argument checking is more lax than VariantCopy()... */
  vt = V_TYPE(pvargSrc);
  if (V_ISARRAY(pvargSrc) ||
     (vt > VT_NULL && vt != (VARTYPE)15 && vt < VT_VOID &&
     !(V_VT(pvargSrc) & (VT_VECTOR|VT_RESERVED))))
  {
    /* OK */
  }
  else
    return E_INVALIDARG; /* ...And the return value for invalid types differs too */

  if (pvargSrc == pvargDest)
  {
    /* In place copy. Use a shallow copy of pvargSrc & init pvargDest.
     * This avoids an expensive VariantCopy() call - e.g. SafeArrayCopy().
     */
    vTmp = *pvargSrc;
    pSrc = &vTmp;
    V_VT(pvargDest) = VT_EMPTY;
  }
  else
  {
    /* Copy into another variant. Free the variant in pvargDest */
    if (FAILED(hres = VariantClear(pvargDest)))
    {
      TRACE("VariantClear() of destination failed\n");
      return hres;
    }
  }

  if (V_ISARRAY(pSrc))
  {
    /* Native doesn't check that *V_ARRAYREF(pSrc) is valid */
    hres = SafeArrayCopy(*V_ARRAYREF(pSrc), &V_ARRAY(pvargDest));
  }
  else if (V_VT(pSrc) == (VT_BSTR|VT_BYREF))
  {
    /* Native doesn't check that *V_BSTRREF(pSrc) is valid */
    V_BSTR(pvargDest) = SysAllocStringByteLen((char*)*V_BSTRREF(pSrc), SysStringByteLen(*V_BSTRREF(pSrc)));
  }
  else if (V_VT(pSrc) == (VT_RECORD|VT_BYREF))
  {
    /*
    V_UNION(pvargDest,brecVal) = V_UNION(pvargSrc,brecVal);
    hres = VARIANT_CopyIRecordInfo(&V_UNION(pvargDest,brecVal));
	*/
	pvargDest->pvRecord = pvargSrc->pvRecord;
	pvargDest->pRecInfo = pvargSrc->pRecInfo;
	hres = VARIANT_CopyIRecordInfo(pvargDest);
  }
  else if (V_VT(pSrc) == (VT_DISPATCH|VT_BYREF) ||
           V_VT(pSrc) == (VT_UNKNOWN|VT_BYREF))
  {
    /* Native doesn't check that *V_UNKNOWNREF(pSrc) is valid */
    V_UNKNOWN(pvargDest) = *V_UNKNOWNREF(pSrc);
    if (*V_UNKNOWNREF(pSrc))
      IUnknown_AddRef(*V_UNKNOWNREF(pSrc));
  }
  else if (V_VT(pSrc) == (VT_VARIANT|VT_BYREF))
  {
    /* Native doesn't check that *V_VARIANTREF(pSrc) is valid */
    if (V_VT(V_VARIANTREF(pSrc)) == (VT_VARIANT|VT_BYREF))
      hres = E_INVALIDARG; /* Don't dereference more than one level */
    else
      hres = VariantCopyInd(pvargDest, V_VARIANTREF(pSrc));

    /* Use the dereferenced variants type value, not VT_VARIANT */
    goto VariantCopyInd_Return;
  }
  else if (V_VT(pSrc) == (VT_DECIMAL|VT_BYREF))
  {
    memcpy(&DEC_SCALE(&V_DECIMAL(pvargDest)), &DEC_SCALE(V_DECIMALREF(pSrc)),
           sizeof(DECIMAL) - sizeof(USHORT));
  }
  else
  {
    /* Copy the pointed to data into this variant */
    memcpy(&V_BYREF(pvargDest), V_BYREF(pSrc), VARIANT_DataSize(pSrc));
  }

  V_VT(pvargDest) = V_VT(pSrc) & ~VT_BYREF;

VariantCopyInd_Return:

  if (pSrc != pvargSrc)
    VariantClear(pSrc);

  TRACE("returning 0x%08x, %p->(%s%s)\n", hres, pvargDest,
        debugstr_VT(pvargDest), debugstr_VF(pvargDest));
  return hres;
}

/******************************************************************************
 *    VariantChangeType  [OLEAUT32.12]
 *
 * Change the type of a variant.
 *
 * PARAMS
 *  pvargDest [O] Destination for the converted variant
 *  pvargSrc  [O] Source variant to change the type of
 *  wFlags    [I] VARIANT_ flags from "oleauto.h"
 *  vt        [I] Variant type to change pvargSrc into
 *
 * RETURNS
 *  Success: S_OK. pvargDest contains the converted value.
 *  Failure: An HRESULT error code describing the failure.
 *
 * NOTES
 *  The LCID used for the conversion is LOCALE_USER_DEFAULT.
 *  See VariantChangeTypeEx.
 */
HRESULT WINAPI VariantChangeType(VARIANTARG* pvargDest, VARIANTARG* pvargSrc,
                                 USHORT wFlags, VARTYPE vt)
{
  return VariantChangeTypeEx( pvargDest, pvargSrc, LOCALE_USER_DEFAULT, wFlags, vt );
}

/******************************************************************************
 *    VariantChangeTypeEx  [OLEAUT32.147]
 *
 * Change the type of a variant.
 *
 * PARAMS
 *  pvargDest [O] Destination for the converted variant
 *  pvargSrc  [O] Source variant to change the type of
 *  lcid      [I] LCID for the conversion
 *  wFlags    [I] VARIANT_ flags from "oleauto.h"
 *  vt        [I] Variant type to change pvargSrc into
 *
 * RETURNS
 *  Success: S_OK. pvargDest contains the converted value.
 *  Failure: An HRESULT error code describing the failure.
 *
 * NOTES
 *  pvargDest and pvargSrc can point to the same variant to perform an in-place
 *  conversion. If the conversion is successful, pvargSrc will be freed.
 */
HRESULT WINAPI VariantChangeTypeEx(VARIANTARG* pvargDest, VARIANTARG* pvargSrc,
                                   LCID lcid, USHORT wFlags, VARTYPE vt)
{
  HRESULT res = S_OK;

  TRACE("(%p->(%s%s),%p->(%s%s),0x%08x,0x%04x,%s%s)\n", pvargDest,
        debugstr_VT(pvargDest), debugstr_VF(pvargDest), pvargSrc,
        debugstr_VT(pvargSrc), debugstr_VF(pvargSrc), lcid, wFlags,
        debugstr_vt(vt), debugstr_vf(vt));

  if (vt == VT_CLSID)
    res = DISP_E_BADVARTYPE;
  else
  {
    res = VARIANT_ValidateType(V_VT(pvargSrc));

    if (SUCCEEDED(res))
    {
      res = VARIANT_ValidateType(vt);

      if (SUCCEEDED(res))
      {
        VARIANTARG vTmp, vSrcDeref;

        if(V_ISBYREF(pvargSrc) && !V_BYREF(pvargSrc))
          res = DISP_E_TYPEMISMATCH;
        else
        {
          V_VT(&vTmp) = VT_EMPTY;
          V_VT(&vSrcDeref) = VT_EMPTY;
          VariantClear(&vTmp);
          VariantClear(&vSrcDeref);
        }

        if (SUCCEEDED(res))
        {
          res = VariantCopyInd(&vSrcDeref, pvargSrc);
          if (SUCCEEDED(res))
          {
            if (V_ISARRAY(&vSrcDeref) || (vt & VT_ARRAY))
              res = VARIANT_CoerceArray(&vTmp, &vSrcDeref, vt);
            else
              res = VARIANT_Coerce(&vTmp, lcid, wFlags, &vSrcDeref, vt);

            if (SUCCEEDED(res)) {
                V_VT(&vTmp) = vt;
                VariantCopy(pvargDest, &vTmp);
            }
            VariantClear(&vTmp);
            VariantClear(&vSrcDeref);
          }
        }
      }
    }
  }

  TRACE("returning 0x%08x, %p->(%s%s)\n", res, pvargDest,
        debugstr_VT(pvargDest), debugstr_VF(pvargDest));
  return res;
}

/* Date Conversions */

#define IsLeapYear(y) (((y % 4) == 0) && (((y % 100) != 0) || ((y % 400) == 0)))

/* Convert a VT_DATE value to a Julian Date */
static inline int VARIANT_JulianFromDate(int dateIn)
{
  int julianDays = dateIn;

  julianDays -= DATE_MIN; /* Convert to + days from 1 Jan 100 AD */
  julianDays += 1757585;  /* Convert to + days from 23 Nov 4713 BC (Julian) */
  return julianDays;
}

/* Convert a Julian Date to a VT_DATE value */
static inline int VARIANT_DateFromJulian(int dateIn)
{
  int julianDays = dateIn;

  julianDays -= 1757585;  /* Convert to + days from 1 Jan 100 AD */
  julianDays += DATE_MIN; /* Convert to +/- days from 1 Jan 1899 AD */
  return julianDays;
}

/* Convert a Julian date to Day/Month/Year - from PostgreSQL */
static inline void VARIANT_DMYFromJulian(int jd, USHORT *year, USHORT *month, USHORT *day)
{
  int j, i, l, n;

  l = jd + 68569;
  n = l * 4 / 146097;
  l -= (n * 146097 + 3) / 4;
  i = (4000 * (l + 1)) / 1461001;
  l += 31 - (i * 1461) / 4;
  j = (l * 80) / 2447;
  *day = l - (j * 2447) / 80;
  l = j / 11;
  *month = (j + 2) - (12 * l);
  *year = 100 * (n - 49) + i + l;
}

/* Convert Day/Month/Year to a Julian date - from PostgreSQL */
static inline double VARIANT_JulianFromDMY(USHORT year, USHORT month, USHORT day)
{
  int m12 = (month - 14) / 12;

  return ((1461 * (year + 4800 + m12)) / 4 + (367 * (month - 2 - 12 * m12)) / 12 -
           (3 * ((year + 4900 + m12) / 100)) / 4 + day - 32075);
}

/* Macros for accessing DOS format date/time fields */
#define DOS_YEAR(x)   (1980 + (x >> 9))
#define DOS_MONTH(x)  ((x >> 5) & 0xf)
#define DOS_DAY(x)    (x & 0x1f)
#define DOS_HOUR(x)   (x >> 11)
#define DOS_MINUTE(x) ((x >> 5) & 0x3f)
#define DOS_SECOND(x) ((x & 0x1f) << 1)
/* Create a DOS format date/time */
#define DOS_DATE(d,m,y) (d | (m << 5) | ((y-1980) << 9))
#define DOS_TIME(h,m,s) ((s >> 1) | (m << 5) | (h << 11))

/* Roll a date forwards or backwards to correct it */
static HRESULT VARIANT_RollUdate(UDATE *lpUd)
{
  static const BYTE days[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
  short iYear, iMonth, iDay, iHour, iMinute, iSecond;

  /* interpret values signed */
  iYear   = lpUd->st.wYear;
  iMonth  = lpUd->st.wMonth;
  iDay    = lpUd->st.wDay;
  iHour   = lpUd->st.wHour;
  iMinute = lpUd->st.wMinute;
  iSecond = lpUd->st.wSecond;

  TRACE("Raw date: %d/%d/%d %d:%d:%d\n", iDay, iMonth,
        iYear, iHour, iMinute, iSecond);

  if (iYear > 9999 || iYear < -9999)
    return E_INVALIDARG; /* Invalid value */
  /* Years < 100 are treated as 1900 + year */
  if (iYear > 0 && iYear < 100)
    iYear += 1900;

  iMinute += iSecond / 60;
  iSecond  = iSecond % 60;
  iHour   += iMinute / 60;
  iMinute  = iMinute % 60;
  iDay    += iHour / 24;
  iHour    = iHour % 24;
  iYear   += iMonth / 12;
  iMonth   = iMonth % 12;
  if (iMonth<=0) {iMonth+=12; iYear--;}
  while (iDay > days[iMonth])
  {
    if (iMonth == 2 && IsLeapYear(iYear))
      iDay -= 29;
    else
      iDay -= days[iMonth];
    iMonth++;
    iYear += iMonth / 12;
    iMonth = iMonth % 12;
  }
  while (iDay <= 0)
  {
    iMonth--;
    if (iMonth<=0) {iMonth+=12; iYear--;}
    if (iMonth == 2 && IsLeapYear(iYear))
      iDay += 29;
    else
      iDay += days[iMonth];
  }

  if (iSecond<0){iSecond+=60; iMinute--;}
  if (iMinute<0){iMinute+=60; iHour--;}
  if (iHour<0)  {iHour+=24; iDay--;}
  if (iYear<=0)  iYear+=2000;

  lpUd->st.wYear   = iYear;
  lpUd->st.wMonth  = iMonth;
  lpUd->st.wDay    = iDay;
  lpUd->st.wHour   = iHour;
  lpUd->st.wMinute = iMinute;
  lpUd->st.wSecond = iSecond;

  TRACE("Rolled date: %d/%d/%d %d:%d:%d\n", lpUd->st.wDay, lpUd->st.wMonth,
        lpUd->st.wYear, lpUd->st.wHour, lpUd->st.wMinute, lpUd->st.wSecond);
  return S_OK;
}

/**********************************************************************
 *              DosDateTimeToVariantTime [OLEAUT32.14]
 *
 * Convert a Dos format date and time into variant VT_DATE format.
 *
 * PARAMS
 *  wDosDate [I] Dos format date
 *  wDosTime [I] Dos format time
 *  pDateOut [O] Destination for VT_DATE format
 *
 * RETURNS
 *  Success: TRUE. pDateOut contains the converted time.
 *  Failure: FALSE, if wDosDate or wDosTime are invalid (see notes).
 *
 * NOTES
 * - Dos format dates can only hold dates from 1-Jan-1980 to 31-Dec-2099.
 * - Dos format times are accurate to only 2 second precision.
 * - The format of a Dos Date is:
 *| Bits   Values  Meaning
 *| ----   ------  -------
 *| 0-4    1-31    Day of the week. 0 rolls back one day. A value greater than
 *|                the days in the month rolls forward the extra days.
 *| 5-8    1-12    Month of the year. 0 rolls back to December of the previous
 *|                year. 13-15 are invalid.
 *| 9-15   0-119   Year based from 1980 (Max 2099). 120-127 are invalid.
 * - The format of a Dos Time is:
 *| Bits   Values  Meaning
 *| ----   ------  -------
 *| 0-4    0-29    Seconds/2. 30 and 31 are invalid.
 *| 5-10   0-59    Minutes. 60-63 are invalid.
 *| 11-15  0-23    Hours (24 hour clock). 24-32 are invalid.
 */
INT WINAPI DosDateTimeToVariantTime(USHORT wDosDate, USHORT wDosTime,
                                    double *pDateOut)
{
  UDATE ud;

  TRACE("(0x%x(%d/%d/%d),0x%x(%d:%d:%d),%p)\n",
        wDosDate, DOS_YEAR(wDosDate), DOS_MONTH(wDosDate), DOS_DAY(wDosDate),
        wDosTime, DOS_HOUR(wDosTime), DOS_MINUTE(wDosTime), DOS_SECOND(wDosTime),
        pDateOut);

  ud.st.wYear = DOS_YEAR(wDosDate);
  ud.st.wMonth = DOS_MONTH(wDosDate);
  if (ud.st.wYear > 2099 || ud.st.wMonth > 12)
    return FALSE;
  ud.st.wDay = DOS_DAY(wDosDate);
  ud.st.wHour = DOS_HOUR(wDosTime);
  ud.st.wMinute = DOS_MINUTE(wDosTime);
  ud.st.wSecond = DOS_SECOND(wDosTime);
  ud.st.wDayOfWeek = ud.st.wMilliseconds = 0;
  if (ud.st.wHour > 23 || ud.st.wMinute > 59 || ud.st.wSecond > 59)
    return FALSE; /* Invalid values in Dos*/

  return VarDateFromUdate(&ud, 0, pDateOut) == S_OK;
}

/**********************************************************************
 *              VariantTimeToDosDateTime [OLEAUT32.13]
 *
 * Convert a variant format date into a Dos format date and time.
 *
 *  dateIn    [I] VT_DATE time format
 *  pwDosDate [O] Destination for Dos format date
 *  pwDosTime [O] Destination for Dos format time
 *
 * RETURNS
 *  Success: TRUE. pwDosDate and pwDosTime contains the converted values.
 *  Failure: FALSE, if dateIn cannot be represented in Dos format.
 *
 * NOTES
 *   See DosDateTimeToVariantTime() for Dos format details and bugs.
 */
INT WINAPI VariantTimeToDosDateTime(double dateIn, USHORT *pwDosDate, USHORT *pwDosTime)
{
  UDATE ud;

  TRACE("(%g,%p,%p)\n", dateIn, pwDosDate, pwDosTime);

  if (FAILED(VarUdateFromDate(dateIn, 0, &ud)))
    return FALSE;

  if (ud.st.wYear < 1980 || ud.st.wYear > 2099)
    return FALSE;

  *pwDosDate = DOS_DATE(ud.st.wDay, ud.st.wMonth, ud.st.wYear);
  *pwDosTime = DOS_TIME(ud.st.wHour, ud.st.wMinute, ud.st.wSecond);

  TRACE("Returning 0x%x(%d/%d/%d), 0x%x(%d:%d:%d)\n",
        *pwDosDate, DOS_YEAR(*pwDosDate), DOS_MONTH(*pwDosDate), DOS_DAY(*pwDosDate),
        *pwDosTime, DOS_HOUR(*pwDosTime), DOS_MINUTE(*pwDosTime), DOS_SECOND(*pwDosTime));
  return TRUE;
}

/***********************************************************************
 *              SystemTimeToVariantTime [OLEAUT32.184]
 *
 * Convert a System format date and time into variant VT_DATE format.
 *
 * PARAMS
 *  lpSt     [I] System format date and time
 *  pDateOut [O] Destination for VT_DATE format date
 *
 * RETURNS
 *  Success: TRUE. *pDateOut contains the converted value.
 *  Failure: FALSE, if lpSt cannot be represented in VT_DATE format.
 */
INT WINAPI SystemTimeToVariantTime(LPSYSTEMTIME lpSt, double *pDateOut)
{
  UDATE ud;

  TRACE("(%p->%d/%d/%d %d:%d:%d,%p)\n", lpSt, lpSt->wDay, lpSt->wMonth,
        lpSt->wYear, lpSt->wHour, lpSt->wMinute, lpSt->wSecond, pDateOut);

  if (lpSt->wMonth > 12)
    return FALSE;

  ud.st = *lpSt;
  return VarDateFromUdate(&ud, 0, pDateOut) == S_OK;
}

/***********************************************************************
 *              VariantTimeToSystemTime [OLEAUT32.185]
 *
 * Convert a variant VT_DATE into a System format date and time.
 *
 * PARAMS
 *  datein [I] Variant VT_DATE format date
 *  lpSt   [O] Destination for System format date and time
 *
 * RETURNS
 *  Success: TRUE. *lpSt contains the converted value.
 *  Failure: FALSE, if dateIn is too large or small.
 */
INT WINAPI VariantTimeToSystemTime(double dateIn, LPSYSTEMTIME lpSt)
{
  UDATE ud;

  TRACE("(%g,%p)\n", dateIn, lpSt);

  if (FAILED(VarUdateFromDate(dateIn, 0, &ud)))
    return FALSE;

  *lpSt = ud.st;
  return TRUE;
}

/***********************************************************************
 *              VarDateFromUdateEx [OLEAUT32.319]
 *
 * Convert an unpacked format date and time to a variant VT_DATE.
 *
 * PARAMS
 *  pUdateIn [I] Unpacked format date and time to convert
 *  lcid     [I] Locale identifier for the conversion
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pDateOut [O] Destination for variant VT_DATE.
 *
 * RETURNS
 *  Success: S_OK. *pDateOut contains the converted value.
 *  Failure: E_INVALIDARG, if pUdateIn cannot be represented in VT_DATE format.
 */
HRESULT WINAPI VarDateFromUdateEx(UDATE *pUdateIn, LCID lcid, ULONG dwFlags, DATE *pDateOut)
{
  UDATE ud;
  double dateVal;

  TRACE("(%p->%d/%d/%d %d:%d:%d:%d %d %d,0x%08x,0x%08x,%p)\n", pUdateIn,
        pUdateIn->st.wMonth, pUdateIn->st.wDay, pUdateIn->st.wYear,
        pUdateIn->st.wHour, pUdateIn->st.wMinute, pUdateIn->st.wSecond,
        pUdateIn->st.wMilliseconds, pUdateIn->st.wDayOfWeek,
        pUdateIn->wDayOfYear, lcid, dwFlags, pDateOut);

  if (lcid != MAKELCID(MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US), SORT_DEFAULT))
    //FixMe("lcid possibly not handled, treating as en-us\n");

  // Manually copy data here because ud = *pUdateIn fill ud incorrectly
  ud.st.wYear = pUdateIn->st.wYear;
  ud.st.wMonth = pUdateIn->st.wMonth;
  ud.st.wDay = pUdateIn->st.wDay;
  ud.st.wHour = pUdateIn->st.wHour;
  ud.st.wMinute = pUdateIn->st.wMinute;
  ud.st.wSecond = pUdateIn->st.wSecond;
  ud.st.wMilliseconds = pUdateIn->st.wMilliseconds;
  ud.st.wDayOfWeek = pUdateIn->st.wDayOfWeek;
  ud.wDayOfYear = pUdateIn->wDayOfYear;

  if (dwFlags & VAR_VALIDDATE)
    WARN("Ignoring VAR_VALIDDATE\n");

  if (FAILED(VARIANT_RollUdate(&ud)))
    return E_INVALIDARG;

  /* Date */
  dateVal = VARIANT_DateFromJulian((int)VARIANT_JulianFromDMY(ud.st.wYear, ud.st.wMonth, ud.st.wDay));

  /* Time */
  dateVal += ud.st.wHour / 24.0;
  dateVal += ud.st.wMinute / 1440.0;
  dateVal += ud.st.wSecond / 86400.0;

  TRACE("Returning %g\n", dateVal);
  *pDateOut = dateVal;
  return S_OK;
}

/***********************************************************************
 *              VarDateFromUdate [OLEAUT32.330]
 *
 * Convert an unpacked format date and time to a variant VT_DATE.
 *
 * PARAMS
 *  pUdateIn [I] Unpacked format date and time to convert
 *  dwFlags  [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  pDateOut [O] Destination for variant VT_DATE.
 *
 * RETURNS
 *  Success: S_OK. *pDateOut contains the converted value.
 *  Failure: E_INVALIDARG, if pUdateIn cannot be represented in VT_DATE format.
 *
 * NOTES
 *  This function uses the United States English locale for the conversion. Use
 *  VarDateFromUdateEx() for alternate locales.
 */
HRESULT WINAPI VarDateFromUdate(UDATE *pUdateIn, ULONG dwFlags, DATE *pDateOut)
{
  LCID lcid = MAKELCID(MAKELANGID(LANG_ENGLISH, SUBLANG_ENGLISH_US), SORT_DEFAULT);
  
  return VarDateFromUdateEx(pUdateIn, lcid, dwFlags, pDateOut);
}

/***********************************************************************
 *              VarUdateFromDate [OLEAUT32.331]
 *
 * Convert a variant VT_DATE into an unpacked format date and time.
 *
 * PARAMS
 *  datein    [I] Variant VT_DATE format date
 *  dwFlags   [I] Flags controlling the conversion (VAR_ flags from "oleauto.h")
 *  lpUdate   [O] Destination for unpacked format date and time
 *
 * RETURNS
 *  Success: S_OK. *lpUdate contains the converted value.
 *  Failure: E_INVALIDARG, if dateIn is too large or small.
 */
HRESULT WINAPI VarUdateFromDate(DATE dateIn, ULONG dwFlags, UDATE *lpUdate)
{
  /* Cumulative totals of days per month */
  static const USHORT cumulativeDays[] =
  {
    0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334
  };
  double datePart, timePart;
  int julianDays;

  TRACE("(%g,0x%08x,%p)\n", dateIn, dwFlags, lpUdate);

  if (dateIn <= (DATE_MIN - 1.0) || dateIn >= (DATE_MAX + 1.0))
    return E_INVALIDARG;

  datePart = dateIn < 0.0 ? ceil(dateIn) : floor(dateIn);
  /* Compensate for int truncation (always downwards) */
  timePart = dateIn - datePart + 0.00000000001;
  if (timePart >= 1.0)
    timePart -= 0.00000000001;

  /* Date */
  julianDays = VARIANT_JulianFromDate((int)dateIn);
  VARIANT_DMYFromJulian(julianDays, &lpUdate->st.wYear, &lpUdate->st.wMonth,
                        &lpUdate->st.wDay);

  datePart = (datePart + 1.5) / 7.0;
  lpUdate->st.wDayOfWeek = (WORD)((datePart - floor(datePart)) * 7);
  if (lpUdate->st.wDayOfWeek == 0)
    lpUdate->st.wDayOfWeek = 5;
  else if (lpUdate->st.wDayOfWeek == 1)
    lpUdate->st.wDayOfWeek = 6;
  else
    lpUdate->st.wDayOfWeek -= 2;

  if (lpUdate->st.wMonth > 2 && IsLeapYear(lpUdate->st.wYear))
    lpUdate->wDayOfYear = 1; /* After February, in a leap year */
  else
    lpUdate->wDayOfYear = 0;

  lpUdate->wDayOfYear += cumulativeDays[lpUdate->st.wMonth];
  lpUdate->wDayOfYear += lpUdate->st.wDay;

  /* Time */
  timePart *= 24.0;
  lpUdate->st.wHour = (WORD)timePart;
  timePart -= lpUdate->st.wHour;
  timePart *= 60.0;
  lpUdate->st.wMinute = (WORD)timePart;
  timePart -= lpUdate->st.wMinute;
  timePart *= 60.0;
  lpUdate->st.wSecond = (WORD)timePart;
  timePart -= lpUdate->st.wSecond;
  lpUdate->st.wMilliseconds = 0;
  if (timePart > 0.5)
  {
    /* Round the milliseconds, adjusting the time/date forward if needed */
    if (lpUdate->st.wSecond < 59)
      lpUdate->st.wSecond++;
    else
    {
      lpUdate->st.wSecond = 0;
      if (lpUdate->st.wMinute < 59)
        lpUdate->st.wMinute++;
      else
      {
        lpUdate->st.wMinute = 0;
        if (lpUdate->st.wHour < 23)
          lpUdate->st.wHour++;
        else
        {
          lpUdate->st.wHour = 0;
          /* Roll over a whole day */
          if (++lpUdate->st.wDay > 28)
            VARIANT_RollUdate(lpUdate);
        }
      }
    }
  }
  return S_OK;
}

#define GET_NUMBER_TEXT(fld,name) \
  buff[0] = 0; \
  if (!GetLocaleInfoW(lcid, lctype|fld, buff, 2)) \
    WARN("buffer too small for " #fld "\n"); \
  else \
    if (buff[0]) lpChars->name = buff[0]; \
  TRACE("lcid 0x%x, " #name "=%d '%c'\n", lcid, lpChars->name, lpChars->name)

/* Get the valid number characters for an lcid */
static void VARIANT_GetLocalisedNumberChars(VARIANT_NUMBER_CHARS *lpChars, LCID lcid, DWORD dwFlags)
{
  static const VARIANT_NUMBER_CHARS defaultChars = { '-','+','.',',','$',0,'.',',' };
  //static CRITICAL_SECTION csLastChars = { NULL, -1, 0, 0, 0, 0 };
  static CRITICAL_SECTION csLastChars;
  InitializeCriticalSection(&csLastChars);
  static VARIANT_NUMBER_CHARS lastChars;
  static LCID lastLcid = (LCID)-1;
  static DWORD lastFlags = 0;
  LCTYPE lctype = dwFlags & LOCALE_NOUSEROVERRIDE;
  WCHAR buff[4];
  
  /* To make caching thread-safe, a critical section is needed */
  EnterCriticalSection(&csLastChars);

  /* Asking for default locale entries is very expensive: It is a registry
     server call. So cache one locally, as Microsoft does it too */
  if(lcid == lastLcid && dwFlags == lastFlags)
  {
    memcpy(lpChars, &lastChars, sizeof(defaultChars));
    LeaveCriticalSection(&csLastChars);
    return;
  }

  memcpy(lpChars, &defaultChars, sizeof(defaultChars));
  GET_NUMBER_TEXT(LOCALE_SNEGATIVESIGN, cNegativeSymbol);
  GET_NUMBER_TEXT(LOCALE_SPOSITIVESIGN, cPositiveSymbol);
  GET_NUMBER_TEXT(LOCALE_SDECIMAL, cDecimalPoint);
  GET_NUMBER_TEXT(LOCALE_STHOUSAND, cDigitSeparator);
  GET_NUMBER_TEXT(LOCALE_SMONDECIMALSEP, cCurrencyDecimalPoint);
  GET_NUMBER_TEXT(LOCALE_SMONTHOUSANDSEP, cCurrencyDigitSeparator);
    
  /* Local currency symbols are often 2 characters */
  lpChars->cCurrencyLocal2 = '\0';
  switch(GetLocaleInfoW(lcid, lctype|LOCALE_SCURRENCY, buff, sizeof(buff)/sizeof(WCHAR)))
  {
    case 3: lpChars->cCurrencyLocal2 = buff[1]; // Fall through
    case 2: lpChars->cCurrencyLocal  = buff[0];
            break;
    default: WARN("buffer too small for LOCALE_SCURRENCY\n");
  }
  TRACE("lcid 0x%x, cCurrencyLocal =%d,%d '%c','%c'\n", lcid, lpChars->cCurrencyLocal,
        lpChars->cCurrencyLocal2, lpChars->cCurrencyLocal, lpChars->cCurrencyLocal2);

  memcpy(&lastChars, lpChars, sizeof(defaultChars));
  lastLcid = lcid;
  lastFlags = dwFlags;
  LeaveCriticalSection(&csLastChars);
}

/* Number Parsing States */
#define B_PROCESSING_EXPONENT 0x1
#define B_NEGATIVE_EXPONENT   0x2
#define B_EXPONENT_START      0x4
#define B_INEXACT_ZEROS       0x8
#define B_LEADING_ZERO        0x10
#define B_PROCESSING_HEX      0x20
#define B_PROCESSING_OCT      0x40

/**********************************************************************
 *              VarParseNumFromStr [OLEAUT32.46]
 *
 * Parse a string containing a number into a NUMPARSE structure.
 *
 * PARAMS
 *  lpszStr [I]   String to parse number from
 *  lcid    [I]   Locale Id for the conversion
 *  dwFlags [I]   0, or LOCALE_NOUSEROVERRIDE to use system default number chars
 *  pNumprs [I/O] Destination for parsed number
 *  rgbDig  [O]   Destination for digits read in
 *
 * RETURNS
 *  Success: S_OK. pNumprs and rgbDig contain the parsed representation of
 *           the number.
 *  Failure: E_INVALIDARG, if any parameter is invalid.
 *           DISP_E_TYPEMISMATCH, if the string is not a number or is formatted
 *           incorrectly.
 *           DISP_E_OVERFLOW, if rgbDig is too small to hold the number.
 *
 * NOTES
 *  pNumprs must have the following fields set:
 *   cDig: Set to the size of rgbDig.
 *   dwInFlags: Set to the allowable syntax of the number using NUMPRS_ flags
 *            from "oleauto.h".
 *
 * //FixMe
 *  - I am unsure if this function should parse non-arabic (e.g. Thai)
 *   numerals, so this has not been implemented.
 */
HRESULT WINAPI VarParseNumFromStr(OLECHAR *lpszStr, LCID lcid, ULONG dwFlags,
                                  NUMPARSE *pNumprs, BYTE *rgbDig)
{
  VARIANT_NUMBER_CHARS chars;
  BYTE rgbTmp[1024];
  DWORD dwState = B_EXPONENT_START|B_INEXACT_ZEROS;
  int iMaxDigits = sizeof(rgbTmp) / sizeof(BYTE);
  int cchUsed = 0;

  TRACE("(%s,%d,0x%08x,%p,%p)\n", debugstr_w(lpszStr), lcid, dwFlags, pNumprs, rgbDig);

  if (!pNumprs || !rgbDig)
    return E_INVALIDARG;

  if (pNumprs->cDig < iMaxDigits)
    iMaxDigits = pNumprs->cDig;

  pNumprs->cDig = 0;
  pNumprs->dwOutFlags = 0;
  pNumprs->cchUsed = 0;
  pNumprs->nBaseShift = 0;
  pNumprs->nPwr10 = 0;

  if (!lpszStr)
    return DISP_E_TYPEMISMATCH;

  VARIANT_GetLocalisedNumberChars(&chars, lcid, dwFlags);

  /* First consume all the leading symbols and space from the string */
  while (1)
  {
    if (pNumprs->dwInFlags & NUMPRS_LEADING_WHITE && isspaceW(*lpszStr))
    {
      pNumprs->dwOutFlags |= NUMPRS_LEADING_WHITE;
      do
      {
        cchUsed++;
        lpszStr++;
      } while (isspaceW(*lpszStr));
    }
    else if (pNumprs->dwInFlags & NUMPRS_LEADING_PLUS &&
             *lpszStr == chars.cPositiveSymbol &&
             !(pNumprs->dwOutFlags & NUMPRS_LEADING_PLUS))
    {
      pNumprs->dwOutFlags |= NUMPRS_LEADING_PLUS;
      cchUsed++;
      lpszStr++;
    }
    else if (pNumprs->dwInFlags & NUMPRS_LEADING_MINUS &&
             *lpszStr == chars.cNegativeSymbol &&
             !(pNumprs->dwOutFlags & NUMPRS_LEADING_MINUS))
    {
      pNumprs->dwOutFlags |= (NUMPRS_LEADING_MINUS|NUMPRS_NEG);
      cchUsed++;
      lpszStr++;
    }
    else if (pNumprs->dwInFlags & NUMPRS_CURRENCY &&
             !(pNumprs->dwOutFlags & NUMPRS_CURRENCY) &&
             *lpszStr == chars.cCurrencyLocal &&
             (!chars.cCurrencyLocal2 || lpszStr[1] == chars.cCurrencyLocal2))
    {
      pNumprs->dwOutFlags |= NUMPRS_CURRENCY;
      cchUsed++;
      lpszStr++;
      /* Only accept currency characters */
      chars.cDecimalPoint = chars.cCurrencyDecimalPoint;
      chars.cDigitSeparator = chars.cCurrencyDigitSeparator;
    }
    else if (pNumprs->dwInFlags & NUMPRS_PARENS && *lpszStr == '(' &&
             !(pNumprs->dwOutFlags & NUMPRS_PARENS))
    {
      pNumprs->dwOutFlags |= NUMPRS_PARENS;
      cchUsed++;
      lpszStr++;
    }
    else
      break;
  }

  if (!(pNumprs->dwOutFlags & NUMPRS_CURRENCY))
  {
    /* Only accept non-currency characters */
    chars.cCurrencyDecimalPoint = chars.cDecimalPoint;
    chars.cCurrencyDigitSeparator = chars.cDigitSeparator;
  }

  if ((*lpszStr == '&' && (*(lpszStr+1) == 'H' || *(lpszStr+1) == 'h')) &&
    pNumprs->dwInFlags & NUMPRS_HEX_OCT)
  {
      dwState |= B_PROCESSING_HEX;
      pNumprs->dwOutFlags |= NUMPRS_HEX_OCT;
      cchUsed=cchUsed+2;
      lpszStr=lpszStr+2;
  }
  else if ((*lpszStr == '&' && (*(lpszStr+1) == 'O' || *(lpszStr+1) == 'o')) &&
    pNumprs->dwInFlags & NUMPRS_HEX_OCT)
  {
      dwState |= B_PROCESSING_OCT;
      pNumprs->dwOutFlags |= NUMPRS_HEX_OCT;
      cchUsed=cchUsed+2;
      lpszStr=lpszStr+2;
  }

  /* Strip Leading zeros */
  while (*lpszStr == '0')
  {
    dwState |= B_LEADING_ZERO;
    cchUsed++;
    lpszStr++;
  }

  while (*lpszStr)
  {
    if (isdigitW(*lpszStr))
    {
      if (dwState & B_PROCESSING_EXPONENT)
      {
        int exponentSize = 0;
        if (dwState & B_EXPONENT_START)
        {
          if (!isdigitW(*lpszStr))
            break; /* No exponent digits - invalid */
          while (*lpszStr == '0')
          {
            /* Skip leading zero's in the exponent */
            cchUsed++;
            lpszStr++;
          }
        }

        while (isdigitW(*lpszStr))
        {
          exponentSize *= 10;
          exponentSize += *lpszStr - '0';
          cchUsed++;
          lpszStr++;
        }
        if (dwState & B_NEGATIVE_EXPONENT)
          exponentSize = -exponentSize;
        /* Add the exponent into the powers of 10 */
        pNumprs->nPwr10 += exponentSize;
        dwState &= ~(B_PROCESSING_EXPONENT|B_EXPONENT_START);
        lpszStr--; /* back up to allow processing of next char */
      }
      else
      {
        if ((pNumprs->cDig >= iMaxDigits) && !(dwState & B_PROCESSING_HEX)
          && !(dwState & B_PROCESSING_OCT))
        {
          pNumprs->dwOutFlags |= NUMPRS_INEXACT;

          if (*lpszStr != '0')
            dwState &= ~B_INEXACT_ZEROS; /* Inexact number with non-trailing zeros */

          /* This digit can't be represented, but count it in nPwr10 */
          if (pNumprs->dwOutFlags & NUMPRS_DECIMAL)
            pNumprs->nPwr10--;
          else
            pNumprs->nPwr10++;
        }
        else
        {
          if ((dwState & B_PROCESSING_OCT) && ((*lpszStr == '8') || (*lpszStr == '9'))) {
            return DISP_E_TYPEMISMATCH;
          }

          if (pNumprs->dwOutFlags & NUMPRS_DECIMAL)
            pNumprs->nPwr10--; /* Count decimal points in nPwr10 */

          rgbTmp[pNumprs->cDig] = *lpszStr - '0';
        }
        pNumprs->cDig++;
        cchUsed++;
      }
    }
    else if (*lpszStr == chars.cDigitSeparator && pNumprs->dwInFlags & NUMPRS_THOUSANDS)
    {
      pNumprs->dwOutFlags |= NUMPRS_THOUSANDS;
      cchUsed++;
    }
    else if (*lpszStr == chars.cDecimalPoint &&
             pNumprs->dwInFlags & NUMPRS_DECIMAL &&
             !(pNumprs->dwOutFlags & (NUMPRS_DECIMAL|NUMPRS_EXPONENT)))
    {
      pNumprs->dwOutFlags |= NUMPRS_DECIMAL;
      cchUsed++;

      /* If we have no digits so far, skip leading zeros */
      if (!pNumprs->cDig)
      {
        while (lpszStr[1] == '0')
        {
          dwState |= B_LEADING_ZERO;
          cchUsed++;
          lpszStr++;
          pNumprs->nPwr10--;
        }
      }
    }
    else if (((*lpszStr >= 'a' && *lpszStr <= 'f') ||
             (*lpszStr >= 'A' && *lpszStr <= 'F')) &&
             dwState & B_PROCESSING_HEX)
    {
      if (pNumprs->cDig >= iMaxDigits)
      {
        return DISP_E_OVERFLOW;
      }
      else
      {
        if (*lpszStr >= 'a')
          rgbTmp[pNumprs->cDig] = *lpszStr - 'a' + 10;
        else
          rgbTmp[pNumprs->cDig] = *lpszStr - 'A' + 10;
      }
      pNumprs->cDig++;
      cchUsed++;
    }
    else if ((*lpszStr == 'e' || *lpszStr == 'E') &&
             pNumprs->dwInFlags & NUMPRS_EXPONENT &&
             !(pNumprs->dwOutFlags & NUMPRS_EXPONENT))
    {
      dwState |= B_PROCESSING_EXPONENT;
      pNumprs->dwOutFlags |= NUMPRS_EXPONENT;
      cchUsed++;
    }
    else if (dwState & B_PROCESSING_EXPONENT && *lpszStr == chars.cPositiveSymbol)
    {
      cchUsed++; /* Ignore positive exponent */
    }
    else if (dwState & B_PROCESSING_EXPONENT && *lpszStr == chars.cNegativeSymbol)
    {
      dwState |= B_NEGATIVE_EXPONENT;
      cchUsed++;
    }
    else
      break; /* Stop at an unrecognised character */

    lpszStr++;
  }

  if (!pNumprs->cDig && dwState & B_LEADING_ZERO)
  {
    /* Ensure a 0 on its own gets stored */
    pNumprs->cDig = 1;
    rgbTmp[0] = 0;
  }

  if (pNumprs->dwOutFlags & NUMPRS_EXPONENT && dwState & B_PROCESSING_EXPONENT)
  {
    pNumprs->cchUsed = cchUsed;
    WARN("didn't completely parse exponent\n");
    return DISP_E_TYPEMISMATCH; /* Failed to completely parse the exponent */
  }

  if (pNumprs->dwOutFlags & NUMPRS_INEXACT)
  {
    if (dwState & B_INEXACT_ZEROS)
      pNumprs->dwOutFlags &= ~NUMPRS_INEXACT; /* All zeros doesn't set NUMPRS_INEXACT */
  } else if(pNumprs->dwInFlags & NUMPRS_HEX_OCT)
  {
    /* copy all of the digits into the output digit buffer */
    /* this is exactly what windows does although it also returns */
    /* cDig of X and writes X+Y where Y>=0 number of digits to rgbDig */
    memcpy(rgbDig, rgbTmp, pNumprs->cDig * sizeof(BYTE));

    if (dwState & B_PROCESSING_HEX) {
      /* hex numbers have always the same format */
      pNumprs->nPwr10=0;
      pNumprs->nBaseShift=4;
    } else {
      if (dwState & B_PROCESSING_OCT) {
        /* oct numbers have always the same format */
        pNumprs->nPwr10=0;
        pNumprs->nBaseShift=3;
      } else {
        while (pNumprs->cDig > 1 && !rgbTmp[pNumprs->cDig - 1])
        {
          pNumprs->nPwr10++;
          pNumprs->cDig--;
        }
      }
    }
  } else
  {
    /* Remove trailing zeros from the last (whole number or decimal) part */
    while (pNumprs->cDig > 1 && !rgbTmp[pNumprs->cDig - 1])
    {
      pNumprs->nPwr10++;
      pNumprs->cDig--;
    }
  }

  if (pNumprs->cDig <= iMaxDigits)
    pNumprs->dwOutFlags &= ~NUMPRS_INEXACT; /* Ignore stripped zeros for NUMPRS_INEXACT */
  else
    pNumprs->cDig = iMaxDigits; /* Only return iMaxDigits worth of digits */

  /* Copy the digits we processed into rgbDig */
  memcpy(rgbDig, rgbTmp, pNumprs->cDig * sizeof(BYTE));

  /* Consume any trailing symbols and space */
  while (1)
  {
    if ((pNumprs->dwInFlags & NUMPRS_TRAILING_WHITE) && isspaceW(*lpszStr))
    {
      pNumprs->dwOutFlags |= NUMPRS_TRAILING_WHITE;
      do
      {
        cchUsed++;
        lpszStr++;
      } while (isspaceW(*lpszStr));
    }
    else if (pNumprs->dwInFlags & NUMPRS_TRAILING_PLUS &&
             !(pNumprs->dwOutFlags & NUMPRS_LEADING_PLUS) &&
             *lpszStr == chars.cPositiveSymbol)
    {
      pNumprs->dwOutFlags |= NUMPRS_TRAILING_PLUS;
      cchUsed++;
      lpszStr++;
    }
    else if (pNumprs->dwInFlags & NUMPRS_TRAILING_MINUS &&
             !(pNumprs->dwOutFlags & NUMPRS_LEADING_MINUS) &&
             *lpszStr == chars.cNegativeSymbol)
    {
      pNumprs->dwOutFlags |= (NUMPRS_TRAILING_MINUS|NUMPRS_NEG);
      cchUsed++;
      lpszStr++;
    }
    else if (pNumprs->dwInFlags & NUMPRS_PARENS && *lpszStr == ')' &&
             pNumprs->dwOutFlags & NUMPRS_PARENS)
    {
      cchUsed++;
      lpszStr++;
      pNumprs->dwOutFlags |= NUMPRS_NEG;
    }
    else
      break;
  }

  if (pNumprs->dwOutFlags & NUMPRS_PARENS && !(pNumprs->dwOutFlags & NUMPRS_NEG))
  {
    pNumprs->cchUsed = cchUsed;
    return DISP_E_TYPEMISMATCH; /* Opening parenthesis not matched */
  }

  if (pNumprs->dwInFlags & NUMPRS_USE_ALL && *lpszStr != '\0')
    return DISP_E_TYPEMISMATCH; /* Not all chars were consumed */

  if (!pNumprs->cDig)
    return DISP_E_TYPEMISMATCH; /* No Number found */

  pNumprs->cchUsed = cchUsed;
  return S_OK;
}

/* VTBIT flags indicating an integer value */
#define INTEGER_VTBITS (VTBIT_I1|VTBIT_UI1|VTBIT_I2|VTBIT_UI2|VTBIT_I4|VTBIT_UI4|VTBIT_I8|VTBIT_UI8)
/* VTBIT flags indicating a real number value */
#define REAL_VTBITS (VTBIT_R4|VTBIT_R8|VTBIT_CY)

/* Helper macros to check whether bit pattern fits in VARIANT (x is a ULONG64 ) */
#define FITS_AS_I1(x) ((x) >> 8 == 0)
#define FITS_AS_I2(x) ((x) >> 16 == 0)
#define FITS_AS_I4(x) ((x) >> 32 == 0)

/**********************************************************************
 *              VarNumFromParseNum [OLEAUT32.47]
 *
 * Convert a NUMPARSE structure into a numeric Variant type.
 *
 * PARAMS
 *  pNumprs  [I] Source for parsed number. cDig must be set to the size of rgbDig
 *  rgbDig   [I] Source for the numbers digits
 *  dwVtBits [I] VTBIT_ flags from "oleauto.h" indicating the acceptable dest types
 *  pVarDst  [O] Destination for the converted Variant value.
 *
 * RETURNS
 *  Success: S_OK. pVarDst contains the converted value.
 *  Failure: E_INVALIDARG, if any parameter is invalid.
 *           DISP_E_OVERFLOW, if the number is too big for the types set in dwVtBits.
 *
 * NOTES
 *  - The smallest favoured type present in dwVtBits that can represent the
 *    number in pNumprs without losing precision is used.
 *  - Signed types are preferred over unsigned types of the same size.
 *  - Preferred types in order are: integer, float, double, currency then decimal.
 *  - Rounding (dropping of decimal points) occurs without error. See VarI8FromR8()
 *    for details of the rounding method.
 *  - pVarDst is not cleared before the result is stored in it.
 *  - WinXP and Win2003 support VTBIT_I8, VTBIT_UI8 but that's buggy (by
 *    design?): If some other VTBIT's for integers are specified together
 *    with VTBIT_I8 and the number will fit only in a VT_I8 Windows will "cast"
 *    the number to the smallest requested integer truncating this way the
 *    number.  Wine doesn't implement this "feature" (yet?).
 */
HRESULT WINAPI VarNumFromParseNum(NUMPARSE *pNumprs, BYTE *rgbDig,
                                  ULONG dwVtBits, VARIANT *pVarDst)
{
  /* Scale factors and limits for double arithmetic */
  static const double dblMultipliers[11] = {
    1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0,
    1000000.0, 10000000.0, 100000000.0, 1000000000.0, 10000000000.0
  };
  static const double dblMinimums[11] = {
    R8_MIN, R8_MIN*10.0, R8_MIN*100.0, R8_MIN*1000.0, R8_MIN*10000.0,
    R8_MIN*100000.0, R8_MIN*1000000.0, R8_MIN*10000000.0,
    R8_MIN*100000000.0, R8_MIN*1000000000.0, R8_MIN*10000000000.0
  };
  static const double dblMaximums[11] = {
    R8_MAX, R8_MAX/10.0, R8_MAX/100.0, R8_MAX/1000.0, R8_MAX/10000.0,
    R8_MAX/100000.0, R8_MAX/1000000.0, R8_MAX/10000000.0,
    R8_MAX/100000000.0, R8_MAX/1000000000.0, R8_MAX/10000000000.0
  };

  int wholeNumberDigits, fractionalDigits, divisor10 = 0, multiplier10 = 0;

  TRACE("(%p,%p,0x%x,%p)\n", pNumprs, rgbDig, dwVtBits, pVarDst);

  if (pNumprs->nBaseShift)
  {
    /* nBaseShift indicates a hex or octal number */
    ULONG64 ul64 = 0;
    LONG64 l64;
    int i;

    /* Convert the hex or octal number string into a UI64 */
    for (i = 0; i < pNumprs->cDig; i++)
    {
      if (ul64 > ((UI8_MAX>>pNumprs->nBaseShift) - rgbDig[i]))
      {
        TRACE("Overflow multiplying digits\n");
        return DISP_E_OVERFLOW;
      }
      ul64 = (ul64<<pNumprs->nBaseShift) + rgbDig[i];
    }

    /* also make a negative representation */
    l64=-ul64;

    /* Try signed and unsigned types in size order */
    if (dwVtBits & VTBIT_I1 && FITS_AS_I1(ul64))
    {
      V_VT(pVarDst) = VT_I1;
      V_I1(pVarDst) = ul64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_UI1 && FITS_AS_I1(ul64))
    {
      V_VT(pVarDst) = VT_UI1;
      V_UI1(pVarDst) = ul64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_I2 && FITS_AS_I2(ul64))
    {
      V_VT(pVarDst) = VT_I2;
      V_I2(pVarDst) = ul64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_UI2 && FITS_AS_I2(ul64))
    {
      V_VT(pVarDst) = VT_UI2;
      V_UI2(pVarDst) = ul64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_I4 && FITS_AS_I4(ul64))
    {
      V_VT(pVarDst) = VT_I4;
      V_I4(pVarDst) = ul64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_UI4 && FITS_AS_I4(ul64))
    {
      V_VT(pVarDst) = VT_UI4;
      V_UI4(pVarDst) = ul64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_I8 && ((ul64 <= I8_MAX)||(l64>=I8_MIN)))
    {
      V_VT(pVarDst) = VT_I8;
      V_I8(pVarDst) = ul64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_UI8)
    {
      V_VT(pVarDst) = VT_UI8;
      V_UI8(pVarDst) = ul64;
      return S_OK;
    }
    else if ((dwVtBits & VTBIT_DECIMAL) == VTBIT_DECIMAL)
    {
      V_VT(pVarDst) = VT_DECIMAL;
      DEC_SIGNSCALE(&V_DECIMAL(pVarDst)) = SIGNSCALE(DECIMAL_POS,0);
      DEC_HI32(&V_DECIMAL(pVarDst)) = 0;
      DEC_LO64(&V_DECIMAL(pVarDst)) = ul64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_R4 && ((ul64 <= I4_MAX)||(l64 >= I4_MIN)))
    {
      V_VT(pVarDst) = VT_R4;
      if (ul64 <= I4_MAX)
          V_R4(pVarDst) = ul64;
      else
          V_R4(pVarDst) = l64;
      return S_OK;
    }
    else if (dwVtBits & VTBIT_R8 && ((ul64 <= I4_MAX)||(l64 >= I4_MIN)))
    {
      V_VT(pVarDst) = VT_R8;
      if (ul64 <= I4_MAX)
          V_R8(pVarDst) = ul64;
      else
          V_R8(pVarDst) = l64;
      return S_OK;
    }

    //TRACE("Overflow: possible return types: 0x%x, value: %s\n", dwVtBits, wine_dbgstr_longlong(ul64));
    return DISP_E_OVERFLOW;
  }

  /* Count the number of relevant fractional and whole digits stored,
   * And compute the divisor/multiplier to scale the number by.
   */
  if (pNumprs->nPwr10 < 0)
  {
    if (-pNumprs->nPwr10 >= pNumprs->cDig)
    {
      /* A real number < +/- 1.0 e.g. 0.1024 or 0.01024 */
      wholeNumberDigits = 0;
      fractionalDigits = pNumprs->cDig;
      divisor10 = -pNumprs->nPwr10;
    }
    else
    {
      /* An exactly represented real number e.g. 1.024 */
      wholeNumberDigits = pNumprs->cDig + pNumprs->nPwr10;
      fractionalDigits = pNumprs->cDig - wholeNumberDigits;
      divisor10 = pNumprs->cDig - wholeNumberDigits;
    }
  }
  else if (pNumprs->nPwr10 == 0)
  {
    /* An exactly represented whole number e.g. 1024 */
    wholeNumberDigits = pNumprs->cDig;
    fractionalDigits = 0;
  }
  else /* pNumprs->nPwr10 > 0 */
  {
    /* A whole number followed by nPwr10 0's e.g. 102400 */
    wholeNumberDigits = pNumprs->cDig;
    fractionalDigits = 0;
    multiplier10 = pNumprs->nPwr10;
  }

  TRACE("cDig %d; nPwr10 %d, whole %d, frac %d mult %d; div %d\n",
        pNumprs->cDig, pNumprs->nPwr10, wholeNumberDigits, fractionalDigits,
        multiplier10, divisor10);

  if (dwVtBits & (INTEGER_VTBITS|VTBIT_DECIMAL) &&
      (!fractionalDigits || !(dwVtBits & (REAL_VTBITS|VTBIT_CY|VTBIT_DECIMAL))))
  {
    /* We have one or more integer output choices, and either:
     *  1) An integer input value, or
     *  2) A real number input value but no floating output choices.
     * Alternately, we have a DECIMAL output available and an integer input.
     *
     * So, place the integer value into pVarDst, using the smallest type
     * possible and preferring signed over unsigned types.
     */
    BOOL bOverflow = FALSE, bNegative;
    ULONG64 ul64 = 0;
    int i;

    /* Convert the integer part of the number into a UI8 */
    for (i = 0; i < wholeNumberDigits; i++)
    {
      if (ul64 > (UI8_MAX / 10 - rgbDig[i]))
      {
        TRACE("Overflow multiplying digits\n");
        bOverflow = TRUE;
        break;
      }
      ul64 = ul64 * 10 + rgbDig[i];
    }

    /* Account for the scale of the number */
    if (!bOverflow && multiplier10)
    {
      for (i = 0; i < multiplier10; i++)
      {
        if (ul64 > (UI8_MAX / 10))
        {
          TRACE("Overflow scaling number\n");
          bOverflow = TRUE;
          break;
        }
        ul64 = ul64 * 10;
      }
    }

    /* If we have any fractional digits, round the value.
     * Note we don't have to do this if divisor10 is < 1,
     * because this means the fractional part must be < 0.5
     */
    if (!bOverflow && fractionalDigits && divisor10 > 0)
    {
      const BYTE* fracDig = rgbDig + wholeNumberDigits;
      BOOL bAdjust = FALSE;

      TRACE("first decimal value is %d\n", *fracDig);

      if (*fracDig > 5)
        bAdjust = TRUE; /* > 0.5 */
      else if (*fracDig == 5)
      {
        for (i = 1; i < fractionalDigits; i++)
        {
          if (fracDig[i])
          {
            bAdjust = TRUE; /* > 0.5 */
            break;
          }
        }
        /* If exactly 0.5, round only odd values */
        if (i == fractionalDigits && (ul64 & 1))
          bAdjust = TRUE;
      }

      if (bAdjust)
      {
        if (ul64 == UI8_MAX)
        {
          TRACE("Overflow after rounding\n");
          bOverflow = TRUE;
        }
        ul64++;
      }
    }

    /* Zero is not a negative number */
    bNegative = pNumprs->dwOutFlags & NUMPRS_NEG && ul64 ? TRUE : FALSE;

    //TRACE("Integer value is 0x%s, bNeg %d\n", wine_dbgstr_longlong(ul64), bNegative);

    /* For negative integers, try the signed types in size order */
    if (!bOverflow && bNegative)
    {
      if (dwVtBits & (VTBIT_I1|VTBIT_I2|VTBIT_I4|VTBIT_I8))
      {
        if (dwVtBits & VTBIT_I1 && ul64 <= -I1_MIN)
        {
          V_VT(pVarDst) = VT_I1;
          V_I1(pVarDst) = -ul64;
          return S_OK;
        }
        else if (dwVtBits & VTBIT_I2 && ul64 <= -I2_MIN)
        {
          V_VT(pVarDst) = VT_I2;
          V_I2(pVarDst) = -ul64;
          return S_OK;
        }
        else if (dwVtBits & VTBIT_I4 && ul64 <= -((LONGLONG)I4_MIN))
        {
          V_VT(pVarDst) = VT_I4;
          V_I4(pVarDst) = -ul64;
          return S_OK;
        }
        else if (dwVtBits & VTBIT_I8 && ul64 <= (ULONGLONG)I8_MAX + 1)
        {
          V_VT(pVarDst) = VT_I8;
          V_I8(pVarDst) = -ul64;
          return S_OK;
        }
        else if ((dwVtBits & REAL_VTBITS) == VTBIT_DECIMAL)
        {
          /* Decimal is only output choice left - fast path */
          V_VT(pVarDst) = VT_DECIMAL;
          DEC_SIGNSCALE(&V_DECIMAL(pVarDst)) = SIGNSCALE(DECIMAL_NEG,0);
          DEC_HI32(&V_DECIMAL(pVarDst)) = 0;
          DEC_LO64(&V_DECIMAL(pVarDst)) = -ul64;
          return S_OK;
        }
      }
    }
    else if (!bOverflow)
    {
      /* For positive integers, try signed then unsigned types in size order */
      if (dwVtBits & VTBIT_I1 && ul64 <= I1_MAX)
      {
        V_VT(pVarDst) = VT_I1;
        V_I1(pVarDst) = ul64;
        return S_OK;
      }
      else if (dwVtBits & VTBIT_UI1 && ul64 <= UI1_MAX)
      {
        V_VT(pVarDst) = VT_UI1;
        V_UI1(pVarDst) = ul64;
        return S_OK;
      }
      else if (dwVtBits & VTBIT_I2 && ul64 <= I2_MAX)
      {
        V_VT(pVarDst) = VT_I2;
        V_I2(pVarDst) = ul64;
        return S_OK;
      }
      else if (dwVtBits & VTBIT_UI2 && ul64 <= UI2_MAX)
      {
        V_VT(pVarDst) = VT_UI2;
        V_UI2(pVarDst) = ul64;
        return S_OK;
      }
      else if (dwVtBits & VTBIT_I4 && ul64 <= I4_MAX)
      {
        V_VT(pVarDst) = VT_I4;
        V_I4(pVarDst) = ul64;
        return S_OK;
      }
      else if (dwVtBits & VTBIT_UI4 && ul64 <= UI4_MAX)
      {
        V_VT(pVarDst) = VT_UI4;
        V_UI4(pVarDst) = ul64;
        return S_OK;
      }
      else if (dwVtBits & VTBIT_I8 && ul64 <= I8_MAX)
      {
        V_VT(pVarDst) = VT_I8;
        V_I8(pVarDst) = ul64;
        return S_OK;
      }
      else if (dwVtBits & VTBIT_UI8)
      {
        V_VT(pVarDst) = VT_UI8;
        V_UI8(pVarDst) = ul64;
        return S_OK;
      }
      else if ((dwVtBits & REAL_VTBITS) == VTBIT_DECIMAL)
      {
        /* Decimal is only output choice left - fast path */
        V_VT(pVarDst) = VT_DECIMAL;
        DEC_SIGNSCALE(&V_DECIMAL(pVarDst)) = SIGNSCALE(DECIMAL_POS,0);
        DEC_HI32(&V_DECIMAL(pVarDst)) = 0;
        DEC_LO64(&V_DECIMAL(pVarDst)) = ul64;
        return S_OK;
      }
    }
  }

  if (dwVtBits & REAL_VTBITS)
  {
    /* Try to put the number into a float or real */
    BOOL bOverflow = FALSE, bNegative = pNumprs->dwOutFlags & NUMPRS_NEG;
    double whole = 0.0;
    int i;

    /* Convert the number into a double */
    for (i = 0; i < pNumprs->cDig; i++)
      whole = whole * 10.0 + rgbDig[i];

    TRACE("Whole double value is %16.16g\n", whole);

    /* Account for the scale */
    while (multiplier10 > 10)
    {
      if (whole > dblMaximums[10])
      {
        dwVtBits &= ~(VTBIT_R4|VTBIT_R8|VTBIT_CY);
        bOverflow = TRUE;
        break;
      }
      whole = whole * dblMultipliers[10];
      multiplier10 -= 10;
    }
    if (multiplier10 && !bOverflow)
    {
      if (whole > dblMaximums[multiplier10])
      {
        dwVtBits &= ~(VTBIT_R4|VTBIT_R8|VTBIT_CY);
        bOverflow = TRUE;
      }
      else
        whole = whole * dblMultipliers[multiplier10];
    }

    if (!bOverflow)
        TRACE("Scaled double value is %16.16g\n", whole);

    while (divisor10 > 10 && !bOverflow)
    {
      if (whole < dblMinimums[10] && whole != 0)
      {
        dwVtBits &= ~(VTBIT_R4|VTBIT_R8|VTBIT_CY); /* Underflow */
        bOverflow = TRUE;
        break;
      }
      whole = whole / dblMultipliers[10];
      divisor10 -= 10;
    }
    if (divisor10 && !bOverflow)
    {
      if (whole < dblMinimums[divisor10] && whole != 0)
      {
        dwVtBits &= ~(VTBIT_R4|VTBIT_R8|VTBIT_CY); /* Underflow */
        bOverflow = TRUE;
      }
      else
        whole = whole / dblMultipliers[divisor10];
    }
    if (!bOverflow)
      TRACE("Final double value is %16.16g\n", whole);

    if (dwVtBits & VTBIT_R4 &&
        ((whole <= R4_MAX && whole >= R4_MIN) || whole == 0.0))
    {
      TRACE("Set R4 to final value\n");
      V_VT(pVarDst) = VT_R4; /* Fits into a float */
      V_R4(pVarDst) = pNumprs->dwOutFlags & NUMPRS_NEG ? -whole : whole;
      return S_OK;
    }

    if (dwVtBits & VTBIT_R8)
    {
      TRACE("Set R8 to final value\n");
      V_VT(pVarDst) = VT_R8; /* Fits into a double */
      V_R8(pVarDst) = pNumprs->dwOutFlags & NUMPRS_NEG ? -whole : whole;
      return S_OK;
    }

    if (dwVtBits & VTBIT_CY)
    {
      if (SUCCEEDED(VarCyFromR8(bNegative ? -whole : whole, &V_CY(pVarDst))))
      {
        V_VT(pVarDst) = VT_CY; /* Fits into a currency */
        TRACE("Set CY to final value\n");
        return S_OK;
      }
      TRACE("Value Overflows CY\n");
    }
  }

  if (dwVtBits & VTBIT_DECIMAL)
  {
    int i;
    ULONG carry;
    ULONG64 tmp;
    DECIMAL* pDec = &V_DECIMAL(pVarDst);

    DECIMAL_SETZERO(*pDec);
    DEC_LO32(pDec) = 0;

    if (pNumprs->dwOutFlags & NUMPRS_NEG)
      DEC_SIGN(pDec) = DECIMAL_NEG;
    else
      DEC_SIGN(pDec) = DECIMAL_POS;

    /* Factor the significant digits */
    for (i = 0; i < pNumprs->cDig; i++)
    {
      tmp = (ULONG64)DEC_LO32(pDec) * 10 + rgbDig[i];
      carry = (ULONG)(tmp >> 32);
      DEC_LO32(pDec) = (ULONG)(tmp & UI4_MAX);
      tmp = (ULONG64)DEC_MID32(pDec) * 10 + carry;
      carry = (ULONG)(tmp >> 32);
      DEC_MID32(pDec) = (ULONG)(tmp & UI4_MAX);
      tmp = (ULONG64)DEC_HI32(pDec) * 10 + carry;
      DEC_HI32(pDec) = (ULONG)(tmp & UI4_MAX);

      if (tmp >> 32 & UI4_MAX)
      {
VarNumFromParseNum_DecOverflow:
        TRACE("Overflow\n");
        DEC_LO32(pDec) = DEC_MID32(pDec) = DEC_HI32(pDec) = UI4_MAX;
        return DISP_E_OVERFLOW;
      }
    }

    /* Account for the scale of the number */
    while (multiplier10 > 0)
    {
      tmp = (ULONG64)DEC_LO32(pDec) * 10;
      carry = (ULONG)(tmp >> 32);
      DEC_LO32(pDec) = (ULONG)(tmp & UI4_MAX);
      tmp = (ULONG64)DEC_MID32(pDec) * 10 + carry;
      carry = (ULONG)(tmp >> 32);
      DEC_MID32(pDec) = (ULONG)(tmp & UI4_MAX);
      tmp = (ULONG64)DEC_HI32(pDec) * 10 + carry;
      DEC_HI32(pDec) = (ULONG)(tmp & UI4_MAX);

      if (tmp >> 32 & UI4_MAX)
        goto VarNumFromParseNum_DecOverflow;
      multiplier10--;
    }
    DEC_SCALE(pDec) = divisor10;

    V_VT(pVarDst) = VT_DECIMAL;
    return S_OK;
  }
  return DISP_E_OVERFLOW; /* No more output choices */
}

/**********************************************************************
 *              VarCat [OLEAUT32.318]
 *
 * Concatenates one variant onto another.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  result  [O] Result variant
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: An HRESULT error code indicating the error.
 */
HRESULT WINAPI VarCat(LPVARIANT left, LPVARIANT right, LPVARIANT out)
{
    VARTYPE leftvt,rightvt,resultvt;
    HRESULT hres;
    static WCHAR str_true[32];
    static WCHAR str_false[32];
    static const WCHAR sz_empty[] = {'\0'};
    leftvt = V_VT(left);
    rightvt = V_VT(right);

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right), out);

    if (!str_true[0]) {
        VARIANT_GetLocalisedText(LOCALE_USER_DEFAULT, IDS_FALSE, str_false);
        VARIANT_GetLocalisedText(LOCALE_USER_DEFAULT, IDS_TRUE, str_true);
    }

    /* when both left and right are NULL the result is NULL */
    if (leftvt == VT_NULL && rightvt == VT_NULL)
    {
        V_VT(out) = VT_NULL;
        return S_OK;
    }

    hres = S_OK;
    resultvt = VT_EMPTY;

    /* There are many special case for errors and return types */
    if (leftvt == VT_VARIANT && (rightvt == VT_ERROR ||
        rightvt == VT_DATE || rightvt == VT_DECIMAL))
        hres = DISP_E_TYPEMISMATCH;
    else if ((leftvt == VT_I2 || leftvt == VT_I4 ||
        leftvt == VT_R4 || leftvt == VT_R8 ||
        leftvt == VT_CY || leftvt == VT_BOOL ||
        leftvt == VT_BSTR || leftvt == VT_I1 ||
        leftvt == VT_UI1 || leftvt == VT_UI2 ||
        leftvt == VT_UI4 || leftvt == VT_I8 ||
        leftvt == VT_UI8 || leftvt == VT_INT ||
        leftvt == VT_UINT || leftvt == VT_EMPTY ||
        leftvt == VT_NULL || leftvt == VT_DATE ||
        leftvt == VT_DECIMAL || leftvt == VT_DISPATCH)
        &&
        (rightvt == VT_I2 || rightvt == VT_I4 ||
        rightvt == VT_R4 || rightvt == VT_R8 ||
        rightvt == VT_CY || rightvt == VT_BOOL ||
        rightvt == VT_BSTR || rightvt == VT_I1 ||
        rightvt == VT_UI1 || rightvt == VT_UI2 ||
        rightvt == VT_UI4 || rightvt == VT_I8 ||
        rightvt == VT_UI8 || rightvt == VT_INT ||
        rightvt == VT_UINT || rightvt == VT_EMPTY ||
        rightvt == VT_NULL || rightvt == VT_DATE ||
        rightvt == VT_DECIMAL || rightvt == VT_DISPATCH))
        resultvt = VT_BSTR;
    else if (rightvt == VT_ERROR && leftvt < VT_VOID)
        hres = DISP_E_TYPEMISMATCH;
    else if (leftvt == VT_ERROR && (rightvt == VT_DATE ||
        rightvt == VT_ERROR || rightvt == VT_DECIMAL))
        hres = DISP_E_TYPEMISMATCH;
    else if (rightvt == VT_DATE || rightvt == VT_ERROR ||
        rightvt == VT_DECIMAL)
        hres = DISP_E_BADVARTYPE;
    else if (leftvt == VT_ERROR || rightvt == VT_ERROR)
        hres = DISP_E_TYPEMISMATCH;
    else if (leftvt == VT_VARIANT)
        hres = DISP_E_TYPEMISMATCH;
    else if (rightvt == VT_VARIANT && (leftvt == VT_EMPTY ||
        leftvt == VT_NULL || leftvt ==  VT_I2 ||
        leftvt == VT_I4 || leftvt == VT_R4 ||
        leftvt == VT_R8 || leftvt == VT_CY ||
        leftvt == VT_DATE || leftvt == VT_BSTR ||
        leftvt == VT_BOOL ||  leftvt == VT_DECIMAL ||
        leftvt == VT_I1 || leftvt == VT_UI1 ||
        leftvt == VT_UI2 || leftvt == VT_UI4 ||
        leftvt == VT_I8 || leftvt == VT_UI8 ||
        leftvt == VT_INT || leftvt == VT_UINT))
        hres = DISP_E_TYPEMISMATCH;
    else
        hres = DISP_E_BADVARTYPE;

    /* if result type is not S_OK, then no need to go further */
    if (hres != S_OK)
    {
        V_VT(out) = resultvt;
        return hres;
    }
    /* Else proceed with formatting inputs to strings */
    else
    {
        VARIANT bstrvar_left, bstrvar_right;
        V_VT(out) = VT_BSTR;

        VariantInit(&bstrvar_left);
        VariantInit(&bstrvar_right);

        /* Convert left side variant to string */
        if (leftvt != VT_BSTR)
        {
            if (leftvt == VT_BOOL)
            {
                /* Bools are handled as localized True/False strings instead of 0/-1 as in MSDN */
                V_VT(&bstrvar_left) = VT_BSTR;
                if (V_BOOL(left) == TRUE)
                    V_BSTR(&bstrvar_left) = SysAllocString(str_true);
                else
                    V_BSTR(&bstrvar_left) = SysAllocString(str_false);
            }
            /* Fill with empty string for later concat with right side */
            else if (leftvt == VT_NULL)
            {
                V_VT(&bstrvar_left) = VT_BSTR;
                V_BSTR(&bstrvar_left) = SysAllocString(sz_empty);
            }
            else
            {
                hres = VariantChangeTypeEx(&bstrvar_left,left,0,0,VT_BSTR);
                if (hres != S_OK) {
                    VariantClear(&bstrvar_left);
                    VariantClear(&bstrvar_right);
                    if (leftvt == VT_NULL && (rightvt == VT_EMPTY ||
                        rightvt == VT_NULL || rightvt ==  VT_I2 ||
                        rightvt == VT_I4 || rightvt == VT_R4 ||
                        rightvt == VT_R8 || rightvt == VT_CY ||
                        rightvt == VT_DATE || rightvt == VT_BSTR ||
                        rightvt == VT_BOOL ||  rightvt == VT_DECIMAL ||
                        rightvt == VT_I1 || rightvt == VT_UI1 ||
                        rightvt == VT_UI2 || rightvt == VT_UI4 ||
                        rightvt == VT_I8 || rightvt == VT_UI8 ||
                        rightvt == VT_INT || rightvt == VT_UINT))
                        return DISP_E_BADVARTYPE;
                    return hres;
                }
            }
        }

        /* convert right side variant to string */
        if (rightvt != VT_BSTR)
        {
            if (rightvt == VT_BOOL)
            {
                /* Bools are handled as localized True/False strings instead of 0/-1 as in MSDN */
                V_VT(&bstrvar_right) = VT_BSTR;
                if (V_BOOL(right) == TRUE)
                    V_BSTR(&bstrvar_right) = SysAllocString(str_true);
                else
                    V_BSTR(&bstrvar_right) = SysAllocString(str_false);
            }
            /* Fill with empty string for later concat with right side */
            else if (rightvt == VT_NULL)
            {
                V_VT(&bstrvar_right) = VT_BSTR;
                V_BSTR(&bstrvar_right) = SysAllocString(sz_empty);
            }
            else
            {
                hres = VariantChangeTypeEx(&bstrvar_right,right,0,0,VT_BSTR);
                if (hres != S_OK) {
                    VariantClear(&bstrvar_left);
                    VariantClear(&bstrvar_right);
                    if (rightvt == VT_NULL && (leftvt == VT_EMPTY ||
                        leftvt == VT_NULL || leftvt ==  VT_I2 ||
                        leftvt == VT_I4 || leftvt == VT_R4 ||
                        leftvt == VT_R8 || leftvt == VT_CY ||
                        leftvt == VT_DATE || leftvt == VT_BSTR ||
                        leftvt == VT_BOOL ||  leftvt == VT_DECIMAL ||
                        leftvt == VT_I1 || leftvt == VT_UI1 ||
                        leftvt == VT_UI2 || leftvt == VT_UI4 ||
                        leftvt == VT_I8 || leftvt == VT_UI8 ||
                        leftvt == VT_INT || leftvt == VT_UINT))
                        return DISP_E_BADVARTYPE;
                    return hres;
                }
            }
        }

        /* Concat the resulting strings together */
        if (leftvt == VT_BSTR && rightvt == VT_BSTR)
            VarBstrCat (V_BSTR(left), V_BSTR(right), &V_BSTR(out));
        else if (leftvt != VT_BSTR && rightvt != VT_BSTR)
            VarBstrCat (V_BSTR(&bstrvar_left), V_BSTR(&bstrvar_right), &V_BSTR(out));
        else if (leftvt != VT_BSTR && rightvt == VT_BSTR)
            VarBstrCat (V_BSTR(&bstrvar_left), V_BSTR(right), &V_BSTR(out));
        else if (leftvt == VT_BSTR && rightvt != VT_BSTR)
            VarBstrCat (V_BSTR(left), V_BSTR(&bstrvar_right), &V_BSTR(out));

        VariantClear(&bstrvar_left);
        VariantClear(&bstrvar_right);
        return S_OK;
    }
}


/* Wrapper around VariantChangeTypeEx() which permits changing a
   variant with VT_RESERVED flag set. Needed by VarCmp. */
static HRESULT _VarChangeTypeExWrap (VARIANTARG* pvargDest,
                    VARIANTARG* pvargSrc, LCID lcid, USHORT wFlags, VARTYPE vt)
{
    HRESULT res;
    VARTYPE flags;

    flags = V_VT(pvargSrc) & ~VT_TYPEMASK;
    V_VT(pvargSrc) &= ~VT_RESERVED;
    res = VariantChangeTypeEx(pvargDest,pvargSrc,lcid,wFlags,vt);
    V_VT(pvargSrc) |= flags;

    return res;
}

/**********************************************************************
 *              VarCmp [OLEAUT32.176]
 *
 * Compare two variants.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  lcid    [I] LCID (locale identifier) for the comparison
 *  flags   [I] Flags to be used in the comparison:
 *              NORM_IGNORECASE, NORM_IGNORENONSPACE, NORM_IGNORESYMBOLS,
 *              NORM_IGNOREWIDTH, NORM_IGNOREKANATYPE, NORM_IGNOREKASHIDA
 *
 * RETURNS
 *  VARCMP_LT:   left variant is less than right variant.
 *  VARCMP_EQ:   input variants are equal.
 *  VARCMP_GT:   left variant is greater than right variant.
 *  VARCMP_NULL: either one of the input variants is NULL.
 *  Failure:     An HRESULT error code indicating the error.
 *
 * NOTES
 *  Native VarCmp up to and including WinXP doesn't like I1, UI2, VT_UI4,
 *  UI8 and UINT as input variants. INT is accepted only as left variant.
 *
 *  If both input variants are ERROR then VARCMP_EQ will be returned, else
 *  an ERROR variant will trigger an error.
 *
 *  Both input variants can have VT_RESERVED flag set which is ignored
 *  unless one and only one of the variants is a BSTR and the other one
 *  is not an EMPTY variant. All four VT_RESERVED combinations have a
 *  different meaning:
 *   - BSTR and other: BSTR is always greater than the other variant.
 *   - BSTR|VT_RESERVED and other: a string comparison is performed.
 *   - BSTR and other|VT_RESERVED: If the BSTR is a number a numeric
 *     comparison will take place else the BSTR is always greater.
 *   - BSTR|VT_RESERVED and other|VT_RESERVED: It seems that the other
 *     variant is ignored and the return value depends only on the sign
 *     of the BSTR if it is a number else the BSTR is always greater. A
 *     positive BSTR is greater, a negative one is smaller than the other
 *     variant.
 *
 * SEE
 *  VarBstrCmp for the lcid and flags usage.
 */
HRESULT WINAPI VarCmp(LPVARIANT left, LPVARIANT right, LCID lcid, DWORD flags)
{
    VARTYPE     lvt, rvt, vt;
    VARIANT     rv,lv;
    DWORD       xmask;
    HRESULT     rc;

    TRACE("(%p->(%s%s),%p->(%s%s),0x%08x,0x%08x)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right), lcid, flags);

    lvt = V_VT(left) & VT_TYPEMASK;
    rvt = V_VT(right) & VT_TYPEMASK;
    xmask = (1 << lvt) | (1 << rvt);

    /* If we have any flag set except VT_RESERVED bail out.
       Same for the left input variant type > VT_INT and for the
       right input variant type > VT_I8. Yes, VT_INT is only supported
       as left variant. Go figure */
    if (((V_VT(left) | V_VT(right)) & ~VT_TYPEMASK & ~VT_RESERVED) ||
            lvt > VT_INT || rvt > VT_I8) {
        return DISP_E_BADVARTYPE;
    }

    /* Don't ask me why but native VarCmp cannot handle: VT_I1, VT_UI2, VT_UI4,
       VT_UINT and VT_UI8. Tested with DCOM98, Win2k, WinXP */
    if (rvt == VT_INT || xmask & (VTBIT_I1 | VTBIT_UI2 | VTBIT_UI4 | VTBIT_UI8 |
                VTBIT_DISPATCH | VTBIT_VARIANT | VTBIT_UNKNOWN | VTBIT_15))
        return DISP_E_TYPEMISMATCH;

    /* If both variants are VT_ERROR return VARCMP_EQ */
    if (xmask == VTBIT_ERROR)
        return VARCMP_EQ;
    else if (xmask & VTBIT_ERROR)
        return DISP_E_TYPEMISMATCH;

    if (xmask & VTBIT_NULL)
        return VARCMP_NULL;

    VariantInit(&lv);
    VariantInit(&rv);

    /* Two BSTRs, ignore VT_RESERVED */
    if (xmask == VTBIT_BSTR)
        return VarBstrCmp(V_BSTR(left), V_BSTR(right), lcid, flags);

    /* A BSTR and an other variant; we have to take care of VT_RESERVED */
    if (xmask & VTBIT_BSTR) {
        VARIANT *bstrv, *nonbv;
        VARTYPE nonbvt;
        int swap = 0;

        /* Swap the variants so the BSTR is always on the left */
        if (lvt == VT_BSTR) {
            bstrv = left;
            nonbv = right;
            nonbvt = rvt;
        } else {
            swap = 1;
            bstrv = right;
            nonbv = left;
            nonbvt = lvt;
        }

        /* BSTR and EMPTY: ignore VT_RESERVED */
        if (nonbvt == VT_EMPTY)
            rc = (!V_BSTR(bstrv) || !*V_BSTR(bstrv)) ? VARCMP_EQ : VARCMP_GT;
        else {
            VARTYPE breserv = V_VT(bstrv) & ~VT_TYPEMASK;
            VARTYPE nreserv = V_VT(nonbv) & ~VT_TYPEMASK;

            if (!breserv && !nreserv) 
                /* No VT_RESERVED set ==> BSTR always greater */
                rc = VARCMP_GT;
            else if (breserv && !nreserv) {
                /* BSTR has VT_RESERVED set. Do a string comparison */
                rc = VariantChangeTypeEx(&rv,nonbv,lcid,0,VT_BSTR);
                if (FAILED(rc))
                    return rc;
                rc = VarBstrCmp(V_BSTR(bstrv), V_BSTR(&rv), lcid, flags);
                VariantClear(&rv);
            } else if (V_BSTR(bstrv) && *V_BSTR(bstrv)) {
            /* Non NULL nor empty BSTR */
                /* If the BSTR is not a number the BSTR is greater */
                rc = _VarChangeTypeExWrap(&lv,bstrv,lcid,0,VT_R8);
                if (FAILED(rc))
                    rc = VARCMP_GT;
                else if (breserv && nreserv)
                    /* //FixMe: This is strange: with both VT_RESERVED set it
                       looks like the result depends only on the sign of
                       the BSTR number */
                    rc = (V_R8(&lv) >= 0) ? VARCMP_GT : VARCMP_LT;
                else
                    /* Numeric comparison, will be handled below.
                       VARCMP_NULL used only to break out. */
                    rc = VARCMP_NULL;
                VariantClear(&lv);
                VariantClear(&rv);
            } else
                /* Empty or NULL BSTR */
                rc = VARCMP_GT;
        }
        /* Fixup the return code if we swapped left and right */
        if (swap) {
            if (rc == VARCMP_GT)
                rc = VARCMP_LT;
            else if (rc == VARCMP_LT)
                rc = VARCMP_GT;
        }
        if (rc != VARCMP_NULL)
            return rc;
    }

    if (xmask & VTBIT_DECIMAL)
        vt = VT_DECIMAL;
    else if (xmask & VTBIT_BSTR)
        vt = VT_R8;
    else if (xmask & VTBIT_R4)
        vt = VT_R4;
    else if (xmask & (VTBIT_R8 | VTBIT_DATE))
        vt = VT_R8;
    else if (xmask & VTBIT_CY)
        vt = VT_CY;
    else
        /* default to I8 */
        vt = VT_I8;

    /* Coerce the variants */
    rc = _VarChangeTypeExWrap(&lv,left,lcid,0,vt);
    if (rc == DISP_E_OVERFLOW && vt != VT_R8) {
        /* Overflow, change to R8 */
        vt = VT_R8;
        rc = _VarChangeTypeExWrap(&lv,left,lcid,0,vt);
    }
    if (FAILED(rc))
        return rc;
    rc = _VarChangeTypeExWrap(&rv,right,lcid,0,vt);
    if (rc == DISP_E_OVERFLOW && vt != VT_R8) {
        /* Overflow, change to R8 */
        vt = VT_R8;
        rc = _VarChangeTypeExWrap(&lv,left,lcid,0,vt);
        if (FAILED(rc))
            return rc;
        rc = _VarChangeTypeExWrap(&rv,right,lcid,0,vt);
    }
    if (FAILED(rc))
        return rc;

#define _VARCMP(a,b) \
    (((a) == (b)) ? VARCMP_EQ : (((a) < (b)) ? VARCMP_LT : VARCMP_GT))

    switch (vt) {
        case VT_CY:
            return VarCyCmp(V_CY(&lv), V_CY(&rv));
        case VT_DECIMAL:
            return VarDecCmp(&V_DECIMAL(&lv), &V_DECIMAL(&rv));
        case VT_I8:
            return _VARCMP(V_I8(&lv), V_I8(&rv));
        case VT_R4:
            return _VARCMP(V_R4(&lv), V_R4(&rv));
        case VT_R8:
            return _VARCMP(V_R8(&lv), V_R8(&rv));
        default:
            /* We should never get here */
            return E_FAIL;
    }
#undef _VARCMP
}


/**********************************************************************
 *              VarAnd [OLEAUT32.142]
 *
 * Computes the logical AND of two variants.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  result  [O] Result variant
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: An HRESULT error code indicating the error.
 */
HRESULT WINAPI VarAnd(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    HRESULT hres = S_OK;
    VARTYPE resvt = VT_EMPTY;
    VARTYPE leftvt,rightvt;
    VARTYPE rightExtraFlags,leftExtraFlags,ExtraFlags;
    VARIANT varLeft, varRight;
    VARIANT tempLeft, tempRight;

    VariantInit(&varLeft);
    VariantInit(&varRight);
    VariantInit(&tempLeft);
    VariantInit(&tempRight);

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right), result);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(left) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hres = VARIANT_FetchDispatchValue(left, &tempLeft);
        if (FAILED(hres)) goto VarAnd_Exit;
        left = &tempLeft;
    }
    if ((V_VT(right) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hres = VARIANT_FetchDispatchValue(right, &tempRight);
        if (FAILED(hres)) goto VarAnd_Exit;
        right = &tempRight;
    }

    leftvt = V_VT(left)&VT_TYPEMASK;
    rightvt = V_VT(right)&VT_TYPEMASK;
    leftExtraFlags = V_VT(left)&(~VT_TYPEMASK);
    rightExtraFlags = V_VT(right)&(~VT_TYPEMASK);

    if (leftExtraFlags != rightExtraFlags)
    {
        hres = DISP_E_BADVARTYPE;
        goto VarAnd_Exit;
    }
    ExtraFlags = leftExtraFlags;

    /* Native VarAnd always returns an error when using extra
     * flags or if the variant combination is I8 and INT.
     */
    if ((leftvt == VT_I8 && rightvt == VT_INT) ||
        (leftvt == VT_INT && rightvt == VT_I8) ||
        ExtraFlags != 0)
    {
        hres = DISP_E_BADVARTYPE;
        goto VarAnd_Exit;
    }

    /* Determine return type */
    else if (leftvt == VT_I8 || rightvt == VT_I8)
        resvt = VT_I8;
    else if (leftvt == VT_I4 || rightvt == VT_I4 ||
        leftvt == VT_UINT || rightvt == VT_UINT ||
        leftvt == VT_INT || rightvt == VT_INT ||
        leftvt == VT_UINT || rightvt == VT_UINT ||
        leftvt == VT_R4 || rightvt == VT_R4 ||
        leftvt == VT_R8 || rightvt == VT_R8 ||
        leftvt == VT_CY || rightvt == VT_CY ||
        leftvt == VT_DATE || rightvt == VT_DATE ||
        leftvt == VT_I1 || rightvt == VT_I1 ||
        leftvt == VT_UI2 || rightvt == VT_UI2 ||
        leftvt == VT_UI4 || rightvt == VT_UI4 ||
        leftvt == VT_UI8 || rightvt == VT_UI8 ||
        leftvt == VT_DECIMAL || rightvt == VT_DECIMAL)
        resvt = VT_I4;
    else if (leftvt == VT_UI1 || rightvt == VT_UI1 ||
        leftvt == VT_I2 || rightvt == VT_I2 ||
        leftvt == VT_EMPTY || rightvt == VT_EMPTY)
        if ((leftvt == VT_NULL && rightvt == VT_UI1) ||
            (leftvt == VT_UI1 && rightvt == VT_NULL) ||
            (leftvt == VT_UI1 && rightvt == VT_UI1))
            resvt = VT_UI1;
        else
            resvt = VT_I2;
    else if (leftvt == VT_BOOL || rightvt == VT_BOOL ||
        (leftvt == VT_BSTR && rightvt == VT_BSTR))
        resvt = VT_BOOL;
    else if (leftvt == VT_NULL || rightvt == VT_NULL ||
        leftvt == VT_BSTR || rightvt == VT_BSTR)
        resvt = VT_NULL;
    else
    {
        hres = DISP_E_BADVARTYPE;
        goto VarAnd_Exit;
    }

    if (leftvt == VT_NULL || rightvt == VT_NULL)
    {
        /*
         * Special cases for when left variant is VT_NULL
         * (VT_NULL & 0 = VT_NULL, VT_NULL & value = value)
         */
        if (leftvt == VT_NULL)
        {
            VARIANT_BOOL b;
            switch(rightvt)
            {
            case VT_I1:   if (V_I1(right)) resvt = VT_NULL; break;
            case VT_UI1:  if (V_UI1(right)) resvt = VT_NULL; break;
            case VT_I2:   if (V_I2(right)) resvt = VT_NULL; break;
            case VT_UI2:  if (V_UI2(right)) resvt = VT_NULL; break;
            case VT_I4:   if (V_I4(right)) resvt = VT_NULL; break;
            case VT_UI4:  if (V_UI4(right)) resvt = VT_NULL; break;
            case VT_I8:   if (V_I8(right)) resvt = VT_NULL; break;
            case VT_UI8:  if (V_UI8(right)) resvt = VT_NULL; break;
            case VT_INT:  if (V_INT(right)) resvt = VT_NULL; break;
            case VT_UINT: if (V_UINT(right)) resvt = VT_NULL; break;
            case VT_BOOL: if (V_BOOL(right)) resvt = VT_NULL; break;
            case VT_R4:   if (V_R4(right)) resvt = VT_NULL; break;
            case VT_R8:   if (V_R8(right)) resvt = VT_NULL; break;
            case VT_CY:
                if(V_CY(right).int64)
                    resvt = VT_NULL;
                break;
            case VT_DECIMAL:
                if (DEC_HI32(&V_DECIMAL(right)) ||
                    DEC_LO64(&V_DECIMAL(right)))
                    resvt = VT_NULL;
                break;
            case VT_BSTR:
                hres = VarBoolFromStr(V_BSTR(right),
                LOCALE_USER_DEFAULT, VAR_LOCALBOOL, &b);
                if (FAILED(hres))
                    return hres;
                else if (b)
                    V_VT(result) = VT_NULL;
                else
                {
                    V_VT(result) = VT_BOOL;
                    V_BOOL(result) = b;
                }
                goto VarAnd_Exit;
            }
        }
        V_VT(result) = resvt;
        goto VarAnd_Exit;
    }

    hres = VariantCopy(&varLeft, left);
    if (FAILED(hres)) goto VarAnd_Exit;

    hres = VariantCopy(&varRight, right);
    if (FAILED(hres)) goto VarAnd_Exit;

    if (resvt == VT_I4 && V_VT(&varLeft) == VT_UI4)
        V_VT(&varLeft) = VT_I4; /* Don't overflow */
    else
    {
        double d;

        if (V_VT(&varLeft) == VT_BSTR &&
            FAILED(VarR8FromStr(V_BSTR(&varLeft),
            LOCALE_USER_DEFAULT, 0, &d)))
            hres = VariantChangeType(&varLeft,&varLeft,
            VARIANT_LOCALBOOL, VT_BOOL);
            if (SUCCEEDED(hres) && V_VT(&varLeft) != resvt)
                hres = VariantChangeType(&varLeft,&varLeft,0,resvt);
            if (FAILED(hres)) goto VarAnd_Exit;
    }

    if (resvt == VT_I4 && V_VT(&varRight) == VT_UI4)
        V_VT(&varRight) = VT_I4; /* Don't overflow */
    else
    {
        double d;

        if (V_VT(&varRight) == VT_BSTR &&
            FAILED(VarR8FromStr(V_BSTR(&varRight),
            LOCALE_USER_DEFAULT, 0, &d)))
            hres = VariantChangeType(&varRight, &varRight,
                VARIANT_LOCALBOOL, VT_BOOL);
        if (SUCCEEDED(hres) && V_VT(&varRight) != resvt)
            hres = VariantChangeType(&varRight, &varRight, 0, resvt);
        if (FAILED(hres)) goto VarAnd_Exit;
    }

    V_VT(result) = resvt;
    switch(resvt)
    {
    case VT_I8:
        V_I8(result) = V_I8(&varLeft) & V_I8(&varRight);
        break;
    case VT_I4:
        V_I4(result) = V_I4(&varLeft) & V_I4(&varRight);
        break;
    case VT_I2:
        V_I2(result) = V_I2(&varLeft) & V_I2(&varRight);
        break;
    case VT_UI1:
        V_UI1(result) = V_UI1(&varLeft) & V_UI1(&varRight);
        break;
    case VT_BOOL:
        V_BOOL(result) = V_BOOL(&varLeft) & V_BOOL(&varRight);
        break;
    default:
		break; // must have a block here for gcc
    }

VarAnd_Exit:
    VariantClear(&varLeft);
    VariantClear(&varRight);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);

    return hres;
}

/**********************************************************************
 *              VarAdd [OLEAUT32.141]
 *
 * Add two variants.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  result  [O] Result variant
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  Native VarAdd up to and including WinXP doesn't like I1, UI2, UI4,
 *  UI8, INT and UINT as input variants.
 *
 *  Native VarAdd doesn't check for NULL in/out pointers and crashes. We do the
 *  same here.
 *
 * //FixMe
 *  Overflow checking for R8 (double) overflow. Return DISP_E_OVERFLOW in that
 *  case.
 */
HRESULT WINAPI VarAdd(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    HRESULT hres;
    VARTYPE lvt, rvt, resvt, tvt;
    VARIANT lv, rv, tv;
    VARIANT tempLeft, tempRight;
    double r8res;

    /* Variant priority for coercion. Sorted from lowest to highest.
       VT_ERROR shows an invalid input variant type. */
    enum coerceprio { vt_EMPTY, vt_UI1, vt_I2, vt_I4, vt_I8, vt_BSTR,vt_R4,
                      vt_R8, vt_CY, vt_DATE, vt_DECIMAL, vt_DISPATCH, vt_NULL,
                      vt_ERROR };
    /* Mapping from priority to variant type. Keep in sync with coerceprio! */
    static const VARTYPE prio2vt[] = { VT_EMPTY, VT_UI1, VT_I2, VT_I4, VT_I8, VT_BSTR, VT_R4,
                          VT_R8, VT_CY, VT_DATE, VT_DECIMAL, VT_DISPATCH,
                          VT_NULL, VT_ERROR };

    /* Mapping for coercion from input variant to priority of result variant. */
    static const VARTYPE coerce[] = {
        /* VT_EMPTY, VT_NULL, VT_I2, VT_I4, VT_R4 */
        vt_EMPTY, vt_NULL, vt_I2, vt_I4, vt_R4,
        /* VT_R8, VT_CY, VT_DATE, VT_BSTR, VT_DISPATCH */
        vt_R8, vt_CY, vt_DATE, vt_BSTR, vt_DISPATCH,
        /* VT_ERROR, VT_BOOL, VT_VARIANT, VT_UNKNOWN, VT_DECIMAL */
        vt_ERROR, vt_I2, vt_ERROR, vt_ERROR, vt_DECIMAL,
        /* 15, VT_I1, VT_UI1, VT_UI2, VT_UI4 VT_I8 */
        vt_ERROR, vt_ERROR, vt_UI1, vt_ERROR, vt_ERROR, vt_I8
    };

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right),
          result);

    VariantInit(&lv);
    VariantInit(&rv);
    VariantInit(&tv);
    VariantInit(&tempLeft);
    VariantInit(&tempRight);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(left) & VT_TYPEMASK) != VT_NULL && (V_VT(right) & VT_TYPEMASK) != VT_NULL)
    {
        if ((V_VT(left) & VT_TYPEMASK) == VT_DISPATCH)
        {
            hres = VARIANT_FetchDispatchValue(left, &tempLeft);
            if (FAILED(hres)) goto end;
            left = &tempLeft;
        }
        if ((V_VT(right) & VT_TYPEMASK) == VT_DISPATCH)
        {
            hres = VARIANT_FetchDispatchValue(right, &tempRight);
            if (FAILED(hres)) goto end;
            right = &tempRight;
        }
    }

    lvt = V_VT(left)&VT_TYPEMASK;
    rvt = V_VT(right)&VT_TYPEMASK;

    /* If we have any flag set (VT_ARRAY, VT_VECTOR, etc.) bail out.
       Same for any input variant type > VT_I8 */
    if (V_VT(left) & ~VT_TYPEMASK || V_VT(right) & ~VT_TYPEMASK ||
        lvt > VT_I8 || rvt > VT_I8) {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }

    /* Determine the variant type to coerce to. */
    if (coerce[lvt] > coerce[rvt]) {
        resvt = prio2vt[coerce[lvt]];
        tvt = prio2vt[coerce[rvt]];
    } else {
        resvt = prio2vt[coerce[rvt]];
        tvt = prio2vt[coerce[lvt]];
    }

    /* Special cases where the result variant type is defined by both
       input variants and not only that with the highest priority */
    if (resvt == VT_BSTR) {
        if (tvt == VT_EMPTY || tvt == VT_BSTR)
            resvt = VT_BSTR;
        else
            resvt = VT_R8;
    }
    if (resvt == VT_R4 && (tvt == VT_BSTR || tvt == VT_I8 || tvt == VT_I4))
        resvt = VT_R8;

    /* For overflow detection use the biggest compatible type for the
       addition */
    switch (resvt) {
        case VT_ERROR:
            hres = DISP_E_BADVARTYPE;
            goto end;
        case VT_NULL:
            hres = S_OK;
            V_VT(result) = VT_NULL;
            goto end;
        case VT_DISPATCH:
            hres = DISP_E_TYPEMISMATCH;
            goto end;
        case VT_EMPTY:
            resvt = VT_I2;
            /* Fall through */
        case VT_UI1:
        case VT_I2:
        case VT_I4:
        case VT_I8:
            tvt = VT_I8;
            break;
        case VT_DATE:
        case VT_R4:
            tvt = VT_R8;
            break;
        default:
            tvt = resvt;
    }

    /* Now coerce the variants */
    hres = VariantChangeType(&lv, left, 0, tvt);
    if (FAILED(hres))
        goto end;
    hres = VariantChangeType(&rv, right, 0, tvt);
    if (FAILED(hres))
        goto end;

    /* Do the math */
    hres = S_OK;
    V_VT(result) = resvt;
    switch (tvt) {
        case VT_DECIMAL:
            hres = VarDecAdd(&V_DECIMAL(&lv), &V_DECIMAL(&rv),
                             &V_DECIMAL(result));
            goto end;
        case VT_CY:
            hres = VarCyAdd(V_CY(&lv), V_CY(&rv), &V_CY(result));
            goto end;
        case VT_BSTR:
            /* We do not add those, we concatenate them. */
            hres = VarBstrCat(V_BSTR(&lv), V_BSTR(&rv), &V_BSTR(result));
            goto end;
        case VT_I8:
            /* Overflow detection */
            r8res = (double)V_I8(&lv) + (double)V_I8(&rv);
            if (r8res > (double)I8_MAX || r8res < (double)I8_MIN) {
                V_VT(result) = VT_R8;
                V_R8(result) = r8res;
                goto end;
            } else {
                V_VT(&tv) = tvt;
                V_I8(&tv) = V_I8(&lv) + V_I8(&rv);
            }
            break;
        case VT_R8:
            V_VT(&tv) = tvt;
            /* //FixMe: overflow detection */
            V_R8(&tv) = V_R8(&lv) + V_R8(&rv);
            break;
        default:
            ERR("We shouldn't get here! tvt = %d!\n", tvt);
            break;
    }
    if (resvt != tvt) {
        if ((hres = VariantChangeType(result, &tv, 0, resvt)) != S_OK) {
            /* Overflow! Change to the vartype with the next higher priority.
               With one exception: I4 ==> R8 even if it would fit in I8 */
            if (resvt == VT_I4)
                resvt = VT_R8;
            else
                resvt = prio2vt[coerce[resvt] + 1];
            hres = VariantChangeType(result, &tv, 0, resvt);
        }
    } else
        hres = VariantCopy(result, &tv);

end:
    if (hres != S_OK) {
        V_VT(result) = VT_EMPTY;
        V_I4(result) = 0;       /* No V_EMPTY */
    }
    VariantClear(&lv);
    VariantClear(&rv);
    VariantClear(&tv);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);
    TRACE("returning 0x%8x (variant type %s)\n", hres, debugstr_VT(result));
    return hres;
}

/**********************************************************************
 *              VarMul [OLEAUT32.156]
 *
 * Multiply two variants.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  result  [O] Result variant
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  Native VarMul up to and including WinXP doesn't like I1, UI2, UI4,
 *  UI8, INT and UINT as input variants. But it can multiply apples with oranges.
 *
 *  Native VarMul doesn't check for NULL in/out pointers and crashes. We do the
 *  same here.
 *
 * //FixMe
 *  Overflow checking for R8 (double) overflow. Return DISP_E_OVERFLOW in that
 *  case.
 */
HRESULT WINAPI VarMul(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    HRESULT hres;
    VARTYPE lvt, rvt, resvt, tvt;
    VARIANT lv, rv, tv;
    VARIANT tempLeft, tempRight;
    double r8res;

    /* Variant priority for coercion. Sorted from lowest to highest.
       VT_ERROR shows an invalid input variant type. */
    enum coerceprio { vt_UI1 = 0, vt_I2, vt_I4, vt_I8, vt_CY, vt_R4, vt_R8,
                      vt_DECIMAL, vt_NULL, vt_ERROR };
    /* Mapping from priority to variant type. Keep in sync with coerceprio! */
    static const VARTYPE prio2vt[] = { VT_UI1, VT_I2, VT_I4, VT_I8, VT_CY, VT_R4, VT_R8,
                          VT_DECIMAL, VT_NULL, VT_ERROR };

    /* Mapping for coercion from input variant to priority of result variant. */
    static const VARTYPE coerce[] = {
        /* VT_EMPTY, VT_NULL, VT_I2, VT_I4, VT_R4 */
        vt_UI1, vt_NULL, vt_I2, vt_I4, vt_R4,
        /* VT_R8, VT_CY, VT_DATE, VT_BSTR, VT_DISPATCH */
        vt_R8, vt_CY, vt_R8, vt_R8, vt_ERROR,
        /* VT_ERROR, VT_BOOL, VT_VARIANT, VT_UNKNOWN, VT_DECIMAL */
        vt_ERROR, vt_I2, vt_ERROR, vt_ERROR, vt_DECIMAL,
        /* 15, VT_I1, VT_UI1, VT_UI2, VT_UI4 VT_I8 */
        vt_ERROR, vt_ERROR, vt_UI1, vt_ERROR, vt_ERROR, vt_I8
    };

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right),
          result);

    VariantInit(&lv);
    VariantInit(&rv);
    VariantInit(&tv);
    VariantInit(&tempLeft);
    VariantInit(&tempRight);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(left) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hres = VARIANT_FetchDispatchValue(left, &tempLeft);
        if (FAILED(hres)) goto end;
        left = &tempLeft;
    }
    if ((V_VT(right) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hres = VARIANT_FetchDispatchValue(right, &tempRight);
        if (FAILED(hres)) goto end;
        right = &tempRight;
    }

    lvt = V_VT(left)&VT_TYPEMASK;
    rvt = V_VT(right)&VT_TYPEMASK;

    /* If we have any flag set (VT_ARRAY, VT_VECTOR, etc.) bail out.
       Same for any input variant type > VT_I8 */
    if (V_VT(left) & ~VT_TYPEMASK || V_VT(right) & ~VT_TYPEMASK ||
        lvt > VT_I8 || rvt > VT_I8) {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }

    /* Determine the variant type to coerce to. */
    if (coerce[lvt] > coerce[rvt]) {
        resvt = prio2vt[coerce[lvt]];
        tvt = prio2vt[coerce[rvt]];
    } else {
        resvt = prio2vt[coerce[rvt]];
        tvt = prio2vt[coerce[lvt]];
    }

    /* Special cases where the result variant type is defined by both
       input variants and not only that with the highest priority */
    if (resvt == VT_R4 && (tvt == VT_CY || tvt == VT_I8 || tvt == VT_I4))
        resvt = VT_R8;
    if (lvt == VT_EMPTY && rvt == VT_EMPTY)
        resvt = VT_I2;

    /* For overflow detection use the biggest compatible type for the
       multiplication */
    switch (resvt) {
        case VT_ERROR:
            hres = DISP_E_BADVARTYPE;
            goto end;
        case VT_NULL:
            hres = S_OK;
            V_VT(result) = VT_NULL;
            goto end;
        case VT_UI1:
        case VT_I2:
        case VT_I4:
        case VT_I8:
            tvt = VT_I8;
            break;
        case VT_R4:
            tvt = VT_R8;
            break;
        default:
            tvt = resvt;
    }

    /* Now coerce the variants */
    hres = VariantChangeType(&lv, left, 0, tvt);
    if (FAILED(hres))
        goto end;
    hres = VariantChangeType(&rv, right, 0, tvt);
    if (FAILED(hres))
        goto end;

    /* Do the math */
    hres = S_OK;
    V_VT(&tv) = tvt;
    V_VT(result) = resvt;
    switch (tvt) {
        case VT_DECIMAL:
            hres = VarDecMul(&V_DECIMAL(&lv), &V_DECIMAL(&rv),
                             &V_DECIMAL(result));
            goto end;
        case VT_CY:
            hres = VarCyMul(V_CY(&lv), V_CY(&rv), &V_CY(result));
            goto end;
        case VT_I8:
            /* Overflow detection */
            r8res = (double)V_I8(&lv) * (double)V_I8(&rv);
            if (r8res > (double)I8_MAX || r8res < (double)I8_MIN) {
                V_VT(result) = VT_R8;
                V_R8(result) = r8res;
                goto end;
            } else
                V_I8(&tv) = V_I8(&lv) * V_I8(&rv);
            break;
        case VT_R8:
            /* //FixMe: overflow detection */
            V_R8(&tv) = V_R8(&lv) * V_R8(&rv);
            break;
        default:
            ERR("We shouldn't get here! tvt = %d!\n", tvt);
            break;
    }
    if (resvt != tvt) {
        while ((hres = VariantChangeType(result, &tv, 0, resvt)) != S_OK) {
            /* Overflow! Change to the vartype with the next higher priority.
               With one exception: I4 ==> R8 even if it would fit in I8 */
            if (resvt == VT_I4)
                resvt = VT_R8;
            else
                resvt = prio2vt[coerce[resvt] + 1];
        }
    } else
        hres = VariantCopy(result, &tv);

end:
    if (hres != S_OK) {
        V_VT(result) = VT_EMPTY;
        V_I4(result) = 0;       /* No V_EMPTY */
    }
    VariantClear(&lv);
    VariantClear(&rv);
    VariantClear(&tv);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);
    TRACE("returning 0x%8x (variant type %s)\n", hres, debugstr_VT(result));
    return hres;
}

/**********************************************************************
 *              VarDiv [OLEAUT32.143]
 *
 * Divides one variant with another.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  result  [O] Result variant
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: An HRESULT error code indicating the error.
 */
HRESULT WINAPI VarDiv(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    HRESULT hres = S_OK;
    VARTYPE resvt = VT_EMPTY;
    VARTYPE leftvt,rightvt;
    VARTYPE rightExtraFlags,leftExtraFlags,ExtraFlags;
    VARIANT lv,rv;
    VARIANT tempLeft, tempRight;

    VariantInit(&tempLeft);
    VariantInit(&tempRight);
    VariantInit(&lv);
    VariantInit(&rv);

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right), result);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(left) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hres = VARIANT_FetchDispatchValue(left, &tempLeft);
        if (FAILED(hres)) goto end;
        left = &tempLeft;
    }
    if ((V_VT(right) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hres = VARIANT_FetchDispatchValue(right, &tempRight);
        if (FAILED(hres)) goto end;
        right = &tempRight;
    }

    leftvt = V_VT(left)&VT_TYPEMASK;
    rightvt = V_VT(right)&VT_TYPEMASK;
    leftExtraFlags = V_VT(left)&(~VT_TYPEMASK);
    rightExtraFlags = V_VT(right)&(~VT_TYPEMASK);

    if (leftExtraFlags != rightExtraFlags)
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }
    ExtraFlags = leftExtraFlags;

    /* Native VarDiv always returns an error when using extra flags */
    if (ExtraFlags != 0)
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }

    /* Determine return type */
    if (!(rightvt == VT_EMPTY))
    {
        if (leftvt == VT_NULL || rightvt == VT_NULL)
        {
            V_VT(result) = VT_NULL;
            hres = S_OK;
            goto end;
        }
        else if (leftvt == VT_DECIMAL || rightvt == VT_DECIMAL)
            resvt = VT_DECIMAL;
        else if (leftvt == VT_I8 || rightvt == VT_I8 ||
            leftvt == VT_CY || rightvt == VT_CY ||
            leftvt == VT_DATE || rightvt == VT_DATE ||
            leftvt == VT_I4 || rightvt == VT_I4 ||
            leftvt == VT_BSTR || rightvt == VT_BSTR ||
            leftvt == VT_I2 || rightvt == VT_I2 ||
            leftvt == VT_BOOL || rightvt == VT_BOOL ||
            leftvt == VT_R8 || rightvt == VT_R8 ||
            leftvt == VT_UI1 || rightvt == VT_UI1)
        {
            if ((leftvt == VT_UI1 && rightvt == VT_R4) ||
                (leftvt == VT_R4 && rightvt == VT_UI1))
                resvt = VT_R4;
            else if ((leftvt == VT_R4 && (rightvt == VT_BOOL ||
                rightvt == VT_I2)) || (rightvt == VT_R4 &&
                (leftvt == VT_BOOL || leftvt == VT_I2)))
                resvt = VT_R4;
            else
                resvt = VT_R8;
        }
        else if (leftvt == VT_R4 || rightvt == VT_R4)
            resvt = VT_R4;
    }
    else if (leftvt == VT_NULL && rightvt == VT_EMPTY)
    {
        V_VT(result) = VT_NULL;
        hres = S_OK;
        goto end;
    }
    else
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }

    /* coerce to the result type */
    hres = VariantChangeType(&lv, left, 0, resvt);
    if (hres != S_OK) goto end;

    hres = VariantChangeType(&rv, right, 0, resvt);
    if (hres != S_OK) goto end;

    /* do the math */
    V_VT(result) = resvt;
    switch (resvt)
    {
    case VT_R4:
    if (V_R4(&lv) == 0.0 && V_R4(&rv) == 0.0)
    {
        hres = DISP_E_OVERFLOW;
        V_VT(result) = VT_EMPTY;
    }
    else if (V_R4(&rv) == 0.0)
    {
        hres = DISP_E_DIVBYZERO;
        V_VT(result) = VT_EMPTY;
    }
    else
        V_R4(result) = V_R4(&lv) / V_R4(&rv);
    break;
    case VT_R8:
    if (V_R8(&lv) == 0.0 && V_R8(&rv) == 0.0)
    {
        hres = DISP_E_OVERFLOW;
        V_VT(result) = VT_EMPTY;
    }
    else if (V_R8(&rv) == 0.0)
    {
        hres = DISP_E_DIVBYZERO;
        V_VT(result) = VT_EMPTY;
    }
    else
        V_R8(result) = V_R8(&lv) / V_R8(&rv);
    break;
    case VT_DECIMAL:
    hres = VarDecDiv(&(V_DECIMAL(&lv)), &(V_DECIMAL(&rv)), &(V_DECIMAL(result)));
    break;
    }

end:
    VariantClear(&lv);
    VariantClear(&rv);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);
    TRACE("returning 0x%8x (variant type %s)\n", hres, debugstr_VT(result));
    return hres;
}

/**********************************************************************
 *              VarSub [OLEAUT32.159]
 *
 * Subtract two variants.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  result  [O] Result variant
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: An HRESULT error code indicating the error.
 */
HRESULT WINAPI VarSub(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    HRESULT hres = S_OK;
    VARTYPE resvt = VT_EMPTY;
    VARTYPE leftvt,rightvt;
    VARTYPE rightExtraFlags,leftExtraFlags,ExtraFlags;
    VARIANT lv,rv;
    VARIANT tempLeft, tempRight;

    VariantInit(&lv);
    VariantInit(&rv);
    VariantInit(&tempLeft);
    VariantInit(&tempRight);

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right), result);

    if ((V_VT(left) & VT_TYPEMASK) == VT_DISPATCH &&
        (V_VT(left)&(~VT_TYPEMASK)) == 0 &&
        (V_VT(right) & VT_TYPEMASK) != VT_NULL)
    {
        if (NULL == V_DISPATCH(left)) {
            if ((V_VT(right) & VT_TYPEMASK) >= VT_INT_PTR)
                hres = DISP_E_BADVARTYPE;
            else if ((V_VT(right) & VT_TYPEMASK) >= VT_UI8 &&
                (V_VT(right) & VT_TYPEMASK) < VT_RECORD)
                hres = DISP_E_BADVARTYPE;
            else switch (V_VT(right) & VT_TYPEMASK)
            {
            case VT_VARIANT:
            case VT_UNKNOWN:
            case 15:
            case VT_I1:
            case VT_UI2:
            case VT_UI4:
                hres = DISP_E_BADVARTYPE;
            }
            if (FAILED(hres)) goto end;
        }
        hres = VARIANT_FetchDispatchValue(left, &tempLeft);
        if (FAILED(hres)) goto end;
        left = &tempLeft;
    }
    if ((V_VT(right) & VT_TYPEMASK) == VT_DISPATCH &&
        (V_VT(right)&(~VT_TYPEMASK)) == 0 &&
        (V_VT(left) & VT_TYPEMASK) != VT_NULL)
    {
        if (NULL == V_DISPATCH(right))
        {
            if ((V_VT(left) & VT_TYPEMASK) >= VT_INT_PTR)
                hres = DISP_E_BADVARTYPE;
            else if ((V_VT(left) & VT_TYPEMASK) >= VT_UI8 &&
                (V_VT(left) & VT_TYPEMASK) < VT_RECORD)
                hres = DISP_E_BADVARTYPE;
            else switch (V_VT(left) & VT_TYPEMASK)
            {
            case VT_VARIANT:
            case VT_UNKNOWN:
            case 15:
            case VT_I1:
            case VT_UI2:
            case VT_UI4:
                hres = DISP_E_BADVARTYPE;
            }
            if (FAILED(hres)) goto end;
        }
        hres = VARIANT_FetchDispatchValue(right, &tempRight);
        if (FAILED(hres)) goto end;
        right = &tempRight;
    }

    leftvt = V_VT(left)&VT_TYPEMASK;
    rightvt = V_VT(right)&VT_TYPEMASK;
    leftExtraFlags = V_VT(left)&(~VT_TYPEMASK);
    rightExtraFlags = V_VT(right)&(~VT_TYPEMASK);

    if (leftExtraFlags != rightExtraFlags)
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }
    ExtraFlags = leftExtraFlags;

    /* determine return type and return code */
    /* All extra flags produce errors */
    if (ExtraFlags == (VT_VECTOR|VT_BYREF|VT_RESERVED) ||
        ExtraFlags == (VT_VECTOR|VT_RESERVED) ||
        ExtraFlags == (VT_VECTOR|VT_BYREF) ||
        ExtraFlags == (VT_BYREF|VT_RESERVED) ||
        ExtraFlags == VT_VECTOR ||
        ExtraFlags == VT_BYREF ||
        ExtraFlags == VT_RESERVED)
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }
    else if (ExtraFlags >= VT_ARRAY)
    {
        hres = DISP_E_TYPEMISMATCH;
        goto end;
    }
    /* Native VarSub cannot handle: VT_I1, VT_UI2, VT_UI4,
       VT_INT, VT_UINT and VT_UI8. Tested with WinXP */
    else if (leftvt == VT_CLSID || rightvt == VT_CLSID ||
        leftvt == VT_VARIANT || rightvt == VT_VARIANT ||
        leftvt == VT_I1 || rightvt == VT_I1 ||
        leftvt == VT_UI2 || rightvt == VT_UI2 ||
        leftvt == VT_UI4 || rightvt == VT_UI4 ||
        leftvt == VT_UI8 || rightvt == VT_UI8 ||
        leftvt == VT_INT || rightvt == VT_INT ||
        leftvt == VT_UINT || rightvt == VT_UINT ||
        leftvt == VT_UNKNOWN || rightvt == VT_UNKNOWN ||
        leftvt == VT_RECORD || rightvt == VT_RECORD)
    {
        if (leftvt == VT_RECORD && rightvt == VT_I8)
            hres = DISP_E_TYPEMISMATCH;
        else if (leftvt < VT_UI1 && rightvt == VT_RECORD)
            hres = DISP_E_TYPEMISMATCH;
        else if (leftvt >= VT_UI1 && rightvt == VT_RECORD)
            hres = DISP_E_TYPEMISMATCH;
        else if (leftvt == VT_RECORD && rightvt <= VT_UI1)
            hres = DISP_E_TYPEMISMATCH;
        else if (leftvt == VT_RECORD && rightvt > VT_UI1)
            hres = DISP_E_BADVARTYPE;
        else
            hres = DISP_E_BADVARTYPE;
        goto end;
    }
    /*  The following flags/types are invalid for left variant */
    else if (!((leftvt <= VT_LPWSTR || leftvt == VT_RECORD ||
        leftvt == VT_CLSID) && leftvt != (VARTYPE)15 /* undefined vt */ &&
        (leftvt < VT_VOID || leftvt > VT_LPWSTR)))
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }
    /*  The following flags/types are invalid for right variant */
    else if (!((rightvt <= VT_LPWSTR || rightvt == VT_RECORD ||
        rightvt == VT_CLSID) && rightvt != (VARTYPE)15 /* undefined vt */ &&
        (rightvt < VT_VOID || rightvt > VT_LPWSTR)))
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }
    else if ((leftvt == VT_NULL && rightvt == VT_DISPATCH) ||
        (leftvt == VT_DISPATCH && rightvt == VT_NULL))
        resvt = VT_NULL;
    else if (leftvt == VT_DISPATCH || rightvt == VT_DISPATCH ||
        leftvt == VT_ERROR || rightvt == VT_ERROR)
    {
        hres = DISP_E_TYPEMISMATCH;
        goto end;
    }
    else if (leftvt == VT_NULL || rightvt == VT_NULL)
        resvt = VT_NULL;
    else if ((leftvt == VT_EMPTY && rightvt == VT_BSTR) ||
        (leftvt == VT_DATE && rightvt == VT_DATE) ||
        (leftvt == VT_BSTR && rightvt == VT_EMPTY) ||
        (leftvt == VT_BSTR && rightvt == VT_BSTR))
        resvt = VT_R8;
    else if (leftvt == VT_DECIMAL || rightvt == VT_DECIMAL)
        resvt = VT_DECIMAL;
    else if (leftvt == VT_DATE || rightvt == VT_DATE)
        resvt = VT_DATE;
    else if (leftvt == VT_CY || rightvt == VT_CY)
        resvt = VT_CY;
    else if (leftvt == VT_R8 || rightvt == VT_R8)
        resvt = VT_R8;
    else if (leftvt == VT_BSTR || rightvt == VT_BSTR)
        resvt = VT_R8;
    else if (leftvt == VT_R4 || rightvt == VT_R4)
    {
        if (leftvt == VT_I4 || rightvt == VT_I4 ||
            leftvt == VT_I8 || rightvt == VT_I8)
            resvt = VT_R8;
        else
            resvt = VT_R4;
    }
    else if (leftvt == VT_I8 || rightvt == VT_I8)
        resvt = VT_I8;
    else if (leftvt == VT_I4 || rightvt == VT_I4)
        resvt = VT_I4;
    else if (leftvt == VT_I2 || rightvt == VT_I2 ||
        leftvt == VT_BOOL || rightvt == VT_BOOL ||
        (leftvt == VT_EMPTY && rightvt == VT_EMPTY))
        resvt = VT_I2;
    else if (leftvt == VT_UI1 || rightvt == VT_UI1)
        resvt = VT_UI1;
    else
    {
        hres = DISP_E_TYPEMISMATCH;
        goto end;
    }

    /* coerce to the result type */
    if (leftvt == VT_BSTR && rightvt == VT_DATE)
        hres = VariantChangeType(&lv, left, 0, VT_R8);
    else
        hres = VariantChangeType(&lv, left, 0, resvt);
    if (hres != S_OK) goto end;
    if (leftvt == VT_DATE && rightvt == VT_BSTR)
        hres = VariantChangeType(&rv, right, 0, VT_R8);
    else
        hres = VariantChangeType(&rv, right, 0, resvt);
    if (hres != S_OK) goto end;

    /* do the math */
    V_VT(result) = resvt;
    switch (resvt)
    {
    case VT_NULL:
    break;
    case VT_DATE:
    V_DATE(result) = V_DATE(&lv) - V_DATE(&rv);
    break;
    case VT_CY:
    hres = VarCySub(V_CY(&lv), V_CY(&rv), &(V_CY(result)));
    break;
    case VT_R4:
    V_R4(result) = V_R4(&lv) - V_R4(&rv);
    break;
    case VT_I8:
    V_I8(result) = V_I8(&lv) - V_I8(&rv);
    break;
    case VT_I4:
    V_I4(result) = V_I4(&lv) - V_I4(&rv);
    break;
    case VT_I2:
    V_I2(result) = V_I2(&lv) - V_I2(&rv);
    break;
    case VT_I1:
    V_I1(result) = V_I1(&lv) - V_I1(&rv);
    break;
    case VT_UI1:
    V_UI1(result) = V_UI2(&lv) - V_UI1(&rv);
    break;
    case VT_R8:
    V_R8(result) = V_R8(&lv) - V_R8(&rv);
    break;
    case VT_DECIMAL:
    hres = VarDecSub(&(V_DECIMAL(&lv)), &(V_DECIMAL(&rv)), &(V_DECIMAL(result)));
    break;
    }

end:
    VariantClear(&lv);
    VariantClear(&rv);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);
    TRACE("returning 0x%8x (variant type %s)\n", hres, debugstr_VT(result));
    return hres;
}


/**********************************************************************
 *              VarOr [OLEAUT32.157]
 *
 * Perform a logical or (OR) operation on two variants.
 *
 * PARAMS
 *  pVarLeft  [I] First variant
 *  pVarRight [I] Variant to OR with pVarLeft
 *  pVarOut   [O] Destination for OR result
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the result of the operation with its type
 *           taken from the table listed under VarXor().
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  See the Notes section of VarXor() for further information.
 */
HRESULT WINAPI VarOr(LPVARIANT pVarLeft, LPVARIANT pVarRight, LPVARIANT pVarOut)
{
    VARTYPE vt = VT_I4;
    VARIANT varLeft, varRight, varStr;
    HRESULT hRet;
    VARIANT tempLeft, tempRight;

    VariantInit(&tempLeft);
    VariantInit(&tempRight);
    VariantInit(&varLeft);
    VariantInit(&varRight);
    VariantInit(&varStr);

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", pVarLeft, debugstr_VT(pVarLeft),
          debugstr_VF(pVarLeft), pVarRight, debugstr_VT(pVarRight),
          debugstr_VF(pVarRight), pVarOut);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(pVarLeft) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hRet = VARIANT_FetchDispatchValue(pVarLeft, &tempLeft);
        if (FAILED(hRet)) goto VarOr_Exit;
        pVarLeft = &tempLeft;
    }
    if ((V_VT(pVarRight) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hRet = VARIANT_FetchDispatchValue(pVarRight, &tempRight);
        if (FAILED(hRet)) goto VarOr_Exit;
        pVarRight = &tempRight;
    }

    if (V_EXTRA_TYPE(pVarLeft) || V_EXTRA_TYPE(pVarRight) ||
        V_VT(pVarLeft) == VT_UNKNOWN || V_VT(pVarRight) == VT_UNKNOWN ||
        V_VT(pVarLeft) == VT_DISPATCH || V_VT(pVarRight) == VT_DISPATCH ||
        V_VT(pVarLeft) == VT_RECORD || V_VT(pVarRight) == VT_RECORD)
    {
        hRet = DISP_E_BADVARTYPE;
        goto VarOr_Exit;
    }

    V_VT(&varLeft) = V_VT(&varRight) = V_VT(&varStr) = VT_EMPTY;

    if (V_VT(pVarLeft) == VT_NULL || V_VT(pVarRight) == VT_NULL)
    {
        /* NULL OR Zero is NULL, NULL OR value is value */
        if (V_VT(pVarLeft) == VT_NULL)
            pVarLeft = pVarRight; /* point to the non-NULL var */

        V_VT(pVarOut) = VT_NULL;
        V_I4(pVarOut) = 0;

        switch (V_VT(pVarLeft))
        {
        case VT_DATE: case VT_R8:
            if (V_R8(pVarLeft))
                goto VarOr_AsEmpty;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_BOOL:
            if (V_BOOL(pVarLeft))
                *pVarOut = *pVarLeft;
            hRet = S_OK;
            goto VarOr_Exit;
         case VT_I2: case VT_UI2:
            if (V_I2(pVarLeft))
                goto VarOr_AsEmpty;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_I1:
            if (V_I1(pVarLeft))
                goto VarOr_AsEmpty;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_UI1:
            if (V_UI1(pVarLeft))
                *pVarOut = *pVarLeft;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_R4:
            if (V_R4(pVarLeft))
                goto VarOr_AsEmpty;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_I4: case VT_UI4: case VT_INT: case VT_UINT:
            if (V_I4(pVarLeft))
                goto VarOr_AsEmpty;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_CY:
            if (V_CY(pVarLeft).int64)
                goto VarOr_AsEmpty;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_I8: case VT_UI8:
            if (V_I8(pVarLeft))
                goto VarOr_AsEmpty;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_DECIMAL:
            if (DEC_HI32(&V_DECIMAL(pVarLeft)) || DEC_LO64(&V_DECIMAL(pVarLeft)))
                goto VarOr_AsEmpty;
            hRet = S_OK;
            goto VarOr_Exit;
        case VT_BSTR:
        {
            VARIANT_BOOL b;

            if (!V_BSTR(pVarLeft))
            {
                hRet = DISP_E_BADVARTYPE;
                goto VarOr_Exit;
            }

            hRet = VarBoolFromStr(V_BSTR(pVarLeft), LOCALE_USER_DEFAULT, VAR_LOCALBOOL, &b);
            if (SUCCEEDED(hRet) && b)
            {
                V_VT(pVarOut) = VT_BOOL;
                V_BOOL(pVarOut) = b;
            }
            goto VarOr_Exit;
        }
        case VT_NULL: case VT_EMPTY:
            V_VT(pVarOut) = VT_NULL;
            hRet = S_OK;
            goto VarOr_Exit;
        default:
            hRet = DISP_E_BADVARTYPE;
            goto VarOr_Exit;
        }
    }

    if (V_VT(pVarLeft) == VT_EMPTY || V_VT(pVarRight) == VT_EMPTY)
    {
        if (V_VT(pVarLeft) == VT_EMPTY)
            pVarLeft = pVarRight; /* point to the non-EMPTY var */

VarOr_AsEmpty:
        /* Since one argument is empty (0), OR'ing it with the other simply
         * gives the others value (as 0|x => x). So just convert the other
         * argument to the required result type.
         */
        switch (V_VT(pVarLeft))
        {
        case VT_BSTR:
            if (!V_BSTR(pVarLeft))
            {
                hRet = DISP_E_BADVARTYPE;
                goto VarOr_Exit;
            }

            hRet = VariantCopy(&varStr, pVarLeft);
            if (FAILED(hRet))
                goto VarOr_Exit;
            pVarLeft = &varStr;
            hRet = VariantChangeType(pVarLeft, pVarLeft, 0, VT_BOOL);
            if (FAILED(hRet))
                goto VarOr_Exit;
            /* Fall Through ... */
        case VT_EMPTY: case VT_UI1: case VT_BOOL: case VT_I2:
            V_VT(pVarOut) = VT_I2;
            break;
        case VT_DATE: case VT_CY: case VT_DECIMAL: case VT_R4: case VT_R8:
        case VT_I1: case VT_UI2: case VT_I4: case VT_UI4:
        case VT_INT: case VT_UINT: case VT_UI8:
            V_VT(pVarOut) = VT_I4;
            break;
        case VT_I8:
            V_VT(pVarOut) = VT_I8;
            break;
        default:
            hRet = DISP_E_BADVARTYPE;
            goto VarOr_Exit;
        }
        hRet = VariantCopy(&varLeft, pVarLeft);
        if (FAILED(hRet))
            goto VarOr_Exit;
        pVarLeft = &varLeft;
        hRet = VariantChangeType(pVarOut, pVarLeft, 0, V_VT(pVarOut));
        goto VarOr_Exit;
    }

    if (V_VT(pVarLeft) == VT_BOOL && V_VT(pVarRight) == VT_BOOL)
    {
        V_VT(pVarOut) = VT_BOOL;
        V_BOOL(pVarOut) = V_BOOL(pVarLeft) | V_BOOL(pVarRight);
        hRet = S_OK;
        goto VarOr_Exit;
    }

    if (V_VT(pVarLeft) == VT_UI1 && V_VT(pVarRight) == VT_UI1)
    {
        V_VT(pVarOut) = VT_UI1;
        V_UI1(pVarOut) = V_UI1(pVarLeft) | V_UI1(pVarRight);
        hRet = S_OK;
        goto VarOr_Exit;
    }

    if (V_VT(pVarLeft) == VT_BSTR)
    {
        hRet = VariantCopy(&varStr, pVarLeft);
        if (FAILED(hRet))
            goto VarOr_Exit;
        pVarLeft = &varStr;
        hRet = VariantChangeType(pVarLeft, pVarLeft, 0, VT_BOOL);
        if (FAILED(hRet))
            goto VarOr_Exit;
    }

    if (V_VT(pVarLeft) == VT_BOOL &&
        (V_VT(pVarRight) == VT_BOOL || V_VT(pVarRight) == VT_BSTR))
    {
        vt = VT_BOOL;
    }
    else if ((V_VT(pVarLeft) == VT_BOOL || V_VT(pVarLeft) == VT_UI1 ||
        V_VT(pVarLeft) == VT_I2 || V_VT(pVarLeft) == VT_BSTR) &&
        (V_VT(pVarRight) == VT_BOOL || V_VT(pVarRight) == VT_UI1 ||
        V_VT(pVarRight) == VT_I2 || V_VT(pVarRight) == VT_BSTR))
    {
        vt = VT_I2;
    }
    else if (V_VT(pVarLeft) == VT_I8 || V_VT(pVarRight) == VT_I8)
    {
        if (V_VT(pVarLeft) == VT_INT || V_VT(pVarRight) == VT_INT)
        {
            hRet = DISP_E_TYPEMISMATCH;
            goto VarOr_Exit;
        }
        vt = VT_I8;
    }

    hRet = VariantCopy(&varLeft, pVarLeft);
    if (FAILED(hRet))
        goto VarOr_Exit;

    hRet = VariantCopy(&varRight, pVarRight);
    if (FAILED(hRet))
        goto VarOr_Exit;

    if (vt == VT_I4 && V_VT(&varLeft) == VT_UI4)
        V_VT(&varLeft) = VT_I4; /* Don't overflow */
    else
    {
        double d;

        if (V_VT(&varLeft) == VT_BSTR &&
            FAILED(VarR8FromStr(V_BSTR(&varLeft), LOCALE_USER_DEFAULT, 0, &d)))
            hRet = VariantChangeType(&varLeft, &varLeft, VARIANT_LOCALBOOL, VT_BOOL);
        if (SUCCEEDED(hRet) && V_VT(&varLeft) != vt)
            hRet = VariantChangeType(&varLeft, &varLeft, 0, vt);
        if (FAILED(hRet))
            goto VarOr_Exit;
    }

    if (vt == VT_I4 && V_VT(&varRight) == VT_UI4)
        V_VT(&varRight) = VT_I4; /* Don't overflow */
    else
    {
        double d;

        if (V_VT(&varRight) == VT_BSTR &&
            FAILED(VarR8FromStr(V_BSTR(&varRight), LOCALE_USER_DEFAULT, 0, &d)))
            hRet = VariantChangeType(&varRight, &varRight, VARIANT_LOCALBOOL, VT_BOOL);
        if (SUCCEEDED(hRet) && V_VT(&varRight) != vt)
            hRet = VariantChangeType(&varRight, &varRight, 0, vt);
        if (FAILED(hRet))
            goto VarOr_Exit;
    }

    V_VT(pVarOut) = vt;
    if (vt == VT_I8)
    {
        V_I8(pVarOut) = V_I8(&varLeft) | V_I8(&varRight);
    }
    else if (vt == VT_I4)
    {
        V_I4(pVarOut) = V_I4(&varLeft) | V_I4(&varRight);
    }
    else
    {
        V_I2(pVarOut) = V_I2(&varLeft) | V_I2(&varRight);
    }

VarOr_Exit:
    VariantClear(&varStr);
    VariantClear(&varLeft);
    VariantClear(&varRight);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);
    return hRet;
}

/**********************************************************************
 * VarAbs [OLEAUT32.168]
 *
 * Convert a variant to its absolute value.
 *
 * PARAMS
 *  pVarIn  [I] Source variant
 *  pVarOut [O] Destination for converted value
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the absolute value of pVarIn.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  - This function does not process by-reference variants.
 *  - The type of the value stored in pVarOut depends on the type of pVarIn,
 *    according to the following table:
 *| Input Type       Output Type
 *| ----------       -----------
 *| VT_BOOL          VT_I2
 *| VT_BSTR          VT_R8
 *| (All others)     Unchanged
 */
HRESULT WINAPI VarAbs(LPVARIANT pVarIn, LPVARIANT pVarOut)
{
    VARIANT varIn;
    HRESULT hRet = S_OK;
    VARIANT temp;

    VariantInit(&temp);

    TRACE("(%p->(%s%s),%p)\n", pVarIn, debugstr_VT(pVarIn),
          debugstr_VF(pVarIn), pVarOut);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(pVarIn) & VT_TYPEMASK) == VT_DISPATCH && ((V_VT(pVarIn) & ~VT_TYPEMASK) == 0))
    {
        hRet = VARIANT_FetchDispatchValue(pVarIn, &temp);
        if (FAILED(hRet)) goto VarAbs_Exit;
        pVarIn = &temp;
    }

    if (V_ISARRAY(pVarIn) || V_VT(pVarIn) == VT_UNKNOWN ||
        V_VT(pVarIn) == VT_DISPATCH || V_VT(pVarIn) == VT_RECORD ||
        V_VT(pVarIn) == VT_ERROR)
    {
        hRet = DISP_E_TYPEMISMATCH;
        goto VarAbs_Exit;
    }
    *pVarOut = *pVarIn; /* Shallow copy the value, and invert it if needed */

#define ABS_CASE(typ,min) \
    case VT_##typ: if (V_##typ(pVarIn) == min) hRet = DISP_E_OVERFLOW; \
                  else if (V_##typ(pVarIn) < 0) V_##typ(pVarOut) = -V_##typ(pVarIn); \
                  break

    switch (V_VT(pVarIn))
    {
    ABS_CASE(I1,I1_MIN);
    case VT_BOOL:
        V_VT(pVarOut) = VT_I2;
        /* BOOL->I2, Fall through ... */
    ABS_CASE(I2,I2_MIN);
    case VT_INT:
    ABS_CASE(I4,I4_MIN);
    ABS_CASE(I8,I8_MIN);
    ABS_CASE(R4,R4_MIN);
    case VT_BSTR:
        hRet = VarR8FromStr(V_BSTR(pVarIn), LOCALE_USER_DEFAULT, 0, &V_R8(&varIn));
        if (FAILED(hRet))
            break;
        V_VT(pVarOut) = VT_R8;
        pVarIn = &varIn;
        /* Fall through ... */
    case VT_DATE:
    ABS_CASE(R8,R8_MIN);
    case VT_CY:
        hRet = VarCyAbs(V_CY(pVarIn), & V_CY(pVarOut));
        break;
    case VT_DECIMAL:
        DEC_SIGN(&V_DECIMAL(pVarOut)) &= ~DECIMAL_NEG;
        break;
    case VT_UI1:
    case VT_UI2:
    case VT_UINT:
    case VT_UI4:
    case VT_UI8:
        /* No-Op */
        break;
    case VT_EMPTY:
        V_VT(pVarOut) = VT_I2;
    case VT_NULL:
        V_I2(pVarOut) = 0;
        break;
    default:
        hRet = DISP_E_BADVARTYPE;
    }

VarAbs_Exit:
    VariantClear(&temp);
    return hRet;
}

/**********************************************************************
 *              VarFix [OLEAUT32.169]
 *
 * Truncate a variants value to a whole number.
 *
 * PARAMS
 *  pVarIn  [I] Source variant
 *  pVarOut [O] Destination for converted value
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the converted value.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  - The type of the value stored in pVarOut depends on the type of pVarIn,
 *    according to the following table:
 *| Input Type       Output Type
 *| ----------       -----------
 *|  VT_BOOL          VT_I2
 *|  VT_EMPTY         VT_I2
 *|  VT_BSTR          VT_R8
 *|  All Others       Unchanged
 *  - The difference between this function and VarInt() is that VarInt() rounds
 *    negative numbers away from 0, while this function rounds them towards zero.
 */
HRESULT WINAPI VarFix(LPVARIANT pVarIn, LPVARIANT pVarOut)
{
    HRESULT hRet = S_OK;
    VARIANT temp;

    VariantInit(&temp);

    TRACE("(%p->(%s%s),%p)\n", pVarIn, debugstr_VT(pVarIn),
          debugstr_VF(pVarIn), pVarOut);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(pVarIn) & VT_TYPEMASK) == VT_DISPATCH && ((V_VT(pVarIn) & ~VT_TYPEMASK) == 0))
    {
        hRet = VARIANT_FetchDispatchValue(pVarIn, &temp);
        if (FAILED(hRet)) goto VarFix_Exit;
        pVarIn = &temp;
    }
    V_VT(pVarOut) = V_VT(pVarIn);

    switch (V_VT(pVarIn))
    {
    case VT_UI1:
        V_UI1(pVarOut) = V_UI1(pVarIn);
        break;
    case VT_BOOL:
        V_VT(pVarOut) = VT_I2;
        /* Fall through */
     case VT_I2:
        V_I2(pVarOut) = V_I2(pVarIn);
        break;
     case VT_I4:
        V_I4(pVarOut) = V_I4(pVarIn);
        break;
     case VT_I8:
        V_I8(pVarOut) = V_I8(pVarIn);
        break;
    case VT_R4:
        if (V_R4(pVarIn) < 0.0f)
            V_R4(pVarOut) = (float)ceil(V_R4(pVarIn));
        else
            V_R4(pVarOut) = (float)floor(V_R4(pVarIn));
        break;
    case VT_BSTR:
        V_VT(pVarOut) = VT_R8;
        hRet = VarR8FromStr(V_BSTR(pVarIn), LOCALE_USER_DEFAULT, 0, &V_R8(pVarOut));
        pVarIn = pVarOut;
        /* Fall through */
    case VT_DATE:
    case VT_R8:
        if (V_R8(pVarIn) < 0.0)
            V_R8(pVarOut) = ceil(V_R8(pVarIn));
        else
            V_R8(pVarOut) = floor(V_R8(pVarIn));
        break;
    case VT_CY:
        hRet = VarCyFix(V_CY(pVarIn), &V_CY(pVarOut));
        break;
    case VT_DECIMAL:
        hRet = VarDecFix(&V_DECIMAL(pVarIn), &V_DECIMAL(pVarOut));
        break;
    case VT_EMPTY:
        V_VT(pVarOut) = VT_I2;
        V_I2(pVarOut) = 0;
        break;
    case VT_NULL:
        /* No-Op */
        break;
    default:
        if (V_TYPE(pVarIn) == VT_CLSID || /* VT_CLSID is a special case */
            FAILED(VARIANT_ValidateType(V_VT(pVarIn))))
            hRet = DISP_E_BADVARTYPE;
        else
            hRet = DISP_E_TYPEMISMATCH;
    }
VarFix_Exit:
    if (FAILED(hRet))
      V_VT(pVarOut) = VT_EMPTY;
    VariantClear(&temp);

    return hRet;
}

/**********************************************************************
 *              VarInt [OLEAUT32.172]
 *
 * Truncate a variants value to a whole number.
 *
 * PARAMS
 *  pVarIn  [I] Source variant
 *  pVarOut [O] Destination for converted value
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the converted value.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  - The type of the value stored in pVarOut depends on the type of pVarIn,
 *    according to the following table:
 *| Input Type       Output Type
 *| ----------       -----------
 *|  VT_BOOL          VT_I2
 *|  VT_EMPTY         VT_I2
 *|  VT_BSTR          VT_R8
 *|  All Others       Unchanged
 *  - The difference between this function and VarFix() is that VarFix() rounds
 *    negative numbers towards 0, while this function rounds them away from zero.
 */
HRESULT WINAPI VarInt(LPVARIANT pVarIn, LPVARIANT pVarOut)
{
    HRESULT hRet = S_OK;
    VARIANT temp;

    VariantInit(&temp);

    TRACE("(%p->(%s%s),%p)\n", pVarIn, debugstr_VT(pVarIn),
          debugstr_VF(pVarIn), pVarOut);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(pVarIn) & VT_TYPEMASK) == VT_DISPATCH && ((V_VT(pVarIn) & ~VT_TYPEMASK) == 0))
    {
        hRet = VARIANT_FetchDispatchValue(pVarIn, &temp);
        if (FAILED(hRet)) goto VarInt_Exit;
        pVarIn = &temp;
    }
    V_VT(pVarOut) = V_VT(pVarIn);

    switch (V_VT(pVarIn))
    {
    case VT_R4:
        V_R4(pVarOut) = (float)floor(V_R4(pVarIn));
        break;
    case VT_BSTR:
        V_VT(pVarOut) = VT_R8;
        hRet = VarR8FromStr(V_BSTR(pVarIn), LOCALE_USER_DEFAULT, 0, &V_R8(pVarOut));
        pVarIn = pVarOut;
        /* Fall through */
    case VT_DATE:
    case VT_R8:
        V_R8(pVarOut) = floor(V_R8(pVarIn));
        break;
    case VT_CY:
        hRet = VarCyInt(V_CY(pVarIn), &V_CY(pVarOut));
        break;
    case VT_DECIMAL:
        hRet = VarDecInt(&V_DECIMAL(pVarIn), &V_DECIMAL(pVarOut));
        break;
    default:
        hRet = VarFix(pVarIn, pVarOut);
    }
VarInt_Exit:
    VariantClear(&temp);

    return hRet;
}

/**********************************************************************
 *              VarXor [OLEAUT32.167]
 *
 * Perform a logical exclusive-or (XOR) operation on two variants.
 *
 * PARAMS
 *  pVarLeft  [I] First variant
 *  pVarRight [I] Variant to XOR with pVarLeft
 *  pVarOut   [O] Destination for XOR result
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the result of the operation with its type
 *           taken from the table below).
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  - Neither pVarLeft or pVarRight are modified by this function.
 *  - This function does not process by-reference variants.
 *  - Input types of VT_BSTR may be numeric strings or boolean text.
 *  - The type of result stored in pVarOut depends on the types of pVarLeft
 *    and pVarRight, and will be one of VT_UI1, VT_I2, VT_I4, VT_I8, VT_BOOL,
 *    or VT_NULL if the function succeeds.
 *  - Type promotion is inconsistent and as a result certain combinations of
 *    values will return DISP_E_OVERFLOW even when they could be represented.
 *    This matches the behaviour of native oleaut32.
 */
HRESULT WINAPI VarXor(LPVARIANT pVarLeft, LPVARIANT pVarRight, LPVARIANT pVarOut)
{
    VARTYPE vt;
    VARIANT varLeft, varRight;
    VARIANT tempLeft, tempRight;
    double d;
    HRESULT hRet;

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", pVarLeft, debugstr_VT(pVarLeft),
          debugstr_VF(pVarLeft), pVarRight, debugstr_VT(pVarRight),
          debugstr_VF(pVarRight), pVarOut);

    if (V_EXTRA_TYPE(pVarLeft) || V_EXTRA_TYPE(pVarRight) ||
        V_VT(pVarLeft) > VT_UINT || V_VT(pVarRight) > VT_UINT ||
        V_VT(pVarLeft) == VT_VARIANT || V_VT(pVarRight) == VT_VARIANT ||
        V_VT(pVarLeft) == VT_UNKNOWN || V_VT(pVarRight) == VT_UNKNOWN ||
        V_VT(pVarLeft) == (VARTYPE)15 || V_VT(pVarRight) == (VARTYPE)15 ||
        V_VT(pVarLeft) == VT_ERROR || V_VT(pVarRight) == VT_ERROR)
        return DISP_E_BADVARTYPE;

    if (V_VT(pVarLeft) == VT_NULL || V_VT(pVarRight) == VT_NULL)
    {
        /* NULL XOR anything valid is NULL */
        V_VT(pVarOut) = VT_NULL;
        return S_OK;
    }

    VariantInit(&tempLeft);
    VariantInit(&tempRight);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(pVarLeft) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hRet = VARIANT_FetchDispatchValue(pVarLeft, &tempLeft);
        if (FAILED(hRet)) goto VarXor_Exit;
        pVarLeft = &tempLeft;
    }
    if ((V_VT(pVarRight) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hRet = VARIANT_FetchDispatchValue(pVarRight, &tempRight);
        if (FAILED(hRet)) goto VarXor_Exit;
        pVarRight = &tempRight;
    }

    /* Copy our inputs so we don't disturb anything */
    V_VT(&varLeft) = V_VT(&varRight) = VT_EMPTY;

    hRet = VariantCopy(&varLeft, pVarLeft);
    if (FAILED(hRet))
        goto VarXor_Exit;

    hRet = VariantCopy(&varRight, pVarRight);
    if (FAILED(hRet))
        goto VarXor_Exit;

    /* Try any strings first as numbers, then as VT_BOOL */
    if (V_VT(&varLeft) == VT_BSTR)
    {
        hRet = VarR8FromStr(V_BSTR(&varLeft), LOCALE_USER_DEFAULT, 0, &d);
        hRet = VariantChangeType(&varLeft, &varLeft, VARIANT_LOCALBOOL,
                                 FAILED(hRet) ? VT_BOOL : VT_I4);
        if (FAILED(hRet))
            goto VarXor_Exit;
    }

    if (V_VT(&varRight) == VT_BSTR)
    {
        hRet = VarR8FromStr(V_BSTR(&varRight), LOCALE_USER_DEFAULT, 0, &d);
        hRet = VariantChangeType(&varRight, &varRight, VARIANT_LOCALBOOL,
                                 FAILED(hRet) ? VT_BOOL : VT_I4);
        if (FAILED(hRet))
            goto VarXor_Exit;
    }

    /* Determine the result type */
    if (V_VT(&varLeft) == VT_I8 || V_VT(&varRight) == VT_I8)
    {
        if (V_VT(pVarLeft) == VT_INT || V_VT(pVarRight) == VT_INT)
        {
            hRet = DISP_E_TYPEMISMATCH;
            goto VarXor_Exit;
        }
        vt = VT_I8;
    }
    else
    {
        switch ((V_VT(&varLeft) << 16) | V_VT(&varRight))
        {
        case (VT_BOOL  << 16) | VT_BOOL:
            vt = VT_BOOL;
            break;
        case (VT_UI1   << 16) | VT_UI1:
            vt = VT_UI1;
            break;
        case (VT_EMPTY << 16) | VT_EMPTY:
        case (VT_EMPTY << 16) | VT_UI1:
        case (VT_EMPTY << 16) | VT_I2:
        case (VT_EMPTY << 16) | VT_BOOL:
        case (VT_UI1   << 16) | VT_EMPTY:
        case (VT_UI1   << 16) | VT_I2:
        case (VT_UI1   << 16) | VT_BOOL:
        case (VT_I2    << 16) | VT_EMPTY:
        case (VT_I2    << 16) | VT_UI1:
        case (VT_I2    << 16) | VT_I2:
        case (VT_I2    << 16) | VT_BOOL:
        case (VT_BOOL  << 16) | VT_EMPTY:
        case (VT_BOOL  << 16) | VT_UI1:
        case (VT_BOOL  << 16) | VT_I2:
            vt = VT_I2;
            break;
        default:
            vt = VT_I4;
            break;
        }
    }

    /* VT_UI4 does not overflow */
    if (vt != VT_I8)
    {
        if (V_VT(&varLeft) == VT_UI4)
            V_VT(&varLeft) = VT_I4;
        if (V_VT(&varRight) == VT_UI4)
            V_VT(&varRight) = VT_I4;
    }

    /* Convert our input copies to the result type */
    if (V_VT(&varLeft) != vt)
        hRet = VariantChangeType(&varLeft, &varLeft, 0, vt);
    if (FAILED(hRet))
        goto VarXor_Exit;

    if (V_VT(&varRight) != vt)
        hRet = VariantChangeType(&varRight, &varRight, 0, vt);
    if (FAILED(hRet))
        goto VarXor_Exit;

    V_VT(pVarOut) = vt;

    /* Calculate the result */
    switch (vt)
    {
    case VT_I8:
        V_I8(pVarOut) = V_I8(&varLeft) ^ V_I8(&varRight);
        break;
    case VT_I4:
        V_I4(pVarOut) = V_I4(&varLeft) ^ V_I4(&varRight);
        break;
    case VT_BOOL:
    case VT_I2:
        V_I2(pVarOut) = V_I2(&varLeft) ^ V_I2(&varRight);
        break;
    case VT_UI1:
        V_UI1(pVarOut) = V_UI1(&varLeft) ^ V_UI1(&varRight);
        break;
    }

VarXor_Exit:
    VariantClear(&varLeft);
    VariantClear(&varRight);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);
    return hRet;
}

/**********************************************************************
 *              VarEqv [OLEAUT32.172]
 *
 * Determine if two variants contain the same value.
 *
 * PARAMS
 *  pVarLeft  [I] First variant to compare
 *  pVarRight [I] Variant to compare to pVarLeft
 *  pVarOut   [O] Destination for comparison result
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the result of the comparison (VARIANT_TRUE
 *           if equivalent or non-zero otherwise.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  - This function simply calls VarXor() on pVarLeft and pVarRight and inverts
 *    the result.
 */
HRESULT WINAPI VarEqv(LPVARIANT pVarLeft, LPVARIANT pVarRight, LPVARIANT pVarOut)
{
    HRESULT hRet;

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", pVarLeft, debugstr_VT(pVarLeft),
          debugstr_VF(pVarLeft), pVarRight, debugstr_VT(pVarRight),
          debugstr_VF(pVarRight), pVarOut);

    hRet = VarXor(pVarLeft, pVarRight, pVarOut);
    if (SUCCEEDED(hRet))
    {
        if (V_VT(pVarOut) == VT_I8)
            V_I8(pVarOut) = ~V_I8(pVarOut);
        else
            V_UI4(pVarOut) = ~V_UI4(pVarOut);
    }
    return hRet;
}

/**********************************************************************
 *              VarNeg [OLEAUT32.173]
 *
 * Negate the value of a variant.
 *
 * PARAMS
 *  pVarIn  [I] Source variant
 *  pVarOut [O] Destination for converted value
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the converted value.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  - The type of the value stored in pVarOut depends on the type of pVarIn,
 *    according to the following table:
 *| Input Type       Output Type
 *| ----------       -----------
 *|  VT_EMPTY         VT_I2
 *|  VT_UI1           VT_I2
 *|  VT_BOOL          VT_I2
 *|  VT_BSTR          VT_R8
 *|  All Others       Unchanged (unless promoted)
 *  - Where the negated value of a variant does not fit in its base type, the type
 *    is promoted according to the following table:
 *| Input Type       Promoted To
 *| ----------       -----------
 *|   VT_I2            VT_I4
 *|   VT_I4            VT_R8
 *|   VT_I8            VT_R8
 *  - The native version of this function returns DISP_E_BADVARTYPE for valid
 *    variant types that cannot be negated, and returns DISP_E_TYPEMISMATCH
 *    for types which are not valid. Since this is in contravention of the
 *    meaning of those error codes and unlikely to be relied on by applications,
 *    this implementation returns errors consistent with the other high level
 *    variant math functions.
 */
HRESULT WINAPI VarNeg(LPVARIANT pVarIn, LPVARIANT pVarOut)
{
    HRESULT hRet = S_OK;
    VARIANT temp;

    VariantInit(&temp);

    TRACE("(%p->(%s%s),%p)\n", pVarIn, debugstr_VT(pVarIn),
          debugstr_VF(pVarIn), pVarOut);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(pVarIn) & VT_TYPEMASK) == VT_DISPATCH && ((V_VT(pVarIn) & ~VT_TYPEMASK) == 0))
    {
        hRet = VARIANT_FetchDispatchValue(pVarIn, &temp);
        if (FAILED(hRet)) goto VarNeg_Exit;
        pVarIn = &temp;
    }
    V_VT(pVarOut) = V_VT(pVarIn);

    switch (V_VT(pVarIn))
    {
    case VT_UI1:
        V_VT(pVarOut) = VT_I2;
        V_I2(pVarOut) = -V_UI1(pVarIn);
        break;
    case VT_BOOL:
        V_VT(pVarOut) = VT_I2;
        /* Fall through */
    case VT_I2:
        if (V_I2(pVarIn) == I2_MIN)
        {
            V_VT(pVarOut) = VT_I4;
            V_I4(pVarOut) = -(int)V_I2(pVarIn);
        }
        else
            V_I2(pVarOut) = -V_I2(pVarIn);
        break;
    case VT_I4:
        if (V_I4(pVarIn) == I4_MIN)
        {
            V_VT(pVarOut) = VT_R8;
            V_R8(pVarOut) = -(double)V_I4(pVarIn);
        }
        else
            V_I4(pVarOut) = -V_I4(pVarIn);
        break;
    case VT_I8:
        if (V_I8(pVarIn) == I8_MIN)
        {
            V_VT(pVarOut) = VT_R8;
            hRet = VarR8FromI8(V_I8(pVarIn), &V_R8(pVarOut));
            V_R8(pVarOut) *= -1.0;
        }
        else
            V_I8(pVarOut) = -V_I8(pVarIn);
        break;
    case VT_R4:
        V_R4(pVarOut) = -V_R4(pVarIn);
        break;
    case VT_DATE:
    case VT_R8:
        V_R8(pVarOut) = -V_R8(pVarIn);
        break;
    case VT_CY:
        hRet = VarCyNeg(V_CY(pVarIn), &V_CY(pVarOut));
        break;
    case VT_DECIMAL:
        hRet = VarDecNeg(&V_DECIMAL(pVarIn), &V_DECIMAL(pVarOut));
        break;
    case VT_BSTR:
        V_VT(pVarOut) = VT_R8;
        hRet = VarR8FromStr(V_BSTR(pVarIn), LOCALE_USER_DEFAULT, 0, &V_R8(pVarOut));
        V_R8(pVarOut) = -V_R8(pVarOut);
        break;
    case VT_EMPTY:
        V_VT(pVarOut) = VT_I2;
        V_I2(pVarOut) = 0;
        break;
    case VT_NULL:
        /* No-Op */
        break;
    default:
        if (V_TYPE(pVarIn) == VT_CLSID || /* VT_CLSID is a special case */
            FAILED(VARIANT_ValidateType(V_VT(pVarIn))))
            hRet = DISP_E_BADVARTYPE;
        else
            hRet = DISP_E_TYPEMISMATCH;
    }
VarNeg_Exit:
    if (FAILED(hRet))
      V_VT(pVarOut) = VT_EMPTY;
    VariantClear(&temp);

    return hRet;
}

/**********************************************************************
 *              VarNot [OLEAUT32.174]
 *
 * Perform a not operation on a variant.
 *
 * PARAMS
 *  pVarIn  [I] Source variant
 *  pVarOut [O] Destination for converted value
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the converted value.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  - Strictly speaking, this function performs a bitwise ones complement
 *    on the variants value (after possibly converting to VT_I4, see below).
 *    This only behaves like a boolean not operation if the value in
 *    pVarIn is either VARIANT_TRUE or VARIANT_FALSE and the type is signed.
 *  - To perform a genuine not operation, convert the variant to a VT_BOOL
 *    before calling this function.
 *  - This function does not process by-reference variants.
 *  - The type of the value stored in pVarOut depends on the type of pVarIn,
 *    according to the following table:
 *| Input Type       Output Type
 *| ----------       -----------
 *| VT_EMPTY         VT_I2
 *| VT_R4            VT_I4
 *| VT_R8            VT_I4
 *| VT_BSTR          VT_I4
 *| VT_DECIMAL       VT_I4
 *| VT_CY            VT_I4
 *| (All others)     Unchanged
 */
HRESULT WINAPI VarNot(LPVARIANT pVarIn, LPVARIANT pVarOut)
{
    VARIANT varIn;
    HRESULT hRet = S_OK;
    VARIANT temp;

    VariantInit(&temp);

    TRACE("(%p->(%s%s),%p)\n", pVarIn, debugstr_VT(pVarIn),
          debugstr_VF(pVarIn), pVarOut);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(pVarIn) & VT_TYPEMASK) == VT_DISPATCH && ((V_VT(pVarIn) & ~VT_TYPEMASK) == 0))
    {
        hRet = VARIANT_FetchDispatchValue(pVarIn, &temp);
        if (FAILED(hRet)) goto VarNot_Exit;
        pVarIn = &temp;
    }

    V_VT(pVarOut) = V_VT(pVarIn);

    switch (V_VT(pVarIn))
    {
    case VT_I1:
        V_I4(pVarOut) = ~V_I1(pVarIn);
        V_VT(pVarOut) = VT_I4;
        break;
    case VT_UI1: V_UI1(pVarOut) = ~V_UI1(pVarIn); break;
    case VT_BOOL:
    case VT_I2:  V_I2(pVarOut) = ~V_I2(pVarIn); break;
    case VT_UI2:
        V_I4(pVarOut) = ~V_UI2(pVarIn);
        V_VT(pVarOut) = VT_I4;
        break;
    case VT_DECIMAL:
        hRet = VarI4FromDec(&V_DECIMAL(pVarIn), &V_I4(&varIn));
        if (FAILED(hRet))
            break;
        pVarIn = &varIn;
        /* Fall through ... */
    case VT_INT:
        V_VT(pVarOut) = VT_I4;
        /* Fall through ... */
    case VT_I4:  V_I4(pVarOut) = ~V_I4(pVarIn); break;
    case VT_UINT:
    case VT_UI4:
        V_I4(pVarOut) = ~V_UI4(pVarIn);
        V_VT(pVarOut) = VT_I4;
        break;
    case VT_I8:  V_I8(pVarOut) = ~V_I8(pVarIn); break;
    case VT_UI8:
        V_I4(pVarOut) = ~V_UI8(pVarIn);
        V_VT(pVarOut) = VT_I4;
        break;
    case VT_R4:
        hRet = VarI4FromR4(V_R4(pVarIn), &V_I4(pVarOut));
        V_I4(pVarOut) = ~V_I4(pVarOut);
        V_VT(pVarOut) = VT_I4;
        break;
    case VT_BSTR:
        hRet = VarR8FromStr(V_BSTR(pVarIn), LOCALE_USER_DEFAULT, 0, &V_R8(&varIn));
        if (FAILED(hRet))
            break;
        pVarIn = &varIn;
        /* Fall through ... */
    case VT_DATE:
    case VT_R8:
        hRet = VarI4FromR8(V_R8(pVarIn), &V_I4(pVarOut));
        V_I4(pVarOut) = ~V_I4(pVarOut);
        V_VT(pVarOut) = VT_I4;
        break;
    case VT_CY:
        hRet = VarI4FromCy(V_CY(pVarIn), &V_I4(pVarOut));
        V_I4(pVarOut) = ~V_I4(pVarOut);
        V_VT(pVarOut) = VT_I4;
        break;
    case VT_EMPTY:
        V_I2(pVarOut) = ~0;
        V_VT(pVarOut) = VT_I2;
        break;
    case VT_NULL:
        /* No-Op */
        break;
    default:
        if (V_TYPE(pVarIn) == VT_CLSID || /* VT_CLSID is a special case */
            FAILED(VARIANT_ValidateType(V_VT(pVarIn))))
            hRet = DISP_E_BADVARTYPE;
        else
            hRet = DISP_E_TYPEMISMATCH;
    }
VarNot_Exit:
    if (FAILED(hRet))
      V_VT(pVarOut) = VT_EMPTY;
    VariantClear(&temp);

    return hRet;
}

/**********************************************************************
 *              VarRound [OLEAUT32.175]
 *
 * Perform a round operation on a variant.
 *
 * PARAMS
 *  pVarIn  [I] Source variant
 *  deci    [I] Number of decimals to round to
 *  pVarOut [O] Destination for converted value
 *
 * RETURNS
 *  Success: S_OK. pVarOut contains the converted value.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  - Floating point values are rounded to the desired number of decimals.
 *  - Some integer types are just copied to the return variable.
 *  - Some other integer types are not handled and fail.
 */
HRESULT WINAPI VarRound(LPVARIANT pVarIn, int deci, LPVARIANT pVarOut)
{
    VARIANT varIn;
    HRESULT hRet = S_OK;
    float factor;
    VARIANT temp;

    VariantInit(&temp);

    TRACE("(%p->(%s%s),%d)\n", pVarIn, debugstr_VT(pVarIn), debugstr_VF(pVarIn), deci);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(pVarIn) & VT_TYPEMASK) == VT_DISPATCH && ((V_VT(pVarIn) & ~VT_TYPEMASK) == 0))
    {
        hRet = VARIANT_FetchDispatchValue(pVarIn, &temp);
        if (FAILED(hRet)) goto VarRound_Exit;
        pVarIn = &temp;
    }

    switch (V_VT(pVarIn))
    {
    /* cases that fail on windows */
    case VT_I1:
    case VT_I8:
    case VT_UI2:
    case VT_UI4:
	hRet = DISP_E_BADVARTYPE;
	break;

    /* cases just copying in to out */
    case VT_UI1:
	V_VT(pVarOut) = V_VT(pVarIn);
	V_UI1(pVarOut) = V_UI1(pVarIn);
	break;
    case VT_I2:
	V_VT(pVarOut) = V_VT(pVarIn);
	V_I2(pVarOut) = V_I2(pVarIn);
	break;
    case VT_I4:
	V_VT(pVarOut) = V_VT(pVarIn);
	V_I4(pVarOut) = V_I4(pVarIn);
	break;
    case VT_NULL:
	V_VT(pVarOut) = V_VT(pVarIn);
	/* value unchanged */
	break;

    /* cases that change type */
    case VT_EMPTY:
	V_VT(pVarOut) = VT_I2;
	V_I2(pVarOut) = 0;
	break;
    case VT_BOOL:
	V_VT(pVarOut) = VT_I2;
	V_I2(pVarOut) = V_BOOL(pVarIn);
	break;
    case VT_BSTR:
	hRet = VarR8FromStr(V_BSTR(pVarIn), LOCALE_USER_DEFAULT, 0, &V_R8(&varIn));
	if (FAILED(hRet))
	    break;
	V_VT(&varIn)=VT_R8;
	pVarIn = &varIn;
	/* Fall through ... */

    /* cases we need to do math */
    case VT_R8:
	if (V_R8(pVarIn)>0) {
	    V_R8(pVarOut)=floor(V_R8(pVarIn)*pow(10, deci)+0.5)/pow(10, deci);
	} else {
	    V_R8(pVarOut)=ceil(V_R8(pVarIn)*pow(10, deci)-0.5)/pow(10, deci);
	}
	V_VT(pVarOut) = V_VT(pVarIn);
	break;
    case VT_R4:
	if (V_R4(pVarIn)>0) {
	    V_R4(pVarOut)=floor(V_R4(pVarIn)*pow(10, deci)+0.5)/pow(10, deci);
	} else {
	    V_R4(pVarOut)=ceil(V_R4(pVarIn)*pow(10, deci)-0.5)/pow(10, deci);
	}
	V_VT(pVarOut) = V_VT(pVarIn);
	break;
    case VT_DATE:
	if (V_DATE(pVarIn)>0) {
	    V_DATE(pVarOut)=floor(V_DATE(pVarIn)*pow(10, deci)+0.5)/pow(10, deci);
	} else {
	    V_DATE(pVarOut)=ceil(V_DATE(pVarIn)*pow(10, deci)-0.5)/pow(10, deci);
	}
	V_VT(pVarOut) = V_VT(pVarIn);
	break;
    case VT_CY:
	if (deci>3)
	    factor=1;
	else
	    factor=pow(10, 4-deci);

	if (V_CY(pVarIn).int64>0) {
	    V_CY(pVarOut).int64=(LONGLONG)(floor(V_CY(pVarIn).int64/factor)*factor);
	} else {
	    V_CY(pVarOut).int64=(LONGLONG)(ceil(V_CY(pVarIn).int64/factor)*factor);
	}
	V_VT(pVarOut) = V_VT(pVarIn);
	break;

    /* cases we don't know yet */
    default:
	hRet = DISP_E_BADVARTYPE;
    }
VarRound_Exit:
    if (FAILED(hRet))
      V_VT(pVarOut) = VT_EMPTY;
    VariantClear(&temp);

    TRACE("returning 0x%08x (%s%s),%f\n", hRet, debugstr_VT(pVarOut),
	debugstr_VF(pVarOut), (V_VT(pVarOut) == VT_R4) ? V_R4(pVarOut) :
	(V_VT(pVarOut) == VT_R8) ? V_R8(pVarOut) : 0);

    return hRet;
}

/**********************************************************************
 *              VarIdiv [OLEAUT32.153]
 *
 * Converts input variants to integers and divides them. 
 *
 * PARAMS
 *  left     [I] Left hand variant
 *  right    [I] Right hand variant
 *  result   [O] Destination for quotient
 *
 * RETURNS
 *  Success: S_OK.  result contains the quotient.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTES
 *  If either expression is null, null is returned, as per MSDN
 */
HRESULT WINAPI VarIdiv(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    HRESULT hres = S_OK;
    VARTYPE resvt = VT_EMPTY;
    VARTYPE leftvt,rightvt;
    VARTYPE rightExtraFlags,leftExtraFlags,ExtraFlags;
    VARIANT lv,rv;
    VARIANT tempLeft, tempRight;

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right), result);

    VariantInit(&lv);
    VariantInit(&rv);
    VariantInit(&tempLeft);
    VariantInit(&tempRight);

    leftvt = V_VT(left)&VT_TYPEMASK;
    rightvt = V_VT(right)&VT_TYPEMASK;
    leftExtraFlags = V_VT(left)&(~VT_TYPEMASK);
    rightExtraFlags = V_VT(right)&(~VT_TYPEMASK);

    if (leftExtraFlags != rightExtraFlags)
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }
    ExtraFlags = leftExtraFlags;

    /* Native VarIdiv always returns an error when using extra
     * flags or if the variant combination is I8 and INT.
     */
    if ((leftvt == VT_I8 && rightvt == VT_INT) ||
        (leftvt == VT_INT && rightvt == VT_I8) ||
        (rightvt == VT_EMPTY && leftvt != VT_NULL) ||
        ExtraFlags != 0)
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }

    /* Determine variant type */
    else if (leftvt == VT_NULL || rightvt == VT_NULL)
    {
        V_VT(result) = VT_NULL;
        hres = S_OK;
        goto end;
    }
    else if (leftvt == VT_I8 || rightvt == VT_I8)
        resvt = VT_I8;
    else if (leftvt == VT_I4 || rightvt == VT_I4 ||
        leftvt == VT_INT || rightvt == VT_INT ||
        leftvt == VT_UINT || rightvt == VT_UINT ||
        leftvt == VT_UI8 || rightvt == VT_UI8 ||
        leftvt == VT_UI4 || rightvt == VT_UI4 ||
        leftvt == VT_UI2 || rightvt == VT_UI2 ||
        leftvt == VT_I1 || rightvt == VT_I1 ||
        leftvt == VT_BSTR || rightvt == VT_BSTR ||
        leftvt == VT_DATE || rightvt == VT_DATE ||
        leftvt == VT_CY || rightvt == VT_CY ||
        leftvt == VT_DECIMAL || rightvt == VT_DECIMAL ||
        leftvt == VT_R8 || rightvt == VT_R8 ||
        leftvt == VT_R4 || rightvt == VT_R4)
        resvt = VT_I4;
    else if (leftvt == VT_I2 || rightvt == VT_I2 ||
        leftvt == VT_BOOL || rightvt == VT_BOOL ||
        leftvt == VT_EMPTY)
        resvt = VT_I2;
    else if (leftvt == VT_UI1 || rightvt == VT_UI1)
        resvt = VT_UI1;
    else
    {
        hres = DISP_E_BADVARTYPE;
        goto end;
    }

    /* coerce to the result type */
    hres = VariantChangeType(&lv, left, 0, resvt);
    if (hres != S_OK) goto end;
    hres = VariantChangeType(&rv, right, 0, resvt);
    if (hres != S_OK) goto end;

    /* do the math */
    V_VT(result) = resvt;
    switch (resvt)
    {
    case VT_UI1:
    if (V_UI1(&rv) == 0)
    {
        hres = DISP_E_DIVBYZERO;
        V_VT(result) = VT_EMPTY;
    }
    else
        V_UI1(result) = V_UI1(&lv) / V_UI1(&rv);
    break;
    case VT_I2:
    if (V_I2(&rv) == 0)
    {
        hres = DISP_E_DIVBYZERO;
        V_VT(result) = VT_EMPTY;
    }
    else
        V_I2(result) = V_I2(&lv) / V_I2(&rv);
    break;
    case VT_I4:
    if (V_I4(&rv) == 0)
    {
        hres = DISP_E_DIVBYZERO;
        V_VT(result) = VT_EMPTY;
    }
    else
        V_I4(result) = V_I4(&lv) / V_I4(&rv);
    break;
    case VT_I8:
    if (V_I8(&rv) == 0)
    {
        hres = DISP_E_DIVBYZERO;
        V_VT(result) = VT_EMPTY;
    }
    else
        V_I8(result) = V_I8(&lv) / V_I8(&rv);
    break;
    default:
	break;
    }

end:
    VariantClear(&lv);
    VariantClear(&rv);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);

    return hres;
}


/**********************************************************************
 *              VarMod [OLEAUT32.155]
 *
 * Perform the modulus operation of the right hand variant on the left
 *
 * PARAMS
 *  left     [I] Left hand variant
 *  right    [I] Right hand variant
 *  result   [O] Destination for converted value
 *
 * RETURNS
 *  Success: S_OK. result contains the remainder.
 *  Failure: An HRESULT error code indicating the error.
 *
 * NOTE:
 *   If an error occurs the type of result will be modified but the value will not be.
 *   Doesn't support arrays or any special flags yet.
 */
HRESULT WINAPI VarMod(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    BOOL         lOk        = TRUE;
    HRESULT      rc         = E_FAIL;
    int          resT = 0;
    VARIANT      lv,rv;
    VARIANT tempLeft, tempRight;

    VariantInit(&tempLeft);
    VariantInit(&tempRight);
    VariantInit(&lv);
    VariantInit(&rv);

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
		  debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right), result);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(left) & VT_TYPEMASK) == VT_DISPATCH)
    {
        rc = VARIANT_FetchDispatchValue(left, &tempLeft);
        if (FAILED(rc)) goto end;
        left = &tempLeft;
    }
    if ((V_VT(right) & VT_TYPEMASK) == VT_DISPATCH)
    {
        rc = VARIANT_FetchDispatchValue(right, &tempRight);
        if (FAILED(rc)) goto end;
        right = &tempRight;
    }

    /* check for invalid inputs */
    lOk = TRUE;
    switch (V_VT(left) & VT_TYPEMASK) {
    case VT_BOOL :
    case VT_I1   :
    case VT_I2   :
    case VT_I4   :
    case VT_I8   :
    case VT_INT  :
    case VT_UI1  :
    case VT_UI2  :
    case VT_UI4  :
    case VT_UI8  :
    case VT_UINT :
    case VT_R4   :
    case VT_R8   :
    case VT_CY   :
    case VT_EMPTY:
    case VT_DATE :
    case VT_BSTR :
    case VT_DECIMAL:
      break;
    case VT_VARIANT:
    case VT_UNKNOWN:
      V_VT(result) = VT_EMPTY;
      rc = DISP_E_TYPEMISMATCH;
      goto end;
    case VT_ERROR:
      rc = DISP_E_TYPEMISMATCH;
      goto end;
    case VT_RECORD:
      V_VT(result) = VT_EMPTY;
      rc = DISP_E_TYPEMISMATCH;
      goto end;
    case VT_NULL:
      break;
    default:
      V_VT(result) = VT_EMPTY;
      rc = DISP_E_BADVARTYPE;
      goto end;
    }


    switch (V_VT(right) & VT_TYPEMASK) {
    case VT_BOOL :
    case VT_I1   :
    case VT_I2   :
    case VT_I4   :
    case VT_I8   :
      if((V_VT(left) == VT_INT) && (V_VT(right) == VT_I8))
      {
	V_VT(result) = VT_EMPTY;
        rc = DISP_E_TYPEMISMATCH;
        goto end;
      }
    case VT_INT  :
      if((V_VT(right) == VT_INT) && (V_VT(left) == VT_I8))
      {
	V_VT(result) = VT_EMPTY;
        rc = DISP_E_TYPEMISMATCH;
        goto end;
      }
    case VT_UI1  :
    case VT_UI2  :
    case VT_UI4  :
    case VT_UI8  :
    case VT_UINT :
    case VT_R4   :
    case VT_R8   :
    case VT_CY   :
      if(V_VT(left) == VT_EMPTY)
      {
	V_VT(result) = VT_I4;
        rc = S_OK;
        goto end;
      }
    case VT_EMPTY:
    case VT_DATE :
    case VT_DECIMAL:
      if(V_VT(left) == VT_ERROR)
      {
	V_VT(result) = VT_EMPTY;
        rc = DISP_E_TYPEMISMATCH;
        goto end;
      }
    case VT_BSTR:
      if(V_VT(left) == VT_NULL)
      {
	V_VT(result) = VT_NULL;
        rc = S_OK;
        goto end;
      }
      break;

    case VT_VOID:
      V_VT(result) = VT_EMPTY;
      rc = DISP_E_BADVARTYPE;
      goto end;
    case VT_NULL:
      if(V_VT(left) == VT_VOID)
      {
	V_VT(result) = VT_EMPTY;
        rc = DISP_E_BADVARTYPE;
      } else if((V_VT(left) == VT_NULL) || (V_VT(left) == VT_EMPTY) || (V_VT(left) == VT_ERROR) ||
		lOk)
      {
        V_VT(result) = VT_NULL;
        rc = S_OK;
      } else
      {
	V_VT(result) = VT_NULL;
        rc = DISP_E_BADVARTYPE;
      }
      goto end;
    case VT_VARIANT:
    case VT_UNKNOWN:
      V_VT(result) = VT_EMPTY;
      rc = DISP_E_TYPEMISMATCH;
      goto end;
    case VT_ERROR:
      rc = DISP_E_TYPEMISMATCH;
      goto end;
    case VT_RECORD:
      if((V_VT(left) == 15) || ((V_VT(left) >= 24) && (V_VT(left) <= 35)) || !lOk)
      {
	V_VT(result) = VT_EMPTY;
        rc = DISP_E_BADVARTYPE;
      } else
      {
	V_VT(result) = VT_EMPTY;
        rc = DISP_E_TYPEMISMATCH;
      }
      goto end;
    default:
      V_VT(result) = VT_EMPTY;
      rc = DISP_E_BADVARTYPE;
      goto end;
    }

    /* determine the result type */
    if((V_VT(left) == VT_I8)        || (V_VT(right) == VT_I8))   resT = VT_I8;
    else if((V_VT(left) == VT_UI1)  && (V_VT(right) == VT_BOOL)) resT = VT_I2;
    else if((V_VT(left) == VT_UI1)  && (V_VT(right) == VT_UI1))  resT = VT_UI1;
    else if((V_VT(left) == VT_UI1)  && (V_VT(right) == VT_I2))   resT = VT_I2;
    else if((V_VT(left) == VT_I2)   && (V_VT(right) == VT_BOOL)) resT = VT_I2;
    else if((V_VT(left) == VT_I2)   && (V_VT(right) == VT_UI1))  resT = VT_I2;
    else if((V_VT(left) == VT_I2)   && (V_VT(right) == VT_I2))   resT = VT_I2;
    else if((V_VT(left) == VT_BOOL) && (V_VT(right) == VT_BOOL)) resT = VT_I2;
    else if((V_VT(left) == VT_BOOL) && (V_VT(right) == VT_UI1))  resT = VT_I2;
    else if((V_VT(left) == VT_BOOL) && (V_VT(right) == VT_I2))   resT = VT_I2;
    else resT = VT_I4; /* most outputs are I4 */

    /* convert to I8 for the modulo */
    rc = VariantChangeType(&lv, left, 0, VT_I8);
    if(FAILED(rc))
    {
      ////FixMe("Could not convert left type %d to %d? rc == 0x%X\n", V_VT(left), VT_I8, rc);
      goto end;
    }

    rc = VariantChangeType(&rv, right, 0, VT_I8);
    if(FAILED(rc))
    {
      ////FixMe("Could not convert right type %d to %d? rc == 0x%X\n", V_VT(right), VT_I8, rc);
      goto end;
    }

    /* if right is zero set VT_EMPTY and return divide by zero */
    if(V_I8(&rv) == 0)
    {
      V_VT(result) = VT_EMPTY;
      rc = DISP_E_DIVBYZERO;
      goto end;
    }

    /* perform the modulo operation */
    V_VT(result) = VT_I8;
    V_I8(result) = V_I8(&lv) % V_I8(&rv);

    /*TRACE("V_I8(left) == %s, V_I8(right) == %s, V_I8(result) == %s\n",
          wine_dbgstr_longlong(V_I8(&lv)), wine_dbgstr_longlong(V_I8(&rv)),
          wine_dbgstr_longlong(V_I8(result))); */

    /* convert left and right to the destination type */
    rc = VariantChangeType(result, result, 0, resT);
    if(FAILED(rc))
    {
      ////FixMe("Could not convert 0x%x to %d?\n", V_VT(result), resT);
      /* fall to end of function */
    }

end:
    VariantClear(&lv);
    VariantClear(&rv);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);
    return rc;
}

/**********************************************************************
 *              VarPow [OLEAUT32.158]
 *
 * Computes the power of one variant to another variant.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  result  [O] Result variant
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: An HRESULT error code indicating the error.
 */
HRESULT WINAPI VarPow(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    HRESULT hr = S_OK;
    VARIANT dl,dr;
    VARTYPE resvt = VT_EMPTY;
    VARTYPE leftvt,rightvt;
    VARTYPE rightExtraFlags,leftExtraFlags,ExtraFlags;
    VARIANT tempLeft, tempRight;

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left), debugstr_VF(left),
          right, debugstr_VT(right), debugstr_VF(right), result);

    VariantInit(&dl);
    VariantInit(&dr);
    VariantInit(&tempLeft);
    VariantInit(&tempRight);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(left) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hr = VARIANT_FetchDispatchValue(left, &tempLeft);
        if (FAILED(hr)) goto end;
        left = &tempLeft;
    }
    if ((V_VT(right) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hr = VARIANT_FetchDispatchValue(right, &tempRight);
        if (FAILED(hr)) goto end;
        right = &tempRight;
    }

    leftvt = V_VT(left)&VT_TYPEMASK;
    rightvt = V_VT(right)&VT_TYPEMASK;
    leftExtraFlags = V_VT(left)&(~VT_TYPEMASK);
    rightExtraFlags = V_VT(right)&(~VT_TYPEMASK);

    if (leftExtraFlags != rightExtraFlags)
    {
        hr = DISP_E_BADVARTYPE;
        goto end;
    }
    ExtraFlags = leftExtraFlags;

    /* Native VarPow always returns an error when using extra flags */
    if (ExtraFlags != 0)
    {
        hr = DISP_E_BADVARTYPE;
        goto end;
    }

    /* Determine return type */
    else if (leftvt == VT_NULL || rightvt == VT_NULL) {
        V_VT(result) = VT_NULL;
        hr = S_OK;
        goto end;
    }
    else if ((leftvt == VT_EMPTY || leftvt == VT_I2 ||
        leftvt == VT_I4 || leftvt == VT_R4 ||
        leftvt == VT_R8 || leftvt == VT_CY ||
        leftvt == VT_DATE || leftvt == VT_BSTR ||
        leftvt == VT_BOOL || leftvt == VT_DECIMAL ||
        (leftvt >= VT_I1 && leftvt <= VT_UINT)) &&
        (rightvt == VT_EMPTY || rightvt == VT_I2 ||
        rightvt == VT_I4 || rightvt == VT_R4 ||
        rightvt == VT_R8 || rightvt == VT_CY ||
        rightvt == VT_DATE || rightvt == VT_BSTR ||
        rightvt == VT_BOOL || rightvt == VT_DECIMAL ||
        (rightvt >= VT_I1 && rightvt <= VT_UINT)))
        resvt = VT_R8;
    else
    {
        hr = DISP_E_BADVARTYPE;
        goto end;
    }

    hr = VariantChangeType(&dl,left,0,resvt);
    if (FAILED(hr)) {
        ERR("Could not change passed left argument to VT_R8, handle it differently.\n");
        hr = E_FAIL;
        goto end;
    }

    hr = VariantChangeType(&dr,right,0,resvt);
    if (FAILED(hr)) {
        ERR("Could not change passed right argument to VT_R8, handle it differently.\n");
        hr = E_FAIL;
        goto end;
    }

    V_VT(result) = VT_R8;
    V_R8(result) = pow(V_R8(&dl),V_R8(&dr));

end:
    VariantClear(&dl);
    VariantClear(&dr);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);

    return hr;
}

/**********************************************************************
 *              VarImp [OLEAUT32.154]
 *
 * Bitwise implication of two variants.
 *
 * PARAMS
 *  left    [I] First variant
 *  right   [I] Second variant
 *  result  [O] Result variant
 *
 * RETURNS
 *  Success: S_OK.
 *  Failure: An HRESULT error code indicating the error.
 */
HRESULT WINAPI VarImp(LPVARIANT left, LPVARIANT right, LPVARIANT result)
{
    HRESULT hres = S_OK;
    VARTYPE resvt = VT_EMPTY;
    VARTYPE leftvt,rightvt;
    VARTYPE rightExtraFlags,leftExtraFlags,ExtraFlags;
    VARIANT lv,rv;
    double d;
    VARIANT tempLeft, tempRight;

    VariantInit(&lv);
    VariantInit(&rv);
    VariantInit(&tempLeft);
    VariantInit(&tempRight);

    TRACE("(%p->(%s%s),%p->(%s%s),%p)\n", left, debugstr_VT(left),
          debugstr_VF(left), right, debugstr_VT(right), debugstr_VF(right), result);

    /* Handle VT_DISPATCH by storing and taking address of returned value */
    if ((V_VT(left) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hres = VARIANT_FetchDispatchValue(left, &tempLeft);
        if (FAILED(hres)) goto VarImp_Exit;
        left = &tempLeft;
    }
    if ((V_VT(right) & VT_TYPEMASK) == VT_DISPATCH)
    {
        hres = VARIANT_FetchDispatchValue(right, &tempRight);
        if (FAILED(hres)) goto VarImp_Exit;
        right = &tempRight;
    }

    leftvt = V_VT(left)&VT_TYPEMASK;
    rightvt = V_VT(right)&VT_TYPEMASK;
    leftExtraFlags = V_VT(left)&(~VT_TYPEMASK);
    rightExtraFlags = V_VT(right)&(~VT_TYPEMASK);

    if (leftExtraFlags != rightExtraFlags)
    {
        hres = DISP_E_BADVARTYPE;
        goto VarImp_Exit;
    }
    ExtraFlags = leftExtraFlags;

    /* Native VarImp always returns an error when using extra
     * flags or if the variants are I8 and INT.
     */
    if ((leftvt == VT_I8 && rightvt == VT_INT) ||
        ExtraFlags != 0)
    {
        hres = DISP_E_BADVARTYPE;
        goto VarImp_Exit;
    }

    /* Determine result type */
    else if ((leftvt == VT_NULL && rightvt == VT_NULL) ||
        (leftvt == VT_NULL && rightvt == VT_EMPTY))
    {
        V_VT(result) = VT_NULL;
        hres = S_OK;
        goto VarImp_Exit;
    }
    else if (leftvt == VT_I8 || rightvt == VT_I8)
        resvt = VT_I8;
    else if (leftvt == VT_I4 || rightvt == VT_I4 ||
        leftvt == VT_INT || rightvt == VT_INT ||
        leftvt == VT_UINT || rightvt == VT_UINT ||
        leftvt == VT_UI4 || rightvt == VT_UI4 ||
        leftvt == VT_UI8 || rightvt == VT_UI8 ||
        leftvt == VT_UI2 || rightvt == VT_UI2 ||
        leftvt == VT_DECIMAL || rightvt == VT_DECIMAL ||
        leftvt == VT_DATE || rightvt == VT_DATE ||
        leftvt == VT_CY || rightvt == VT_CY ||
        leftvt == VT_R8 || rightvt == VT_R8 ||
        leftvt == VT_R4 || rightvt == VT_R4 ||
        leftvt == VT_I1 || rightvt == VT_I1)
        resvt = VT_I4;
    else if ((leftvt == VT_UI1 && rightvt == VT_UI1) ||
        (leftvt == VT_UI1 && rightvt == VT_NULL) ||
        (leftvt == VT_NULL && rightvt == VT_UI1))
        resvt = VT_UI1;
    else if (leftvt == VT_EMPTY || rightvt == VT_EMPTY ||
        leftvt == VT_I2 || rightvt == VT_I2 ||
        leftvt == VT_UI1 || rightvt == VT_UI1)
        resvt = VT_I2;
    else if (leftvt == VT_BOOL || rightvt == VT_BOOL ||
        leftvt == VT_BSTR || rightvt == VT_BSTR)
        resvt = VT_BOOL;

    /* VT_NULL requires special handling for when the opposite
     * variant is equal to something other than -1.
     * (NULL Imp 0 = NULL, NULL Imp n = n)
     */
    if (leftvt == VT_NULL)
    {
        VARIANT_BOOL b;
        switch(rightvt)
        {
        case VT_I1:   if (!V_I1(right)) resvt = VT_NULL; break;
        case VT_UI1:  if (!V_UI1(right)) resvt = VT_NULL; break;
        case VT_I2:   if (!V_I2(right)) resvt = VT_NULL; break;
        case VT_UI2:  if (!V_UI2(right)) resvt = VT_NULL; break;
        case VT_I4:   if (!V_I4(right)) resvt = VT_NULL; break;
        case VT_UI4:  if (!V_UI4(right)) resvt = VT_NULL; break;
        case VT_I8:   if (!V_I8(right)) resvt = VT_NULL; break;
        case VT_UI8:  if (!V_UI8(right)) resvt = VT_NULL; break;
        case VT_INT:  if (!V_INT(right)) resvt = VT_NULL; break;
        case VT_UINT: if (!V_UINT(right)) resvt = VT_NULL; break;
        case VT_BOOL: if (!V_BOOL(right)) resvt = VT_NULL; break;
        case VT_R4:   if (!V_R4(right)) resvt = VT_NULL; break;
        case VT_R8:   if (!V_R8(right)) resvt = VT_NULL; break;
        case VT_DATE: if (!V_DATE(right)) resvt = VT_NULL; break;
        case VT_CY:   if (!V_CY(right).int64) resvt = VT_NULL; break;
        case VT_DECIMAL:
            if (!(DEC_HI32(&V_DECIMAL(right)) || DEC_LO64(&V_DECIMAL(right))))
                resvt = VT_NULL;
            break;
        case VT_BSTR:
            hres = VarBoolFromStr(V_BSTR(right),LOCALE_USER_DEFAULT, VAR_LOCALBOOL, &b);
            if (FAILED(hres)) goto VarImp_Exit;
            else if (!b)
                V_VT(result) = VT_NULL;
            else
            {
                V_VT(result) = VT_BOOL;
                V_BOOL(result) = b;
            }
            goto VarImp_Exit;
        }
        if (resvt == VT_NULL)
        {
            V_VT(result) = resvt;
            goto VarImp_Exit;
        }
        else
        {
            hres = VariantChangeType(result,right,0,resvt);
            goto VarImp_Exit;
        }
    }

    /* Special handling is required when NULL is the right variant.
     * (-1 Imp NULL = NULL, n Imp NULL = n Imp 0)
     */
    else if (rightvt == VT_NULL)
    {
        VARIANT_BOOL b;
        switch(leftvt)
        {
        case VT_I1:     if (V_I1(left) == -1) resvt = VT_NULL; break;
        case VT_UI1:    if (V_UI1(left) == 0xff) resvt = VT_NULL; break;
        case VT_I2:     if (V_I2(left) == -1) resvt = VT_NULL; break;
        case VT_UI2:    if (V_UI2(left) == 0xffff) resvt = VT_NULL; break;
        case VT_INT:    if (V_INT(left) == -1) resvt = VT_NULL; break;
        case VT_UINT:   if (V_UINT(left) == ~0u) resvt = VT_NULL; break;
        case VT_I4:     if (V_I4(left) == -1) resvt = VT_NULL; break;
        case VT_UI4:    if (V_UI4(left) == ~0u) resvt = VT_NULL; break;
        case VT_I8:     if (V_I8(left) == -1) resvt = VT_NULL; break;
        case VT_UI8:    if (V_UI8(left) == ~(ULONGLONG)0) resvt = VT_NULL; break;
        case VT_BOOL:   if (V_BOOL(left) == VARIANT_TRUE) resvt = VT_NULL; break;
        case VT_R4:     if (V_R4(left) == -1.0) resvt = VT_NULL; break;
        case VT_R8:     if (V_R8(left) == -1.0) resvt = VT_NULL; break;
        case VT_CY:     if (V_CY(left).int64 == -1) resvt = VT_NULL; break;
        case VT_DECIMAL:
            if (DEC_HI32(&V_DECIMAL(left)) == 0xffffffff)
                resvt = VT_NULL;
            break;
        case VT_BSTR:
            hres = VarBoolFromStr(V_BSTR(left),LOCALE_USER_DEFAULT, VAR_LOCALBOOL, &b);
            if (FAILED(hres)) goto VarImp_Exit;
            else if (b == VARIANT_TRUE)
                resvt = VT_NULL;
        }
        if (resvt == VT_NULL)
        {
            V_VT(result) = resvt;
            goto VarImp_Exit;
        }
    }

    hres = VariantCopy(&lv, left);
    if (FAILED(hres)) goto VarImp_Exit;

    if (rightvt == VT_NULL)
    {
        memset( &rv, 0, sizeof(rv) );
        V_VT(&rv) = resvt;
    }
    else
    {
        hres = VariantCopy(&rv, right);
        if (FAILED(hres)) goto VarImp_Exit;
    }

    if (V_VT(&lv) == VT_BSTR &&
        FAILED(VarR8FromStr(V_BSTR(&lv),LOCALE_USER_DEFAULT, 0, &d)))
        hres = VariantChangeType(&lv,&lv,VARIANT_LOCALBOOL, VT_BOOL);
    if (SUCCEEDED(hres) && V_VT(&lv) != resvt)
        hres = VariantChangeType(&lv,&lv,0,resvt);
    if (FAILED(hres)) goto VarImp_Exit;

    if (V_VT(&rv) == VT_BSTR &&
        FAILED(VarR8FromStr(V_BSTR(&rv),LOCALE_USER_DEFAULT, 0, &d)))
        hres = VariantChangeType(&rv, &rv,VARIANT_LOCALBOOL, VT_BOOL);
    if (SUCCEEDED(hres) && V_VT(&rv) != resvt)
        hres = VariantChangeType(&rv, &rv, 0, resvt);
    if (FAILED(hres)) goto VarImp_Exit;

    /* do the math */
    V_VT(result) = resvt;
    switch (resvt)
    {
    case VT_I8:
    V_I8(result) = (~V_I8(&lv)) | V_I8(&rv);
    break;
    case VT_I4:
    V_I4(result) = (~V_I4(&lv)) | V_I4(&rv);
    break;
    case VT_I2:
    V_I2(result) = (~V_I2(&lv)) | V_I2(&rv);
    break;
    case VT_UI1:
    V_UI1(result) = (~V_UI1(&lv)) | V_UI1(&rv);
    break;
    case VT_BOOL:
    V_BOOL(result) = (~V_BOOL(&lv)) | V_BOOL(&rv);
    break;
    default:
	break;
    ////FixMe("Couldn't perform bitwise implication on variant types %d,%d\n",
    //    leftvt,rightvt);
    }

VarImp_Exit:

    VariantClear(&lv);
    VariantClear(&rv);
    VariantClear(&tempLeft);
    VariantClear(&tempRight);

    return hres;
}

static INT GetDateTimeFormatW(LCID lcid, DWORD dwFlags,
                              const SYSTEMTIME* lpTime, LPCWSTR lpFormat,
                              LPWSTR lpStr, INT cchOut)
{
  NLS_FORMAT_NODE nodeStack;
  NLS_FORMAT_NODE* node = &nodeStack;
  SYSTEMTIME st;
  INT cchWritten = 0;
  INT lastFormatPos = 0;
  BOOL bSkipping = FALSE; /* Skipping text around marker? */
  BOOL d_dd_formatted = FALSE; /* previous formatted part was for d or dd */

  /* Verify our arguments */
  if ((cchOut && !lpStr) || !NLS_GetFormats(lcid, dwFlags, nodeStack))
    goto invalid_parameter;

  if (dwFlags & ~(DATE_DATEVARSONLY|TIME_TIMEVARSONLY))
  {
    if (lpFormat &&
        ((dwFlags & DATE_DATEVARSONLY && dwFlags & ~DATE_FORMAT_FLAGS) ||
         (dwFlags & TIME_TIMEVARSONLY && dwFlags & ~TIME_FORMAT_FLAGS)))
    {
      goto invalid_flags;
    }

    if (dwFlags & DATE_DATEVARSONLY)
    {
      if ((dwFlags & (DATE_LTRREADING|DATE_RTLREADING)) == (DATE_LTRREADING|DATE_RTLREADING))
        goto invalid_flags;
      else if (dwFlags & (DATE_LTRREADING|DATE_RTLREADING))
        FIXME("Unsupported flags: DATE_LTRREADING/DATE_RTLREADING\n");

      switch (dwFlags & (DATE_SHORTDATE|DATE_LONGDATE|DATE_YEARMONTH))
      {
      case 0:
        break;
      case DATE_SHORTDATE:
      case DATE_LONGDATE:
      case DATE_YEARMONTH:
        if (lpFormat)
          goto invalid_flags;
        break;
      default:
        goto invalid_flags;
      }
    }
  }

  if (!lpFormat)
  {
    /* Use the appropriate default format */
    if (dwFlags & DATE_DATEVARSONLY)
    {
      if (dwFlags & DATE_YEARMONTH)
        lpFormat = GetYearMonth(node);
      else if (dwFlags & DATE_LONGDATE)
        lpFormat = GetLongDate(node);
      else
        lpFormat = GetShortDate(node);
    }
    else
      lpFormat = GetTime(node);
  }

  if (!lpTime)
  {
    GetLocalTime(&st); /* Default to current time */
    lpTime = &st;
  }
  else
  {
    if (dwFlags & DATE_DATEVARSONLY)
    {
      FILETIME ftTmp;

      /* Verify the date and correct the D.O.W. if needed */
      memset(&st, 0, sizeof(st));
      st.wYear = lpTime->wYear;
      st.wMonth = lpTime->wMonth;
      st.wDay = lpTime->wDay;

      if (st.wDay > 31 || st.wMonth > 12 || !SystemTimeToFileTime(&st, &ftTmp))
        goto invalid_parameter;

      FileTimeToSystemTime(&ftTmp, &st);
      lpTime = &st;
    }

    if (dwFlags & TIME_TIMEVARSONLY)
    {
      /* Verify the time */
      if (lpTime->wHour > 24 || lpTime->wMinute > 59 || lpTime->wSecond > 59)
        goto invalid_parameter;
    }
  }

  /* Format the output */
  while (*lpFormat)
  {
    if (IsLiteralMarker(*lpFormat))
    {
      /* Start of a literal string */
      lpFormat++;

      /* Loop until the end of the literal marker or end of the string */
      while (*lpFormat)
      {
        if (IsLiteralMarker(*lpFormat))
        {
          lpFormat++;
          if (!IsLiteralMarker(*lpFormat))
            break; /* Terminating literal marker */
        }

        if (!cchOut)
          cchWritten++;   /* Count size only */
        else if (cchWritten >= cchOut)
          goto overrun;
        else if (!bSkipping)
        {
          lpStr[cchWritten] = *lpFormat;
          cchWritten++;
        }
        lpFormat++;
      }
    }
    else if ((dwFlags & DATE_DATEVARSONLY && IsDateFmtChar(*lpFormat)) ||
             (dwFlags & TIME_TIMEVARSONLY && IsTimeFmtChar(*lpFormat)))
    {
      WCHAR buff[32], fmtChar;
      LPCWSTR szAdd = NULL;
      DWORD dwVal = 0;
      int   count = 0, dwLen;

      bSkipping = FALSE;

      fmtChar = *lpFormat;
      while (*lpFormat == fmtChar)
      {
        count++;
        lpFormat++;
      }
      buff[0] = '\0';

      if (fmtChar != 'M') d_dd_formatted = FALSE;
      switch(fmtChar)
      {
      case 'd':
        if (count >= 4)
          szAdd = GetLongDay(node, (lpTime->wDayOfWeek + 6) % 7);
        else if (count == 3)
          szAdd = GetShortDay(node, (lpTime->wDayOfWeek + 6) % 7);
        else
        {
          dwVal = lpTime->wDay;
          szAdd = buff;
          d_dd_formatted = TRUE;
        }
        break;

      case 'M':
        if (count >= 4)
        {
          LPCWSTR genitive = GetGenitiveMonth(node, lpTime->wMonth - 1);
          if (genitive)
          {
            if (d_dd_formatted)
            {
              szAdd = genitive;
              break;
            }
            else
            {
              LPCWSTR format = lpFormat;
              /* Look forward now, if next format pattern is for day genitive
                 name should be used */
              while (*format)
              {
                /* Skip parts within markers */
                if (IsLiteralMarker(*format))
                {
                  ++format;
                  while (*format)
                  {
                    if (IsLiteralMarker(*format))
                    {
                      ++format;
                      if (!IsLiteralMarker(*format)) break;
                    }
                  }
                }
                if (*format != ' ') break;
                ++format;
              }
              /* Only numeric day form matters */
              if (*format && *format == 'd')
              {
                INT dcount = 1;
                while (*++format == 'd') dcount++;
                if (dcount < 3)
                {
                  szAdd = genitive;
                  break;
                }
              }
            }
          }
          szAdd = GetLongMonth(node, lpTime->wMonth - 1);
        }
        else if (count == 3)
          szAdd = GetShortMonth(node, lpTime->wMonth - 1);
        else
        {
          dwVal = lpTime->wMonth;
          szAdd = buff;
        }
        break;

      case 'y':
        if (count >= 4)
        {
          count = 4;
          dwVal = lpTime->wYear;
        }
        else
        {
          count = count > 2 ? 2 : count;
          dwVal = lpTime->wYear % 100;
        }
        szAdd = buff;
        break;

      case 'g':
        if (count == 2)
        {
          /* FIXME: Our GetCalendarInfo() does not yet support CAL_SERASTRING.
           *        When it is fixed, this string should be cached in 'node'.
           */
          FIXME("Should be using GetCalendarInfo(CAL_SERASTRING), defaulting to 'AD'\n");
          buff[0] = 'A'; buff[1] = 'D'; buff[2] = '\0';
        }
        else
        {
          buff[0] = 'g'; buff[1] = '\0'; /* Add a literal 'g' */
        }
        szAdd = buff;
        break;

      case 'h':
        if (!(dwFlags & TIME_FORCE24HOURFORMAT))
        {
          count = count > 2 ? 2 : count;
          dwVal = lpTime->wHour == 0 ? 12 : (lpTime->wHour - 1) % 12 + 1;
          szAdd = buff;
          break;
        }
        /* .. fall through if we are forced to output in 24 hour format */

      case 'H':
        count = count > 2 ? 2 : count;
        dwVal = lpTime->wHour;
        szAdd = buff;
        break;

      case 'm':
        if (dwFlags & TIME_NOMINUTESORSECONDS)
        {
          cchWritten = lastFormatPos; /* Skip */
          bSkipping = TRUE;
        }
        else
        {
          count = count > 2 ? 2 : count;
          dwVal = lpTime->wMinute;
          szAdd = buff;
        }
        break;

      case 's':
        if (dwFlags & (TIME_NOSECONDS|TIME_NOMINUTESORSECONDS))
        {
          cchWritten = lastFormatPos; /* Skip */
          bSkipping = TRUE;
        }
        else
        {
          count = count > 2 ? 2 : count;
          dwVal = lpTime->wSecond;
          szAdd = buff;
        }
        break;

      case 't':
        if (dwFlags & TIME_NOTIMEMARKER)
        {
          cchWritten = lastFormatPos; /* Skip */
          bSkipping = TRUE;
        }
        else
        {
          if (count == 1)
            szAdd = lpTime->wHour < 12 ? node->szShortAM : node->szShortPM;
          else
            szAdd = lpTime->wHour < 12 ? GetAM(node) : GetPM(node);
        }
        break;
      }

      if (szAdd == buff && buff[0] == '\0')
      {
        static const char fmt[] = {'%','.','*','d',0};
        /* We have a numeric value to add */
		char tmpBuffer[256];
		snprintf(tmpBuffer, 256, fmt, count, dwVal);
		wcscpy(buff, StrAdapter(tmpBuffer));
      }

      dwLen = szAdd ? strlenW(szAdd) : 0;

      if (cchOut && dwLen)
      {
        if (cchWritten + dwLen < cchOut)
          memcpy(lpStr + cchWritten, szAdd, dwLen * sizeof(WCHAR));
        else
        {
          memcpy(lpStr + cchWritten, szAdd, (cchOut - cchWritten) * sizeof(WCHAR));
          goto overrun;
        }
      }
      cchWritten += dwLen;
      lastFormatPos = cchWritten; /* Save position of last output format text */
    }
    else
    {
      /* Literal character */
      if (!cchOut)
        cchWritten++;   /* Count size only */
      else if (cchWritten >= cchOut)
        goto overrun;
      else if (!bSkipping || *lpFormat == ' ')
      {
        lpStr[cchWritten] = *lpFormat;
        cchWritten++;
      }
      lpFormat++;
    }
  }


  /* Final string terminator and sanity check */
  if (cchOut)
  {
   if (cchWritten >= cchOut)
     goto overrun;
   else
     lpStr[cchWritten] = '\0';
  }
  cchWritten++; /* Include terminating NUL */

  TRACE("returning length=%d, ouput=%s\n", cchWritten, debugstr_w(lpStr));
  return cchWritten;

overrun:
  TRACE("returning 0, (ERROR_INSUFFICIENT_BUFFER)\n");
  //SetLastError(ERROR_INSUFFICIENT_BUFFER);
  return 0;

invalid_parameter:
  //SetLastError(ERROR_INVALID_PARAMETER);
  return 0;

invalid_flags:
  //SetLastError(ERROR_INVALID_FLAGS);
  return 0;
}

INT WINAPI GetDateFormatW(LCID lcid, DWORD dwFlags, const SYSTEMTIME* lpTime,
                          LPCWSTR lpFormat, LPWSTR lpDateStr, INT cchOut)
{
  return GetDateFormat(lcid, dwFlags|DATE_DATEVARSONLY, lpTime,
                                lpFormat, lpDateStr, cchOut);
}

INT WINAPI GetTimeFormatW(LCID lcid, DWORD dwFlags, const SYSTEMTIME* lpTime,
                          LPCWSTR lpFormat, LPWSTR lpTimeStr, INT cchOut)
{
  return GetTimeFormat(lcid, dwFlags|TIME_TIMEVARSONLY, lpTime,
                                lpFormat, lpTimeStr, cchOut);
}

BOOL WINAPI NtQuerySystemTime( PLARGE_INTEGER Time )
{
    struct timeval now;

    gettimeofday( &now, 0 );
    Time->QuadPart = now.tv_sec * (ULONGLONG)TICKSPERSEC + TICKS_1601_TO_1970;
    Time->QuadPart += now.tv_usec * 10;
    return true;
}

VOID WINAPI GetSystemTime(LPSYSTEMTIME systime)
{
    FILETIME ft;
    LARGE_INTEGER t;

    NtQuerySystemTime(&t);
    ft.dwLowDateTime = t.u.LowPart;
    ft.dwHighDateTime = t.u.HighPart;
    FileTimeToSystemTime(&ft, systime);
}

BOOL WINAPI FileTimeToSystemTime(const FILETIME *ft, LPSYSTEMTIME syst )
{
  TIME_FIELDS tf;
  LARGE_INTEGER t;

  t.LowPart = ft->dwLowDateTime;
  t.HighPart = ft->dwHighDateTime;
  RtlTimeToTimeFields(&t, &tf);

  syst->wYear = tf.Year;
  syst->wDay = tf.Day;
  syst->wMonth = tf.Month;
  syst->wHour = tf.Hour;
  syst->wMinute = tf.Minute;
  syst->wSecond = tf.Second;
  syst->wMilliseconds = tf.Milliseconds;
  syst->wDayOfWeek = tf.Weekday;
  return TRUE;
}

BOOLEAN WINAPI RtlTimeFieldsToTime(PTIME_FIELDS tfTimeFields,
                                   PLARGE_INTEGER Time)
{
  int month, year, cleaps, day;

   /* FIXME: normalize the TIME_FIELDS structure here */
    /* No, native just returns 0 (error) if the fields are not */
  if( tfTimeFields->Milliseconds < 0 || tfTimeFields->Milliseconds > 999 ||
       tfTimeFields->Second      < 0 || tfTimeFields->Second       > 59  ||
       tfTimeFields->Minute      < 0 || tfTimeFields->Minute       > 59  ||
       tfTimeFields->Hour        < 0 || tfTimeFields->Hour         > 23  ||
       tfTimeFields->Month       < 1 || tfTimeFields->Month        > 12  ||
       tfTimeFields->Day         < 1 ||
       tfTimeFields->Day > MonthLengths
       [ tfTimeFields->Month ==2 || IsLeapYear(tfTimeFields->Year)]
       [ tfTimeFields->Month - 1] ||
       tfTimeFields->Year < 1601 )
            return FALSE;

  /* now calculate a day count from the date
   * First start counting years from March. This way the leap days
   * are added at the end of the year, not somewhere in the middle.
   * Formula's become so much less complicate that way.
   * To convert: add 12 to the month numbers of Jan and Feb, and 
   * take 1 from the year */
        if(tfTimeFields->Month < 3) {
            month = tfTimeFields->Month + 13;
            year = tfTimeFields->Year - 1;
        } else {
            month = tfTimeFields->Month + 1;
            year = tfTimeFields->Year;
        }
        cleaps = (3 * (year / 100) + 3) / 4;   /* nr of "century leap years"*/
        day =  (36525 * year) / 100 - cleaps + /* year * dayperyr, corrected */
                 (1959 * month) / 64 +         /* months * daypermonth */
                 tfTimeFields->Day -          /* day of the month */
                 584817 ;                      /* zero that on 1601-01-01 */
        /* done */

        Time->QuadPart = (((((LONGLONG) day * HOURSPERDAY +
            tfTimeFields->Hour) * MINSPERHOUR +
            tfTimeFields->Minute) * SECSPERMIN +
            tfTimeFields->Second ) * 1000 +
            tfTimeFields->Milliseconds ) * TICKSPERMSEC;

        return TRUE;
}

VOID WINAPI RtlTimeToTimeFields(const LARGE_INTEGER *liTime,
                                PTIME_FIELDS TimeFields)
{
  int SecondsInDay;
  long int cleaps, years, yearday, months;
  long int Days;
  LONGLONG Time;

  /* Extract millisecond from time and convert time into seconds */
  TimeFields->Milliseconds =
    (CSHORT) (( liTime->QuadPart % TICKSPERSEC) / TICKSPERMSEC);
  Time = liTime->QuadPart / TICKSPERSEC;

  /* The native version of RtlTimeToTimeFields does not take leap seconds
  * into account */
  /* Split the time into days and seconds within the day */
  Days = Time / SECSPERDAY;
  SecondsInDay = Time % SECSPERDAY;

  /* compute time of day */
  TimeFields->Hour = (CSHORT) (SecondsInDay / SECSPERHOUR);
  SecondsInDay = SecondsInDay % SECSPERHOUR;
  TimeFields->Minute = (CSHORT) (SecondsInDay / SECSPERMIN);
  TimeFields->Second = (CSHORT) (SecondsInDay % SECSPERMIN);

  /* compute day of week */
  TimeFields->Weekday = (CSHORT) ((EPOCHWEEKDAY + Days) % DAYSPERWEEK);
  /* compute year, month and day of month. */
  cleaps=( 3 * ((4 * Days + 1227) / DAYSPERQUADRICENTENNIUM) + 3 ) / 4;
  Days += 28188 + cleaps;
  years = (20 * Days - 2442) / (5 * DAYSPERNORMALQUADRENNIUM);
  yearday = Days - (years * DAYSPERNORMALQUADRENNIUM)/4;
  months = (64 * yearday) / 1959;
  /* the result is based on a year starting on March.
  * To convert take 12 from Januari and Februari and
  * increase the year by one. */
  if( months < 14 ) 
  {
    TimeFields->Month = months - 1;
    TimeFields->Year = years + 1524;
  } 
  else 
  {
    TimeFields->Month = months - 13;
    TimeFields->Year = years + 1525;
  }
  /* calculation of day of month is based on the wonderful
  * sequence of INT( n * 30.6): it reproduces the 
  * 31-30-31-30-31-31 month lengths exactly for small n's */
  TimeFields->Day = yearday - (1959 * months) / 64 ;
}


static bool NLS_GetFormats(LCID lcid, DWORD dwFlags, NLS_FORMAT_NODE& node)
// WINE caches these values and allowes for storing them for multiple locales
// it's only ever called once, so calculate on the fly.
{
  node.lcid = lcid;
  node.dwFlags = dwFlags;
  GetLocaleInfo(lcid, dwFlags|LOCALE_S1159, node.szShortAM, 2);
  GetLocaleInfo(lcid, dwFlags|LOCALE_S2359, node.szShortPM, 2);
    
  // we need to fill this structure up in lppszStrings[NLS_NUM_CACHED_STRINGS]
  static const LCTYPE NLS_LocaleIndices[NLS_NUM_CACHED_STRINGS] = {
  LOCALE_SNEGATIVESIGN,
  LOCALE_SLONGDATE, LOCALE_SSHORTDATE,
  LOCALE_STIMEFORMAT,
  LOCALE_SDAYNAME1, LOCALE_SDAYNAME2, LOCALE_SDAYNAME3,
  LOCALE_SDAYNAME4, LOCALE_SDAYNAME5, LOCALE_SDAYNAME6, LOCALE_SDAYNAME7,
  LOCALE_SABBREVDAYNAME1, LOCALE_SABBREVDAYNAME2, LOCALE_SABBREVDAYNAME3,
  LOCALE_SABBREVDAYNAME4, LOCALE_SABBREVDAYNAME5, LOCALE_SABBREVDAYNAME6,
  LOCALE_SABBREVDAYNAME7,
  LOCALE_SMONTHNAME1, LOCALE_SMONTHNAME2, LOCALE_SMONTHNAME3,
  LOCALE_SMONTHNAME4, LOCALE_SMONTHNAME5, LOCALE_SMONTHNAME6,
  LOCALE_SMONTHNAME7, LOCALE_SMONTHNAME8, LOCALE_SMONTHNAME9,
  LOCALE_SMONTHNAME10, LOCALE_SMONTHNAME11, LOCALE_SMONTHNAME12,
  LOCALE_SMONTHNAME1  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME2  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME3  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME4  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME5  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME6  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME7  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME8  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME9  | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME10 | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME11 | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SMONTHNAME12 | LOCALE_RETURN_GENITIVE_NAMES,
  LOCALE_SABBREVMONTHNAME1, LOCALE_SABBREVMONTHNAME2, LOCALE_SABBREVMONTHNAME3,
  LOCALE_SABBREVMONTHNAME4, LOCALE_SABBREVMONTHNAME5, LOCALE_SABBREVMONTHNAME6,
  LOCALE_SABBREVMONTHNAME7, LOCALE_SABBREVMONTHNAME8, LOCALE_SABBREVMONTHNAME9,
  LOCALE_SABBREVMONTHNAME10, LOCALE_SABBREVMONTHNAME11, LOCALE_SABBREVMONTHNAME12,
  LOCALE_S1159, LOCALE_S2359,
  LOCALE_SYEARMONTH
  };

  for (int i = 0 ; i < NLS_NUM_CACHED_STRINGS; i++)
    GetLocaleInfo(lcid, dwFlags|NLS_LocaleIndices[i], node.lppszStrings[i], NLS_STRING_SIZE);

  return true;
}

#ifndef UNIX_FILEGDB_API
VOID WINAPI GetLocalTime(LPSYSTEMTIME systime)
{
  FILETIME lft;
  LARGE_INTEGER ft, ft2;

  NtQuerySystemTime(&ft);
  RtlSystemTimeToLocalTime(&ft, &ft2);
  lft.dwLowDateTime = ft2.u.LowPart;
  lft.dwHighDateTime = ft2.u.HighPart;
  FileTimeToSystemTime(&lft, systime);
}
#endif

BOOL WINAPI SystemTimeToFileTime( const SYSTEMTIME *syst, LPFILETIME ft )
{
  TIME_FIELDS tf;
  LARGE_INTEGER t;

  tf.Year = syst->wYear;
  tf.Month = syst->wMonth;
  tf.Day = syst->wDay;
  tf.Hour = syst->wHour;
  tf.Minute = syst->wMinute;
  tf.Second = syst->wSecond;
  tf.Milliseconds = syst->wMilliseconds;

  if( !RtlTimeFieldsToTime(&tf, &t)) 
  {
    return FALSE;
  }

  ft->dwLowDateTime = t.u.LowPart;
  ft->dwHighDateTime = t.u.HighPart;
  return TRUE;
}

INT WINAPI RtlSystemTimeToLocalTime( const LARGE_INTEGER *SystemTime,
                                          PLARGE_INTEGER LocalTime )
// For this implementation, system time and local time are equal.
// Both SystemTime and LocalTime functions end up at gettimeofday, which 
// returns the local time. So don't calculate a bias.
{
  LONG bias = 0; 
  TRACE("(%p, %p)\n", SystemTime, LocalTime);
  //bias = TIME_GetBias();
  LocalTime->QuadPart = SystemTime->QuadPart - bias * (LONGLONG)TICKSPERSEC;
  return 0;
}
