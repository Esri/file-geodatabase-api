/*
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#ifndef WinSupport_h
#define WinSupport_h

#ifndef UNIX_FILEGDB_API
#error This file must only be included on Unix builds
#endif

#include "WinTypes.h"
#include "WinDef.h"

// So we can call min and max without modifying calling code that relies
// on the min/max macros.
using std::min;
using std::max;

// This header defines structures that we need to support Win32 interfaces.
// It may also include modified Win32 structures/interfaces.

// To force StrAdapter to fall back to using wcslen, strlen, wcstombs and
// mbstowcs, comment out the following line.
#define STR_ADAPTER_UNICODE

// Only null-terminated strings are supported by SrtAdapter
int str_utf8_to_uni(wchar_t*, const char*, int);
int str_uni_to_utf8(char*, const wchar_t*, int);
int str_utf8_len(const char*);
int str_uni_bytes(const wchar_t*);

class EXPORT StrAdapter
{
public:
  StrAdapter(const char* pAnsi)
  {m_pWide=0; m_isWide=false; m_pAnsi =((char*)pAnsi);}
  StrAdapter(const WCHAR* pWide)
  {m_pAnsi =0; m_isWide=true ; m_pWide=((WCHAR*)pWide);}
  ~StrAdapter()
  {
    if (m_isWide)
      delete [] m_pAnsi;
    else
      delete [] m_pWide;
  }

  operator LPCSTR()
  {
    if (!m_pAnsi && m_isWide)
    {
      if (!m_pWide)  // NULL string -- return NULL.
        return m_pAnsi;
#ifdef STR_ADAPTER_UNICODE
      int len = str_uni_bytes(m_pWide)+1;
      m_pAnsi = new char[len];
      if (m_pAnsi)
        str_uni_to_utf8(m_pAnsi, m_pWide, len);
#else
      size_t len = wcstombs(NULL, m_pWide, 0) + 1;
      if (len == 0)
      {
        len = wcslen(m_pWide);
        len++;
      }
	    m_pAnsi = new char[len];
      if (m_pAnsi)
        wcstombs(m_pAnsi, m_pWide, len);
#endif
    }
    return m_pAnsi;
  }

  operator LPCWSTR()
  {
    if (!m_pWide && !m_isWide)
    {
#ifdef STR_ADAPTER_UNICODE
      int len = str_utf8_len(m_pAnsi)+1;
      m_pWide = new WCHAR[len];
      if (m_pWide)
        str_utf8_to_uni(m_pWide, m_pAnsi, len);
#else
      size_t len = strlen(m_pAnsi) + 1;
      m_pWide = new WCHAR[len];
      if (m_pWide)
        mbstowcs(m_pWide, m_pAnsi, len);
#endif
    }
    return m_pWide;
  }

private:
  char*  m_pAnsi;
  WCHAR* m_pWide;
  bool   m_isWide;
};

struct GuidMapComp
{ // use special comparison for strings since default '<' fails
  bool operator() (const LPCWSTR a, const LPCWSTR b) const
  {return wcscmp(a, b) < 0;}
};

class CRITICAL_SECTION
{
public:
  CRITICAL_SECTION()
  { // make mutexes recursive to match windows
    pthread_mutexattr_t mtAttr;
    pthread_mutexattr_init(&mtAttr);
    pthread_mutexattr_settype(&mtAttr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&m_mutex, &mtAttr);
  }
  void lock()  {pthread_mutex_lock  (&m_mutex);}
  void unlock(){pthread_mutex_unlock(&m_mutex);}
private:
  pthread_mutex_t m_mutex;
};
typedef CRITICAL_SECTION *LPCRITICAL_SECTION;

// Define atomicLong type which provides locking mechanism for
// simulated atomic increment and decrement operations.
// Client assumes all locking responsibilities.
class atomicLong : public CRITICAL_SECTION
{
public:
  atomicLong();
  atomicLong(LONG initial_value):value(initial_value){}
  operator LONG (){return value;} // plays well with LONG
  operator LONG () const volatile {return value;} // plays well with LONG
  atomicLong& operator = (const LONG& l) {value = l; return *this;}
  volatile atomicLong& operator = (const LONG& l) volatile {value = l; return *this;}
  bool operator <  (const LONG& l){return value < l;}
  bool operator <= (const LONG& l){return value <= l;}
  bool operator >= (const LONG& l){return value >= l;}
  bool operator > (const LONG& l){return value > l;}
  bool operator ==(const LONG& l){return value == l;}
  atomicLong& operator * (){return *this;}
  atomicLong& operator ++ (){++value;return *this;}//prefix only
  atomicLong& operator -- (){--value;return *this;}//prefix only
private:
  LONG value;
};

#endif
