/*
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#ifndef WinDef_h
#define WinDef_h

#ifndef UNIX_FILEGDB_API
#error This file must only be included on Unix builds
#endif

#include "WinTypes.h"
#include "WinMap.h"
#include "WinStructures.h"
#define STDMETHOD(method)        virtual  HRESULT STDMETHODCALLTYPE method
#define STDMETHOD_(type,method)  virtual  type STDMETHODCALLTYPE method
#define STDMETHODIMP     HRESULT STDMETHODCALLTYPE
#define STDMETHODIMP_(type)     type STDMETHODCALLTYPE

#define WINAPI __attribute__((visibility("default")))
#define EXPORT WINAPI

#ifndef __APPLE__
#define MAX_COMPUTERNAME_LENGTH HOST_NAME_MAX
#else
#define MAX_COMPUTERNAME_LENGTH _SC_HOST_NAME_MAX
#endif

#define __TEXT(quote) L##quote
#define TEXT(quote) __TEXT(quote)
#define __T(x)      L ## x
#define _T(x)       __T(x)
#define _TEXT(x)    __T(x)
#define OLESTR(str) __T(str)

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
#define DECLARE_HANDLE(n) typedef struct n##__{int i;}*n
DECLARE_HANDLE (HWND);
DECLARE_HANDLE (HRSRC);

typedef HANDLE HGLOBAL;

#define FALSE 0
#define TRUE  1
#define _HRESULT_TYPEDEF_(_sc) ((HRESULT)_sc)
#define SUCCEEDED(Status) ((HRESULT)(Status) >= 0)
#define FAILED(Status) ((HRESULT)(Status)<0)
#define S_OK                 _HRESULT_TYPEDEF_(0x00000000L)
#define E_FAIL               _HRESULT_TYPEDEF_(0x80004005L)
#define DISP_E_BADINDEX      _HRESULT_TYPEDEF_(0x8002000BL)
#define E_INVALIDARG         _HRESULT_TYPEDEF_(0x80070057L)
#define DISP_E_ARRAYISLOCKED _HRESULT_TYPEDEF_(0x8002000DL)
#define CO_E_CLASSSTRING     _HRESULT_TYPEDEF_(0x800401F3L)
#define E_OUTOFMEMORY        _HRESULT_TYPEDEF_(0x8007000EL)
#define E_NOTIMPL            _HRESULT_TYPEDEF_(0x80004001L)
#define E_NOINTERFACE        _HRESULT_TYPEDEF_(0x80004002L)
#define E_POINTER            _HRESULT_TYPEDEF_(0x80004003L)
#define DISP_E_BADVARTYPE    _HRESULT_TYPEDEF_(0x80020008L)
#define DISP_E_TYPEMISMATCH  _HRESULT_TYPEDEF_(0x80020005L)
#define DISP_E_OVERFLOW      _HRESULT_TYPEDEF_(0x8002000AL)
#define DISP_E_DIVBYZERO     _HRESULT_TYPEDEF_(0x80020012L)
#define E_UNEXPECTED         _HRESULT_TYPEDEF_(0x8000FFFFL)
#define	FADF_AUTO        0x0001
#define	FADF_STATIC      0x0002
#define	FADF_EMBEDDED    0x0004
#define	FADF_FIXEDSIZE   0x0010
#define	FADF_RECORD      0x0020
#define	FADF_HAVEIID     0x0040
#define	FADF_HAVEVARTYPE 0x0080
#define	FADF_BSTR	       0x0100
#define	FADF_UNKNOWN     0x0200
#define	FADF_DISPATCH    0x0400
#define	FADF_VARIANT     0x0800
#define	FADF_RESERVED    0xf008

#define ERROR_INSUFFICIENT_BUFFER        122L
#define ERROR_INVALID_PARAMETER          87L
#define ERROR_INVALID_FLAGS              1004L

#define LANG_NEUTRAL                0x00
#define LANG_ENGLISH                0x09
#define SUBLANG_ENGLISH_US          0x01    // English (USA)
#define SUBLANG_DEFAULT             0x01
#define SUBLANG_SYS_DEFAULT         0x02
#define LANG_INVARIANT              0x7f
#define LANG_CHINESE                0x04
#define LANG_CHINESE_SIMPLIFIED     0x04
#define LANG_CHINESE_TRADITIONAL    0x7c04
#define LANG_JAPANESE               0x11
#define LANG_KOREAN                 0x12
#define SUBLANG_CHINESE_HONGKONG    0x03
#define SUBLANG_CHINESE_TRADITIONAL 0x01

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
#define LOCALE_SDECIMAL               14
#define LOCALE_STHOUSAND              15
#define LOCALE_SCURRENCY              20
#define LOCALE_SMONDECIMALSEP         22
#define LOCALE_SMONTHOUSANDSEP        23
#define LOCALE_SDATE                  29
#define LOCALE_SSHORTDATE             31
#define LOCALE_SLONGDATE              32
#define LOCALE_IDATE                  33
#define LOCALE_S1159                  40
#define LOCALE_S2359                  41
#define LOCALE_SDAYNAME1              42
#define LOCALE_SDAYNAME2              43
#define LOCALE_SDAYNAME3              44
#define LOCALE_SDAYNAME4              45
#define LOCALE_SDAYNAME5              46
#define LOCALE_SDAYNAME6              47
#define LOCALE_SDAYNAME7              48
#define LOCALE_SABBREVDAYNAME1        49
#define LOCALE_SABBREVDAYNAME2        50
#define LOCALE_SABBREVDAYNAME3        51
#define LOCALE_SABBREVDAYNAME4        52
#define LOCALE_SABBREVDAYNAME5        53
#define LOCALE_SABBREVDAYNAME6        54
#define LOCALE_SABBREVDAYNAME7        55
#define LOCALE_SMONTHNAME1            56
#define LOCALE_SMONTHNAME2            57
#define LOCALE_SMONTHNAME3            58
#define LOCALE_SMONTHNAME4            59
#define LOCALE_SMONTHNAME5            60
#define LOCALE_SMONTHNAME6            61
#define LOCALE_SMONTHNAME7            62
#define LOCALE_SMONTHNAME8            63
#define LOCALE_SMONTHNAME9            64
#define LOCALE_SMONTHNAME10           65
#define LOCALE_SMONTHNAME11           66
#define LOCALE_SMONTHNAME12           67
#define LOCALE_SMONTHNAME13           0x100E
#define LOCALE_SABBREVMONTHNAME1      68
#define LOCALE_SABBREVMONTHNAME2      69
#define LOCALE_SABBREVMONTHNAME3      70
#define LOCALE_SABBREVMONTHNAME4      71
#define LOCALE_SABBREVMONTHNAME5      72
#define LOCALE_SABBREVMONTHNAME6      73
#define LOCALE_SABBREVMONTHNAME7      74
#define LOCALE_SABBREVMONTHNAME8      75
#define LOCALE_SABBREVMONTHNAME9      76
#define LOCALE_SABBREVMONTHNAME10     77
#define LOCALE_SABBREVMONTHNAME11     78
#define LOCALE_SABBREVMONTHNAME12     79
#define LOCALE_SABBREVMONTHNAME13     0x100F
#define LOCALE_SPOSITIVESIGN          80
#define LOCALE_SNEGATIVESIGN          81
#define LOCALE_STIMEFORMAT            0x1003
#define LOCALE_SYEARMONTH             0x1006
#define LOCALE_RETURN_NUMBER          0x20000000
#define LOCALE_NOUSEROVERRIDE         0x80000000
#define LOCALE_SENGCOUNTRY            0x1002
#define LOCALE_SENGLANGUAGE           0x1001
#define LOCALE_IDEFAULTANSICODEPAGE   0x1004
#define LOCALE_FONTSIGNATURE          88
#define LOCALE_SISO639LANGNAME        89
#define LOCALE_SISO3166CTRYNAME       90
#define DATE_SHORTDATE                1
#define DATE_LONGDATE                 2
#define DATE_USE_ALT_CALENDAR         4
#define DATE_YEARMONTH                8
#define DATE_LTRREADING               16
#define DATE_RTLREADING               32
#define TIME_NOMINUTESORSECONDS       1
#define TIME_NOSECONDS                2
#define TIME_NOTIMEMARKER             4
#define TIME_FORCE24HOURFORMAT        8
#define LOCALE_STIME                  30
#define LCID_SUPPORTED                2
#define CP_UTF8                       65001
#define CP_THREAD_ACP                 3
#define DISPID_VALUE (0)

// Don't use this on Linux - map it to nothing so it can't be anded or or'd 
#define LOCALE_RETURN_GENITIVE_NAMES  0x0 // no support for this on Linux

#define MAX_PATH          260
#define EXTERN_C    extern "C"
#define _NLSCMPERROR    2147483647 

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
#define DISPATCH_METHOD         1
#define DISPATCH_PROPERTYGET    2
#define DISPATCH_PROPERTYPUT    4
#define DISPATCH_PROPERTYPUTREF 8
#define HEAP_NO_SERIALIZE             1
#define HEAP_GROWABLE                 2
#define HEAP_GENERATE_EXCEPTIONS      4
#define HEAP_ZERO_MEMORY              8
#define HEAP_REALLOC_IN_PLACE_ONLY    16
#define HEAP_TAIL_CHECKING_ENABLED    32
#define HEAP_FREE_CHECKING_ENABLED    64
#define HEAP_DISABLE_COALESCE_ON_FREE 128
#define HEAP_CREATE_ALIGN_16          0x0000
#define HEAP_CREATE_ENABLE_TRACING    0x20000
#define HEAP_MAXIMUM_TAG              0xFFF
#define HEAP_PSEUDO_TAG_FLAG          0x8000
#define HEAP_TAG_SHIFT                16    
#define DLL_PROCESS_DETACH     0  
#define DLL_PROCESS_ATTACH     1    
#define DLL_THREAD_ATTACH      2    
#define DLL_THREAD_DETACH      3    
#define SORT_DEFAULT           0
#define MAKELANGID(p,s)  ((((WORD)(s))<<10)|(WORD)(p))
#define PRIMARYLANGID(l) ((WORD)(l)&0x3ff)
#define SUBLANGID(l)     ((WORD)(l)>>10)
#define NLS_VALID_LOCALE_MASK   1048575
#define MAKELCID(l,s) ((DWORD)((((DWORD)((WORD)(s)))<<16)|((DWORD)((WORD)(l)))))
#define LANGIDFROMLCID(l)       ((WORD)(l))
#define SORTIDFROMLCID(lcid)   ((WORD  )((((DWORD)(lcid)) >> 16) & 0xf))
#define SORTVERSIONFROMLCID(l) ((WORD)((((DWORD)(l))>>20)&0xf))
#define LANG_SYSTEM_DEFAULT     MAKELANGID(LANG_NEUTRAL,SUBLANG_SYS_DEFAULT)
#define LANG_USER_DEFAULT       MAKELANGID(LANG_NEUTRAL,SUBLANG_DEFAULT)
#define LOCALE_SYSTEM_DEFAULT  0x800
#define LOCALE_USER_DEFAULT    0x400
#define GENERIC_READ    0x80000000
#define GENERIC_WRITE   0x40000000
#define GENERIC_EXECUTE 0x20000000
#define GENERIC_ALL     0x10000000
#define PROCESS_VM_READ 16
#define PROCESS_QUERY_INFORMATION       1024
#define FILE_SHARE_READ     0x00000001  
#define FILE_SHARE_WRITE    0x00000002  
#define FILE_SHARE_DELETE   0x00000004  
#define CREATE_NEW          1
#define CREATE_ALWAYS       2
#define OPEN_EXISTING       3
#define OPEN_ALWAYS         4
#define TRUNCATE_EXISTING   5
#define INVALID_FILE_ATTRIBUTES ((DWORD)-1)

#define LOCALE_NAME_MAX_LENGTH   85

// Our version for compatibility
#if defined (DEBUG) || defined (_DEBUG)
#define ASSERT(x)                       \
{                                       \
    if (!(x))                           \
    {                                   \
      static WCHAR tmp[] = TEXT(#x);    \
      OutputDebugString(L"ASSERT: ");   \
	    OutputDebugString(tmp);           \
	    OutputDebugString(L"\n");         \
    }                                   \
}
#else
#define ASSERT(x)
#endif 

#define _ASSERT(expr)   ASSERT(expr)

typedef enum tagREGCLS
{
  REGCLS_SINGLEUSE      = 0,
  REGCLS_MULTIPLEUSE    = 1,
  REGCLS_MULTI_SEPARATE = 2,
  REGCLS_SUSPENDED      = 4,
  REGCLS_SURROGATE      = 8 
} REGCLS;

typedef enum tagCLSCTX
{
  CLSCTX_INPROC_SERVER          = 0x1,
  CLSCTX_INPROC_HANDLER         = 0x2,
  CLSCTX_LOCAL_SERVER           = 0x4,
  CLSCTX_INPROC_SERVER16        = 0x8,
  CLSCTX_REMOTE_SERVER          = 0x10,
  CLSCTX_INPROC_HANDLER16       = 0x20,
  CLSCTX_RESERVED1              = 0x40,
  CLSCTX_RESERVED2              = 0x80,
  CLSCTX_RESERVED3              = 0x100,
  CLSCTX_RESERVED4              = 0x200,
  CLSCTX_NO_CODE_DOWNLOAD       = 0x400,
  CLSCTX_RESERVED5              = 0x800,
  CLSCTX_NO_CUSTOM_MARSHAL      = 0x1000,
  CLSCTX_ENABLE_CODE_DOWNLOAD   = 0x2000,
  CLSCTX_NO_FAILURE_LOG         = 0x4000,
  CLSCTX_DISABLE_AAA            = 0x8000,
  CLSCTX_ENABLE_AAA             = 0x10000,
  CLSCTX_FROM_DEFAULT_CONTEXT   = 0x20000,
  CLSCTX_ACTIVATE_32_BIT_SERVER = 0x40000,
  CLSCTX_ACTIVATE_64_BIT_SERVER = 0x80000,
  CLSCTX_ENABLE_CLOAKING        = 0x100000,
  CLSCTX_PS_DLL                 = 0x80000000
} CLSCTX;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
#define CLSCTX_ALL (CLSCTX_INPROC_SERVER|CLSCTX_INPROC_HANDLER|CLSCTX_LOCAL_SERVER)
enum VARENUM {
  VT_EMPTY,VT_NULL,VT_I2,VT_I4,VT_R4,VT_R8,VT_CY,VT_DATE,VT_BSTR,VT_DISPATCH,
  VT_ERROR,VT_BOOL,VT_VARIANT,VT_UNKNOWN,VT_DECIMAL,VT_I1=16,VT_UI1,VT_UI2,
  VT_UI4,VT_I8,VT_UI8,VT_INT,VT_UINT,VT_VOID,VT_HRESULT,VT_PTR,VT_SAFEARRAY,
  VT_CARRAY,VT_USERDEFINED,VT_LPSTR,VT_LPWSTR,VT_RECORD=36,VT_INT_PTR=37,
  VT_UINT_PTR=38,VT_FILETIME=64,VT_BLOB,VT_STREAM,VT_STORAGE,
  VT_STREAMED_OBJECT,VT_STORED_OBJECT,VT_BLOB_OBJECT,VT_CF,VT_CLSID,
  VT_BSTR_BLOB=0xfff,VT_VECTOR=0x1000,VT_ARRAY=0x2000,VT_BYREF=0x4000,
  VT_RESERVED=0x8000,VT_ILLEGAL= 0xffff,VT_ILLEGALMASKED=0xfff,
  VT_TYPEMASK=0xfff
};
#define DECIMAL_NEG ((BYTE)0x80)
#define DECIMAL_SETZERO(d) {(d).Lo64=(d).Hi32=(d).signscale=0;}

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
#define V_UNION(X,Y) ((X)->Y)
#define V_VT(X) ((X)->vt)
#define V_BOOL(X) V_UNION(X,boolVal)
#define V_ISBYREF(X) (V_VT(X)&VT_BYREF)
#define V_ISARRAY(X) (V_VT(X)&VT_ARRAY)
#define V_ISVECTOR(X) (V_VT(X)&VT_VECTOR)
#define V_NONE(X) V_I2(X)
#define V_UI1(X) V_UNION(X,bVal)
#define V_UI1REF(X) V_UNION(X,pbVal)
#define V_I2(X) V_UNION(X,iVal)
#define V_UI2(X) V_UNION(X,uiVal)
#define V_I2REF(X) V_UNION(X,piVal)
#define V_I4(X) V_UNION(X,lVal)
#define V_UI4(X) V_UNION(X,ulVal)
#define V_I4REF(X) V_UNION(X,plVal)
#define V_UI4REF(X) V_UNION(X,pulVal)
#define V_I8(X) V_UNION(X,llVal)
#define V_UI8(X) V_UNION(X,ullVal)
#define V_I8REF(X) V_UNION(X,pllVal)
#define V_UI8REF(X) V_UNION(X,pullVal)
#define V_R4(X) V_UNION(X,fltVal)
#define V_R4REF(X) V_UNION(X,pfltVal)
#define V_R8(X) V_UNION(X,dblVal)
#define V_R8REF(X) V_UNION(X,pdblVal)
#define V_CY(X) V_UNION(X,cyVal)
#define V_CYREF(X) V_UNION(X,pcyVal)
#define V_DATE(X) V_UNION(X,date)
#define V_DATEREF(X) V_UNION(X,pdate)
#define V_BSTR(X) V_UNION(X,bstrVal)
#define V_BSTRREF(X) V_UNION(X,pbstrVal)
#define V_DISPATCH(X) V_UNION(X,pdispVal)
#define V_DISPATCHREF(X) V_UNION(X,ppdispVal)
#define V_ERROR(X) V_UNION(X,scode)
#define V_ERRORREF(X) V_UNION(X,pscode)
#define V_BOOLREF(X) V_UNION(X,pboolVal)
#define V_UNKNOWN(X) V_UNION(X,punkVal)
#define V_UNKNOWNREF(X) V_UNION(X,ppunkVal)
#define V_VARIANTREF(X) V_UNION(X,pvarVal)
#define V_LPSTR(X) V_UNION(X,pszVal)
#define V_LPSTRREF(X) V_UNION(X,ppszVal)
#define V_LPWSTR(X) V_UNION(X,pwszVal)
#define V_LPWSTRREF(X) V_UNION(X,ppwszVal)
#define V_FILETIME(X) V_UNION(X,filetime)
#define V_FILETIMEREF(X) V_UNION(X,pfiletime)
#define V_BLOB(X) V_UNION(X,blob)
#define V_UUID(X) V_UNION(X,puuid)
#define V_CLSID(X) V_UNION(X,puuid)
#define V_ARRAY(X) V_UNION(X,parray)
#define V_ARRAYREF(X) V_UNION(X,pparray)
#define V_BYREF(X) V_UNION(X,byref)
#define V_DECIMAL(X) ((X)->decVal)
#define V_DECIMALREF(X) V_UNION(X,pdecVal)
#define V_I1(X) V_UNION(X,cVal)
#define V_INT_PTR(X) V_I4(X)
#define V_UINT_PTR(X) V_UI4(X)
#define V_INT_PTRREF(X) V_I4REF(X)
#define V_UINT_PTRREF(X) V_UI4REF(X)
// these are needed for accessing the intVal and uintVal members
#define V_INT(X)    V_UNION(X,intVal)
#define V_UINT(X)   V_UNION(X,uintVal)

#define NUMPRS_LEADING_WHITE 0x00001
#define NUMPRS_TRAILING_WHITE 0x00002
#define NUMPRS_LEADING_PLUS 0x00004
#define NUMPRS_TRAILING_PLUS 0x00008
#define NUMPRS_LEADING_MINUS 0x00010
#define NUMPRS_TRAILING_MINUS 0x00020
#define NUMPRS_HEX_OCT 0x00040
#define NUMPRS_PARENS 0x00080
#define NUMPRS_DECIMAL 0x00100
#define NUMPRS_THOUSANDS 0x00200
#define NUMPRS_CURRENCY 0x00400
#define NUMPRS_EXPONENT 0x00800
#define NUMPRS_USE_ALL 0x01000
#define NUMPRS_STD 0x01FFF
#define NUMPRS_NEG 0x10000
#define NUMPRS_INEXACT 0x20000

#define VTBIT_I1 (1<<VT_I1)
#define VTBIT_UI1 (1<<VT_UI1)
#define VTBIT_I2 (1<<VT_I2)
#define VTBIT_UI2 (1<<VT_UI2)
#define VTBIT_I4 (1<<VT_I4)
#define VTBIT_UI4 (1<<VT_UI4)
#define VTBIT_I8 (1<<VT_I8)
#define VTBIT_UI8 (1<<VT_UI8)
#define VTBIT_R4 (1<<VT_R4)
#define VTBIT_R8 (1<<VT_R8)
#define VTBIT_CY (1<<VT_CY)
#define VTBIT_DECIMAL (1<<VT_DECIMAL)

#define FILE_ATTRIBUTE_READONLY                 0x00000001 

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
#define S_FALSE ((HRESULT)0x00000001L)
#define STATUS_WAIT_0           0
#define STATUS_ABANDONED_WAIT_0 0x80

#define INVALID_HANDLE_VALUE           (HANDLE)(-1)
#define WAIT_OBJECT_0                  0
#define WAIT_ABANDONED_0               128
#define WAIT_FAILED                    ((DWORD)0xFFFFFFFF)
#define LOAD_WITH_ALTERED_SEARCH_PATH  8
#define FORMAT_MESSAGE_FROM_STRING     1024
#define FORMAT_MESSAGE_ALLOCATE_BUFFER 256

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef enum tagSTREAM_SEEK {
        STREAM_SEEK_SET,
        STREAM_SEEK_CUR,
        STREAM_SEEK_END
} STREAM_SEEK;

#define _MAX_DRIVE  3  
#define _MAX_DIR    256
#define _MAX_FNAME  256
#define _MAX_EXT    256

#define FILE_ATTRIBUTE_SYSTEM    0x00000004
#define FILE_ATTRIBUTE_DIRECTORY 0x00000010
#define FILE_ATTRIBUTE_HIDDEN    0x00000002
#define FILE_ATTRIBUTE_NORMAL    0x00000080

// Support for huge paths - not using the standard 128, 256 or 260
#define _MAX_PATH 2048

// Use Linux system definitions for portability
#define _I64_MIN LLONG_MIN
#define _I64_MAX LLONG_MAX

#endif
