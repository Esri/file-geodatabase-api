/*
 * Variant Inlines
 *
 * Copyright 2003 Jon Griffiths
 *
 * VARIANT
 * Copyright 1998 Jean-Claude Cote
 * Copyright 2003 Jon Griffiths
 * Copyright 2005 Daniel Remenak
 * Copyright 2006 Google (Benjamin Arai)
 *
 * The algorithm for conversion from Julian days to day/month/year is based on
 * that devised by Henry Fliegel, as implemented in PostgreSQL, which is
 * Copyright 1994-7 Regents of the University of California
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 *
 * This file adapted for the ESRI FGDB Linux RTL from Wine sources. Modified on
 * 02/07/2011.
 */

/*
 * This header is used internally by Wine and must not be exported. See
 * RtlExtensions.h for function definitions and pieces that need to be exported
 */
 
#ifndef WineInternal_h
#define WineInternal_h

#include "FileGDBUnix.h"
#include "RtlExtensions.h"
#include <sys/time.h>
#include <math.h>

// From http://msdn.microsoft.com/en-us/library/ff563638(v=VS.85).aspx
// According to MSDN, these RTL routines shouldn't be exposed
INT WINAPI RtlSystemTimeToLocalTime( const LARGE_INTEGER *SystemTime,
                                          PLARGE_INTEGER LocalTime );
BOOLEAN WINAPI RtlTimeFieldsToTime(PTIME_FIELDS tfTimeFields,
                                   PLARGE_INTEGER Time);
VOID WINAPI RtlTimeToTimeFields(const LARGE_INTEGER *liTime,
                                PTIME_FIELDS TimeFields);

// Used internally by WINE
SAFEARRAY* SAFEARRAY_Create(VARTYPE vt, UINT cDims, 
                            const SAFEARRAYBOUND *rgsabound, ULONG ulSize);

#if defined DEBUG || defined _DEBUG
#define WARN printf
#define TRACE printf
#define FIXME printf
#define debugstr_w StrAdapter
#define ERR printf
#else // no-ops for release
#define WARN 
#define TRACE
#define debugstr_w
#define ERR
#define FIXME
#endif

#define IDS_TRUE  100
#define IDS_FALSE 101
#define IDS_YES   102
#define IDS_NO    103
#define IDS_ON    104
#define IDS_OFF   105

#define TICKSPERSEC 10000000
#define SECSPERDAY  86400
#define HOURSPERDAY        24
#define MINSPERHOUR        60
#define TICKSPERMSEC       10000
#define SECSPERHOUR        3600
#define EPOCHWEEKDAY       1
#define DAYSPERWEEK        7
#define SECS_1601_TO_1970  ((369 * 365 + 89) * (ULONGLONG)SECSPERDAY)
#define TICKS_1601_TO_1970 (SECS_1601_TO_1970 * TICKSPERSEC)
#define SECSPERMIN 60
#define DAYSPERQUADRICENTENNIUM (365 * 400 + 97)
#define DAYSPERNORMALQUADRENNIUM (365 * 4 + 1)

#define ConvertDefaultLocale(a) LOCALE_SYSTEM_DEFAULT

#define GetLocaleInfoW GetLocaleInfo
#define GetNumberFormatW GetNumberFormat

static const int MonthLengths[2][12] =
{
        { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 },
        { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
};

#define IsLiteralMarker(p) (p == '\'')
#define IsDateFmtChar(p)   (p == 'd'||p == 'M'||p == 'y'||p == 'g')
#define IsTimeFmtChar(p)   (p == 'H'||p == 'h'||p == 'm'||p == 's'||p == 't')

#define IUnknown_Release(This) (This)->Release()
#define IUnknown_AddRef(This) (This)->AddRef()
#define IRecordInfo_Release(This) (This)->Release()

#define IRecordInfo_RecordClear(This,pvExisting) (This)->RecordClear(pvExisting)
#define IRecordInfo_GetSize(This,pcbSize) (This)->GetSize(pcbSize)
#define IRecordInfo_RecordCopy(This,pvExisting,pvNew) (This)->RecordCopy(pvExisting,pvNew)
#define IRecordInfo_AddRef(This) (This)->AddRef(This)

#define FADF_CREATEVECTOR (0x2000)
#define FADF_DATADELETED (0x1000)

typedef struct tagVARIANT_NUMBER_CHARS
{
  WCHAR cNegativeSymbol;
  WCHAR cPositiveSymbol;
  WCHAR cDecimalPoint;
  WCHAR cDigitSeparator;
  WCHAR cCurrencyLocal;
  WCHAR cCurrencyLocal2;
  WCHAR cCurrencyDecimalPoint;
  WCHAR cCurrencyDigitSeparator;
} VARIANT_NUMBER_CHARS;

#define DATE_DATEVARSONLY 0x0100  /* only date stuff: yMdg */
#define TIME_TIMEVARSONLY 0x0200  /* only time stuff: hHmst */
#define NLS_NUM_CACHED_STRINGS 57
#define NLS_STRING_SIZE 80

typedef struct _NLS_FORMAT_NODE
{
  LCID  lcid;         /* Locale Id */
  DWORD dwFlags;      /* 0 or LOCALE_NOUSEROVERRIDE */
  DWORD dwCodePage;   /* Default code page (if LOCALE_USE_ANSI_CP not given) */
  NUMBERFMTW   fmt;   /* Default format for numbers */
  CURRENCYFMTW cyfmt; /* Default format for currencies */
  LPWSTR lppszStrings[NLS_NUM_CACHED_STRINGS]; /* Default formats,day/month names */
  WCHAR szShortAM[2]; /* Short 'AM' marker */
  WCHAR szShortPM[2]; /* Short 'PM' marker */
  _NLS_FORMAT_NODE()
  {
    for (int i = 0 ; i < NLS_NUM_CACHED_STRINGS ; i++)
     lppszStrings[i] = (WCHAR*)malloc(sizeof(WCHAR)*NLS_STRING_SIZE);
  }
  ~_NLS_FORMAT_NODE()
  {
    for (int i = 0 ; i < NLS_NUM_CACHED_STRINGS ; i++)
	  free(lppszStrings[i]);
  }
} NLS_FORMAT_NODE;

// Note, signature changed from WINE
static bool NLS_GetFormats(LCID lcid, DWORD dwFlags, NLS_FORMAT_NODE& node);

/* Only the following flags can be given if a date/time format is specified */
#define DATE_FORMAT_FLAGS (DATE_DATEVARSONLY)
#define TIME_FORMAT_FLAGS (TIME_TIMEVARSONLY|TIME_FORCE24HOURFORMAT| \
                           TIME_NOMINUTESORSECONDS|TIME_NOSECONDS| \
                           TIME_NOTIMEMARKER)

/* Macros to get particular data strings from a format node */
// #define GetNegative(fmt)  fmt->lppszStrings[0] // unused
#define GetLongDate(fmt)  fmt->lppszStrings[1]
#define GetShortDate(fmt) fmt->lppszStrings[2]
#define GetTime(fmt)      fmt->lppszStrings[3]
#define GetAM(fmt)        fmt->lppszStrings[54]
#define GetPM(fmt)        fmt->lppszStrings[55]
#define GetYearMonth(fmt) fmt->lppszStrings[56]

#define GetLongDay(fmt,day)       fmt->lppszStrings[4 + day]
#define GetShortDay(fmt,day)      fmt->lppszStrings[11 + day]
#define GetLongMonth(fmt,mth)     fmt->lppszStrings[18 + mth]
#define GetGenitiveMonth(fmt,mth) fmt->lppszStrings[30 + mth]
#define GetShortMonth(fmt,mth)    fmt->lppszStrings[42 + mth]

/* Get just the type from a variant pointer */
#define V_TYPE(v)  (V_VT((v)) & VT_TYPEMASK)

/* Flags set in V_VT, other than the actual type value */
#define VT_EXTRA_TYPE (VT_VECTOR|VT_ARRAY|VT_BYREF|VT_RESERVED)

/* Get the extra flags from a variant pointer */
#define V_EXTRA_TYPE(v) (V_VT((v)) & VT_EXTRA_TYPE)

/* Missing in Windows but useful VTBIT_* defines */
#define VTBIT_BOOL      (1 << VT_BSTR)
#define VTBIT_BSTR      (1 << VT_BSTR)
#define VTBIT_DATE      (1 << VT_DATE)
#define VTBIT_DISPATCH  (1 << VT_DISPATCH)
#define VTBIT_EMPTY     (1 << VT_EMPTY)
#define VTBIT_ERROR     (1 << VT_ERROR)
#define VTBIT_INT       (1 << VT_INT)
#define VTBIT_NULL      (1 << VT_NULL)
#define VTBIT_UINT      (1 << VT_UINT)
#define VTBIT_UNKNOWN   (1 << VT_UNKNOWN)
#define VTBIT_VARIANT   (1 << VT_VARIANT)
#define VTBIT_15        (1 << 15)        /* no variant type with this number */

extern const char * const wine_vtypes[];
#define debugstr_vt(v) (((v)&VT_TYPEMASK) <= VT_CLSID ? wine_vtypes[((v)&VT_TYPEMASK)] : \
  ((v)&VT_TYPEMASK) == VT_BSTR_BLOB ? "VT_BSTR_BLOB": "Invalid")
#define debugstr_VT(v) (!(v) ? "(null)" : debugstr_vt(V_TYPE((v))))

extern const char * const wine_vflags[];
#define debugstr_vf(v) (wine_vflags[((v)&VT_EXTRA_TYPE)>>12])
#define debugstr_VF(v) (!(v) ? "(null)" : debugstr_vf(V_EXTRA_TYPE(v)))

/* Size constraints */
#define I1_MAX   0x7f
#define I1_MIN   ((-I1_MAX)-1)
#define UI1_MAX  0xff
#define UI1_MIN  0
#define I2_MAX   0x7fff
#define I2_MIN   ((-I2_MAX)-1)
#define UI2_MAX  0xffff
#define UI2_MIN  0
#define I4_MAX   0x7fffffff
#define I4_MIN   ((-I4_MAX)-1)
#define UI4_MAX  0xffffffff
#define UI4_MIN  0
#define I8_MAX   (((LONGLONG)I4_MAX << 32) | UI4_MAX)
#define I8_MIN   ((-I8_MAX)-1)
#define UI8_MAX  (((ULONGLONG)UI4_MAX << 32) | UI4_MAX)
#define UI8_MIN  0
#define DATE_MAX 2958465
#define DATE_MIN -657434
#define R4_MAX 3.402823567797336e38
#define R4_MIN 1.40129846432481707e-45
#define R8_MAX 1.79769313486231470e+308
#define R8_MIN 4.94065645841246544e-324

/* Value of sign for a positive decimal number */
#define DECIMAL_POS 0

/* Native headers don't change the union ordering for DECIMAL sign/scale (duh).
 * This means that the signscale member is only useful for setting both members to 0.
 * SIGNSCALE creates endian-correct values so that we can properly set both at once
 * to values other than 0.
 */
#ifdef WORDS_BIGENDIAN
#define SIGNSCALE(sign,scale) (((scale) << 8) | sign)
#else
#define SIGNSCALE(sign,scale) (((sign) << 8) | scale)
#endif

/* Macros for getting at a DECIMAL's parts */
#define DEC_SIGN(d)      ((d)->sign)
#define DEC_SCALE(d)     ((d)->scale)
#define DEC_SIGNSCALE(d) ((d)->signscale)
#define DEC_HI32(d)      ((d)->Hi32)
#define DEC_MID32(d)     ((d)->Mid32)
#define DEC_LO32(d)      ((d)->Lo32)
#define DEC_LO64(d)      ((d)->Lo64)

#define DEC_MAX_SCALE    28 /* Maximum scale for a decimal */

/* Internal flags for low level conversion functions */
#define  VAR_BOOLONOFF 0x0400 /* Convert bool to "On"/"Off" */
#define  VAR_BOOLYESNO 0x0800 /* Convert bool to "Yes"/"No" */
#define  VAR_NEGATIVE  0x1000 /* Number is negative */

/* VariantChangeType/VariantChangeTypeEx flags */
#define VARIANT_NOVALUEPROP        0x01 /* Don't get the default value property from IDispatch */
#define VARIANT_ALPHABOOL          0x02 /* Coerce to "True"|"False" instead of "-1"|"0" */
#define VARIANT_NOUSEROVERRIDE     0x04 /* Pass LOCALE_NOUSEROVERRIDE to low level conversions */
#define VARIANT_CALENDAR_HIJRI     0x08 /* Use the Hijri calendar */
#define VARIANT_LOCALBOOL          0x10 /* Like VARIANT_ALPHABOOL, but use localised text */
#define VARIANT_CALENDAR_THAI      0x20 /* Use the Thai buddhist calendar */
#define VARIANT_CALENDAR_GREGORIAN 0x40 /* Use the Gregorian calendar */
#define VARIANT_USE_NLS            0x80 /* Format result using NLS calls */

/*
 * Low level Variant coercion functions
 */

#define VT_HARDTYPE VT_RESERVED /* Don't coerce this variant when comparing it to others */

/* Flags for low level coercions. LOCALE_ flags can also be passed */
#define VAR_VALIDDATE           0x004
#define VAR_CALENDAR_HIJRI      0x008 /* Use the Hijri calendar */
#define VAR_LOCALBOOL           0x010 /* VT_BOOL<->VT_BSTR: Use localised boolean text */
#define VAR_FORMAT_NOSUBSTITUTE 0x020 /* Don't change format strings for un-coercable types */
#define VAR_FOURDIGITYEARS      0x040 /* Always print years with 4 digits */
#define VAR_CALENDAR_THAI       0x080 /* Use the Thai buddhist calendar */
#define VAR_CALENDAR_GREGORIAN  0x100 /* Use the Gregorian calendar */

#ifndef LOCALE_USE_NLS
/* This is missing from native winnls.h, but may be added at some point */
#define LOCALE_USE_NLS          0x10000000
#endif

#define VTDATEGRE_MIN -657434 /* Minimum possible Gregorian date: 1/1/100 */
#define VTDATEGRE_MAX 2958465 /* Maximum possible Gregorian date: 31/12/9999 */

#define VarUI4FromUI4( in,pOut ) ( *(pOut) =  (in) )
#define VarI4FromI4( in,pOut )   ( *(pOut) =  (in) )

#define VarUI1FromInt   VarUI1FromI4
#define VarUI1FromUint  VarUI1FromUI4
#define VarI2FromInt    VarI2FromI4
#define VarI2FromUint   VarI2FromUI4
#define VarI4FromInt    VarI4FromI4
#define VarI4FromUint   VarI4FromUI4
#define VarI8FromInt    VarI8FromI4
#define VarI8FromUint   VarI8FromUI4
#define VarR4FromInt    VarR4FromI4
#define VarR4FromUint   VarR4FromUI4
#define VarR8FromInt    VarR8FromI4
#define VarR8FromUint   VarR8FromUI4
#define VarDateFromInt  VarDateFromI4
#define VarDateFromUint VarDateFromUI4
#define VarCyFromInt    VarCyFromI4
#define VarCyFromUint   VarCyFromUI4
#define VarBstrFromInt  VarBstrFromI4
#define VarBstrFromUint VarBstrFromUI4
#define VarBoolFromInt  VarBoolFromI4
#define VarBoolFromUint VarBoolFromUI4
#define VarI1FromInt    VarI1FromI4
#define VarI1FromUint   VarI1FromUI4
#define VarUI2FromInt   VarUI2FromI4
#define VarUI2FromUint  VarUI2FromUI4
#define VarUI4FromInt   VarUI4FromI4
#define VarUI4FromUint  VarUI4FromUI4
#define VarUI8FromInt   VarUI8FromI4
#define VarUI8FromUint  VarUI8FromUI4
#define VarDecFromInt   VarDecFromI4
#define VarDecFromUint  VarDecFromUI4
#define VarIntFromUI1   VarI4FromUI1
#define VarIntFromI2    VarI4FromI2
#define VarIntFromI4    VarI4FromI4
#define VarIntFromI8    VarI4FromI8
#define VarIntFromR4    VarI4FromR4
#define VarIntFromR8    VarI4FromR8
#define VarIntFromDate  VarI4FromDate
#define VarIntFromCy    VarI4FromCy
#define VarIntFromStr   VarI4FromStr
#define VarIntFromDisp  VarI4FromDisp
#define VarIntFromBool  VarI4FromBool
#define VarIntFromI1    VarI4FromI1
#define VarIntFromUI2   VarI4FromUI2
#define VarIntFromUI4   VarI4FromUI4
#define VarIntFromUI8   VarI4FromUI8
#define VarIntFromDec   VarI4FromDec
#define VarIntFromUint  VarI4FromUI4
#define VarUintFromUI1  VarUI4FromUI1
#define VarUintFromI2   VarUI4FromI2
#define VarUintFromI4   VarUI4FromI4
#define VarUintFromI8   VarUI4FromI8
#define VarUintFromR4   VarUI4FromR4
#define VarUintFromR8   VarUI4FromR8
#define VarUintFromDate VarUI4FromDate
#define VarUintFromCy   VarUI4FromCy
#define VarUintFromStr  VarUI4FromStr
#define VarUintFromDisp VarUI4FromDisp
#define VarUintFromBool VarUI4FromBool
#define VarUintFromI1   VarUI4FromI1
#define VarUintFromUI2  VarUI4FromUI2
#define VarUintFromUI4  VarUI4FromUI4
#define VarUintFromUI8  VarUI4FromUI8
#define VarUintFromDec  VarUI4FromDec
#define VarUintFromInt  VarUI4FromI4

/*
 * Variant Math operations
 */
#define VARCMP_LT   0
#define VARCMP_EQ   1
#define VARCMP_GT   2
#define VARCMP_NULL 3

static INT GetDateTimeFormatW(LCID lcid, DWORD dwFlags,
                              const SYSTEMTIME* lpTime, LPCWSTR lpFormat,
                              LPWSTR lpStr, INT cchOut);

static INT NLS_GetDateTimeFormatW(LCID lcid, DWORD dwFlags,
                                  const SYSTEMTIME* lpTime, LPCWSTR lpFormat,
                                  LPWSTR lpStr, INT cchOut);

// Dispatch unsupported in this implementation
static HRESULT VARIANT_FetchDispatchValue(LPVARIANT pvDispatch, LPVARIANT pValue){return E_FAIL;}

#endif // #define WineInternal_h
