/*
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#ifndef WinMap_h
#define WinMap_h

#ifndef UNIX_FILEGDB_API
#error This file must only be included on Unix builds
#endif

#include "WinTypes.h"
#include "WinSupport.h"

// Dummies - mapped to nothing
#define O_BINARY 0
#define EXT_CLASS
#define __stdcall
#define __declspec(a)
#define uuid(a)
#define HUGEP
#define __cdecl
#define __forceinline inline
#define APIENTRY
#define CALLBACK
#define STDMETHODCALLTYPE
#define STDAPI HRESULT
#define FAR
#define __RPC__in_opt
#define __RPC__in
#define __RPC__in_string
#define __RPC__in_opt_string
#define __RPC__deref_opt_in_opt
#define __RPC__opt_in_opt_string
#define __RPC__in_ecount(size) 
#define __RPC__in_ecount_full(size)
#define __RPC__in_ecount_full_string(size)
#define __RPC__in_ecount_part(size, length)
#define __RPC__in_ecount_full_opt(size)
#define __RPC__in_ecount_full_opt_string(size)
#define __RPC__inout_ecount_full_opt_string(size)
#define __RPC__in_ecount_part_opt(size, length)
#define __RPC__deref_in 
#define __RPC__deref_in_string
#define __RPC__deref_opt_in
#define __RPC__deref_in_opt
#define __RPC__deref_out_opt 
#define __RPC__deref_in_ecount(size) 
#define __RPC__deref_in_ecount_part(size, length) 
#define __RPC__deref_in_ecount_full(size) 
#define __RPC__deref_in_ecount_full_opt(size)
#define __RPC__deref_in_ecount_full_string(size)
#define __RPC__deref_in_ecount_full_opt_string(size)
#define __RPC__deref_in_ecount_opt(size) 
#define __RPC__deref_in_ecount_opt_string(size)
#define __RPC__deref_in_ecount_part_opt(size, length) 
#define __RPC__out     
#define __RPC__out_ecount(size) 
#define __RPC__out_ecount_part(size, length) 
#define __RPC__out_ecount_full(size)
#define __RPC__out_ecount_full_string(size)

// Mappings to existing functions
#define _open open
#define _read read
#define _write write
#define _lseek lseek
#define _close close
#define _snprintf snprintf
#define _snwprintf swprintf
#define _tcsncmp wcsncmp
#define _wfopen wfopen
#define _tfopen wfopen
#define _isnan std::isnan
#define lstrcpy wcscpy
#define lstrcat wcscat
#define lstrlen wcslen
#define lstrlenA strlen
#define lstrcmpi(a, b) strcasecmp(StrAdapter(a), StrAdapter(b))
#define strncmpiW(a, b, c) strncasecmp(StrAdapter(a), StrAdapter(b), c)
#ifdef __APPLE__
#define _wcsicmp lstrcmpi
#else
#define _wcsicmp wcscasecmp
#endif
#define _stricmp strcasecmp
#define stricmp _stricmp
#define CompareStringW(a, b, c, d, e, f) wcscmp(c, e) // ignore locale
#ifndef __APPLE__
#define _tcsdup wcsdup
#endif
#define _wcsdup wcsdup
#define _tcscat wcscat
#define _tcscmp wcscmp
#define _tcslen wcslen
#define _tcscpy wcscpy
#define _tcspbrk wcspbrk
#define _tcsicmp _wcsicmp
#define strcmpW wcscmp
#define strlenW wcslen
#define sprintfW wsprintf // we implement wsprintf
#define strspnW(a, b) strspn(StrAdapter(a), StrAdapter(b))
#define _wcsnicmp(a, b, c) strncasecmp(StrAdapter(a), StrAdapter(b), c)
#define wfopen(a, b) fopen(StrAdapter(a), StrAdapter(b))
#define _wtof(a) atof(StrAdapter(a))
#define _wtoi(a) atoi(StrAdapter(a))
#define _wtol(a) atol(StrAdapter(a))
#define __debugbreak DebugBreak
#define _hypot hypot
#define _istspace iswspace
#define _istdigit iswdigit
#define _tcschr wcschr
#define _tcstod wcstod
#define _tcsstr wcsstr
#define _istlower iswlower
#define _totupper towupper
#define _tcsncpy wcsncpy
#define _tcsncat wcsncat
#define _tcslen wcslen
#define _tsetlocale _wsetlocale
#define _totlower towlower
#define _istalnum iswalnum
#define _istupper iswupper
#define _istalpha iswalpha
#define _tclen wcslen
#define _tcstol wcstol
#define _tcsnicmp _wcsnicmp
#define _ttol _wtol
#define _ttoi _wtoi
#define PathFileExists PathFileExistsW
#define PathCombine PathCombineW
#define PathFindExtension PathFindExtensionW
#define PathFindFileName PathFindFileNameW
#define PathRemoveExtension PathRemoveExtensionW
#define PathRemoveFileSpec PathRemoveFileSpecW
#define _wchdir(a) chdir(StrAdapter(a))
#define _wmkdir(a, b) mkdir(StrAdapter(a), b)
#define _wopen(a, b, c) open(StrAdapter(a), (b), c)
#define _chsize(a, b) ftruncate(a, (off_t)b)
#define _wunlink(a) unlink(StrAdapter(a))
#define _dup dup
#define ZeroMemory(a, b) memset(a, 0, b)
#define _nextafter            nextafter
#define _finite               isfinite

#endif
