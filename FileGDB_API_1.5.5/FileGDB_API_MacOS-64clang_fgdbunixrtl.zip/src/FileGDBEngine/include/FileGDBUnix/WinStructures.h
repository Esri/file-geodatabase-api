/*
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#ifndef WinStructures_h
#define WinStructures_h

#ifndef UNIX_FILEGDB_API
#error This file must only be included on Unix builds
#endif

#include "WinTypes.h"
#include "WinMap.h"
#include "WinSupport.h"
#include "WinDef.h"

typedef struct _GUID {
  DWORD Data1;
  WORD  Data2;
  WORD  Data3;
  BYTE  Data4[ 8 ];
} GUID;

typedef GUID UUID, IID, CLSID, *LPGUID, *LPCLSID;

// prototype
HRESULT CLSIDFromString(LPCOLESTR lpsz, LPCLSID pclsid);
class GUIDIFY
{
// Use this class to do a one-line conversion from a char*
// like uuid("01234567-89ab-cdef-0123-456789abcdef") into
// a legit GUID.
public:
  GUIDIFY(const char* guidStr)
  {CLSIDFromString(StrAdapter(guidStr), &m_guid);}
  GUIDIFY(const LPCOLESTR guidStr)
  {CLSIDFromString(guidStr, &m_guid);}
  operator GUID() {return m_guid;}
private:
  GUID m_guid;
};

#ifdef INITGUID
#define DEFINE_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) \
        EXTERN_C const GUID name \
                = { l, w1, w2, { b1, b2,  b3,  b4,  b5,  b6,  b7,  b8 } }
#else
#define DEFINE_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) \
    EXTERN_C const GUID name
#endif // INITGUID

// From http://msdn.microsoft.com/en-us/library/cc237592(v=PROT.13).aspx
#define REFIID const IID &
#define REFCLSID const IID &
#define REFGUID const GUID &
// characters needed to store a formatted guid + '{' + '}' + NULL
#define GUID_STR_LEN 40

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
inline BOOL IsEqualGUID(REFGUID rguid1, REFGUID rguid2)
        { return !memcmp(&rguid1, &rguid2, sizeof(GUID)); }
inline BOOL operator==(const GUID& guidOne, const GUID& guidOther)
        { return !memcmp(&guidOne,&guidOther,sizeof(GUID)); }
inline BOOL operator!=(const GUID& g1, const GUID& g2)
        { return !(g1 == g2); }
#define IsEqualIID(id1,id2) IsEqualGUID(id1,id2)
#define IsEqualCLSID(id1,id2) IsEqualGUID(id1,id2)

typedef union _LARGE_INTEGER {
  struct {
    DWORD LowPart;
    LONG HighPart;
  };
  struct {
    DWORD LowPart;
    LONG HighPart;
  } u;
  LONGLONG QuadPart;
}LARGE_INTEGER, *PLARGE_INTEGER;

typedef union _ULARGE_INTEGER {
  struct {
    DWORD LowPart;
    DWORD HighPart;
  };
  struct {
    DWORD LowPart;
    DWORD HighPart;
  } u;
  ULONGLONG QuadPart;
}ULARGE_INTEGER;
typedef ULARGE_INTEGER *PULARGE_INTEGER;

typedef struct tagPOINT
{
  LONG  x;
  LONG  y;
} POINT, *PPOINT, *NPPOINT, *LPPOINT;

typedef union tagCY {
  struct {
#ifndef _LP64
    unsigned long Lo;
    long      Hi;
#else
    unsigned int Lo;
    int      Hi;
#endif
  };
  LONGLONG int64;
} CY;
typedef CY *LPCY;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
// Modified since we can support nameless unions
typedef struct tagDEC {
  USHORT wReserved;
  union {
    struct {
      BYTE scale;
      BYTE sign;
    };
    USHORT signscale;
  };
  ULONG Hi32;
  union {
    struct {
      ULONG Lo32;
      ULONG Mid32;
    };
    ULONGLONG Lo64;
  };
} DECIMAL;
typedef DECIMAL *LPDECIMAL;

typedef struct tagSAFEARRAYBOUND
{
  ULONG cElements;
  LONG lLbound;
} SAFEARRAYBOUND;

class tagSAFEARRAY : public CRITICAL_SECTION
{
public:
  USHORT cDims;// Count of dimensions in this array.
  USHORT fFeatures; // unused, always allocated on the heap
  ULONG cbElements; // Size of an element of the array.
  ULONG cLocks; // Times the array has been locked (unlock decrements)
  PVOID pvData; // Pointer to the data.
  SAFEARRAYBOUND rgsabound[ 1 ]; // bounds
  ~tagSAFEARRAY()
  {
    if (pvData)
      free(pvData);
  }
  tagSAFEARRAY():cLocks(0), pvData(0){}
};
typedef tagSAFEARRAY SAFEARRAY, *LPSAFEARRAY;

typedef struct tagIDLDESC
    {
    ULONG_PTR dwReserved;
    USHORT wIDLFlags;
    } 	IDLDESC;
typedef struct tagIDLDESC *LPIDLDESC;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef enum tagTYPEKIND {
        TKIND_ENUM,TKIND_RECORD,TKIND_MODULE,TKIND_INTERFACE,TKIND_DISPATCH,
        TKIND_COCLASS,TKIND_ALIAS,TKIND_UNION,TKIND_MAX
}TYPEKIND;

typedef struct tagTYPEDESC
{
  union 
  {
    struct tagTYPEDESC *lptdesc;
    struct tagARRAYDESC *lpadesc;
    HREFTYPE hreftype;
  } /* nameless union for c++ */;
  VARTYPE vt;
} 	TYPEDESC;


typedef struct tagTYPEATTR   {
    GUID guid;
    LCID lcid;
    DWORD dwReserved;
    MEMBERID memidConstructor;
    MEMBERID memidDestructor;
    LPOLESTR lpstrSchema;
    ULONG cbSizeInstance;
    TYPEKIND typekind;
    WORD cFuncs;
    WORD cVars;
    WORD cImplTypes;
    WORD cbSizeVft;
    WORD cbAlignment;
    WORD wTypeFlags;
    WORD wMajorVerNum;
    WORD wMinorVerNum;
    TYPEDESC tdescAlias;
    IDLDESC idldescType;
    } 	TYPEATTR;
typedef struct tagTYPEATTR *LPTYPEATTR;

typedef /* [v1_enum] */ 
enum tagCALLCONV{
   CC_FASTCALL   = 0,
   CC_CDECL   = 1,
   CC_MSCPASCAL   = CC_CDECL + 1,
   CC_PASCAL   = CC_MSCPASCAL,
   CC_MACPASCAL   = CC_PASCAL + 1,
   CC_STDCALL   = CC_MACPASCAL + 1,
   CC_FPFASTCALL   = CC_STDCALL + 1,
   CC_SYSCALL   = CC_FPFASTCALL + 1,
   CC_MPWCDECL   = CC_SYSCALL + 1,
   CC_MPWPASCAL   = CC_MPWCDECL + 1,
   CC_MAX   = CC_MPWPASCAL + 1
    }   CALLCONV;


// forward declare
class  IUnknown;
class  ITypeComp;
class  ITypeInfo;
class  IDispatch;
class  IRecordInfo;
typedef struct tagPARAMDESCEX PARAMDESCEX, *LPPARAMDESCEX;
typedef struct tagDISPPARAMS DISPPARAMS;
typedef struct tagSTATSTG STATSTG;

// Use nameless unions
#define __tagVARIANT
#define __VARIANT_NAME_1
#define __VARIANT_NAME_2
#define __VARIANT_NAME_3
#define __tagBRECORD
#define __VARIANT_NAME_4
typedef struct tagVARIANT VARIANT;

struct tagVARIANT
    {
    union 
        {
        struct __tagVARIANT
            {
            VARTYPE vt;
            WORD wReserved1;
            WORD wReserved2;
            WORD wReserved3;
            union 
                {
                LONGLONG llVal;
                LONG lVal;
                BYTE bVal;
                SHORT iVal;
                FLOAT fltVal;
                DOUBLE dblVal;
                VARIANT_BOOL boolVal;
                //_VARIANT_BOOL bool; //invalid with gcc
                SCODE scode;
                CY cyVal;
                DATE date;
                BSTR bstrVal;
                IUnknown *punkVal;
                IDispatch *pdispVal;
                SAFEARRAY *parray;
                BYTE *pbVal;
                SHORT *piVal;
                LONG *plVal;
                LONGLONG *pllVal;
                FLOAT *pfltVal;
                DOUBLE *pdblVal;
                VARIANT_BOOL *pboolVal;
                //_VARIANT_BOOL *pbool; // invalid with gcc
                SCODE *pscode;
                CY *pcyVal;
                DATE *pdate;
                BSTR *pbstrVal;
                IUnknown **ppunkVal;
                IDispatch **ppdispVal;
                SAFEARRAY **pparray;
                VARIANT *pvarVal;
                PVOID byref;
                CHAR cVal;
                USHORT uiVal;
                ULONG ulVal;
                ULONGLONG ullVal;
                INT intVal;
                UINT uintVal;
                DECIMAL *pdecVal;
                CHAR *pcVal;
                USHORT *puiVal;
                ULONG *pulVal;
                ULONGLONG *pullVal;
                INT *pintVal;
                UINT *puintVal;
                struct __tagBRECORD
                    {
                    PVOID pvRecord;
                    IRecordInfo *pRecInfo;
                    } 	__VARIANT_NAME_4;
                } 	__VARIANT_NAME_3;
            } 	__VARIANT_NAME_2;
        DECIMAL decVal;
        } 	__VARIANT_NAME_1;
    } ;
typedef VARIANT *LPVARIANT;
typedef VARIANT VARIANTARG;
typedef VARIANT *LPVARIANTARG;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
#define VARIANT_TRUE ((VARIANT_BOOL)0xffff)
#define VARIANT_FALSE ((VARIANT_BOOL)0)
#define VARIANT_NOUSEROVERRIDE 0x04

typedef struct tagPARAMDESC
    {
    LPPARAMDESCEX pparamdescex;
    USHORT wParamFlags;
    } 	PARAMDESC, *LPPARAMDESC;

typedef struct tagELEMDESC {
    TYPEDESC tdesc;             /* the type of the element */
    union {
        IDLDESC idldesc;        /* info for remoting the element */
        PARAMDESC paramdesc;    /* info about the parameter */
    };
} ELEMDESC, * LPELEMDESC;

typedef enum tagFUNCKIND {
   FUNC_VIRTUAL,
   FUNC_PUREVIRTUAL,
   FUNC_NONVIRTUAL,
   FUNC_STATIC,
   FUNC_DISPATCH,
} FUNCKIND;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef enum tagINVOKEKIND {
        INVOKE_FUNC=1,INVOKE_PROPERTYGET,INVOKE_PROPERTYPUT=4,
        INVOKE_PROPERTYPUTREF=8
}INVOKEKIND;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef struct tagFUNCDESC {
        MEMBERID memid;
        SCODE *lprgscode;
        ELEMDESC *lprgelemdescParam;
        FUNCKIND funckind;
        INVOKEKIND invkind;
        CALLCONV callconv;
        SHORT cParams;
        SHORT cParamsOpt;
        SHORT oVft;
        SHORT cScodes;
        ELEMDESC elemdescFunc;
        WORD wFuncFlags;
}FUNCDESC,*LPFUNCDESC;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef struct tagEXCEPINFO {
        WORD wCode;
        WORD wReserved;
        BSTR bstrSource;
        BSTR bstrDescription;
        BSTR bstrHelpFile;
        DWORD dwHelpContext;
        PVOID pvReserved;
        HRESULT(__stdcall * pfnDeferredFillIn)(struct tagEXCEPINFO*);
        SCODE scode;
} EXCEPINFO,*LPEXCEPINFO;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef enum tagDESCKIND {
        DESCKIND_NONE=0,DESCKIND_FUNCDESC=DESCKIND_NONE+1,
        DESCKIND_VARDESC=DESCKIND_FUNCDESC+1,DESCKIND_TYPECOMP=DESCKIND_VARDESC+1,
        DESCKIND_IMPLICITAPPOBJ=DESCKIND_TYPECOMP+1,
        DESCKIND_MAX=DESCKIND_IMPLICITAPPOBJ+1
} DESCKIND;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef enum tagVARKIND {
        VAR_PERINSTANCE,VAR_STATIC,VAR_CONST,VAR_DISPATCH
} VARKIND;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
// Modified for nameless union support
typedef struct tagVARDESC {
        MEMBERID memid;
        LPOLESTR lpstrSchema;
        union {
          ULONG oInst;
          VARIANT *lpvarValue;
        };
        ELEMDESC elemdescVar;
        WORD wVarFlags;
        VARKIND varkind;
} VARDESC,*LPVARDESC;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
// Modified to use available type
typedef union tagBINDPTR {
        LPFUNCDESC lpfuncdesc;
        LPVARDESC lpvardesc;
        //LPTYPECOMP lptcomp; // we don't have this type
        ITypeComp *lptcomp;
} BINDPTR,*LPBINDPTR;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef enum tagSYSKIND {
        SYS_WIN16,SYS_WIN32,SYS_MAC
} SYSKIND;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef struct tagTLIBATTR {
        GUID guid;
        LCID lcid;
        SYSKIND syskind;
        WORD wMajorVerNum;
        WORD wMinorVerNum;
        WORD wLibFlags;
} TLIBATTR,*LPTLIBATTR;

// prototype -- our stuff
GUID uuidof(LPWSTR);
#define __uuidof(x) uuidof(TEXT(#x))

class IUnknown
{
public:
  virtual HRESULT QueryInterface(REFIID riid, void **ppvObject) = 0;
  virtual ULONG   AddRef(void)  = 0;
  virtual ULONG   Release(void) = 0;
};
typedef IUnknown *LPUNKNOWN;

class ISequentialStream : public IUnknown {
  public:
    virtual HRESULT Read(void *pv,ULONG cb,ULONG *pcbRead) = 0;
    virtual HRESULT Write(const void *pv,ULONG cb,ULONG *pcbWritten) = 0;
};

class IClassFactory : public IUnknown
{
public:
  virtual HRESULT CreateInstance(IUnknown *pUnkOuter, REFIID riid, 
                                 void **ppvObject) = 0;
  virtual HRESULT LockServer(BOOL fLock) = 0;
};

class IStream : public ISequentialStream
{
public:
  virtual HRESULT Seek(LARGE_INTEGER dlibMove, DWORD dwOrigin,
                       ULARGE_INTEGER *plibNewPosition) = 0;
  virtual HRESULT SetSize(ULARGE_INTEGER libNewSize) = 0;
  virtual HRESULT CopyTo(IStream *pstm, ULARGE_INTEGER cb,
                         ULARGE_INTEGER *pcbRead, 
                         ULARGE_INTEGER *pcbWritten) = 0;
  virtual HRESULT Commit(DWORD grfCommitFlags) = 0;
  virtual HRESULT Revert(void) = 0;
  virtual HRESULT LockRegion(ULARGE_INTEGER libOffset, ULARGE_INTEGER cb,
                             DWORD dwLockType) = 0;
  virtual HRESULT UnlockRegion(ULARGE_INTEGER libOffset, ULARGE_INTEGER cb,
                               DWORD dwLockType) = 0;
  virtual HRESULT Stat(STATSTG *pstatstg, DWORD grfStatFlag) = 0;
  virtual HRESULT Clone(IStream **ppstm) = 0;
};

class ITypeComp : public IUnknown
{
public:
  virtual HRESULT Bind(LPOLESTR szName,
                       ULONG lHashVal,
                       WORD wFlags,
                       ITypeInfo **ppTInfo,
                       DESCKIND *pDescKind,
                       BINDPTR *pBindPtr) = 0;
  virtual HRESULT BindType(LPOLESTR szName,
                           ULONG lHashVal,
                           ITypeInfo **ppTInfo,
                           ITypeComp **ppTComp) = 0;
};

class ITypeLib : public IUnknown
{
public:
  virtual UINT GetTypeInfoCount( void) = 0;
  virtual HRESULT GetTypeInfo(UINT index, ITypeInfo **ppTInfo) = 0;
  virtual HRESULT GetTypeInfoType(UINT index, TYPEKIND *pTKind) = 0;
  virtual HRESULT GetTypeInfoOfGuid(REFGUID guid, ITypeInfo **ppTinfo) = 0;
  virtual HRESULT GetLibAttr(TLIBATTR **ppTLibAttr) = 0;
  virtual HRESULT GetTypeComp(ITypeComp **ppTComp) = 0;
  virtual HRESULT GetDocumentation(INT index, BSTR *pBstrName, 
                                   BSTR *pBstrDocString, DWORD *pdwHelpContext,
                                   BSTR *pBstrHelpFile) = 0;
  virtual HRESULT IsName(LPOLESTR szNameBuf, ULONG lHashVal, BOOL *pfName) = 0;
  virtual HRESULT FindName(LPOLESTR szNameBuf, ULONG lHashVal, 
                           ITypeInfo **ppTInfo, MEMBERID *rgMemId,
                           USHORT *pcFound) = 0;
  virtual void ReleaseTLibAttr(TLIBATTR *pTLibAttr) = 0;
};

class ITypeInfo : public IUnknown
{
public:
  virtual HRESULT GetTypeAttr(TYPEATTR **ppTypeAttr) = 0;
  virtual HRESULT GetTypeComp(ITypeComp **ppTComp) = 0;
  virtual HRESULT GetFuncDesc(UINT index, FUNCDESC **ppFuncDesc) = 0;
  virtual HRESULT GetVarDesc(UINT index, VARDESC **ppVarDesc) = 0;
  virtual HRESULT GetNames(MEMBERID memid, BSTR *rgBstrNames, UINT cMaxNames,
                           UINT *pcNames) = 0;
  virtual HRESULT GetRefTypeOfImplType(UINT index, HREFTYPE *pRefType) = 0;
  virtual HRESULT GetImplTypeFlags(UINT index, INT *pImplTypeFlags) = 0;
  virtual HRESULT GetIDsOfNames(LPOLESTR *rgszNames, UINT cNames, 
                                MEMBERID *pMemId) = 0;
  virtual HRESULT Invoke(PVOID pvInstance, MEMBERID memid, WORD wFlags,
                         DISPPARAMS *pDispParams,
                         VARIANT *pVarResult,
                         EXCEPINFO *pExcepInfo,
                         UINT *puArgErr) = 0;
  virtual HRESULT GetDocumentation(MEMBERID memid, BSTR *pBstrName,
                                   BSTR *pBstrDocString, DWORD *pdwHelpContext,
                                   BSTR *pBstrHelpFile) = 0;
  virtual HRESULT GetDllEntry(MEMBERID memid, INVOKEKIND invKind, 
                              BSTR *pBstrDllName, BSTR *pBstrName, 
                              WORD *pwOrdinal) = 0;
  virtual HRESULT GetRefTypeInfo(HREFTYPE hRefType, ITypeInfo **ppTInfo) = 0;
  virtual HRESULT AddressOfMember(MEMBERID memid, INVOKEKIND invKind, 
                                  PVOID *ppv) = 0;
  virtual HRESULT CreateInstance(IUnknown *pUnkOuter, REFIID riid,
                                 PVOID *ppvObj) = 0;
  virtual HRESULT GetMops(MEMBERID memid, BSTR *pBstrMops) = 0;
  virtual HRESULT GetContainingTypeLib(ITypeLib **ppTLib, UINT *pIndex) = 0;
  virtual void ReleaseTypeAttr(TYPEATTR *pTypeAttr) = 0;
  virtual void ReleaseFuncDesc(FUNCDESC *pFuncDesc) = 0;
  virtual void ReleaseVarDesc(VARDESC *pVarDesc) = 0;
};

class IDispatch : public IUnknown
{
public:
  virtual HRESULT GetTypeInfoCount(UINT *pctinfo) = 0;
  virtual HRESULT GetTypeInfo(UINT iTInfo, LCID lcid, ITypeInfo **ppTInfo) = 0;
  virtual HRESULT GetIDsOfNames(REFIID riid, OLECHAR rgszNames,  
                                UINT cNames, LCID lcid, DISPID FAR* rgDispId) = 0;
  virtual HRESULT Invoke(DISPID dispIdMember, REFIID riid, LCID lcid, WORD wFlags,
                         DISPPARAMS *pDispParams, VARIANT *pVarResult,
                         EXCEPINFO *pExcepInfo, UINT *puArgErr) = 0;
};
typedef IDispatch *LPDISPATCH;

class IRecordInfo : public IUnknown
{
public:
	virtual HRESULT AddRef(IRecordInfo*) = 0;
  virtual HRESULT RecordInit(PVOID pvNew) = 0;
  virtual HRESULT RecordClear(PVOID pvExisting) = 0;
  virtual HRESULT RecordCopy(PVOID pvExisting, PVOID pvNew) = 0;
  virtual HRESULT GetGuid(GUID *pguid) = 0;
  virtual HRESULT GetName(BSTR *pbstrName) = 0;
  virtual HRESULT GetSize(ULONG *pcbSize) = 0;
  virtual HRESULT GetTypeInfo(ITypeInfo **ppTypeInfo) = 0;
  virtual HRESULT GetField(PVOID pvData, LPCOLESTR szFieldName,
                           VARIANT *pvarField) = 0;
  virtual HRESULT GetFieldNoCopy(PVOID pvData, LPCOLESTR szFieldName,
                                 VARIANT *pvarField, PVOID *ppvDataCArray) = 0;
  virtual HRESULT PutField(ULONG wFlags, PVOID pvData, LPCOLESTR szFieldName,
                           VARIANT *pvarField) = 0;
  virtual HRESULT PutFieldNoCopy(ULONG wFlags, PVOID pvData, 
                                 LPCOLESTR szFieldName,
                                 VARIANT *pvarField) = 0;
  virtual HRESULT GetFieldNames(ULONG *pcNames, BSTR *rgBstrNames) = 0;
  virtual BOOL IsMatchingType(IRecordInfo *pRecordInfo) = 0;
  virtual PVOID RecordCreate(void) = 0;
  virtual HRESULT RecordCreateCopy(PVOID pvSource, PVOID *ppvDest) = 0;
  virtual HRESULT RecordDestroy(PVOID pvRecord) = 0;
};

class IErrorInfo : public IUnknown
{
public:
  virtual HRESULT GetGUID(GUID *pGUID) = 0;
  virtual HRESULT GetSource(BSTR *pBstrSource) = 0;
  virtual HRESULT GetDescription(BSTR *pBstrDescription) = 0;
  virtual HRESULT GetHelpFile(BSTR *pBstrHelpFile) = 0;
  virtual HRESULT GetHelpContext(DWORD *pdwHelpContext) = 0;
};

// Forward declare
EXTERN_C const IID IID_IEnumVARIANT;
EXTERN_C const IID IID_IPersist;
EXTERN_C const IID IID_IPersistStream;

class IEnumVARIANT : public IUnknown 
{ 
public:
  virtual HRESULT Next(DWORD celt, VARIANT FAR* rgvar, 
                       DWORD FAR* pceltFetched) = 0;
  virtual HRESULT Skip(DWORD celt) = 0;
  virtual HRESULT Reset() = 0;
  virtual HRESULT Clone(IEnumVARIANT FAR* FAR* ppenum) = 0;
};

class IPersist : public IUnknown
{
public:
  virtual HRESULT GetClassID(CLSID *pClassID) = 0;
};

class IPersistStream : public IPersist 
{
public:
  virtual HRESULT IsDirty(void) = 0;
  virtual HRESULT Load(IStream *pStm) = 0;
  virtual HRESULT Save(IStream *pStm, BOOL fClearDirty) = 0;
  virtual HRESULT GetSizeMax(ULARGE_INTEGER *pcbSize) = 0;
};

typedef struct tagERRORINFO
{
  HRESULT hrError;
  DWORD dwMinor;
  CLSID clsid;
  IID iid;
  DISPID dispid;
} ERRORINFO;

class IErrorRecords : public IUnknown
{
public:
  virtual HRESULT AddErrorRecord(ERRORINFO *pErrorInfo, DWORD dwLookupID,
                                 DISPPARAMS *pdispparams, 
                                 IUnknown *punkCustomError, 
                                 DWORD dwDynamicErrorID) = 0;
  virtual HRESULT GetBasicErrorInfo(ULONG ulRecordNum, 
                                    ERRORINFO *pErrorInfo) = 0;
  virtual HRESULT GetCustomErrorObject(ULONG ulRecordNum, REFIID riid, 
                                       IUnknown **ppObject) = 0;
  virtual HRESULT GetErrorInfo(ULONG ulRecordNum, LCID lcid, 
                               IErrorInfo **ppErrorInfo) = 0;
  virtual HRESULT GetErrorParameters(ULONG ulRecordNum, DISPPARAMS *pdispparams) = 0;
  virtual HRESULT GetRecordCount(ULONG *pcRecords) = 0;
};

class ICreateErrorInfo : public IUnknown
{
public:
  virtual HRESULT SetGUID(REFGUID rguid) = 0;
  virtual HRESULT SetSource(LPOLESTR szSource) = 0;
  virtual HRESULT SetDescription(LPOLESTR szDescription) = 0;
  virtual HRESULT SetHelpFile(LPOLESTR szHelpFile) = 0;
  virtual HRESULT SetHelpContext(DWORD dwHelpContext) = 0;
};

class ISupportErrorInfo : public IUnknown
{
public:
  virtual HRESULT InterfaceSupportsErrorInfo(REFIID riid) = 0;
};

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef struct tagPARAMDESCEX {
        ULONG cBytes;
        VARIANTARG varDefaultValue;
}PARAMDESCEX,*LPPARAMDESCEX;

typedef struct {
  INT   cDig;
  ULONG dwInFlags;
  ULONG dwOutFlags;
  INT   cchUsed;
  INT   nBaseShift;
  INT   nPwr10;
} NUMPARSE;

typedef struct tagDISPPARAMS {
  VARIANTARG *rgvarg;
  DISPID *rgdispidNamedArgs;
  UINT cArgs;
  UINT cNamedArgs;
} DISPPARAMS;

typedef struct _SYSTEMTIME {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek;
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;

// From http://sourceforge.net/projects/mingw/files/MinGW/BaseSystem/RuntimeLibrary/Win32-API/w32api-3.15/ w32api-3.15-1-mingw32-src.tar.lzma
typedef struct {
        SYSTEMTIME st;
        USHORT wDayOfYear;
} UDATE;

typedef struct _TIME_FIELDS
{   CSHORT Year;
    CSHORT Month;
    CSHORT Day;
    CSHORT Hour;
    CSHORT Minute;
    CSHORT Second;
    CSHORT Milliseconds;
    CSHORT Weekday;
} TIME_FIELDS, *PTIME_FIELDS;

typedef struct _FILETIME {
    DWORD dwLowDateTime;
    DWORD dwHighDateTime;
} FILETIME, *PFILETIME, *LPFILETIME;

typedef struct _numberfmtW 
{
  UINT    NumDigits;
  UINT    LeadingZero;
  UINT    Grouping;
  LPWSTR  lpDecimalSep;
  LPWSTR  lpThousandSep;
  UINT    NegativeOrder;
} NUMBERFMTW, *LPNUMBERFMTW;
typedef NUMBERFMTW NUMBERFMT;
typedef LPNUMBERFMTW LPNUMBERFMT;

typedef struct _currencyfmtW 
{
  UINT    NumDigits;
  UINT    LeadingZero;
  UINT    Grouping;
  LPWSTR  lpDecimalSep;
  LPWSTR  lpThousandSep;
  UINT    NegativeOrder;
  UINT    PositiveOrder;
  LPWSTR  lpCurrencySymbol;
} CURRENCYFMTW, *LPCURRENCYFMTW;
typedef CURRENCYFMTW CURRENCYFMT;
typedef LPCURRENCYFMTW LPCURRENCYFMT;

typedef struct tagSTATSTG
{
  LPOLESTR pwcsName;
  DWORD type;
  ULARGE_INTEGER cbSize;
  FILETIME mtime;
  FILETIME ctime;
  FILETIME atime;
  DWORD grfMode;
  DWORD grfLocksSupported;
  CLSID clsid;
  DWORD grfStateBits;
  DWORD reserved;
} STATSTG;

typedef struct _WIN32_FIND_DATA {
  DWORD    dwFileAttributes;
  FILETIME ftCreationTime;
  FILETIME ftLastAccessTime;
  FILETIME ftLastWriteTime;
  DWORD    nFileSizeHigh;
  DWORD    nFileSizeLow;
  DWORD    dwReserved0;
  DWORD    dwReserved1;
  TCHAR    cFileName[MAX_PATH];
  TCHAR    cAlternateFileName[14];
} WIN32_FIND_DATA, *PWIN32_FIND_DATA, *LPWIN32_FIND_DATA;

typedef struct _COAUTHIDENTITY
{
  USHORT *User;
  ULONG UserLength;
  USHORT *Domain;
  ULONG DomainLength;
  USHORT *Password;
  ULONG PasswordLength;
  ULONG Flags;
} COAUTHIDENTITY;

typedef struct _COAUTHINFO
{
  DWORD dwAuthnSvc;
  DWORD dwAuthzSvc;
  LPWSTR pwszServerPrincName;
  DWORD dwAuthnLevel;
  DWORD dwImpersonationLevel;
  COAUTHIDENTITY *pAuthIdentityData;
  DWORD dwCapabilities;
} COAUTHINFO;

typedef struct _COSERVERINFO
{
  DWORD dwReserved1;
  LPWSTR pwszName;
  COAUTHINFO *pAuthInfo;
  DWORD dwReserved2;
} COSERVERINFO;

typedef struct threadlocaleinfostruct * pthreadlocinfo;
typedef struct threadmbcinfostruct * pthreadmbcinfo;
typedef struct localeinfo_struct
{
    pthreadlocinfo locinfo;
    pthreadmbcinfo mbcinfo;
} _locale_tstruct, *_locale_t;

typedef enum tagSTATFLAG
{	
  STATFLAG_DEFAULT  = 0,
  STATFLAG_NONAME   = 1,
  STATFLAG_NOOPEN   = 2
} STATFLAG;

typedef enum tagSTGTY
{
  STGTY_STORAGE   = 1,
  STGTY_STREAM    = 2,
  STGTY_LOCKBYTES = 3,
  STGTY_PROPERTY  = 4
} STGTY;

typedef struct tagLOCALESIGNATURE
{
  DWORD lsUsb[4];
  DWORD lsCsbDefault[2];
  DWORD lsCsbSupported[2];
} LOCALESIGNATURE, *PLOCALESIGNATURE;

#endif
