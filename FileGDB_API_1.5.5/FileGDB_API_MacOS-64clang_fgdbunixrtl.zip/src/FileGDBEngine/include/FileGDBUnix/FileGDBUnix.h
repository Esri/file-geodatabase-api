/*
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#ifndef FileGDBUnix_h
#define FileGDBUnix_h

#ifndef UNIX_FILEGDB_API
#error This file must only be included on Unix builds
#endif

#include "WinTypes.h"      // windows types
#include "WinStructures.h" // windows structures
#include "WinSupport.h"    // our stuff
#include "WinMap.h"        // windows mappings
#include "WinDef.h"        // windows definitions
#include "WinError.h"      // windows errors

#ifndef GCC_VERSION
#define GCC_VERSION (__GNUC__ * 10000 \
                    + __GNUC_MINOR__ * 100 \
                    + __GNUC_PATCHLEVEL__)
#endif

GUID uuidof(LPWSTR);

// Implement missing Windows functions for Unix.
// Some of these might be candidates for macros, but that makes
// debugging tougher.

void WINAPI InitializeCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
void WINAPI EnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
void WINAPI LeaveCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
BOOL WINAPI InitializeCriticalSectionAndSpinCount(
                               LPCRITICAL_SECTION lpCriticalSection,
                               DWORD dwSpinCount);
void WINAPI DeleteCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
LONG WINAPI InterlockedIncrement(atomicLong *aLong);
LONG WINAPI InterlockedDecrement(atomicLong *aLong);
LONG WINAPI InterlockedIncrementDummy(LONG *val);
LONG WINAPI InterlockedDecrementDummy(LONG *val);
BOOL WINAPI GetComputerName(LPTSTR lpBuffer, LPDWORD lpnSize);
DWORD WINAPI GetCurrentProcessId(void);
DWORD WINAPI GetCurrentThreadId(void);
DWORD WINAPI GetEnvironmentVariable(LPCTSTR lpName, LPTSTR lpBuffer, DWORD nSize);
DWORD WINAPI GetFileAttributes(LPCTSTR lpFileName);
HANDLE WINAPI GetCurrentProcess(void);
BOOL WINAPI GetProcessTimes( HANDLE hprocess, LPFILETIME lpCreationTime,
                      LPFILETIME lpExitTime, LPFILETIME lpKernelTime, LPFILETIME lpUserTime );
HANDLE WINAPI GetProcessHeap();
LPVOID WINAPI HeapAlloc(HANDLE hHeap, DWORD dwFlags, SIZE_T dwBytes);
LPVOID WINAPI HeapReAlloc(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem, SIZE_T dwBytes);
BOOL WINAPI HeapFree(HANDLE hHeap, DWORD dwFlags, LPVOID lpMem);
HMODULE WINAPI GetModuleHandle(LPCTSTR lpModuleName);
DWORD WINAPI GetModuleFileName(HMODULE hModule, LPTSTR lpFilename, DWORD nSize);
HMODULE WINAPI LoadLibrary(LPCTSTR lpFileName);
HMODULE WINAPI LoadLibraryEx(LPCTSTR lpFileName, HANDLE hFile, DWORD dwFlags);
BOOL WINAPI FreeLibrary(HMODULE hModule);
void WINAPI *GetProcAddress(HMODULE hModule, LPCSTR lpProcName);
void WINAPI DebugBreak();
void WINAPI FatalAppExit(UINT uAction, LPCTSTR lpMessageText);
void WINAPI Sleep(DWORD dwMilliseconds);
int WINAPI MultiByteToWideChar(UINT CodePage, DWORD dwFlags,
                        LPCSTR lpMultiByteStr, int cbMultiByte,
                        LPWSTR lpWideCharStr, int cchWideChar);
int WINAPI WideCharToMultiByte(UINT CodePage, DWORD dwFlags,
                        LPCWSTR lpWideCharStr, int cchWideChar,
                        LPSTR lpMultiByteStr,  int cbMultiByte,
                        LPCSTR lpDefaultChar,  LPBOOL lpUsedDefaultChar);
BSTR WINAPI SysAllocStringLen(const OLECHAR *pch, unsigned int cch);
VOID WINAPI SysFreeString(BSTR bstr);
UINT WINAPI SysStringLen(BSTR bstr);
UINT WINAPI SysStringByteLen(BSTR bstr);
BSTR WINAPI SysAllocString(const OLECHAR *sz);
BSTR WINAPI SysAllocStringByteLen(char *psz, unsigned int len);
void WINAPI OutputDebugString(LPCTSTR lpOutputString);
void WINAPI CoTaskMemFree(LPVOID pv);
LPVOID WINAPI CoTaskMemAlloc(SIZE_T cb);
DWORD WINAPI QueryDosDevice(LPCTSTR lpDeviceName, LPTSTR lpTargetPath, DWORD ucchMax);
BOOL WINAPI PathIsDirectory(LPCTSTR pszPath);
BOOL WINAPI PathIsDirectoryEmpty(LPCTSTR pszPath);
int WINAPI wsprintf(LPTSTR lpOut, LPCTSTR lpFmt, ...);
errno_t WINAPI wcscat_s(wchar_t *strDestination, size_t numberOfElements,
                                          const wchar_t *strSource);
errno_t WINAPI wcscpy_s(wchar_t *strDestination, size_t numberOfElements, 
                                          const wchar_t *strSource);
int WINAPI swscanf_s(const wchar_t *buffer, const wchar_t *format, ...);
wchar_t WINAPI *_wsetlocale(int category, const wchar_t *locale);
HRESULT WINAPI StringFromCLSID(REFCLSID rclsid, LPOLESTR *lplpsz);
int WINAPI StringFromGUID2(REFGUID rguid, LPOLESTR lpsz, int cchMax);
HRESULT WINAPI CoCreateGuid(GUID *pguid);
RPC_STATUS WINAPI UuidCreate(UUID *Uuid);
HRESULT WINAPI CLSIDFromString(LPCOLESTR lpsz, LPCLSID pclsid);
int WINAPI GetLocaleInfo(LCID Locale, LCTYPE LCType, LPTSTR lpLCData, int cchData);
int WINAPI GetNumberFormat(LCID Locale, DWORD dwFlags, LPCTSTR lpValue,
                    const NUMBERFMT *lpFormat, LPTSTR lpNumberStr,
                    int cchNumber);
int WINAPI GetTimeFormat(LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpTime,
                  LPCTSTR lpFormat, LPTSTR lpTimeStr, int cchTime);
int WINAPI GetDateFormat(LCID Locale, DWORD dwFlags, const SYSTEMTIME *lpDate,
                  LPCTSTR lpFormat, LPTSTR lpDateStr, int cchDate);
void WINAPI GetLocalTime(LPSYSTEMTIME lpSystemTime);
LPTSTR WINAPI PathCombineW(LPTSTR lpszDest, LPCTSTR lpszDir, LPCTSTR lpszFile);
BOOL WINAPI PathFileExistsW(LPCTSTR pszPath);
BOOL WINAPI PathFileExists(LPCSTR pszPath);
BOOL WINAPI IsCharAlphaNumeric(TCHAR ch);
LPWSTR WINAPI PathFindExtensionW( LPCWSTR lpszPath );
LPWSTR WINAPI PathFindFileNameW(LPCWSTR lpszPath);
void WINAPI PathRemoveExtensionW(LPTSTR pszPath);
BOOL WINAPI PathRemoveFileSpecW(LPWSTR pszPath);
bool WINAPI IsDigit(const char *a);
bool WINAPI isdigitW(const WCHAR chr);
ULONG WINAPI strtoulW(WCHAR *a, WCHAR **b, int base);
bool WINAPI isspaceW(const WCHAR chr);
WCHAR WINAPI *_tcstok(WCHAR* wcs, const WCHAR* del);
__int64 WINAPI _wtoi64(const wchar_t *_Str);
int WINAPI _wcsncoll(const wchar_t *str1, const wchar_t *str2, size_t count);
int WINAPI _wcsnicoll(const wchar_t *str1, const wchar_t *str2, size_t count);
int WINAPI _wcsicoll(const wchar_t *str1, const wchar_t *str2);
void WINAPI _fpreset();
HANDLE WINAPI OpenProcess(DWORD dwDesiredAccess, BOOL bInheritHandle, DWORD dwProcessId);
BOOL WINAPI CloseHandle(HANDLE hObject);
DWORD WINAPI GetModuleFileNameExA(HANDLE hProcess, HMODULE hModule, LPSTR lpFilename, DWORD nSize);
DWORD WINAPI GetModuleFileNameExW(HANDLE hProcess, HMODULE hModule, LPWSTR lpFilename, DWORD nSize);
__int64 WINAPI _filelengthi64(int fd);
int WINAPI _filelength(int fd);

#ifdef __clang__
WCHAR WINAPI *_tcsdup(const WCHAR *wstr);
#endif

#ifdef UNICODE
#define GetModuleFileNameEx  GetModuleFileNameExW
#else
#define GetModuleFileNameEx  GetModuleFileNameExA
#endif // !UNICODE
HRESULT WINAPI HRESULT_FROM_WIN32(ULONG x);
HRESULT WINAPI SetErrorInfo(DWORD  dwReserved, IErrorInfo  *perrinfo);
HRESULT WINAPI GetErrorInfo(DWORD  dwReserved, IErrorInfo  **pperrinfo);
#ifdef UNICODE
#define _tmakepath _wmakepath
#else
#define _tmakepath _makepath
#endif

void WINAPI _wmakepath(wchar_t *path, const wchar_t *drive, const wchar_t *dir, 
                const wchar_t *fname, const wchar_t *ext);
#ifdef UNICODE
#define _tsplitpath _wsplitpath
#else
#define _tsplitpath _splitpath
#endif

void WINAPI _wsplitpath(const wchar_t *path, wchar_t *drive, wchar_t *dir,
                 wchar_t *fname, wchar_t *ext);

#ifdef UNICODE
#define _tfullpath _wfullpath
#else
#define _tfullpath _fullpath
#endif

wchar_t WINAPI *_wfullpath(wchar_t *absPath, const wchar_t *relPath, 
                    size_t maxLength);
#define _tcsftime wcsftime
#ifdef LINUX_CLANG
size_t WINAPI wcsftime(wchar_t *strDest, size_t maxsize, const wchar_t *format, const struct tm *timeptr) throw();
#else
size_t WINAPI wcsftime(wchar_t *strDest, size_t maxsize, const wchar_t *format, const struct tm *timeptr);
#endif
HANDLE WINAPI FindFirstFile(LPCTSTR lpFileName, LPWIN32_FIND_DATA lpFindFileData);
BOOL WINAPI FindNextFile(HANDLE hFindFile, LPWIN32_FIND_DATA lpFindFileData);
BOOL WINAPI FindClose(HANDLE hFindFile);
HRESULT WINAPI CoGetClassObject(REFCLSID rclsid, DWORD dwClsContext, COSERVERINFO *pServerInfo, REFIID riid, LPVOID *ppv);
HRESULT WINAPI CoCreateInstance(REFCLSID rclsid, LPUNKNOWN pUnkOuter, DWORD dwClsContext, REFIID riid, LPVOID *ppv);
int WINAPI LoadStringW(HINSTANCE hInstance, UINT uID, LPWSTR lpBuffer, int cchBufferMax);
#ifdef UNICODE
#define LoadString  LoadStringW
#else
#define LoadString  LoadStringA
#endif // !UNICODE
HANDLE WINAPI LocalFree(HANDLE hMem);
const WINAPI wchar_t* _wcsinc(const wchar_t *current);
#define _tcsinc _wcsinc
int WINAPI _vstprintf(wchar_t *buffer, size_t maxLen, const wchar_t *lpszFormat, 
               va_list argptr);
DWORD WINAPI FormatMessage(DWORD dwFlags, LPCVOID lpSource, DWORD dwMessageId,
                    DWORD dwLanguageId, LPTSTR lpBuffer, DWORD nSize,
                    va_list *Arguments);
HRESULT WINAPI ProgIDFromCLSID(REFCLSID clsid, LPOLESTR *lplpszProgID);
HRESULT WINAPI CreateErrorInfo(ICreateErrorInfo** pperrinfo); 
#define CALLBACK 
typedef BOOL (CALLBACK* LOCALE_ENUMPROCW)(LPWSTR);
#define LOCALE_ENUMPROC LOCALE_ENUMPROCW
BOOL WINAPI EnumSystemLocales(LOCALE_ENUMPROC lpLocaleEnumProc, DWORD dwFlags);
LPWSTR WINAPI GetCommandLineW(void);
LPWSTR WINAPI *CommandLineToArgvW(LPCWSTR lpCmdLine, int *pNumArgs);
wchar_t WINAPI *_wcsupr( wchar_t *string );
LPTSTR WINAPI PathCombine(LPTSTR lpszDest, LPCTSTR lpszDir, LPCTSTR lpszFile);
LANGID WINAPI GetUserDefaultUILanguage(void);
LANGID WINAPI SetThreadUILanguage(LANGID LangId);
LANGID WINAPI GetUserDefaultLangID(void);
BOOL WINAPI SetThreadLocale(LCID Locale);
DWORD WINAPI GetLongPathName(LPCTSTR lpszShortPath, LPTSTR lpszLongPath, DWORD cchBuffer);
int WINAPI wcsnicmp(const wchar_t *string1, const wchar_t *string2, size_t count);
BOOL WINAPI PathRenameExtension(LPTSTR pszPath, LPCTSTR pszExt);
BOOL WINAPI PathIsDirectoryW(const wchar_t* pszPath);
BOOL WINAPI WinHelpW(HWND hWndMain, LPCTSTR lpszHelp, UINT uCommand, ULONG_PTR dwData);
#define HtmlHelp  HtmlHelpW
HWND WINAPI HtmlHelpW(HWND hwndCaller, LPCWSTR pszFile, UINT uCommand, DWORD_PTR dwData);
int WINAPI _waccess(const wchar_t *path, int mode);
char WINAPI *_getcwd(char *buffer, int maxlen);
wchar_t WINAPI *_wgetcwd(wchar_t *buffer, int maxlen);

// Note that the following functions can't be implemented safely with
// portability in mind (aka __asm). If you can get along fine without locking, 
// map these to the 'Dummy' versions implemented above. You can also declare
// the longs that you want to protect as type atomicLong, which provide 
// their own locking. The reason the following aren't available is that
// we'd have to lock the entire system to truly protect the passed in value
// and that is rather heavy-handed.
/*
long InterlockedIncrement(LONG& val);
long InterlockedDecrement(LONG& val);
*/

/*
 * Unicode UTF-8 helper conversion routines for NULL-terminated strings
 */
// The 'n' argument is target buffer size. Pass -1 to scan the entire source
int EXPORT str_utf8_to_uni (wchar_t *target, const char *source, int n);
int EXPORT str_uni_to_utf8 (char *target, const wchar_t *source, int n);
// The len and bytes functions do not process the null terminator, like strlen
int EXPORT str_utf8_len(const char *str);
int EXPORT str_uni_bytes(const wchar_t *str);

/*
 * Unicode UTF-8 helper conversion routines for non NULL-terminated strings
 * or partial scans/extractions
 */
// The 'n' argument is target buffer size. Pass -1 to scan the entire source
int EXPORT str_utf8_to_uni (wchar_t *target, const char *source, int n, int scan);
int EXPORT str_uni_to_utf8 (char *target, const wchar_t *source, int n, int scan);
int EXPORT str_utf8_len(const char *str, int scan);
int EXPORT str_uni_bytes(const wchar_t *str, int scan);

extern "C" const IID GUID_NULL;
extern "C" const IID IID_IStream;
extern "C" const IID IID_ISequentialStream;
extern "C" const IID IID_IUnknown;

#endif // FileGDBUnix_h
