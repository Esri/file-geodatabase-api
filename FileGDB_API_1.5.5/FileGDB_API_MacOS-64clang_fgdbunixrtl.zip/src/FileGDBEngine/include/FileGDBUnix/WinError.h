/*
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#ifndef WinError_h
#define WinError_h

#ifndef UNIX_FILEGDB_API
#error This file must only be included on Unix builds
#endif

// Access is denied.
#define ERROR_ACCESS_DENIED              5

// The system cannot find the file specified.
#define ERROR_FILE_NOT_FOUND             2

// The process cannot access the file because it is being used by another process.
#define ERROR_SHARING_VIOLATION          32

// The directory or file cannot be created.
#define ERROR_CANNOT_MAKE                82

// The handle is invalid.
#define ERROR_INVALID_HANDLE             6

// The wait operation timed out.
#define WAIT_TIMEOUT                     258

// Already Exists.
#define ERROR_ALREADY_EXISTS			       183

// General access denied error.
#define E_ACCESSDENIED                   _HRESULT_TYPEDEF_(0x80070005L)

// Invalid pointer error.
#define STG_E_INVALIDPOINTER             _HRESULT_TYPEDEF_(0x80030009L)

// ClassFactory cannot supply requested class.
#define CLASS_E_CLASSNOTAVAILABLE        _HRESULT_TYPEDEF_(0x80040111L)

#define RPC_S_OK                          ERROR_SUCCESS

// From MinGW
#define ERROR_SUCCESS                    0
#define ERROR_PATH_NOT_FOUND             3
#define ERROR_SEEK                       25
#define ERROR_HANDLE_DISK_FULL           39
#define ERROR_FILE_EXISTS                80

#define FACILITY_ITF 4
#define SEVERITY_SUCCESS    0
#define SEVERITY_ERROR      1

#ifndef _LP64
#define MAKE_HRESULT(sev,fac,code) \
    ((HRESULT) (((unsigned long)(sev)<<31) | ((unsigned long)(fac)<<16) | ((unsigned long)(code))) )
#else
#define MAKE_HRESULT(sev,fac,code) \
    ((HRESULT) (((unsigned int)(sev)<<31) | ((unsigned int)(fac)<<16) | ((unsigned int)(code))) )
#endif

#endif
