/*
 * Copyright (C) 2012 ESRI
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#ifndef WinTypes_h
#define WinTypes_h

#ifndef UNIX_FILEGDB_API
#error This file must only be included on Unix builds
#endif

// Bring in Unix headers
#include <stdio.h>
#include <wchar.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/times.h>
#include <sys/time.h>
#include <time.h>
#include <dlfcn.h>
#include <strings.h>
#include <string.h>
#include <pthread.h>
#include <cstdarg>
#include <climits>
#include <cstdlib>
#include <cctype>
#include <locale.h>
#include <langinfo.h>
#ifndef __APPLE__
#include <link.h>
#endif
#include <map>
#include <string>
#include <iostream>
#include <algorithm>
#include <cmath>

// define windows types
#ifndef _LP64
typedef unsigned long  DWORD; 
typedef long           HRESULT;
#else
typedef unsigned int   DWORD; 
typedef int            HRESULT;
#endif
typedef unsigned short WORD;
typedef unsigned char  BYTE;
typedef wchar_t        OLECHAR, *LPOLESTR;

#ifdef _LP64
#define __int64 long
typedef __int64 INT_PTR, *PINT_PTR;
typedef unsigned __int64 UINT_PTR, *PUINT_PTR;
typedef __int64 LONG_PTR, *PLONG_PTR;
typedef unsigned __int64 ULONG_PTR, *PULONG_PTR;
#else
// For 32-bit Unix, Use the same ifdef used in stdint.h for int64
#if __WORDSIZE == 64
#define __int64 long int
#else
#define __int64 long long int
#endif

typedef int INT_PTR, *PINT_PTR;
typedef unsigned int UINT_PTR, *PUINT_PTR;
typedef long LONG_PTR, *PLONG_PTR;
typedef unsigned long ULONG_PTR, *PULONG_PTR;
#endif
#define _int64 __int64

typedef DWORD ULONG, LCID, PROPID, *LPDWORD;
typedef DWORD LCTYPE, HREFTYPE, RPC_STATUS;
typedef WORD VARTYPE, USHORT, LANGID;
typedef BYTE *PBYTE;
typedef void VOID, *PVOID, *HANDLE, *LPVOID, *HMODULE, *HINSTANCE;
typedef const void *LPCVOID;
typedef ULONG_PTR DWORD_PTR, *PDWORD_PTR;
typedef char CHAR;
typedef short SHORT, CSHORT, VARIANT_BOOL;
typedef float FLOAT;
typedef double DOUBLE, DATE;
typedef unsigned int UINT, UINT32, *PUINT32; 
typedef int INT, errno_t, INT32, *PINT32;
typedef int64_t LONGLONG, INT64, *PINT64, LONG64;
typedef u_int64_t ULONGLONG, ULONG64, DWORD64, UINT64, *PULONG64, *PDWORD64;
#ifdef _LP64
typedef int LONG, SCODE, DISPID, MEMBERID;
#else
typedef long LONG, SCODE, DISPID, MEMBERID;
#endif
typedef int BOOL, BOOLEAN;
typedef BOOL *LPBOOL;
typedef size_t SIZE_T;
typedef wchar_t WCHAR, _TCHAR;
typedef WCHAR TCHAR, *PTCHAR;
typedef OLECHAR *BSTR;
typedef const OLECHAR *LPCOLESTR;
typedef const char *LPCSTR, *PCSTR;
typedef CHAR *NPSTR, *LPSTR, *PSTR;
typedef const WCHAR *LPCWSTR, *PCWSTR;
typedef WCHAR *NWPSTR, *LPWSTR, *PWSTR;
typedef LPWSTR PTSTR, LPTSTR;
typedef LPCWSTR PCTSTR, LPCTSTR;
typedef unsigned char byte;

#endif
