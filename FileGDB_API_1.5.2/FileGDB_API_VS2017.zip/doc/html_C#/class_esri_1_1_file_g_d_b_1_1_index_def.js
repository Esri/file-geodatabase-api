var class_esri_1_1_file_g_d_b_1_1_index_def =
[
    [ "IndexDef", "class_esri_1_1_file_g_d_b_1_1_index_def.html#a77b61558c03757942486449ff97cdec9", null ],
    [ "IndexName", "class_esri_1_1_file_g_d_b_1_1_index_def.html#a679ed21b3abce8c7d06f42ad98279698", null ],
    [ "FieldName", "class_esri_1_1_file_g_d_b_1_1_index_def.html#ae44ee518614020f76c5a612d7d5478c8", null ],
    [ "IsUnique", "class_esri_1_1_file_g_d_b_1_1_index_def.html#aa4f9f5695c86b22284f3ab81301e94b0", null ]
];