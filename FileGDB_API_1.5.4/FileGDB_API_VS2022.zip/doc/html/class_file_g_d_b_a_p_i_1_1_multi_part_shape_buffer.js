var class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer =
[
    [ "GetExtent", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#a246ad2aeb723776bfadcabe111be3ef1", null ],
    [ "GetNumParts", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#af6a2f66b36e493d198f0a3064acfd5c9", null ],
    [ "GetNumPoints", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#abb84ca678b409e99929e3c939a87c168", null ],
    [ "GetParts", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#ad87fac2bc67b22ed3d4e96f98c766907", null ],
    [ "GetPoints", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#a2e4a849e8503756c2f9a305aab1a49be", null ],
    [ "GetZExtent", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#a18c1827dad53bdb2a13a28d54b231479", null ],
    [ "GetZs", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#a838d47d4b9b0b7ae67bebe62be0c73e4", null ],
    [ "GetMExtent", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#aa7e3f50328efb58dab95be0737eb6de0", null ],
    [ "GetMs", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#ade043a28f33f19abd0b5dec81ec9aca4", null ],
    [ "GetNumCurves", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#acb518e313d40dc579ad144e46732f40c", null ],
    [ "GetCurves", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#a37333c92efcb51868f2c6f4b0de728cc", null ],
    [ "GetIDs", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#ae99eaabf3fe2175b80e16856a98a8497", null ],
    [ "Setup", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#a0cd0c1d89796698ff94311ff961b3f3f", null ],
    [ "CalculateExtent", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#a05355e6c7cf192a9371a49332b57e366", null ],
    [ "PackCurves", "class_file_g_d_b_a_p_i_1_1_multi_part_shape_buffer.html#a54f141eaa060c88090211ee251ddff70", null ]
];