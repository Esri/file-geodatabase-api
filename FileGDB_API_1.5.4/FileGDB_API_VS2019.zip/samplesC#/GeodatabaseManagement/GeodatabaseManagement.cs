﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Esri.FileGDB;

namespace GeodatabaseManagement
{
    //
    // Sample: GeodatabaseManagement
    //
    // Demonstrates how to create a new geodatabase, open a geodatabase, and delete
    // a geodatabase.

/*
   Copyright © 2025 Esri

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

   A local copy of the license and additional notices are located with the
   source distribution at:

   http://github.com/Esri/file-geodatabase-api/FileGDB_API_1.5.4
*/

  class GeodatabaseManagement
  {
    static void Main(string[] args)
    {
      try
      {
        Geodatabase geodatabase = Geodatabase.Create("../GeodatabaseManagement/GdbManagement.gdb");
        Console.WriteLine("The geodatabase has been created.");

        geodatabase.Close();

        geodatabase = Geodatabase.Open("../GeodatabaseManagement/GdbManagement.gdb");
        Console.WriteLine("The geodatabase has been opened.");

        geodatabase.Close();

        Geodatabase.Delete("../GeodatabaseManagement/GdbManagement.gdb");
        Console.WriteLine("The geodatabase has been deleted.");

      }
      catch (FileGDBException ex)
      {
        Console.WriteLine("{0} - {1}", ex.Message, ex.ErrorCode);
      }
      catch (Exception ex)
      {
        Console.WriteLine("General exception.  " + ex.Message);
      }
    }
  }
}
