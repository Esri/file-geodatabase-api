var class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer =
[
    [ "GetExtent", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#ae706b52ea20ef07b8adc0ccf44bd2a4a", null ],
    [ "GetNumParts", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#af7a0c5f8f2ad508db8f3cebae9e5c345", null ],
    [ "GetNumPoints", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#a2c34395ed53e87bf74542f2742d75b5e", null ],
    [ "GetParts", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#a0659bd90ba0c7d5847314dcb808a4d9c", null ],
    [ "GetPartDescriptors", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#a3bf8fa94b08d87d7371fdc1d2bee7fb6", null ],
    [ "GetPoints", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#acd0d94fe8048933119457d5def60eb08", null ],
    [ "GetZExtent", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#a52d300867a08cfaed6bf5b4e33428a59", null ],
    [ "GetZs", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#adea0bcecbe26d2359c8a2db1d58dbf98", null ],
    [ "GetMExtent", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#a0b77e6b0907da5bd4f630b8c837f8fc0", null ],
    [ "GetMs", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#aac85111ae96b6c2d1192af33374057fa", null ],
    [ "GetIDs", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#a2a4ba0ca2e6b62c7aef753a2db68ce47", null ],
    [ "GetNormals", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#aa95a86c3ec95244601e7530250b8ecac", null ],
    [ "GetTextures", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#ae94ccd50a2124871e713dd67b1a49cf6", null ],
    [ "GetMaterials", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#a54f89907671c69bac7b673c2cac634f6", null ],
    [ "Setup", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#affe73a2314aebac992fc3c2aef78c9ff", null ],
    [ "CalculateExtent", "class_file_g_d_b_a_p_i_1_1_multi_patch_shape_buffer.html#a6ea1dbd2047fca9517c324460b00ee9f", null ]
];