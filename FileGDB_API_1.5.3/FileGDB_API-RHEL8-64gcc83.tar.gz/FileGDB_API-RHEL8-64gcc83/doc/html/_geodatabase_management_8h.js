var _geodatabase_management_8h =
[
    [ "CreateGeodatabase", "_geodatabase_management_8h.html#a84b317d0d0587ce0ea9e5815bbc95f24", null ],
    [ "OpenGeodatabase", "_geodatabase_management_8h.html#a156d31213d4d7123f1f11d8813e8eb61", null ],
    [ "CloseGeodatabase", "_geodatabase_management_8h.html#afa19a7e7854dde8fbc6de33e2df2a24f", null ],
    [ "DeleteGeodatabase", "_geodatabase_management_8h.html#a028cdf0d0b1f190a31a849b052658469", null ]
];